using NwadHealth.Besthealthorg.IdentityFunction;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var tablesForCleanup = Environment.GetEnvironmentVariable("TablesForCleanup") ??
                       throw new ArgumentNullException("TablesForCleanup", "Tables for cleanup are missing");

var sqlConnectionString = Environment.GetEnvironmentVariable("SqlDbConnectionString")
                          ?? throw new ArgumentNullException("SqlDbConnectionString", "Connection string is missing");

const string keySqlConnectionString = "sql-connection-string";
const string keyTablesForCleanup = "tables-for-cleanup";

new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices(serviceCollection =>
    {
        var tables = tablesForCleanup
            .Split(",")
            .Select(s => s.Trim())
            .ToList();

        serviceCollection.AddKeyedSingleton(keySqlConnectionString, sqlConnectionString);
        serviceCollection.AddKeyedSingleton(keyTablesForCleanup, tables);
        serviceCollection.AddSingleton<SqlScriptExecutor>();
        serviceCollection.AddSingleton<IDataRetentionCleanup, DataRetentionCleanup>();
    })
    .Build()
    .Run();
