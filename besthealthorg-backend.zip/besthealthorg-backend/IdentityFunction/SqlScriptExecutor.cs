using Microsoft.Data.SqlClient;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityFunction;

/// <summary>
/// Executes SQL scripts with optional placeholder replacements.
/// </summary>
/// <param name="sqlConnectionString">The connection string to the SQL database.</param>
/// <param name="logger">The logger instance.</param>
public class SqlScriptExecutor(
    [FromKeyedServices("sql-connection-string")] string sqlConnectionString,
    ILogger<SqlScriptExecutor> logger
)
{
    /// <summary>
    /// Loads the SQL template from the specified file path.
    /// </summary>
    /// <param name="templatePath">The path to the SQL template file.</param>
    /// <returns>The content of the SQL template file.</returns>
    /// <exception cref="FileNotFoundException">Thrown when the SQL script file is not found.</exception>
    private async Task<string> LoadSqlTemplate(string templatePath)
    {
        var sqlFilePath = Path.Combine(AppContext.BaseDirectory, templatePath);

        if (File.Exists(sqlFilePath))
        {
            return await File.ReadAllTextAsync(sqlFilePath);
        }

        logger.LogError("SQL script file not found at path: {SqlFilePath}", sqlFilePath);
        throw new FileNotFoundException($"SQL script file not found: {sqlFilePath}");
    }

    /// <summary>
    /// Replaces placeholders in the SQL script content with the specified replacements.
    /// </summary>
    /// <param name="scriptContent">The content of the SQL script.</param>
    /// <param name="replacements">A dictionary of placeholders and their replacements.</param>
    /// <returns>The SQL script content with placeholders replaced.</returns>
    private static string ReplacePlaceholders(
        string scriptContent,
        IDictionary<string, string> replacements
    )
    {
        foreach (var (key, value) in replacements)
        {
            scriptContent = scriptContent.Replace(key, value);
        }

        return scriptContent;
    }

    /// <summary>
    /// Executes the SQL script with optional placeholder replacements.
    /// </summary>
    /// <param name="templatePath">The path to the SQL template file.</param>
    /// <param name="replacements">A dictionary of placeholders and their replacements.</param>
    /// <returns>The number of rows affected by the SQL script execution.</returns>
    /// <exception cref="SqlException">Thrown when a SQL error occurs during script execution.</exception>
    /// <exception cref="Exception">Thrown when an unexpected error occurs during script execution.</exception>
    public async Task<int> ExecuteScript(
        string templatePath,
        IDictionary<string, string>? replacements = null
    )
    {
        try
        {
            // Read the SQL template from the file
            var sqlTemplate = await LoadSqlTemplate(templatePath);

            // Replace placeholders
            sqlTemplate = ReplacePlaceholders(sqlTemplate, replacements ?? new Dictionary<string, string>());

            // Execute the SQL
            await using var connection = new SqlConnection(sqlConnectionString);
            await connection.OpenAsync();

            var command = connection.CreateCommand();
            command.CommandText = sqlTemplate;

            var rowsAffected = await command.ExecuteNonQueryAsync();

            logger.LogInformation("Executed script {TemplatePath}. Rows affected: {RowsAffected}", templatePath, rowsAffected);

            return rowsAffected;
        }
        catch (SqlException sqlEx)
        {
            logger.LogError(sqlEx, "SQL error occurred during script execution");
            throw;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unexpected error occurred during script execution");
            throw;
        }
    }
}
