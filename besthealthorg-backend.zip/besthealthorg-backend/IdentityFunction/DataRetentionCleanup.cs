using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityFunction;

/// <inheritdoc cref="NwadHealth.Besthealthorg.IdentityFunction.IDataRetentionCleanup" />
public class DataRetentionCleanup(
    [FromKeyedServices("tables-for-cleanup")] List<string> tableNamesForCleanup,
    SqlScriptExecutor sqlScriptExecutor,
    ILogger<DataRetentionCleanup> logger
) : IDataRetentionCleanup
{
    private const string DeletionScriptName = "Sql/DeleteExpiredRows.sql";

    /// <summary>
    /// Deletes expired data from all tables specified in the injected list.
    /// </summary>
    /// <returns>The total number of rows deleted across all tables.</returns>
    public async Task<int> DeleteExpiredData()
    {
        logger.LogInformation(
            "Deleting expired data from tables: {TableNames}",
            string.Join(", ", tableNamesForCleanup)
        );
        var rowsAffected = 0;

        // Iterate over each table and execute SQL cleanup
        foreach (var tableName in tableNamesForCleanup)
        {
            try
            {
                var replacements = new Dictionary<string, string>
                {
                    ["{TableName}"] = tableName,
                };

                rowsAffected += await sqlScriptExecutor.ExecuteScript(
                    DeletionScriptName,
                    replacements
                );
            }
            catch (Exception e)
            {
                logger.LogError(e, "Error deleting expired rows from table {TableName}", tableName);
            }

            logger.LogInformation(
                "Deleted expired rows. Affected {RowsAffected} rows in table {TableName}",
                rowsAffected,
                tableName
            );
        }

        return rowsAffected;
    }
}
