BEGIN TRANSACTION [TR1]

BEGIN TRY
    -- Declare variables
    DECLARE @CurrentUtcTime datetime2(7) = GETUTCDATE();
    DECLARE @TableName nvarchar(128) = N'{TableName}';
    DECLARE @Sql nvarchar(max);

    -- Build dynamic SQL query
    SET @Sql = '
        DELETE FROM ' + QUOTENAME(@TableName) + '
        WHERE RetainUntil < @CurrentUtcTime;
        SELECT @@ROWCOUNT AS RowsDeleted;
            ';
            PRINT 'Executing SQL query: ' + @Sql;

    -- Execute dynamic SQL
    EXEC sp_executesql @Sql,    N'@CurrentUtcTime datetime2(7)', @CurrentUtcTime;

    -- Commit the transaction
    COMMIT TRANSACTION [TR1];
    PRINT CONCAT('Rows deleted: ', @@ROWCOUNT);
END TRY

BEGIN CATCH
    -- Rollback the transaction in case of an error
    ROLLBACK TRANSACTION [TR1];

    -- Raise the error
    THROW;
END CATCH
