namespace NwadHealth.Besthealthorg.IdentityFunction;

/// <summary>
/// Responsible for cleaning up expired data from specified tables in the database.
/// Executes SQL scripts dynamically, replacing table placeholders with actual table names.
/// </summary>
public interface IDataRetentionCleanup
{
    /// <summary>
    /// Deletes expired data.
    /// </summary>
    /// <returns>The number of affected rows</returns>
    Task<int> DeleteExpiredData();
}
