using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Logging;
// ReSharper disable ClassNeverInstantiated.Global

namespace NwadHealth.Besthealthorg.IdentityFunction;

using Microsoft.Azure.Functions.Worker;

/// <summary>
/// Azure Function to handle data retention cleanup.
/// </summary>
/// <param name="logger">Logger instance for logging information.</param>
/// <param name="dataRetentionCleanup">Service to handle data deletion.</param>
[SuppressMessage("Roslynator", "RCS1163:Unused parameter")]
public class RetainUntilCleanupFunction(ILogger<RetainUntilCleanupFunction> logger, IDataRetentionCleanup dataRetentionCleanup)
{
    [Function("RetainUntilCleanupFunction")]
    public async Task Run([TimerTrigger("0 0 1 * * *")] TimerInfo timer)
    {
        logger.LogInformation("RetainUntilCleanupFunction started at: {Time}", DateTime.UtcNow);

        await dataRetentionCleanup.DeleteExpiredData();
    }
}
