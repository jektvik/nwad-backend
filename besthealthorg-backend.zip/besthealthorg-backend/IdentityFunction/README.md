# Data Retention Cleanup Function

An Azure Function app designed to cleanup expired data across the provided database tables. This function runs on a daily schedule and removes records that have exceeded their retention period.

## Features

- Automated daily cleanup at 01:00 AM UTC
- Configurable table list for cleanup operations
- Transactional deletion to ensure data consistency
- Comprehensive error handling and logging
- Retention-based deletion using `RetainUntil` column

## Configuration

### Environment Variables

Required environment variables in `local.settings.json`:

```json
{
    "IsEncrypted": false,
    "Values": {
        "AzureWebJobsStorage": "UseDevelopmentStorage=true",
        "FUNCTIONS_WORKER_RUNTIME": "dotnet-isolated",
        "TablesForCleanup": "Table1,Table2,Table3",
        "SqlDbConnectionString": "Server=your-server;Database=your-db;User Id=your-user;Password=your-password;..."
    }
}
```

- `TablesForCleanup`: Comma-separated list of database tables to clean up
- `SqlDbConnectionString`: SQL Server connection string

For convenience, you can use the `local.settings.example.json` file as a template.

### Database Requirements

Each table specified in `TablesForCleanup` must have a `RetainUntil` column of type `datetime2`. Records are deleted when their `RetainUntil` date is earlier than the current UTC time.

## Local Development

1. Copy `local.settings.example.json` to `local.settings.json`
1. Update the configuration values in `local.settings.json`
1.Run the function locally:

```bash
func start
```

## Deployment

Make sure to configure the application settings in Azure to match your `local.settings.json` values.

## Error Handling

The function implements comprehensive error handling:

- Transaction-based deletions with automatic rollback on failure
- Detailed error logging for each table operation
- Continuation of cleanup process even if one table fails
- SQL error capturing and logging
