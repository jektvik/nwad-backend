using NwadHealth.Besthealthorg.ConsultationModule.Infrastructure.Models;
using NwadHealth.Besthealthorg.NoteModule.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace NwadHealth.Besthealthorg.ConsultationModule.Infrastructure;

/// <summary>
/// Represents required actions of a provided database context
/// </summary>
public interface IConsultationDbContext : INoteDbContext
{
    /// <summary>
    /// The collection of stored Appointments
    /// </summary>
    DbSet<AppointmentDbModel> Appointments { get; }

    /// <summary>
    /// The collection of stored Appointment types
    /// </summary>
    DbSet<AppointmentTypeDbModel> AppointmentTypes { get; }

    /// <summary>
    /// Executes queued add/update tasks
    /// </summary>
    /// <param name="cancellationToken">Used for notifying whether the action should be cancelled</param>
    /// <returns>The number of affected items</returns>
    new Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);

    /// <inheritdoc />
    new EntityEntry<TEntity> Entry<TEntity>(TEntity entity) where TEntity : class;

    /// <summary>
    /// Configures DbSets as required by the consultation module
    /// </summary>
    /// <param name="modelBuilder">The model builder to use for configuring</param>
    new void ConfigureDbSets(ModelBuilder modelBuilder)
    {
        (this as INoteDbContext).ConfigureDbSets(modelBuilder);

        var appointmentTypes = modelBuilder.Entity<AppointmentTypeDbModel>();
        appointmentTypes.HasKey(at => at.Id);

        var appointments = modelBuilder.Entity<AppointmentDbModel>();
        appointments.HasKey(a => a.Id);

        appointments
            .HasMany(a => a.Types)
            .WithMany();

        appointments.HasPaceNotes();
    }
}
