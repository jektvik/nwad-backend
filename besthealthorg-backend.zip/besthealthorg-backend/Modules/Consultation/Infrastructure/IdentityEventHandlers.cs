using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Events;
using Microsoft.Extensions.DependencyInjection;

namespace NwadHealth.Besthealthorg.ConsultationModule.Infrastructure;

internal static class IdentityEventHandlers
{
    internal static async Task OnIdentityDeleted(IServiceProvider serviceProvider, IdentityDeletedEvent identityDeletedEvent)
    {
        using var scope = serviceProvider.CreateScope();

        var appointmentRepository = scope.ServiceProvider.GetRequiredService<IAppointmentRepository>();
        await appointmentRepository.AnonymizePersonalData(identityDeletedEvent.Identity.Id, identityDeletedEvent.AnonymizationId);
    }
}
