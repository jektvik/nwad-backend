using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsultationModule.Infrastructure.Repositories;
using NwadHealth.Besthealthorg.Foundation.Extensions.ServiceCollection;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.NoteModule.Domain.Entities;
using NwadHealth.Besthealthorg.NoteModule.Infrastructure;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace NwadHealth.Besthealthorg.ConsultationModule.Infrastructure;

/// <summary>
/// Provides extension methods for configuring the dependency injection of the ConsultationModule
/// </summary>
public static class ConsultationExtensions
{
    /// <summary>
    /// Configures dependency injection to use the provided configuration
    /// </summary>
    /// <typeparam name="TDbContext">The type of the database context</typeparam>
    /// <param name="services">The IServiceCollection to be configured</param>
    /// <returns>The same IServiceCollection the method was called on, with configuration set</returns>
    public static IServiceCollection AddPaceConsultation<TDbContext>(
        this IServiceCollection services)
    where TDbContext : DbContext, IConsultationDbContext
    {
        services.AddScoped<IAppointmentTypeRepository, AppointmentTypeRepository>();
        services.AddScoped<IAppointmentRepository, AppointmentRepository>();

        services.AddScoped<IConsultationDbContext>(provider => provider.GetRequiredService<TDbContext>());

        services.AddPaceNote<TDbContext>();

        // Interactors
        services.AddScoped<ICreateAppointmentInteractor, CreateAppointmentInteractor>();
        services.AddScoped<IGetAppointmentInteractor, GetAppointmentInteractor>();
        services.AddScoped<IGetAppointmentsInteractor, GetAppointmentsInteractor>();
        services.AddScoped<IGetAppointmentTypesInteractor, GetAppointmentTypesInteractor>();
        services.AddScoped<IReplaceAppointmentInteractor, ReplaceAppointmentInteractor>();
        services.AddScoped<IDeleteAppointmentInteractor, DeleteAppointmentInteractor>();

        return services;
    }

    /// <summary>
    /// Prepares the application to use the Consultation Module
    /// </summary>
    /// <param name="app">The IApplicationBuilder to be prepared</param>
    /// <returns>The same IApplicationBuilder the method was called on, prepared for the Consultation Module</returns>
    public static void UsePaceConsultation(this IApplicationBuilder app)
    {
        var subscriber = app.ApplicationServices.GetRequiredService<IIdentityEventSubscriber>();

        subscriber.IdentityDeleted += async (_, @event) => await IdentityEventHandlers.OnIdentityDeleted(app.ApplicationServices, @event);
    }
}
