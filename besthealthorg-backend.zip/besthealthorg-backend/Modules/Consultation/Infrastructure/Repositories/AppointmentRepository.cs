using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsultationModule.Infrastructure.Models;
using NwadHealth.Besthealthorg.Foundation.Extensions.Queryable;
using NwadHealth.Besthealthorg.NoteModule.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ConsultationModule.Infrastructure.Repositories;

/// <summary>
/// Represents operations available for storage/retrieval of appointments
/// </summary>
public class AppointmentRepository : IAppointmentRepository
{
    private readonly IConsultationDbContext _context;

    /// <summary>
    /// Initializes the appointment repository
    /// </summary>
    /// <param name="context">The database context the repo should use for data access</param>
    public AppointmentRepository(IConsultationDbContext context)
    {
        _context = context;
    }

    /// <summary>
    /// Adds an appointment to the data store
    /// </summary>
    /// <param name="appointment">The appointment to add</param>
    /// <returns>The newly added appointment</returns>
    public async Task<Appointment> Create(Appointment appointment)
    {
        var dbModel = AppointmentDbModel.FromDomain(appointment);

        dbModel.CreatedAt = DateTimeOffset.UtcNow;
        dbModel.UpdatedAt = dbModel.CreatedAt;

        if (appointment.Types.Any())
        {
            var typeIds = appointment.Types.Select(at => at.Id);
            dbModel.Types = await _context.AppointmentTypes.Where(at => typeIds.Contains(at.Id)).ToListAsync();
        }

        dbModel.Notes = await dbModel.BuildNoteCollection(_context);

        var result = _context.Appointments.Add(dbModel);
        await _context.SaveChangesAsync();

        return result.Entity.ToDomain();
    }

    /// <summary>
    /// Fetches an appointment by id
    /// </summary>
    /// <param name="id">The id of the appointment to fetch</param>
    /// <returns>The appointment if found, otherwise null</returns>
    public async Task<Appointment?> Get(Guid id)
    {
        var appointmentDbModel = await _context.Appointments
            .Where(a => a.Id == id && a.DeletedAt == null)
            .Include(a => a.Types)
            .Include(a => a.Notes)
            .ThenInclude(n => n.Types)
            .Include(a => a.Notes)
            .ThenInclude(n => n.Topics)
            .AsNoTracking()
            .FirstOrDefaultAsync();

        return appointmentDbModel?.ToDomain();
    }

    /// <summary>
    /// Gets all appointments from the data store filtered by identity id,
    /// optionally filtered by start date, end date and type
    /// </summary>
    /// <param name="identityId">The identity id for which to fetch appointments</param>
    /// <param name="startDate">Optional date filter, to only include appointments ending after this date</param>
    /// <param name="endDate">Optional date filter, to only include appointments starting before this date</param>
    /// <param name="typeIds">Optional type filter, to only include appointments which has at least one of the types assigned</param>
    /// <returns>An enumerable of all appointments for the identity id and optional filters</returns>
    public async Task<IEnumerable<Appointment>> GetByIdentityId(
        string identityId,
        DateTimeOffset? startDate,
        DateTimeOffset? endDate,
        IEnumerable<int>? typeIds)
    {
        var dbModels = await _context.Appointments
            .Where(a => a.IdentityId == identityId && a.DeletedAt == null)
            .MaybeWhere(a => a.TimeEnd >= startDate, startDate is not null)
            .MaybeWhere(a => a.TimeStart <= endDate, endDate is not null)
            .Include(a => a.Types)
            .MaybeWhere(a => a.Types.Any(type => typeIds!.Contains(type.Id)), typeIds is not null)
            .Include(a => a.Notes)
            .ThenInclude(n => n.Types)
            .Include(a => a.Notes)
            .ThenInclude(n => n.Topics)
            .ToListAsync();

        return dbModels.Select(a => a.ToDomain());
    }

    /// <summary>
    /// Replaces an appointment
    /// </summary>
    /// <param name="appointment">The appointment to replace</param>
    /// <returns>The new appointment</returns>
    public async Task<Appointment> Replace(Appointment appointment)
    {
        var newNoteIds = appointment.Notes.Select(n => n.Id);

        var existingDbModel = await _context.Appointments
            .Where(a => a.Id == appointment.Id && a.DeletedAt == null)
            .Include(a => a.Types)
            .Include(a => a.Notes)
            .FirstAsync();

        var notesToDelete = existingDbModel.Notes.Where(n => !newNoteIds.Contains(n.Id));

        _context.Notes.RemoveRange(notesToDelete);

        existingDbModel.UpdatedAt = DateTimeOffset.UtcNow;
        existingDbModel.TimeStart = appointment.TimeStart;
        existingDbModel.TimeEnd = appointment.TimeEnd;
        existingDbModel.Title = appointment.Title;

        existingDbModel.Types.Clear();

        var typeIds = appointment.Types.Select(at => at.Id);
        existingDbModel.Types = await _context.AppointmentTypes.Where(at => typeIds.Contains(at.Id)).ToListAsync();

        existingDbModel.Notes = await AppointmentDbModel.FromDomain(appointment).BuildNoteCollection(_context);

        var result = _context.Appointments.Update(existingDbModel);

        await _context.SaveChangesAsync();

        return result.Entity.ToDomain();
    }

    /// <summary>
    /// Deletes an appointment by id
    /// </summary>
    /// <param name="id">The id of the appointment to delete</param>
    public async Task Delete(Guid id)
    {
        await _context.Appointments
            .Where(a => a.Id == id && a.DeletedAt == null)
            .ExecuteUpdateAsync(setter => setter.SetProperty(a => a.DeletedAt, DateTimeOffset.UtcNow));
    }

    /// <summary>
    /// Overwrites the identityId for all the identity appointments, with the supplied anonymizationId
    /// </summary>
    /// <param name="identityId">The ID of the identity for which to anonymize the appointments</param>
    /// <param name="anonymizationId">The value to use for overwriting the identityId</param>
    public async Task AnonymizePersonalData(string identityId, string anonymizationId)
    {
        await _context.Appointments
            .Where(a => a.IdentityId == identityId)
            .ExecuteUpdateAsync(setters => setters.SetProperty(a => a.IdentityId, anonymizationId));
    }
}
