using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsultationModule.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ConsultationModule.Infrastructure.Repositories;

/// <summary>
/// Implementation of data store interaction for appointments
/// </summary>
public class AppointmentTypeRepository : IAppointmentTypeRepository
{
    private readonly IConsultationDbContext _context;

    /// <summary>
    /// Initializes the repository
    /// </summary>
    /// <param name="context">The database context to use</param>
    public AppointmentTypeRepository(IConsultationDbContext context)
    {
        _context = context;
    }

    /// <summary>
    /// Fetches all appointment types from the data store
    /// </summary>
    /// <returns>An enumerable of appointment types</returns>
    public async Task<IEnumerable<AppointmentType>> GetAll()
    {
        var dbModels = await _context.AppointmentTypes.ToListAsync();

        return dbModels.Select(at => at.ToDomain());
    }
}
