using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.Infrastructure.Models;

// not relevant for db models
#nullable disable warnings

/// <summary>
/// The Appointment type database model
/// </summary>
public class AppointmentTypeDbModel
{
    /// <summary>
    /// Unique identifier of the appointment type
    /// </summary>
    public int Id { get; init; }

    /// <summary>
    /// Name/translation key for the appointment type
    /// </summary>
    public required string Name { get; init; }

    /// <summary>
    /// Converts a AppointmentType domain model to a database model
    /// </summary>
    /// <param name="appointmentType">The domain model to convert</param>
    /// <returns>The database model</returns>
    public static AppointmentTypeDbModel FromDomain(AppointmentType appointmentType)
    {
        return new()
        {
            Id = appointmentType.Id,
            Name = appointmentType.Name,
        };
    }

    /// <summary>
    /// Converts a AppointmentType database model to a domain model
    /// </summary>
    /// <returns>The domain model</returns>
    public AppointmentType ToDomain()
    {
        return new()
        {
            Id = Id,
            Name = Name,
        };
    }
}
