using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.NoteModule.Infrastructure;
using NwadHealth.Besthealthorg.NoteModule.Infrastructure.Models;

namespace NwadHealth.Besthealthorg.ConsultationModule.Infrastructure.Models;

// not relevant for db models
#nullable disable warnings

/// <summary>
/// The Appointment database model
/// </summary>
public class AppointmentDbModel : IHasNotes
{
    /// <summary>
    /// Unique identifier of this appointment
    /// </summary>
    public required Guid Id { get; init; }

    /// <summary>
    /// The ID of the identity that owns this appointment
    /// </summary>
    public required string IdentityId { get; init; }

    /// <summary>
    /// The title of the appointment
    /// </summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>
    /// The types of the appointment
    /// </summary>
    public virtual ICollection<AppointmentTypeDbModel> Types { get; set; }

    /// <summary>
    /// The start date and time of the appointment
    /// </summary>
    public DateTimeOffset TimeStart { get; set; }

    /// <summary>
    /// The start date and time of the appointment
    /// </summary>
    public DateTimeOffset TimeEnd { get; set; }

    /// <summary>
    /// The creation time of the appointment
    /// </summary>
    public DateTimeOffset CreatedAt { get; set; }

    /// <summary>
    /// The time the appointment was last updated
    /// </summary>
    public DateTimeOffset UpdatedAt { get; set; }

    /// <summary>
    /// The time the appointment was deleted
    /// </summary>
    public DateTimeOffset? DeletedAt { get; set; }

    /// <inheritdoc />
    public virtual ICollection<NoteDbModel> Notes { get; set; }

    /// <summary>
    /// Converts an appointment domain model to database model
    /// </summary>
    /// <param name="appointment">The domain model to convert</param>
    /// <returns>The database model</returns>
    public static AppointmentDbModel FromDomain(Appointment appointment)
    {
        return new()
        {
            Id = appointment.Id,
            IdentityId = appointment.IdentityId,
            Title = appointment.Title,
            TimeStart = appointment.TimeStart,
            TimeEnd = appointment.TimeEnd,
            Types = appointment.Types.Select(AppointmentTypeDbModel.FromDomain).ToList(),
            Notes = appointment.Notes.Select(NoteDbModel.FromDomain).ToList(),
        };
    }

    /// <summary>
    /// Converts an appointment database model to domain model
    /// </summary>
    /// <returns>The domain model</returns>
    public Appointment ToDomain()
    {
        return new()
        {
            Id = Id,
            IdentityId = IdentityId,
            Title = Title,
            TimeStart = TimeStart,
            TimeEnd = TimeEnd,
            Types = Types.Select(type => type.ToDomain()).ToList(),
            Notes = Notes.Select(noteDbModel => noteDbModel.ToDomain()).ToList(),
        };
    }
}
