# Consultation Module

The PACE Consultation module is used for managing appointments for users

## Module setup

### General requirements

The Consultation module requires the application to have authorization enabled (ideally through the [Identity module](/Identity/README.md)).

### Required infrastructure

- SQL Server
  - SQL database

### Installation

Install the `NwadHealth.Pace.ConsultationModule` NuGet package by following the [instructions](/README.md#sdk-modules) in the main README.

### Application Configuration

To configure the Consultation module in your application, when registering services call the `AddPaceConsultation()` extension method on your service provider as well as `UsePaceConsultation()` on your web application instance.

#### Example

```CSharp
using NwadHealth.Pace.ConsultationModule.Infrastructure;

...// other setup

services.AddPaceConsultation<YourDbContext>();

...// other setup

var app = builder.Build();

...// other setup

app.UsePaceConsultation();

... // other setup

app.Run(); 
```

`AddPaceConsultation` method expects a type parameter that implements both `DbContext` and `IConsultationDbContext`

If your project already uses SQL database this class should already be present in your project and you should just extend it, otherwise you need to create a new one 

The example below illustrates how to implement the `IConsultationDbContext` 

```CSharp
using NwadHealth.Pace.ConsultationModule.Infrastructure;
using NwadHealth.Pace.ConsultationModule.Infrastructure.Models;
using NwadHealth.Pace.NoteModule.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace YourProjectNamespace;

public class YourDbContext : DbContext, IConsultationDbContext
{
    public YourDbContext(DbContextOptions<YourDbContext> options) : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        (this as IConsultationDbContext).ConfigureDbSets(modelBuilder);
    }

    public DbSet<AppointmentDbModel> Appointments { get; set; }

    public DbSet<AppointmentTypeDbModel> AppointmentTypes { get; set; }

    public DbSet<NoteDbModel> Notes { get; set; }

    public DbSet<NoteTypeDbModel> NoteTypes { get; set; }

    public DbSet<NoteTopicDbModel> NoteTopics { get; set; }
}

```

The consultation module internaly depends on Note module thats why you can see Note models being added 

## Events Published

This module does not publish any events

## Application Lifecycle 

When an identity is deleted the module will anonymize the appointments belonging to the deleted identity.
