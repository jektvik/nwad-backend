using NwadHealth.Besthealthorg.NoteModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

/// <summary>
/// The Appointment domain model
/// </summary>
public class Appointment
{
    /// <summary>
    /// Unique identifier of this appointment
    /// </summary>
    public Guid Id { get; set; }

    /// <summary>
    /// The ID of the identity that owns this appointment
    /// </summary>
    public string IdentityId { get; set; } = string.Empty;

    /// <summary>
    /// The title of the appointment
    /// </summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>
    /// The types of the appointment
    /// </summary>
    public IReadOnlyCollection<AppointmentType> Types { get; init; } = [];

    /// <summary>
    /// The start date and time of the appointment
    /// </summary>
    public DateTimeOffset TimeStart { get; set; }

    /// <summary>
    /// The start date and time of the appointment
    /// </summary>
    public DateTimeOffset TimeEnd { get; set; }

    /// <summary>
    /// The notes relating to the appointment
    /// </summary>
    public IReadOnlyCollection<Note> Notes { get; init; } = [];

    /// <summary>
    /// Whether the appointment time span is valid.
    /// </summary>
    /// <returns>False if the appointment ends before it starts, otherwise true</returns>
    public bool IsTimeSpanValid => TimeStart <= TimeEnd;
}
