namespace NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

/// <summary>
/// Domain model representing an appointment type
/// </summary>
public class AppointmentType
{
    /// <summary>
    /// Unique identifier of the appointment type
    /// </summary>
    public required int Id { get; init; }

    /// <summary>
    /// Name/translation key for the appointment type
    /// </summary>
    public string Name { get; init; } = string.Empty;
}
