using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsultationModule.Dtos.Response;
using NwadHealth.Besthealthorg.NoteModule.Domain.Entities;
using NwadHealth.Besthealthorg.NoteModule.Frameworks.Dtos.Response;

namespace NwadHealth.Besthealthorg.ConsultationModule.Frameworks.Dtos.Response;

/// <summary>
/// The data produced by the following endpoints:
/// <see cref="Controllers.AppointmentController.CreateAppointment"/>
/// <see cref="Controllers.AppointmentController.GetAppointment"/>
/// <see cref="Controllers.AppointmentController.GetAppointments"/>
/// <see cref="Controllers.AppointmentController.ReplaceAppointment"/>
/// </summary>
public record AppointmentResponseDto
{
    /// <summary>
    /// The Id of the appointment
    /// </summary>
    public Guid Id { get; set; }

    /// <summary>
    /// The title of the appointment
    /// </summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>
    /// The start time of the appointment
    /// </summary>
    public DateTimeOffset TimeStart { get; set; }

    /// <summary>
    /// The end time of the appointment
    /// </summary>
    public DateTimeOffset TimeEnd { get; set; }

    /// <summary>
    /// The types of the appointment
    /// </summary>
    public IEnumerable<AppointmentTypeResponseDto> Types { get; set; } = new List<AppointmentTypeResponseDto>();

    /// <summary>
    /// The notes attached to the appointment
    /// </summary>
    public IEnumerable<NoteResponseDto> Notes { get; set; } = new List<NoteResponseDto>();

    /// <summary>
    /// Converts an appointment domain model to response dto
    /// </summary>
    /// <param name="appointment">The domain model to convert</param>
    /// <returns>The response dto</returns>
    public static AppointmentResponseDto FromDomain(Appointment appointment)
    {
        return new()
        {
            Id = appointment.Id,
            Title = appointment.Title,
            TimeStart = appointment.TimeStart,
            TimeEnd = appointment.TimeEnd,
            Types = appointment.Types.Select(AppointmentTypeResponseDto.FromDomain),
            Notes = appointment.Notes.Select(NoteResponseDto.FromDomain),
        };
    }
}
