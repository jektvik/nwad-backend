using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.Dtos.Response;

/// <summary>
/// The data produced by the following endpoints:
/// <see cref="Controllers.AppointmentTypeController.GetTypes"/>
/// </summary>
public record AppointmentTypeResponseDto
{
    /// <summary>
    /// The Id of the appointment type
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// The name/translation key of the appointment type
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Converts an appointment type domain model to response dto
    /// </summary>
    /// <param name="type">The domain model to convert</param>
    /// <returns>The response dto</returns>
    public static AppointmentTypeResponseDto FromDomain(AppointmentType type)
    {
        return new()
        {
            Id = type.Id,
            Name = type.Name,
        };
    }
}
