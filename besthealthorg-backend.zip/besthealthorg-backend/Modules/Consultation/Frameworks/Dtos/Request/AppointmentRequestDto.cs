using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.NoteModule.Frameworks.Dtos.Request;

namespace NwadHealth.Besthealthorg.ConsultationModule.Frameworks.Dtos.Request;

/// <summary>
/// The data required by the following endpoints:
/// <see cref="Controllers.AppointmentController.CreateAppointment"/>
/// <see cref="Controllers.AppointmentController.ReplaceAppointment"/>
/// </summary>
public record AppointmentRequestDto
{
    /// <summary>
    /// The Id of the appointment
    /// </summary>
    public Guid Id { get; set; }

    /// <summary>
    /// The title of the appointment
    /// </summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>
    /// The start time of the appointment
    /// </summary>
    public DateTimeOffset TimeStart { get; set; }

    /// <summary>
    /// The end time of the appointment
    /// </summary>
    public DateTimeOffset TimeEnd { get; set; }

    /// <summary>
    /// The types of the appointment
    /// </summary>
    public IEnumerable<int> TypeIds { get; set; } = new List<int>();

    /// <summary>
    /// The notes relating to the appointment
    /// </summary>
    public IEnumerable<NoteRequestDto> Notes { get; set; } = new List<NoteRequestDto>();

    /// <summary>
    /// Converts an appointment request dto to domain model
    /// </summary>
    /// <param name="identityId">The unique identifier of the identity that owns the appointment</param>
    /// <returns>The domain model</returns>
    public Appointment ToDomain(string identityId)
    {
        return new()
        {
            Id = Id,
            IdentityId = identityId,
            Title = Title,
            TimeStart = TimeStart,
            TimeEnd = TimeEnd,
            Types = TypeIds.Select(typeId => new AppointmentType { Id = typeId }).ToList(),
            Notes = Notes.Select(n => n.ToDomain(identityId)).ToList(),
        };
    }
}
