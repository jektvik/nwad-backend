﻿using Microsoft.AspNetCore.Mvc;
using static NwadHealth.Besthealthorg.Foundation.Extensions.Controller.ErrorResponseExtensions;

namespace NwadHealth.Besthealthorg.ConsultationModule.Frameworks;

/// <summary>
/// ControllerBase extensions for creating error responses
/// </summary>
public static class ErrorResponseExtensions
{
    /// <summary>
    /// Creates an appointment not found result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>An appontment not found</returns>
    public static IActionResult AppointmentNotFoundError(this ControllerBase controller) =>
        controller.NotFound(CreateErrorResponseDto("appointment_not_found", "The appointment could not be found"));

    /// <summary>
    /// Creates an invalid appointment time span error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>An invalid appointment time span result</returns>
    public static IActionResult InvalidAppointmentTimeSpan(this ControllerBase controller) =>
        controller.BadRequest(CreateErrorResponseDto("invalid_appointment_time_span", "The appointment time span is invalid"));
}
