using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsultationModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.ConsultationModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.Foundation.Extensions.Controller;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.ConsultationModule.Frameworks.Controllers;

/// <summary>
/// Contains endpoints relating to the Appointment domain
/// </summary>
[ApiController]
[Route("Consultation/[controller]")]
public class AppointmentController : ControllerBase
{
    private readonly ILogger<AppointmentController> _logger;

    /// <summary>
    /// Initializes the AppointmentController
    /// </summary>
    /// <param name="logger">The logger to use</param>
    public AppointmentController(ILogger<AppointmentController> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Gets an appointment for the currently authorized identity by appointment id
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="id">The id of the appointment to get</param>
    /// <returns>An IActionResult representing the result of the endpoint call</returns>
    /// <response code="200">Appointment was successfully fetched</response>
    /// <response code="404">The appointment was not found or the user does not have access</response>
    [HttpGet("{id}", Name = "Get appointment")]
    [Produces("application/json")]
    [ProducesResponseType(typeof(AppointmentResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [Authorize]
    public async Task<IActionResult> GetAppointment([FromServices] IGetAppointmentInteractor interactor, Guid id)
    {
        _logger.LogInformation("Processing request to GetAppointment");

        try
        {
            var appointment = await interactor.Execute(HttpContext.CurrentIdentityId(), id);

            if (appointment is null)
            {
                return this.AppointmentNotFoundError();
            }

            var dto = AppointmentResponseDto.FromDomain(appointment);

            return Ok(dto);
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during GetAppointment request processing");
            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Gets appointments for the currently authorized identity
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="startDate">Optional date filter, to only include appointments ending after this date</param>
    /// <param name="endDate">Optional date filter, to only include appointments starting before this date</param>
    /// <param name="typeIds">Optional type filter, to only include appointments which has at least one of the types assigned</param>
    /// <returns>An IActionResult representing the result of the endpoint call</returns>
    /// <response code="200">Appointments were successfully fetched</response>
    [HttpGet(Name = "Get appointments")]
    [Produces("application/json")]
    [ProducesResponseType(typeof(IEnumerable<AppointmentResponseDto>), StatusCodes.Status200OK)]
    [Authorize]
    public async Task<IActionResult> GetAppointments(
        [FromServices] IGetAppointmentsInteractor interactor,
        [FromQuery] DateTimeOffset? startDate,
        [FromQuery] DateTimeOffset? endDate,
        [FromQuery] int[] typeIds)
    {
        _logger.LogInformation("Processing request to GetAppointments");

        try
        {
            var appointments = await interactor.Execute(HttpContext.CurrentIdentityId(), startDate, endDate, (typeIds.Length > 0) ? typeIds : null);

            return Ok(appointments.Select(AppointmentResponseDto.FromDomain));
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during GetAppointments request processing");
            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Creates a new appointment for the currently authorized identity
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="dto">The appointment to create</param>
    /// <returns>An IActionResult representing the result of the endpoint call</returns>
    /// <response code="201">The appointment was successfully created</response>
    /// <response code="400">The request payload was invalid</response>
    [HttpPost(Name = "Create appointment")]
    [Consumes("application/json")]
    [Produces("application/json")]
    [ProducesResponseType(typeof(AppointmentResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [Authorize]
    public async Task<IActionResult> CreateAppointment([FromServices] ICreateAppointmentInteractor interactor, [FromBody] AppointmentRequestDto dto)
    {
        _logger.LogInformation("Processing request to CreateAppointment");

        try
        {
            var appointment = dto.ToDomain(HttpContext.CurrentIdentityId());

            if (!appointment.IsTimeSpanValid)
            {
                return this.InvalidAppointmentTimeSpan();
            }

            appointment = await interactor.Execute(appointment);

            return Created(string.Empty, AppointmentResponseDto.FromDomain(appointment));
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during CreateAppointment request processing");
            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Replaces an existing appointment for the currently authorized identity
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="dto">The appointment to replace</param>
    /// <returns>An IActionResult representing the result of the endpoint call</returns>
    /// <response code="200">The appointment was successfully replaced</response>
    /// <response code="400">The request payload was invalid</response>
    /// <response code="404">The appointment was not found or the user does not have access</response>
    [HttpPut(Name = "Replace appointment")]
    [Consumes("application/json")]
    [Produces("application/json")]
    [ProducesResponseType(typeof(AppointmentResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [Authorize]
    public async Task<IActionResult> ReplaceAppointment([FromServices] IReplaceAppointmentInteractor interactor, [FromBody] AppointmentRequestDto dto)
    {
        _logger.LogInformation("Processing request to ReplaceAppointment");

        try
        {
            var appointment = dto.ToDomain(HttpContext.CurrentIdentityId());

            if (!appointment.IsTimeSpanValid)
            {
                return this.InvalidAppointmentTimeSpan();
            }

            var updatedAppointment = await interactor.Execute(appointment);

            if (updatedAppointment is null)
            {
                return this.AppointmentNotFoundError();
            }

            var responseDto = AppointmentResponseDto.FromDomain(updatedAppointment);

            return Ok(responseDto);
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during ReplaceAppointment request processing");
            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Delete an appointment
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="id">The id of the appointment to delete</param>
    /// <returns>An IActionResult representing the result of the endpoint call</returns>
    /// <response code="204">Appointment was successfully deleted</response>
    [HttpDelete("{id}", Name = "Delete appointment")]
    [Produces("application/json")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [Authorize]
    public async Task<IActionResult> DeleteAppointment([FromServices] IDeleteAppointmentInteractor interactor, Guid id)
    {
        _logger.LogInformation("Processing request to DeleteAppointment");

        try
        {
            if (!await interactor.Execute(HttpContext.CurrentIdentityId(), id))
            {
                return this.AppointmentNotFoundError();
            }

            return NoContent();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during DeleteAppointment request processing");
            return this.UnexpectedError();
        }
    }
}
