using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsultationModule.Dtos.Response;
using NwadHealth.Besthealthorg.Foundation.Extensions.Controller;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.ConsultationModule.Controllers;

/// <summary>
/// Contains endpoints relating to the AppointmentTypes domain
/// </summary>
[ApiController]
[Route("Consultation/[controller]")]
public class AppointmentTypeController : ControllerBase
{
    private readonly ILogger<AppointmentTypeController> _logger;

    /// <summary>
    /// Initializes the AppointmentTypeController
    /// </summary>
    /// <param name="logger">The logger to use</param>
    public AppointmentTypeController(ILogger<AppointmentTypeController> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Gets available types for appointments
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <returns>An IActionResult representing the result of the endpoint call</returns>
    /// <response code="200">Appointment types were successfully fetched</response>
    [HttpGet(Name = "Get appointment types")]
    [Produces("application/json")]
    [ProducesResponseType(typeof(IEnumerable<AppointmentTypeResponseDto>), StatusCodes.Status200OK)]
    [Authorize]
    public async Task<IActionResult> GetTypes([FromServices] IGetAppointmentTypesInteractor interactor)
    {
        _logger.LogInformation("Processing request to GetTypes");

        try
        {
            var result = await interactor.Execute();
            return Ok(result.Select(AppointmentTypeResponseDto.FromDomain));
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during GetTypes request processing");
            return this.UnexpectedError();
        }
    }
}
