using NwadHealth.Besthealthorg.ConsultationModule.Infrastructure;
using NwadHealth.Besthealthorg.ConsultationModule.Infrastructure.Models;
using NwadHealth.Besthealthorg.NoteModule.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ConsultationModule.IntegrationTest;

/// <summary>
/// DbContext for Consultation integration tests
/// </summary>
public class ConsultationTestDbContext : DbContext, IConsultationDbContext
{
    public ConsultationTestDbContext(DbContextOptions<ConsultationTestDbContext> options) : base(options)
    {
    }

    public DbSet<AppointmentDbModel> Appointments { get; set; } = null!;

    public DbSet<AppointmentTypeDbModel> AppointmentTypes { get; set; } = null!;

    public DbSet<NoteDbModel> Notes { get; set; } = null!;

    public DbSet<NoteTypeDbModel> NoteTypes { get; set; } = null!;

    public DbSet<NoteTopicDbModel> NoteTopics { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        (this as IConsultationDbContext).ConfigureDbSets(modelBuilder);
    }
}
