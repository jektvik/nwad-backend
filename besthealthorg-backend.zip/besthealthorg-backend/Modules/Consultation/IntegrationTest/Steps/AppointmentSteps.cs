using NwadHealth.Besthealthorg.ConsultationModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.ConsultationModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.ConsultationModule.Infrastructure.Models;
using NwadHealth.Besthealthorg.NoteModule.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsultationModule.IntegrationTest;

[Binding]
public class AppointmentSteps
{
    private static readonly Guid _existingAppointmentId = Guid.NewGuid();
    private static readonly Dictionary<int, Guid> _typeIdToExistingAppointmentId = new()
    {
        [1] = Guid.NewGuid(),
        [2] = Guid.NewGuid(),
        [3] = Guid.NewGuid(),
        [4] = Guid.NewGuid(),
    };

    private readonly ScenarioContext _context;
    private readonly ConsultationWebApplicationFactory _factory;

    public AppointmentSteps(ScenarioContext context, ConsultationWebApplicationFactory factory)
    {
        _context = context;
        _factory = factory;
    }

    [Given("I have an appointment")]
    public async Task GivenIHaveAnAppointment()
    {
        using var scope = _factory.Services.CreateScope();

        var sqlContext = scope.ServiceProvider.GetRequiredService<ConsultationTestDbContext>();

        sqlContext.Appointments.Add(new()
        {
            Id = _existingAppointmentId,
            IdentityId = _context.Get<string>("userId"),
            CreatedAt = DateTimeOffset.UtcNow,
            TimeStart = DateTimeOffset.UtcNow,
            TimeEnd = DateTimeOffset.UtcNow.AddHours(1),
            Title = "Title",
            Notes = [new NoteDbModel()
            {
                Id = Guid.NewGuid(),
                Content = "content",
                CreatedAt = DateTimeOffset.UtcNow,
                IdentityId = _context.Get<string>("userId"),
                Title = "title",
                Topics = [(await sqlContext.NoteTopics.FindAsync(1))!],
                Types = [(await sqlContext.NoteTypes.FindAsync(2))!]
            }]
        });

        await sqlContext.SaveChangesAsync();
    }

    [Given("An appointment that is not mine exists")]
    public async Task GivenAnAppointmentThatIsNotMineExists()
    {
        using var scope = _factory.Services.CreateScope();

        var sqlContext = scope.ServiceProvider.GetRequiredService<ConsultationTestDbContext>();

        sqlContext.Appointments.Add(new()
        {
            Id = _existingAppointmentId,
            IdentityId = _context.Get<string>("userId") + "notme",
            CreatedAt = DateTimeOffset.UtcNow,
            TimeStart = DateTimeOffset.UtcNow,
            TimeEnd = DateTimeOffset.UtcNow.AddHours(1),
            Title = "Title",
        });

        await sqlContext.SaveChangesAsync();
    }

    [Given("I have appointments with different types")]
    public async Task GivenIHaveAppointmentsWithDifferentTypes()
    {
        using var scope = _factory.Services.CreateScope();

        var sqlContext = scope.ServiceProvider.GetRequiredService<ConsultationTestDbContext>();

        foreach (var pair in _typeIdToExistingAppointmentId)
        {
            var type = await sqlContext.AppointmentTypes.FirstAsync(at => at.Id == pair.Key);

            sqlContext.Appointments.Add(new()
            {
                Id = pair.Value,
                IdentityId = _context.Get<string>("userId"),
                CreatedAt = DateTimeOffset.UtcNow,
                TimeStart = DateTimeOffset.UtcNow,
                TimeEnd = DateTimeOffset.UtcNow.AddHours(1),
                Title = "Title",
                Types = [type]
            });
        }

        await sqlContext.SaveChangesAsync();
    }

    [Given("I have appointments with several different start and end dates")]
    public async Task GivenIHaveAppointmentsWithSeveralDifferentStartAndEndDates()
    {
        var userId = _context.Get<string>("userId");
        using var scope = _factory.Services.CreateScope();

        var sqlContext = scope.ServiceProvider.GetRequiredService<ConsultationTestDbContext>();
        var type = await sqlContext.AppointmentTypes.FirstAsync();

        // startDateTest                    |
        // endDateTest                 |
        // startEndDateTest          |         |
        // Date         21          22          23          24
        // Appointment1  ------------
        // Appointment2              ------------
        // Appointment3                          ------------
        // Appointment4 ------------
        AppointmentDbModel[] appointments = [
            new()
            {
                Id = Guid.NewGuid(),
                IdentityId = userId,
                TimeStart = DateTimeOffset.Parse("2023-09-21T00:00:00Z"),
                TimeEnd = DateTimeOffset.Parse("2023-09-21T23:59:59Z"),
                Title = "Appointment1",
                Types = [type],
            },
            new()
            {
                Id = Guid.NewGuid(),
                IdentityId = userId,
                TimeStart = DateTimeOffset.Parse("2023-09-22T00:00:00Z"),
                TimeEnd = DateTimeOffset.Parse("2023-09-22T23:59:59Z"),
                Title = "Appointment2",
            },
            new()
            {
                Id = Guid.NewGuid(),
                IdentityId = userId,
                TimeStart = DateTimeOffset.Parse("2023-09-23T00:00:00Z"),
                TimeEnd = DateTimeOffset.Parse("2023-09-23T23:59:59Z"),
                Title = "Appointment3",
            },
            new()
            {
                Id = Guid.NewGuid(),
                IdentityId = userId,
                TimeStart = DateTimeOffset.Parse("2023-09-21T12:00:00Z"),
                TimeEnd = DateTimeOffset.Parse("2023-09-22T12:00:00Z"),
                Title = "Appointment4",
            },
        ];

        sqlContext.Appointments.AddRange(appointments);
        await sqlContext.SaveChangesAsync();
    }

    [When("I request to create an appointment")]
    public async Task WhenIRequestToCreateAnAppointment()
    {
        var dto = new AppointmentRequestDto
        {
            Id = Guid.NewGuid(),
            TimeStart = DateTimeOffset.UtcNow,
            TimeEnd = DateTimeOffset.UtcNow.AddHours(1),
            Title = "AppointmentTitle",
            TypeIds = [1, 2],
            Notes = [new(Guid.NewGuid(), "title", "content", DateTimeOffset.UtcNow, [1], [3])]
        };

        var client = _context.Get<HttpClient>();
        var resp = await client.PostAsJsonAsync("/Consultation/Appointment", dto);

        _context.Set(resp);
        _context.Set(dto);
    }

    [When("I request to create an appointment that ends before it starts")]
    public async Task WhenIRequestToCreateAnAppointmentThatEndsBeforeItStarts()
    {
        var dto = new AppointmentRequestDto
        {
            Id = Guid.NewGuid(),
            TimeStart = DateTimeOffset.UtcNow,
            TimeEnd = DateTimeOffset.UtcNow.AddHours(-1),
            Title = "AppointmentTitle",
            TypeIds = [1, 2],
            Notes = []
        };

        var client = _context.Get<HttpClient>();
        var resp = await client.PostAsJsonAsync("/Consultation/Appointment", dto);

        _context.Set(resp);
    }

    [When("I request to delete an appointment")]
    public async Task WhenIRequestToDeleteAnAppointment()
    {
        var client = _context.Get<HttpClient>();
        var resp = await client.DeleteAsync($"/Consultation/Appointment/{_existingAppointmentId}");

        _context.Set(resp);
    }

    [When("I request to delete an appointment that does not exist")]
    public async Task WhenIRequestToDeleteAnAppointmentThatDoesNotExist()
    {
        var client = _context.Get<HttpClient>();
        var resp = await client.DeleteAsync($"/Consultation/Appointment/{Guid.NewGuid()}");

        _context.Set(resp);
    }

    [When("I request to edit an appointment")]
    public async Task WhenIRequestToEditAnAppointment()
    {
        var dto = new AppointmentRequestDto
        {
            Id = _existingAppointmentId,
            TimeStart = DateTimeOffset.UtcNow.AddHours(1),
            TimeEnd = DateTimeOffset.UtcNow.AddHours(2),
            Title = "UpdatedAppointmentTitle",
            TypeIds = [2, 3]
        };

        var client = _context.Get<HttpClient>();
        var resp = await client.PutAsJsonAsync("/Consultation/Appointment", dto);

        _context.Set(resp);
        _context.Set(dto);
    }

    [When("I request to edit an appointment that does not exist")]
    public async Task WhenIRequestToEditAnAppointmentThatDoesNotExist()
    {
        var dto = new AppointmentRequestDto
        {
            Id = Guid.NewGuid(),
            TimeStart = DateTimeOffset.UtcNow,
            TimeEnd = DateTimeOffset.UtcNow.AddHours(1),
            Title = "AppointmentTitle",
            TypeIds = [1, 2]
        };

        var client = _context.Get<HttpClient>();
        var resp = await client.PutAsJsonAsync("/Consultation/Appointment", dto);

        _context.Set(resp);
    }

    [When("I request to edit an appointment so that it ends before it starts")]
    public async Task WhenIRequestToEditAnAppointmentSoThatItEndsBeforeItStarts()
    {
        var dto = new AppointmentRequestDto
        {
            Id = _existingAppointmentId,
            TimeStart = DateTimeOffset.UtcNow,
            TimeEnd = DateTimeOffset.UtcNow.AddHours(-1),
            Title = "AppointmentTitle",
            TypeIds = [1, 2]
        };

        var client = _context.Get<HttpClient>();
        var resp = await client.PutAsJsonAsync("/Consultation/Appointment", dto);

        _context.Set(resp);
    }

    [When("I request to get an appointment")]
    public async Task WhenIRequestToGetAnAppointment()
    {
        var client = _context.Get<HttpClient>();
        var resp = await client.GetAsync($"/Consultation/Appointment/{_existingAppointmentId}");

        _context.Set(resp);
    }

    [When("I request to get my appointments")]
    public async Task WhenIRequestToGetMyAppointments()
    {
        await GetAppointments();
    }

    [When("I request to get my appointments with type (.*)")]
    public async Task WhenIRequestToGetMyAppointmentsWithType(string type)
    {
        await GetAppointments($"?typeIds={GetIdFromType(type)}");
    }

    [When("I request to get my appointments with start date filter")]
    public async Task WhenIRequestToGetMyAppointmentsWithStartDateFilter()
    {
        await GetAppointments("?startDate=2023-09-22T16:00:00Z");
    }

    [When("I request to get my appointments with end date filter")]
    public async Task WhenIRequestToGetMyAppointmentsWithEndDateFilter()
    {
        await GetAppointments("?endDate=2023-09-22T04:00:00Z");
    }

    [When("I request to get my appointments with start and end date filter")]
    public async Task WhenIRequestToGetMyAppointmentsWithStartAndEndDateFilter()
    {
        await GetAppointments("?startDate=2023-09-22T00:00:00Z&endDate=2023-09-22T22:00:00Z");
    }

    [Then("the appointment is created")]
    public async Task ThenTheAppointmentIsCreated()
    {
        using var scope = _factory.Services.CreateScope();

        var sqlContext = scope.ServiceProvider.GetRequiredService<ConsultationTestDbContext>();

        var appointmentFromDb = await sqlContext.Appointments
            .Include(a => a.Types)
            .Include(a => a.Notes)
            .ThenInclude(n => n.Types)
            .Include(a => a.Notes)
            .ThenInclude(n => n.Topics)
            .FirstAsync();

        var dto = _context.Get<AppointmentRequestDto>();

        Assert.Equal(dto.Id, appointmentFromDb.Id);
        Assert.Equal(dto.TimeStart, appointmentFromDb.TimeStart);
        Assert.Equal(dto.TimeEnd, appointmentFromDb.TimeEnd);
        Assert.Equal(dto.Title, appointmentFromDb.Title);
        Assert.True(appointmentFromDb.Types.All(t => dto.TypeIds.Contains(t.Id)));
        Assert.Equal(dto.Notes.First().Id, appointmentFromDb.Notes.First().Id);
        Assert.Equal(dto.Notes.First().TypeIds.First(), appointmentFromDb.Notes.First().Types.First().Id);
        Assert.Equal(dto.Notes.First().TopicIds.First(), appointmentFromDb.Notes.First().Topics.First().Id);
    }

    [Then("the appointment is soft deleted")]
    public async Task ThenTheAppointmentIsSoftDeleted()
    {
        using var scope = _factory.Services.CreateScope();

        var sqlContext = scope.ServiceProvider.GetRequiredService<ConsultationTestDbContext>();

        var appointmentFromDb = await sqlContext.Appointments.FirstOrDefaultAsync();

        Assert.NotNull(appointmentFromDb!.DeletedAt);
    }

    [Then("the appointment is edited")]
    public async Task ThenTheAppointmentIsEdited()
    {
        using var scope = _factory.Services.CreateScope();

        var sqlContext = scope.ServiceProvider.GetRequiredService<ConsultationTestDbContext>();

        var appointmentFromDb = await sqlContext.Appointments.Include(a => a.Types).FirstAsync(a => a.Id == _existingAppointmentId);

        var dto = _context.Get<AppointmentRequestDto>();

        Assert.Equal(dto.Id, appointmentFromDb.Id);
        Assert.Equal(dto.TimeStart, appointmentFromDb.TimeStart);
        Assert.Equal(dto.TimeEnd, appointmentFromDb.TimeEnd);
        Assert.Equal(dto.Title, appointmentFromDb.Title);
        Assert.Empty(dto.Notes);
        Assert.True(appointmentFromDb.Types.All(t => dto.TypeIds.Contains(t.Id)));
    }

    [Then("I receive the appointment")]
    public async Task ThenIReceiveTheAppointment()
    {
        using var scope = _factory.Services.CreateScope();

        var sqlContext = scope.ServiceProvider.GetRequiredService<ConsultationTestDbContext>();

        var appointmentFromDb = await sqlContext.Appointments
            .Include(a => a.Types)
            .Include(a => a.Notes)
            .ThenInclude(n => n.Types)
            .Include(a => a.Notes)
            .ThenInclude(n => n.Topics)
            .FirstAsync(a => a.Id == _existingAppointmentId);

        var dto = await _context.Get<HttpResponseMessage>().Content.ReadFromJsonAsync<AppointmentResponseDto>();

        Assert.Equal(dto!.Id, appointmentFromDb.Id);
        Assert.Equal(dto!.TimeStart, appointmentFromDb.TimeStart);
        Assert.Equal(dto!.TimeEnd, appointmentFromDb.TimeEnd);
        Assert.Equal(dto!.Title, appointmentFromDb.Title);
        Assert.All(appointmentFromDb.Notes, nDb => Assert.Contains(dto.Notes, n => n.Id == nDb.Id));
        Assert.All(appointmentFromDb.Types, tDb => Assert.Contains(dto.Types, t => t.Id == tDb.Id));
    }

    [Then("I receive my existing appointments")]
    public async Task ThenIReceiveMyExistingAppointments()
    {
        var userId = _context.Get<string>("userId");

        using var scope = _factory.Services.CreateScope();

        var sqlContext = scope.ServiceProvider.GetRequiredService<ConsultationTestDbContext>();

        var appointmentsFromDb = await sqlContext.Appointments.Where(a => a.IdentityId == userId).ToListAsync();

        var returnedAppointments = await _context.Get<HttpResponseMessage>()
            .Content
            .ReadFromJsonAsync<IEnumerable<AppointmentResponseDto>>();

        Assert.Equal(4, appointmentsFromDb.Count);
        Assert.All(appointmentsFromDb, aDb => Assert.Contains(returnedAppointments!, a => a.Id == aDb.Id));
    }

    [Then("I receive my existing appointments with type (.*)")]
    public async Task ThenIReceiveMyExistingAppointmentsWithType(string type)
    {
        var typeId = GetIdFromType(type);

        var returnedAppointments = await _context.Get<HttpResponseMessage>()
            .Content
            .ReadFromJsonAsync<IEnumerable<AppointmentResponseDto>>();

        Assert.Single(returnedAppointments!);
        Assert.Equal(typeId, returnedAppointments!.First().Types.First().Id);
    }

    [Then("I receive my appointments that end after the start date")]
    public async Task ThenIReceiveMyAppointmentsThatEndAfterTheStartDate()
    {
        var resp = _context.Get<HttpResponseMessage>();
        var appointments = await resp.Content.ReadFromJsonAsync<List<AppointmentResponseDto>>();

        Assert.Equal(2, appointments!.Count);
        Assert.Contains(appointments, appointment => appointment.Title == "Appointment2");
        Assert.Contains(appointments, appointment => appointment.Title == "Appointment3");
    }

    [Then("I receive my appointments that start before the end date")]
    public async Task ThenIReceiveMyAppointmentsThatStartBeforeTheEndDate()
    {
        var resp = _context.Get<HttpResponseMessage>();
        var appointments = await resp.Content.ReadFromJsonAsync<List<AppointmentResponseDto>>();

        Assert.Equal(3, appointments!.Count);
        Assert.Contains(appointments, appointment => appointment.Title == "Appointment1");
        Assert.Contains(appointments, appointment => appointment.Title == "Appointment2");
        Assert.Contains(appointments, appointment => appointment.Title == "Appointment4");
    }

    [Then("I receive my appointments that start before the end date and end before the start date")]
    public async Task ThenIReceiveMyAppointmentsThatStartBeforeTheEndDateAndEndBeforeTheStartDate()
    {
        var resp = _context.Get<HttpResponseMessage>();
        var appointments = await resp.Content.ReadFromJsonAsync<List<AppointmentResponseDto>>();

        Assert.Equal(2, appointments!.Count);
        Assert.Contains(appointments, appointment => appointment.Title == "Appointment2");
        Assert.Contains(appointments, appointment => appointment.Title == "Appointment4");
    }

    private async Task GetAppointments(string queryString = "")
    {
        var client = _context.Get<HttpClient>();
        var resp = await client.GetAsync($"/Consultation/Appointment{queryString}");

        _context.Set(resp);
    }

    private static int GetIdFromType(string type)
    {
        return type.ToLower() switch
        {
            "general practitioner" => 1,
            "therapy" => 2,
            "bloodwork" => 3,
            "other" => 4,
            _ => throw new ArgumentException($"{type} is not a valid type", nameof(type))
        };
    }
}
