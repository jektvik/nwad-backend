using NwadHealth.Besthealthorg.ConsultationModule.Dtos.Response;
using Microsoft.EntityFrameworkCore;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsultationModule.IntegrationTest;

[Binding]
public class AppointmentTypeSteps
{
    private readonly ScenarioContext _context;
    private readonly ConsultationWebApplicationFactory _factory;

    public AppointmentTypeSteps(ScenarioContext context, ConsultationWebApplicationFactory factory)
    {
        _context = context;
        _factory = factory;
    }

    [When("I request available appointment types")]
    public async Task WhenIRequestAvailableAppointmentTypes()
    {
        var client = _context.Get<HttpClient>();
        var response = await client.GetAsync("/Consultation/AppointmentType");
        _context.Set(response);
    }

    [Then("I receive the configured appointment types")]
    public async Task ThenIReceiveTheConfiguredAppointmentTypes()
    {
        using var scope = _factory.Services.CreateScope();

        var sqlContext = scope.ServiceProvider.GetRequiredService<ConsultationTestDbContext>();

        var appointmentTypesFromDb = await sqlContext.AppointmentTypes.ToListAsync();

        Assert.NotEmpty(appointmentTypesFromDb);

        var receivedAppointmentTypes = await _context.Get<HttpResponseMessage>()
            .Content
            .ReadFromJsonAsync<IEnumerable<AppointmentTypeResponseDto>>();

        foreach (var dbAppointment in appointmentTypesFromDb)
        {
            var match = receivedAppointmentTypes!.FirstOrDefault(at => at.Id == dbAppointment.Id);

            Assert.NotNull(match);
            Assert.Equal(dbAppointment.Name, match.Name);
        }
    }
}
