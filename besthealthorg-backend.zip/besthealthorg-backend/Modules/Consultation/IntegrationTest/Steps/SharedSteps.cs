﻿using Microsoft.EntityFrameworkCore;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsultationModule.IntegrationTest;

[Binding]
public sealed class SharedSteps : IClassFixture<ConsultationWebApplicationFactory>
{
    private readonly ScenarioContext _context;
    private readonly ConsultationWebApplicationFactory _factory;

    public SharedSteps(ScenarioContext context, ConsultationWebApplicationFactory factory)
    {
        _context = context;
        _factory = factory;
    }

    [Given("A running backend")]
    public void GivenARunningBackend()
    {
        _context.Set(_factory.CreateClient());
    }

    [BeforeScenario]
    public async Task ResetDatabases()
    {
        using var scope = _factory.Services.CreateScope();

        var sqlContext = scope.ServiceProvider.GetRequiredService<ConsultationTestDbContext>();

        await sqlContext.Appointments.ExecuteDeleteAsync();
    }
}
