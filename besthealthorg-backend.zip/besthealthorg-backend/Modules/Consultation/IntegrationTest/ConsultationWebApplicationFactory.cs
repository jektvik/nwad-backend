using NwadHealth.Besthealthorg.ConsultationModule.Infrastructure;
using NwadHealth.Besthealthorg.ConsultationModule.Infrastructure.Models;
using NwadHealth.Besthealthorg.NoteModule.Infrastructure.Models;
using NwadHealth.Besthealthorg.TestUtilities.IntegrationTestHelpers;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ConsultationModule.IntegrationTest;

public class ConsultationWebApplicationFactory : PaceWebApplicationFactory
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        base.ConfigureWebHost(builder);
        base.ConfigureTestAuth(builder);

        builder.ConfigureServices(services =>
        {
            services
                .AddControllers()
                .AddApplicationPart(typeof(Frameworks.Controllers.AppointmentController).Assembly);

            services.AddDbContext<ConsultationTestDbContext>(o => o.UseSqlServer(SqlDbConnectionString));

            services.AddPaceConsultation<ConsultationTestDbContext>();
        });

        builder.Configure(app =>
        {
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseEndpoints(conf => conf.MapControllers());

            using (var scope = app.ApplicationServices.CreateScope())
            {
                var services = scope.ServiceProvider;

                var context = services.GetRequiredService<ConsultationTestDbContext>();
                context.Database.EnsureCreated();
                context.Database.OpenConnection();

                if (!context.AppointmentTypes.Any())
                {
                    var appointmentTypes = new List<AppointmentTypeDbModel>
                    {
                        new() { Id = 1, Name = "General Practitioner" },
                        new() { Id = 2, Name = "Therapy" },
                        new() { Id = 3, Name = "Bloodwork" },
                        new() { Id = 4, Name = "Other" },
                    };

                    context.AppointmentTypes.AddRange(appointmentTypes);

                    context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT dbo.AppointmentTypes ON");
                    context.SaveChanges();
                    context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT dbo.AppointmentTypes OFF");
                }

                if (!context.NoteTypes.Any())
                {
                    for (var id = 1; id <= 3; id++)
                    {
                        context.NoteTypes.Add(new NoteTypeDbModel
                        {
                            Id = id,
                            Name = $"type{id}"
                        });
                    }

                    context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT dbo.NoteTypes ON");
                    context.SaveChanges();
                    context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT dbo.NoteTypes OFF");
                }

                if (!context.NoteTopics.Any())
                {
                    for (var id = 1; id <= 3; id++)
                    {
                        context.NoteTopics.Add(new NoteTopicDbModel
                        {
                            Id = id,
                            Name = $"topic{id}",
                            Category = $"category{id}",
                            TipContent = $"tip{id}"
                        });
                    }

                    context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT dbo.NoteTopics ON");
                    context.SaveChanges();
                    context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT dbo.NoteTopics OFF");
                }

                context.Database.CloseConnection();
            }
        });
    }
}
