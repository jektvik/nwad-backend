using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.Foundation.Interfaces;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing the required interactions with a data store containing appointments
/// </summary>
public interface IAppointmentRepository : IAnonymizable
{
    /// <summary>
    /// Adds an appointment to the data store
    /// </summary>
    /// <param name="appointment">The appointment to add</param>
    /// <returns>The newly added appointment</returns>
    Task<Appointment> Create(Appointment appointment);

    /// <summary>
    /// Gets all appointments from the data store filtered by identity id,
    /// optionally filtered by start date, end date and type
    /// </summary>
    /// <param name="identityId">The identity id for which to fetch appointments</param>
    /// <param name="startDate">Optional date filter, to only include appointments ending after this date</param>
    /// <param name="endDate">Optional date filter, to only include appointments starting before this date</param>
    /// <param name="typeIds">Optional type filter, to only include appointments which has at least one of the types assigned</param>
    /// <returns>An enumerable of all appointments for the identity id and optional filters</returns>
    Task<IEnumerable<Appointment>> GetByIdentityId(string identityId, DateTimeOffset? startDate, DateTimeOffset? endDate, IEnumerable<int>? typeIds);

    /// <summary>
    /// Fetches an appointment by id
    /// </summary>
    /// <param name="id">The id of the appointment to fetch</param>
    /// <returns>The appointment if found, otherwise null</returns>
    Task<Appointment?> Get(Guid id);

    /// <summary>
    /// Deletes an appointment by id
    /// </summary>
    /// <param name="id">The id of the appointment to delete</param>
    Task Delete(Guid id);

    /// <summary>
    /// Replaces an appointment
    /// </summary>
    /// <param name="appointment">The appointment to replace</param>
    /// <returns>The new appointment</returns>
    Task<Appointment> Replace(Appointment appointment);
}
