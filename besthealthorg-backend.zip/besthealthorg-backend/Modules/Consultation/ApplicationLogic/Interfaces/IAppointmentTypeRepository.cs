using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing the required interactions with a data store containing appointment types
/// </summary>
public interface IAppointmentTypeRepository
{
    /// <summary>
    /// Fetches all appointment types from the data store
    /// </summary>
    /// <returns>An enumerable of appointment types</returns>
    public Task<IEnumerable<AppointmentType>> GetAll();
}
