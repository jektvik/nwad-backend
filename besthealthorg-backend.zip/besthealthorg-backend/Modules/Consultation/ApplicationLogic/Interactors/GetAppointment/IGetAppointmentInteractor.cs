using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of fetching an appointment
/// </summary>
public interface IGetAppointmentInteractor
{
    /// <summary>
    /// Attempts to fetch an appointment from the data store
    /// </summary>
    /// <param name="identityId">The id of the identity trying to fetch the appointment</param>
    /// <param name="appointmentId">The id of the appointment to fetch</param>
    /// <returns>The appointment or null if it was not found</returns>
    Task<Appointment?> Execute(string identityId, Guid appointmentId);
}
