using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents the business logic for fetching an appointment from a data store
/// </summary>
public class GetAppointmentInteractor : IGetAppointmentInteractor
{
    private readonly IAppointmentRepository _repository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="repository">The data store to use for fetching data</param>
    public GetAppointmentInteractor(IAppointmentRepository repository)
    {
        _repository = repository;
    }

    /// <summary>
    /// Attempts to fetch an appointment from the data store
    /// </summary>
    /// <param name="identityId">The id of the identity trying to fetch the appointment</param>
    /// <param name="appointmentId">The id of the appointment to fetch</param>
    /// <returns>The appointment or null if it was not found</returns>
    public async Task<Appointment?> Execute(string identityId, Guid appointmentId)
    {
        var appointment = await _repository.Get(appointmentId);

        if (appointment is null || appointment.IdentityId != identityId)
        {
            return null;
        }

        return appointment;
    }
}
