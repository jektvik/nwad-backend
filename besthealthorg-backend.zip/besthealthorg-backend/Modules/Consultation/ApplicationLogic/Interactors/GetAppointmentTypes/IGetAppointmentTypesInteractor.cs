using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of fetching appointment types
/// </summary>
public interface IGetAppointmentTypesInteractor
{
    /// <summary>
    /// Attempts to fetch all appointment types from the data store
    /// </summary>
    /// <returns>The appointment types</returns>
    Task<IEnumerable<AppointmentType>> Execute();
}
