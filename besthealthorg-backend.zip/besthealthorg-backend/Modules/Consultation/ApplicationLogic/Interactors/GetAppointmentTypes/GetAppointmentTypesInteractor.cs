using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents the business logic for fetching appointment types from a data store
/// </summary>
public class GetAppointmentTypesInteractor : IGetAppointmentTypesInteractor
{
    private readonly IAppointmentTypeRepository _repository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="repository">The data store to use for fetching data</param>
    public GetAppointmentTypesInteractor(IAppointmentTypeRepository repository)
    {
        _repository = repository;
    }

    /// <summary>
    /// Attempts to fetch all appointment types from the data store
    /// </summary>
    /// <returns>The appointment types</returns>
    public async Task<IEnumerable<AppointmentType>> Execute()
    {
        return await _repository.GetAll();
    }
}
