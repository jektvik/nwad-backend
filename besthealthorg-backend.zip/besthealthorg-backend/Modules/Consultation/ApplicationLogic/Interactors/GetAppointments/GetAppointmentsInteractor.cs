using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents the business logic for fetching an identitys appointments from a data store
/// </summary>
public class GetAppointmentsInteractor : IGetAppointmentsInteractor
{
    private readonly IAppointmentRepository _repository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="repository">The data store to use for fetching data</param>
    public GetAppointmentsInteractor(IAppointmentRepository repository)
    {
        _repository = repository;
    }

    /// <summary>
    /// Attempts to fetch all appointment for a specific identity from the data store
    /// </summary>
    /// <param name="identityId">The id of the identity for which appointments should be fetched</param>
    /// <param name="startDate">Optional date filter, to only include appointments ending after this date</param>
    /// <param name="endDate">Optional date filter, to only include appointments starting before this date</param>
    /// <param name="typeIds">Optional type filter, to only include appointments which has at least one of the types assigned</param>
    /// <returns>The appointments</returns>
    public async Task<IEnumerable<Appointment>> Execute(string identityId, DateTimeOffset? startDate, DateTimeOffset? endDate, IEnumerable<int>? typeIds)
    {
        return await _repository.GetByIdentityId(identityId, startDate, endDate, typeIds);
    }
}
