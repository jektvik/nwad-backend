using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of fetching an identitys appointments
/// </summary>
public interface IGetAppointmentsInteractor
{
    /// <summary>
    /// Attempts to fetch all appointment for a specific identity from the data store
    /// </summary>
    /// <param name="identityId">The id of the identity for which appointments should be fetched</param>
    /// <param name="startDate">Optional date filter, to only include appointments ending after this date</param>
    /// <param name="endDate">Optional date filter, to only include appointments starting before this date</param>
    /// <param name="typeIds">Optional type filter, to only include appointments which has at least one of the types assigned</param>
    /// <returns>The appointments</returns>
    Task<IEnumerable<Appointment>> Execute(string identityId, DateTimeOffset? startDate, DateTimeOffset? endDate, IEnumerable<int>? typeIds);
}
