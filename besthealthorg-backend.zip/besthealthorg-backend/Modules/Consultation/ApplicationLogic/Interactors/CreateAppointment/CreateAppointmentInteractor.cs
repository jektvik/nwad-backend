using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interfaces;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents the business logic for adding an appointment to a data store
/// </summary>
public class CreateAppointmentInteractor : ICreateAppointmentInteractor
{
    private readonly IAppointmentRepository _repository;
    private readonly INoteRepository _noteRepository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="repository">The data store to use for saving data</param>
    /// <param name="noteRepository">The data store to use for note data interactions</param>
    public CreateAppointmentInteractor(IAppointmentRepository repository, INoteRepository noteRepository)
    {
        _repository = repository;
        _noteRepository = noteRepository;
    }

    /// <summary>
    /// Attempts to save the appointment to the data store
    /// </summary>
    /// <param name="appointment">The appointment to save</param>
    /// <returns>Returns the saved appointment</returns>
    /// <exception cref="InvalidOperationException">Thrown when appointment contains notes not owned by the owner of the appointment</exception>
    public async Task<Appointment> Execute(Appointment appointment)
    {
        var noteIds = appointment.Notes.Select(n => n.Id);

        var notesFromDb = await _noteRepository.GetMany(noteIds);

        if (notesFromDb.Any(n => n.IdentityId != appointment.IdentityId))
        {
            throw new InvalidOperationException("Identity does not own all provided notes");
        }

        return await _repository.Create(appointment);
    }
}
