using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of creating an appointment
/// </summary>
public interface ICreateAppointmentInteractor
{
    /// <summary>
    /// Attempts to save the appointment to the data store
    /// </summary>
    /// <param name="appointment">The appointment to save</param>
    /// <returns>Returns the saved appointment</returns>
    Task<Appointment> Execute(Appointment appointment);
}
