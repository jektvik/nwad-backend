using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of replacing an appointment
/// </summary>
public interface IReplaceAppointmentInteractor
{
    /// <summary>
    /// Attempts to replace an appointment in the data store
    /// </summary>
    /// <param name="appointment">The appointment to replace</param>
    /// <returns>The new appointment or null if it could not be found</returns>
    Task<Appointment?> Execute(Appointment appointment);
}
