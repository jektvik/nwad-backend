using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interfaces;

namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents the business logic for replacing an appointment in a data store
/// </summary>
public class ReplaceAppointmentInteractor : IReplaceAppointmentInteractor
{
    private readonly IAppointmentRepository _repository;
    private readonly INoteRepository _noteRepository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="repository">The data store to use for saving data</param>
    /// <param name="noteRepository">The data store to use for note data interactions</param>
    public ReplaceAppointmentInteractor(IAppointmentRepository repository, INoteRepository noteRepository)
    {
        _repository = repository;
        _noteRepository = noteRepository;
    }

    /// <summary>
    /// Attempts to replace an appointment in the data store
    /// </summary>
    /// <param name="appointment">The appointment to replace</param>
    /// <returns>The new appointment or null if it could not be found</returns>
    /// <exception cref="InvalidOperationException">Thrown when appointment contains notes not owned by the owner of the appointment</exception>
    public async Task<Appointment?> Execute(Appointment appointment)
    {
        var existingAppointment = await _repository.Get(appointment.Id);

        if (existingAppointment is null || existingAppointment.IdentityId != appointment.IdentityId)
        {
            return null;
        }

        var noteIds = appointment.Notes.Select(n => n.Id);

        var notesFromDb = await _noteRepository.GetMany(noteIds);

        if (notesFromDb.Any(n => n.IdentityId != appointment.IdentityId))
        {
            throw new InvalidOperationException("Identity does not own all provided notes");
        }

        return await _repository.Replace(appointment);
    }
}
