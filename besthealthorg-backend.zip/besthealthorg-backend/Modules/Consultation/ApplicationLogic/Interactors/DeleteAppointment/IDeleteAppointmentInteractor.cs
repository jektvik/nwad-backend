namespace NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of deleting an appointment
/// </summary>
public interface IDeleteAppointmentInteractor
{
    /// <summary>
    /// Attempts to delete the appointment from the data store
    /// </summary>
    /// <param name="identityId">The id of the identity trying to delete the appointment</param>
    /// <param name="appointmentId">The id of the appointment to delete</param>
    /// <returns>Returns true if the appointment waas deleted otherwise false</returns>
    Task<bool> Execute(string identityId, Guid appointmentId);
}
