using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsultationModule.Frameworks.Controllers;
using NwadHealth.Besthealthorg.ConsultationModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.ConsultationModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsultationModule.UnitTest;

public class AppointmentControllerTests
{
    #region GetAppointment

    [Fact]
    public async Task GetAppointment_WhenInteractorReturnsNull_ReturnsNotFound()
    {
        var guid = Guid.NewGuid();
        var interactorMock = new Mock<IGetAppointmentInteractor>();

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.GetAppointment(interactorMock.Object, guid);
        interactorMock.Verify(mock => mock.Execute("identityId", guid), Times.Once);

        Assert.IsType<NotFoundObjectResult>(resp);

        var objectResult = resp as NotFoundObjectResult;
        Assert.IsType<ErrorResponseDto>(objectResult!.Value);

        var errorDto = objectResult!.Value as ErrorResponseDto;

        Assert.Equal("appointment_not_found", errorDto!.ErrorCode);
        Assert.Equal("The appointment could not be found", errorDto!.Error);
    }

    [Fact]
    public async Task GetAppointment_WhenInteractorReturnsAppointment_ReturnsOk()
    {
        var appointment = new Appointment
        {
            Id = Guid.NewGuid()
        };

        var interactorMock = new Mock<IGetAppointmentInteractor>();

        interactorMock.Setup(mock => mock.Execute("identityId", appointment.Id)).ReturnsAsync(appointment);

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.GetAppointment(interactorMock.Object, appointment.Id);

        Assert.IsType<OkObjectResult>(resp);
        var objectResult = resp as OkObjectResult;

        Assert.IsType<AppointmentResponseDto>(objectResult!.Value);
        var data = objectResult!.Value as AppointmentResponseDto;

        Assert.Equal(appointment.Id, data!.Id);

        interactorMock.Verify(mock => mock.Execute("identityId", appointment.Id), Times.Once);
    }

    [Fact]
    public async Task GetAppointment_WhenInteractorThrows_Returns500()
    {
        var appointment = new Appointment
        {
            Id = Guid.NewGuid()
        };

        var interactorMock = new Mock<IGetAppointmentInteractor>();

        interactorMock.Setup(mock => mock.Execute("identityId", appointment.Id)).ThrowsAsync(new Exception());

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.GetAppointment(interactorMock.Object, appointment.Id);

        Assert.IsType<ObjectResult>(resp);
        var objectResult = resp as ObjectResult;

        Assert.IsType<ErrorResponseDto>(objectResult!.Value);
        var error = objectResult!.Value as ErrorResponseDto;

        Assert.Equal(500, objectResult.StatusCode);
        Assert.Equal("unexpected_error", error!.ErrorCode);
        Assert.Equal("An unexpected error occured", error!.Error);
    }

    #endregion GetAppointment

    #region GetAppointments

    [Fact]
    public async Task GetAppointments_WhenInteractorSucceeds_ReturnsOkWithResultFromInteractor()
    {
        var appointments = new List<Appointment>
        {
            new()
            {
                Id = Guid.NewGuid(),
            }
        };

        var startDate = DateTimeOffset.UtcNow;
        var endDate = DateTimeOffset.UtcNow;
        var typeIds = new int[] { 1 };

        var interactorMock = new Mock<IGetAppointmentsInteractor>();

        interactorMock
            .Setup(mock => mock.Execute("identityId", It.IsAny<DateTimeOffset?>(), It.IsAny<DateTimeOffset?>(), It.IsAny<int[]>()))
            .ReturnsAsync(appointments);

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.GetAppointments(interactorMock.Object, startDate, endDate, typeIds);

        interactorMock.Verify(mock => mock.Execute("identityId", startDate, endDate, typeIds), Times.Once);

        Assert.IsType<OkObjectResult>(resp);
        var objectResult = resp as OkObjectResult;

        Assert.IsAssignableFrom<IEnumerable<AppointmentResponseDto>>(objectResult!.Value);
        var data = objectResult!.Value as IEnumerable<AppointmentResponseDto>;

        Assert.Equal(appointments[0].Id, data!.ElementAt(0).Id);
    }

    [Fact]
    public async Task GetAppointments_WhenInteractorThrows_Returns500()
    {
        var interactorMock = new Mock<IGetAppointmentsInteractor>();

        interactorMock
            .Setup(mock => mock.Execute("identityId", It.IsAny<DateTimeOffset?>(), It.IsAny<DateTimeOffset?>(), It.IsAny<int[]>()))
            .ThrowsAsync(new Exception());

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.GetAppointments(interactorMock.Object, null, null, []);

        Assert.IsType<ObjectResult>(resp);
        var objectResult = resp as ObjectResult;

        Assert.IsType<ErrorResponseDto>(objectResult!.Value);
        var error = objectResult!.Value as ErrorResponseDto;

        Assert.Equal(500, objectResult.StatusCode);
        Assert.Equal("unexpected_error", error!.ErrorCode);
        Assert.Equal("An unexpected error occured", error!.Error);
    }

    #endregion GetAppointments

    #region CreateAppointment

    [Fact]
    public async Task CreateAppointment_WhenInteractorSucceeds_ReturnsCreatedWithResultFromInteractor()
    {
        var appointment = new AppointmentRequestDto
        {
            Id = Guid.NewGuid(),
        };

        var interactorMock = new Mock<ICreateAppointmentInteractor>();

        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<Appointment>()))
            .ReturnsAsync(new Appointment { Id = appointment.Id });

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.CreateAppointment(interactorMock.Object, appointment);

        Assert.IsType<CreatedResult>(resp);
        var objectResult = resp as CreatedResult;

        Assert.IsType<AppointmentResponseDto>(objectResult!.Value);
        var data = objectResult!.Value as AppointmentResponseDto;

        Assert.Equal(appointment.Id, data!.Id);

        interactorMock.Verify(mock => mock.Execute(It.Is<Appointment>(a => a.Id == appointment.Id && a.IdentityId == "identityId")), Times.Once);
    }

    [Fact]
    public async Task CreateAppointment_WhenInteractorThrows_Returns500()
    {
        var appointment = new AppointmentRequestDto
        {
            Id = Guid.NewGuid(),
        };

        var interactorMock = new Mock<ICreateAppointmentInteractor>();

        interactorMock.Setup(mock => mock.Execute(It.IsAny<Appointment>())).ThrowsAsync(new Exception());

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.CreateAppointment(interactorMock.Object, appointment);

        Assert.IsType<ObjectResult>(resp);
        var objectResult = resp as ObjectResult;

        Assert.IsType<ErrorResponseDto>(objectResult!.Value);
        var error = objectResult!.Value as ErrorResponseDto;

        Assert.Equal(500, objectResult.StatusCode);
        Assert.Equal("unexpected_error", error!.ErrorCode);
        Assert.Equal("An unexpected error occured", error!.Error);
    }

    [Fact]
    public async Task CreateAppointment_WhenEndTimeIsBeforeStartTime_ReturnsInvalidTimeSpan()
    {
        var appointment = new AppointmentRequestDto
        {
            Id = Guid.NewGuid(),
            TimeStart = DateTimeOffset.UtcNow,
            TimeEnd = DateTimeOffset.UtcNow.AddHours(-1)
        };

        var interactorMock = new Mock<ICreateAppointmentInteractor>();

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.CreateAppointment(interactorMock.Object, appointment);

        Assert.IsType<BadRequestObjectResult>(resp);
        var objectResult = resp as BadRequestObjectResult;

        Assert.IsType<ErrorResponseDto>(objectResult!.Value);
        var error = objectResult!.Value as ErrorResponseDto;

        Assert.Equal("invalid_appointment_time_span", error!.ErrorCode);
        Assert.Equal("The appointment time span is invalid", error!.Error);
    }

    #endregion CreateAppointment

    #region ReplaceAppointment

    [Fact]
    public async Task ReplaceAppointment_WhenInteractorReturnsNull_ReturnsNotFound()
    {
        var appointment = new AppointmentRequestDto
        {
            Id = Guid.NewGuid(),
        };

        var interactorMock = new Mock<IReplaceAppointmentInteractor>();

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ReplaceAppointment(interactorMock.Object, appointment);
        interactorMock.Verify(mock => mock.Execute(It.Is<Appointment>(a => a.Id == appointment.Id && a.IdentityId == "identityId")), Times.Once);

        Assert.IsType<NotFoundObjectResult>(resp);

        var objectResult = resp as NotFoundObjectResult;
        Assert.IsType<ErrorResponseDto>(objectResult!.Value);

        var errorDto = objectResult!.Value as ErrorResponseDto;

        Assert.Equal("appointment_not_found", errorDto!.ErrorCode);
        Assert.Equal("The appointment could not be found", errorDto!.Error);
    }

    [Fact]
    public async Task ReplaceAppointment_WhenInteractorReturnsAppointment_ReturnsOk()
    {
        var appointment = new AppointmentRequestDto
        {
            Id = Guid.NewGuid()
        };

        var updatedAppointment = new Appointment
        {
            Id = appointment.Id
        };

        var interactorMock = new Mock<IReplaceAppointmentInteractor>();

        interactorMock.Setup(mock => mock.Execute(It.IsAny<Appointment>())).ReturnsAsync(updatedAppointment);

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ReplaceAppointment(interactorMock.Object, appointment);

        Assert.IsType<OkObjectResult>(resp);
        var objectResult = resp as OkObjectResult;

        Assert.IsType<AppointmentResponseDto>(objectResult!.Value);
        var data = objectResult!.Value as AppointmentResponseDto;

        Assert.Equal(updatedAppointment.Id, data!.Id);

        interactorMock.Verify(mock => mock.Execute(It.Is<Appointment>(a => a.Id == appointment.Id && a.IdentityId == "identityId")), Times.Once);
    }

    [Fact]
    public async Task ReplaceAppointment_WhenInteractorThrows_Returns500()
    {
        var appointment = new AppointmentRequestDto
        {
            Id = Guid.NewGuid(),
        };

        var interactorMock = new Mock<IReplaceAppointmentInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Appointment>())).ThrowsAsync(new Exception());

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ReplaceAppointment(interactorMock.Object, appointment);

        Assert.IsType<ObjectResult>(resp);
        var objectResult = resp as ObjectResult;

        Assert.IsType<ErrorResponseDto>(objectResult!.Value);
        var error = objectResult!.Value as ErrorResponseDto;

        Assert.Equal(500, objectResult.StatusCode);
        Assert.Equal("unexpected_error", error!.ErrorCode);
        Assert.Equal("An unexpected error occured", error!.Error);
    }

    #endregion ReplaceAppointment

    #region DeleteAppointment

    [Fact]
    public async Task DeleteAppointment_WhenInteractorReturnsFalse_ReturnsNotFound()
    {
        var guid = Guid.NewGuid();

        var interactorMock = new Mock<IDeleteAppointmentInteractor>();

        interactorMock.Setup(mock => mock.Execute("identityId", guid)).ReturnsAsync(false);

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.DeleteAppointment(interactorMock.Object, guid);
        interactorMock.Verify(mock => mock.Execute("identityId", guid), Times.Once);

        Assert.IsType<NotFoundObjectResult>(resp);

        var objectResult = resp as NotFoundObjectResult;
        Assert.IsType<ErrorResponseDto>(objectResult!.Value);

        var errorDto = objectResult!.Value as ErrorResponseDto;

        Assert.Equal("appointment_not_found", errorDto!.ErrorCode);
        Assert.Equal("The appointment could not be found", errorDto!.Error);
    }

    [Fact]
    public async Task DeleteAppointment_WhenInteractorReturnsTrue_ReturnsNoContent()
    {
        var guid = Guid.NewGuid();

        var interactorMock = new Mock<IDeleteAppointmentInteractor>();

        interactorMock.Setup(mock => mock.Execute("identityId", guid)).ReturnsAsync(true);

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.DeleteAppointment(interactorMock.Object, guid);

        Assert.IsType<NoContentResult>(resp);

        interactorMock.Verify(mock => mock.Execute("identityId", guid), Times.Once);
    }

    [Fact]
    public async Task DeleteAppointment_WhenInteractorThrows_ReturnsNotFound()
    {
        var guid = Guid.NewGuid();

        var interactorMock = new Mock<IDeleteAppointmentInteractor>();

        interactorMock.Setup(mock => mock.Execute("identityId", guid)).ThrowsAsync(new Exception());

        var controller = new AppointmentController(Mock.Of<ILogger<AppointmentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.DeleteAppointment(interactorMock.Object, guid);

        Assert.IsType<ObjectResult>(resp);
        var objectResult = resp as ObjectResult;

        Assert.IsType<ErrorResponseDto>(objectResult!.Value);
        var error = objectResult!.Value as ErrorResponseDto;

        Assert.Equal(500, objectResult.StatusCode);
        Assert.Equal("unexpected_error", error!.ErrorCode);
        Assert.Equal("An unexpected error occured", error!.Error);
    }

    #endregion DeleteAppointment
}
