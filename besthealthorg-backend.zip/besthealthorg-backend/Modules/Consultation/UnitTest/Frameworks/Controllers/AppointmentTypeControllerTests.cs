using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsultationModule.Controllers;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsultationModule.Dtos.Response;
using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsultationModule.UnitTest;

public class AppointmentTypeControllerTests
{
    #region GetTypes

    [Fact]
    public async Task GetTypes_WhenInteractorSucceeds_ReturnsOkWithResultFromInteractor()
    {
        var types = new List<AppointmentType>
        {
            new()
            {
                Id = 1,
                Name = "type1"
            }
        };

        var interactorMock = new Mock<IGetAppointmentTypesInteractor>();

        interactorMock.Setup(mock => mock.Execute()).ReturnsAsync(types);

        var controller = new AppointmentTypeController(Mock.Of<ILogger<AppointmentTypeController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.GetTypes(interactorMock.Object);

        Assert.IsType<OkObjectResult>(resp);
        var objectResult = resp as OkObjectResult;

        Assert.IsAssignableFrom<IEnumerable<AppointmentTypeResponseDto>>(objectResult!.Value);
        var data = objectResult!.Value as IEnumerable<AppointmentTypeResponseDto>;

        Assert.Equal(1, data!.ElementAt(0).Id);
        Assert.Equal("type1", data!.ElementAt(0).Name);
    }

    [Fact]
    public async Task GetTypes_WhenInteractorThrows_Returns500()
    {
        var interactorMock = new Mock<IGetAppointmentTypesInteractor>();

        interactorMock.Setup(mock => mock.Execute()).ThrowsAsync(new Exception());

        var controller = new AppointmentTypeController(Mock.Of<ILogger<AppointmentTypeController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.GetTypes(interactorMock.Object);

        Assert.IsType<ObjectResult>(resp);
        var objectResult = resp as ObjectResult;

        Assert.IsType<ErrorResponseDto>(objectResult!.Value);
        var error = objectResult!.Value as ErrorResponseDto;

        Assert.Equal(500, objectResult.StatusCode);
        Assert.Equal("unexpected_error", error!.ErrorCode);
        Assert.Equal("An unexpected error occured", error!.Error);
    }

    #endregion GetTypes
}
