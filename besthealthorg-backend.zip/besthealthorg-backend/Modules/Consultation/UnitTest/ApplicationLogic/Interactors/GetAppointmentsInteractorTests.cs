using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsultationModule.UnitTest;

public class GetAppointmentsInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_CallsRepoAndReturnsResult()
    {
        const string identityId = "identityId";
        var startDate = DateTimeOffset.UtcNow;
        var endDate = DateTimeOffset.UtcNow;
        var typeIds = new int[] { 1, 2 };

        var appointments = new List<Appointment>
        {
            new()
            {
                Id = Guid.NewGuid(),
                IdentityId = "identityId",
            },
            new()
            {
                Id = Guid.NewGuid(),
                IdentityId = "identityId",
            }
        };

        var repoMock = new Mock<IAppointmentRepository>();

        repoMock.Setup(mock => mock.GetByIdentityId(identityId, startDate, endDate, typeIds)).ReturnsAsync(appointments);

        var interactor = new GetAppointmentsInteractor(repoMock.Object);

        var result = await interactor.Execute(identityId, startDate, endDate, typeIds);

        Assert.Equal(appointments[0], result.ElementAt(0));
        Assert.Equal(appointments[1], result.ElementAt(1));

        repoMock.Verify(mock => mock.GetByIdentityId(identityId, startDate, endDate, typeIds), Times.Once);
    }

    #endregion Execute
}
