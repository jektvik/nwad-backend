using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsultationModule.UnitTest;

public class DeleteAppointmentInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenAppointmentDoesNotExist_ReturnsFalse()
    {
        var repoMock = new Mock<IAppointmentRepository>();

        var interactor = new DeleteAppointmentInteractor(repoMock.Object);

        var result = await interactor.Execute("identityId", Guid.NewGuid());

        Assert.False(result);
        repoMock.Verify(mock => mock.Delete(It.IsAny<Guid>()), Times.Never);
    }

    [Fact]
    public async Task Execute_WhenAppointmentExistsButIsNotOwnedByProvidedIdentity_ReturnsFalse()
    {
        var appointment = new Appointment
        {
            Id = Guid.NewGuid(),
            IdentityId = "identityId"
        };

        var repoMock = new Mock<IAppointmentRepository>();

        repoMock.Setup(mock => mock.Get(appointment.Id)).ReturnsAsync(appointment);

        var interactor = new DeleteAppointmentInteractor(repoMock.Object);

        var result = await interactor.Execute("otherIdentityId", appointment.Id);

        Assert.False(result);
        repoMock.Verify(mock => mock.Delete(It.IsAny<Guid>()), Times.Never);
    }

    [Fact]
    public async Task Execute_WhenAppointmentExistsAndIsOwnedByProvidedIdentity_ReturnsTrue()
    {
        var appointment = new Appointment
        {
            Id = Guid.NewGuid(),
            IdentityId = "identityId"
        };

        var repoMock = new Mock<IAppointmentRepository>();

        repoMock.Setup(mock => mock.Get(appointment.Id)).ReturnsAsync(appointment);

        var interactor = new DeleteAppointmentInteractor(repoMock.Object);

        var result = await interactor.Execute("identityId", appointment.Id);

        Assert.True(result);
        repoMock.Verify(mock => mock.Delete(It.IsAny<Guid>()), Times.Once);
    }

    #endregion Execute
}
