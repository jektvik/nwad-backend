using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.NoteModule.Domain.Entities;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsultationModule.UnitTest;

public class ReplaceAppointmentInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenAppointmentDoesNotExist_ReturnsNull()
    {
        var appointment = new Appointment
        {
            Id = Guid.NewGuid(),
            IdentityId = "identiyId"
        };

        var repoMock = new Mock<IAppointmentRepository>();
        var noteRepoMock = new Mock<INoteRepository>();

        var interactor = new ReplaceAppointmentInteractor(repoMock.Object, noteRepoMock.Object);

        var result = await interactor.Execute(appointment);

        Assert.Null(result);
        repoMock.Verify(mock => mock.Replace(It.IsAny<Appointment>()), Times.Never);
    }

    [Fact]
    public async Task Execute_WhenAppointmentExistsButIsNotOwnedByProvidedIdentity_ReturnsNull()
    {
        var appointment = new Appointment
        {
            Id = Guid.NewGuid(),
            IdentityId = "identityId"
        };

        var newAppointment = new Appointment
        {
            Id = appointment.Id,
            IdentityId = "otherIdentityId"
        };

        var repoMock = new Mock<IAppointmentRepository>();

        repoMock.Setup(mock => mock.Get(appointment.Id)).ReturnsAsync(appointment);

        var noteRepoMock = new Mock<INoteRepository>();

        var interactor = new ReplaceAppointmentInteractor(repoMock.Object, noteRepoMock.Object);

        var result = await interactor.Execute(newAppointment);

        Assert.Null(result);
        repoMock.Verify(mock => mock.Replace(It.IsAny<Appointment>()), Times.Never);
    }

    [Fact]
    public async Task Execute_WhenAppointmentContainsNoteOwnedByOtherIdentity_ThrowsInvalidOperatioException()
    {
        var existingNoteGuid = Guid.NewGuid();

        var appointment = new Appointment
        {
            Id = Guid.NewGuid(),
            IdentityId = "identityId",
            Notes = [new Note(existingNoteGuid, "identityId", "title", "content", DateTimeOffset.UtcNow)]
        };

        var repoMock = new Mock<IAppointmentRepository>();

        repoMock.Setup(mock => mock.Get(appointment.Id)).ReturnsAsync(appointment);
        repoMock.Setup(mock => mock.Replace(appointment)).ReturnsAsync(appointment);

        var noteRepoMock = new Mock<INoteRepository>();

        noteRepoMock
            .Setup(mock => mock.GetMany(It.IsAny<IEnumerable<Guid>>()))
            .ReturnsAsync([new Note(existingNoteGuid, "otherId", "title", "content", DateTimeOffset.UtcNow)]);

        var interactor = new ReplaceAppointmentInteractor(repoMock.Object, noteRepoMock.Object);

        await Assert.ThrowsAsync<InvalidOperationException>(async () => await interactor.Execute(appointment));
    }

    [Fact]
    public async Task Execute_WhenAppointmentExistsAndIsOwnedByProvidedIdentity_ReturnsAppointment()
    {
        var appointment = new Appointment
        {
            Id = Guid.NewGuid(),
            IdentityId = "identityId"
        };

        var repoMock = new Mock<IAppointmentRepository>();

        repoMock.Setup(mock => mock.Get(appointment.Id)).ReturnsAsync(appointment);
        repoMock.Setup(mock => mock.Replace(appointment)).ReturnsAsync(appointment);

        var noteRepoMock = new Mock<INoteRepository>();

        var interactor = new ReplaceAppointmentInteractor(repoMock.Object, noteRepoMock.Object);

        var result = await interactor.Execute(appointment);

        Assert.Equal(appointment, result);
        repoMock.Verify(mock => mock.Replace(It.IsAny<Appointment>()), Times.Once);
    }

    #endregion Execute
}
