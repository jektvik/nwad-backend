using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsultationModule.UnitTest;

public class GetAppointmentTypesInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_CallsRepoAndReturnsResult()
    {
        var types = new List<AppointmentType>
        {
            new()
            {
                Id = 1,
                Name = "name1"
            },
            new()
            {
                Id = 2,
                Name = "name2"
            }
        };

        var repoMock = new Mock<IAppointmentTypeRepository>();

        repoMock.Setup(mock => mock.GetAll()).ReturnsAsync(types);

        var interactor = new GetAppointmentTypesInteractor(repoMock.Object);

        var result = await interactor.Execute();

        Assert.Equal(types[0], result.ElementAt(0));
        Assert.Equal(types[1], result.ElementAt(1));

        repoMock.Verify(mock => mock.GetAll(), Times.Once);
    }

    #endregion Execute
}
