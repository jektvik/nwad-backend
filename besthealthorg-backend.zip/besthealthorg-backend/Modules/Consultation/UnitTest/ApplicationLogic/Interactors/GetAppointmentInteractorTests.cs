using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsultationModule.UnitTest;

public class GetAppointmentInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenAppointmentDoesNotExist_ReturnsNull()
    {
        var repoMock = new Mock<IAppointmentRepository>();

        var interactor = new GetAppointmentInteractor(repoMock.Object);

        var result = await interactor.Execute("identityId", Guid.NewGuid());

        Assert.Null(result);
    }

    [Fact]
    public async Task Execute_WhenAppointmentExistsButIsNotOwnedByProvidedIdentity_ReturnsNull()
    {
        var appointment = new Appointment
        {
            Id = Guid.NewGuid(),
            IdentityId = "identityId"
        };

        var repoMock = new Mock<IAppointmentRepository>();

        repoMock.Setup(mock => mock.Get(appointment.Id)).ReturnsAsync(appointment);

        var interactor = new GetAppointmentInteractor(repoMock.Object);

        var result = await interactor.Execute("otherIdentityId", appointment.Id);

        Assert.Null(result);
    }

    [Fact]
    public async Task Execute_WhenAppointmentExistsAndIsOwnedByProvidedIdentity_ReturnsAppointment()
    {
        var appointment = new Appointment
        {
            Id = Guid.NewGuid(),
            IdentityId = "identityId"
        };

        var repoMock = new Mock<IAppointmentRepository>();

        repoMock.Setup(mock => mock.Get(appointment.Id)).ReturnsAsync(appointment);

        var interactor = new GetAppointmentInteractor(repoMock.Object);

        var result = await interactor.Execute("identityId", appointment.Id);

        Assert.Equal(appointment, result);
    }

    #endregion Execute
}
