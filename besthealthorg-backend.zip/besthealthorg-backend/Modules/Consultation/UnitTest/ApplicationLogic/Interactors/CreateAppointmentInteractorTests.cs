using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsultationModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsultationModule.Domain.Entities;
using NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.NoteModule.Domain.Entities;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsultationModule.UnitTest;

public class CreateAppointmentInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_CallsRepoAndReturnsResult()
    {
        var appointment = new Appointment
        {
            Id = Guid.NewGuid(),
            IdentityId = "identityId",
        };

        var repoMock = new Mock<IAppointmentRepository>();

        repoMock.Setup(mock => mock.Create(It.IsAny<Appointment>())).ReturnsAsync(appointment);

        var noteRepoMock = new Mock<INoteRepository>();

        var interactor = new CreateAppointmentInteractor(repoMock.Object, noteRepoMock.Object);

        var result = await interactor.Execute(appointment);

        Assert.Equal(appointment, result);

        repoMock.Verify(mock => mock.Create(appointment), Times.Once);
    }

    [Fact]
    public async Task Execute_WhenAppointmentContainsNoteOwnedByOtherIdentity_ThrowsInvalidOperatioException()
    {
        var existingNoteGuid = Guid.NewGuid();

        var appointment = new Appointment
        {
            Id = Guid.NewGuid(),
            IdentityId = "identityId",
            Notes = [new Note(existingNoteGuid, "identityId", "title", "content", DateTimeOffset.UtcNow)]
        };

        var repoMock = new Mock<IAppointmentRepository>();

        repoMock.Setup(mock => mock.Get(appointment.Id)).ReturnsAsync(appointment);
        repoMock.Setup(mock => mock.Replace(appointment)).ReturnsAsync(appointment);

        var noteRepoMock = new Mock<INoteRepository>();

        noteRepoMock
            .Setup(mock => mock.GetMany(It.IsAny<IEnumerable<Guid>>()))
            .ReturnsAsync([new Note(existingNoteGuid, "otherId", "title", "content", DateTimeOffset.UtcNow)]);

        var interactor = new CreateAppointmentInteractor(repoMock.Object, noteRepoMock.Object);

        await Assert.ThrowsAsync<InvalidOperationException>(async () => await interactor.Execute(appointment));
    }

    #endregion Execute
}
