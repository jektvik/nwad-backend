using NwadHealth.Besthealthorg.Foundation.Interfaces;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace NwadHealth.Besthealthorg.Foundation.SendGrid;

/// <summary>
/// A SendGrid implementation of IMailer
/// </summary>
public class SendGridMailer : IMailer
{
    private readonly ISendGridClient _sendGridClient;

    /// <summary>
    /// Initializes the SendGridMailer
    /// </summary>
    /// <param name="sendGridClient">The SendGrid client to use</param>
    public SendGridMailer(ISendGridClient sendGridClient)
    {
        _sendGridClient = sendGridClient;
    }

    /// <summary>
    /// Sends a mail from fromEmail to toEmail with content as HTML
    /// </summary>
    /// <param name="fromEmail">The email address to send from</param>
    /// <param name="fromName">The name to send from</param>
    /// <param name="toEmail">The email address to send to</param>
    /// <param name="subject">The subject of the email to send</param>
    /// <param name="content">The HTML content to send</param>
    /// <exception cref="Exception">Thrown if the mail could not be sent</exception>
    /// <exception cref="SendGridException">Thrown if the mail could not be sent</exception>
    public async Task SendHtml(string fromEmail, string fromName, string toEmail, string subject, string content)
    {
        var message = new SendGridMessage
        {
            From = new(fromEmail, fromName),
            Subject = subject,
            HtmlContent = content
        };

        message.AddTo(toEmail);

        var resp = await _sendGridClient.SendEmailAsync(message);

        if (!resp.IsSuccessStatusCode)
        {
            throw new SendGridException("Failed to send email", resp);
        }
    }
}
