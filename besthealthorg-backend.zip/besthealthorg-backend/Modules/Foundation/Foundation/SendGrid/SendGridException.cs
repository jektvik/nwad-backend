using SendGrid;

namespace NwadHealth.Besthealthorg.Foundation.SendGrid;

/// <summary>
/// Represents an error that happens during communication with SendGrid
/// </summary>
public class SendGridException : Exception
{
    /// <summary>
    /// The HTTP response received during the Auth0 request
    /// </summary>
    /// <remarks>Note: will be lost on serialization</remarks>
    public Response? Response { get; }

    /// <summary>
    /// Initializes the SendGridException
    /// </summary>
    /// <param name="message">The message that describes the error.</param>
    /// <param name="response">The response received during SendGrid communication</param>
    public SendGridException(string message, Response response)
        : base(message)
    {
        Response = response;
    }

    /// <summary>
    /// Initializes the SendGridException
    /// </summary>
    /// <param name="message">The message that describes the error.</param>
    /// <param name="innerException">The exception that is the cause of the current exception</param>
    public SendGridException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
