﻿using System.Text.Json.Serialization;

namespace NwadHealth.Besthealthorg.Foundation.Pagination;

/// <summary>
/// Represents a paginated set of items of a given type.
/// </summary>
/// <typeparam name="TEntity">The type of the entities being paginated.</typeparam>
/// <param name="pageIndex">The current page index (starting from 0), indicating which page of data is being retrieved.</param>
/// <param name="pageSize">The number of items per page, controlling how many items are included in each page of results.</param>
/// <param name="count">The total number of items across all pages. This represents the full dataset count, not just the current page.</param>
/// <param name="data">The data for the current page, represented as an enumerable collection of <typeparamref name="TEntity"/> instances.</param>
public class PaginatedItems<TEntity>(int pageIndex, int pageSize, int count, IEnumerable<TEntity> data) where TEntity : class
{
    /// <summary>
    /// The current page index (starting from 0), indicating which page of data is being retrieved.
    /// </summary>
    [JsonPropertyName("page")]
    public int PageIndex { get; } = pageIndex;

    /// <summary>
    /// The number of items per page, controlling how many items are included in each page of results.
    /// </summary>
    [JsonPropertyName("pageSize")]
    public int PageSize { get; } = pageSize;

    /// <summary>
    /// The total number of items across all pages. This represents the full dataset count, not just the current page.
    /// </summary>
    [JsonPropertyName("totalItems")]
    public int Count { get; } = count;

    /// <summary>
    /// The total number of pages. This is calculated based on the total item count and the page size.
    /// </summary>
    [JsonPropertyName("totalPages")]
    public int PageCount => (PageSize > 0) ? (int)Math.Ceiling(Count / (float)PageSize) : 0;

    /// <summary>
    /// The data for the current page, represented as an enumerable collection of <typeparamref name="TEntity"/> instances.
    /// </summary>
    public IEnumerable<TEntity> Data { get;} = data;
}
