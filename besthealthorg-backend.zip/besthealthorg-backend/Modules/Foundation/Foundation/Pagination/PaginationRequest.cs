﻿namespace NwadHealth.Besthealthorg.Foundation.Pagination;

/// <summary>
/// Represents a request for paginated data, specifying the size of the page and the index of the page to retrieve.
/// </summary>
/// <param name="PageSize">
/// The number of items to include on each page. The default value is 20.
/// </param>
/// <param name="Page">
/// The index of the page to retrieve, starting from 0. The default value is 0, which means the first page.
/// </param>
public record PaginationRequest(
    int PageSize = 20,
    int Page = 0
)
{
    public (int pageSize, int pageIndex) Limit(long totalCount, int maxPageSize)
    {
        var pageSize = Math.Clamp(PageSize, 1, maxPageSize);

        // Calculate the total number of pages
        var totalPages = (int)Math.Ceiling((double)totalCount / PageSize);

        // Adjust page index to ensure it's within valid range (0-based)
        var pageIndex = (Page >= totalPages) ? totalPages - 1 : Page;

        // Ensure page index is not negative
        pageIndex = Math.Max(pageIndex, 0);

        return (pageSize, pageIndex);
    }
}
