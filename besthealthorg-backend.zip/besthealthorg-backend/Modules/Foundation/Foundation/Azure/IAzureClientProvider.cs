using Microsoft.Azure.Cosmos;

namespace NwadHealth.Besthealthorg.Foundation.Azure;

/// <summary>
/// Interface representing functionality for providing Azure clients from connection strings
/// </summary>
public interface IAzureClientProvider
{
    /// <summary>
    /// Creates a new, or gets an existing CosmosClient that is already connected with the specified connection string
    /// </summary>
    /// <param name="connectionString">The connection string to get a client for</param>
    /// <returns>A CosmosClient pointing to the given connection string</returns>
    public CosmosClient GetCosmosClient(string connectionString);
}
