using System.Collections.Concurrent;
using Microsoft.Azure.Cosmos;

namespace NwadHealth.Besthealthorg.Foundation.Azure;

/// <summary>
/// Responsible for providing Azure clients from connection strings
/// </summary>
public class AzureClientProvider : IAzureClientProvider
{
    private ConcurrentDictionary<string, CosmosClient> CosmosClients { get; } = new();

    /// <summary>
    /// Creates a new, or gets an existing CosmosClient that is already connected with the specified connection string
    /// </summary>
    /// <param name="connectionString">The connection string to get a client for</param>
    /// <returns>A CosmosClient pointing to the given connection string</returns>
    public CosmosClient GetCosmosClient(string connectionString)
    {
        return CosmosClients.GetOrAdd(connectionString, key =>
            new(key, new()
            {
                SerializerOptions = new()
                {
                    PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase
                }
            }));
    }
}
