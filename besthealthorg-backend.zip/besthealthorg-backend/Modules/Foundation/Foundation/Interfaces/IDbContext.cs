namespace NwadHealth.Besthealthorg.Foundation.Interfaces;

public interface IDbContext
{
    /// <summary>
    /// Saves all changes made in this context to the database.
    /// </summary>
    /// <param name="cancellationToken">A <see cref="CancellationToken" /> to observe while waiting for the task to complete.</param>
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
