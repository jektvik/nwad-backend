using NwadHealth.Besthealthorg.Foundation.Events;

namespace NwadHealth.Besthealthorg.Foundation.Interfaces;

/// <summary>
/// Interface representing a repository for writing Audit Logs
/// </summary>
public interface IAuditLogRepository
{
    /// <summary>
    /// Writes an event to the audit log
    /// </summary>
    /// <param name="paceEvent">The event to write</param>
    Task WriteRecord(PaceEvent paceEvent);

    /// <summary>
    /// Sets retention time on all events containing the identityId
    /// </summary>
    /// <param name="identityId">The id of the identity, whose events should be marked</param>
    Task SetRetentionOnRecords(string identityId);
}
