namespace NwadHealth.Besthealthorg.Foundation.Interfaces;

/// <summary>
/// Interface representing a component capable of sending emails
/// </summary>
public interface IMailer
{
    /// <summary>
    /// Sends a mail from fromEmail to toEmail with content as HTML
    /// </summary>
    /// <param name="fromEmail">The email address to send from</param>
    /// <param name="fromName">The name to send from</param>
    /// <param name="toEmail">The email address to send to</param>
    /// <param name="subject">The subject of the email to send</param>
    /// <param name="content">The HTML content to send</param>
    public Task SendHtml(string fromEmail, string fromName, string toEmail, string subject, string content);
}
