namespace NwadHealth.Besthealthorg.Foundation.Interfaces;

public interface IAnonymizable
{
    /// <summary>
    /// Overwrites the identityId for all data relating to the identity, with the supplied anonymizationId
    /// </summary>
    /// <param name="identityId">The ID of the identity for which to anonymize personal data</param>
    /// <param name="anonymizationId">The value to use for overwriting the identityId</param>
    Task AnonymizePersonalData(string identityId, string anonymizationId);
}
