﻿namespace NwadHealth.Besthealthorg.Foundation.Dtos;

/// <summary>
/// Represents a BESTHEALTHORG error response
/// </summary>
public class ErrorResponseDto
{
    /// <summary>
    /// The error code identifying the error
    /// </summary>
    public string ErrorCode { get; set; } = string.Empty;

    /// <summary>
    /// The error message
    /// </summary>
    public string Error { get; set; } = string.Empty;
}
