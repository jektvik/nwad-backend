using System.Linq.Expressions;
using System.Reflection;
using NwadHealth.Besthealthorg.Foundation.Sorting;

namespace NwadHealth.Besthealthorg.Foundation.Extensions;

/// <summary>
/// Extension methods for sorting IQueryable collections.
/// </summary>
public static class SortExtensions
{
    /// <summary>
    /// Sorts an IQueryable collection by a given property and sort order.
    /// </summary>
    /// <typeparam name="T">The type of the items in the IQueryable.</typeparam>
    /// <param name="items">The IQueryable collection to be sorted.</param>
    /// <param name="sortBy">The name of the property to sort by (case-insensitive).</param>
    /// <param name="sortOrder">The order of sorting: "asc" for ascending, "desc" for descending.</param>
    /// <returns>An IOrderedQueryable with the applied sorting.</returns>
    /// <exception cref="ArgumentException">
    /// Thrown when the property specified by <paramref name="sortBy"/> does not exist on type <typeparamref name="T"/>,
    /// or when the <paramref name="sortOrder"/> is invalid.
    /// </exception>
    public static IOrderedQueryable<T> SortBy<T>(this IQueryable<T> items, string sortBy, SortOrder sortOrder)
    {
        // If no sortBy is provided, return items without sorting
        if (string.IsNullOrWhiteSpace(sortBy))
        {
            return (IOrderedQueryable<T>)items;
        }

        // Use reflection to get information about the property to sort by from the entity type <T>.
        var sortByPropInfo = typeof(T).GetProperty(
            sortBy,
            BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);

        if (sortByPropInfo is null)
        {
            throw new ArgumentException($"No property '{sortBy}' found on type '{typeof(T).Name}'");
        }

        // Create an expression parameter that represents each item in the collection (i.e., 'x' in x => x.Property).
        var parameter = Expression.Parameter(typeof(T), "x");
        // Create a member access expression to represent accessing the property (i.e., x.Property).
        var propertyAccess = Expression.MakeMemberAccess(parameter, sortByPropInfo);
        // Combine the two above to create a lambda expression
        // to use in the OrderBy or OrderByDescending methods (i.e., x => x.Property).
        var orderByExpression = Expression.Lambda(propertyAccess, parameter);

        // Determine if sorting is ascending or descending
        var sortCommand = sortOrder switch
        {
            SortOrder.Asc => nameof(System.Linq.Queryable.OrderBy),
            SortOrder.Desc => nameof(System.Linq.Queryable.OrderByDescending),
            _ => throw new ArgumentException($"Invalid sort order: {sortOrder}"),
        };

        // Use Expression.Call to build the LINQ OrderBy/OrderByDescending method call dynamically.
        // This will create the actual method invocation at runtime.
        var resultExpression = Expression.Call(
            typeof(System.Linq.Queryable),            // The class where OrderBy/OrderByDescending resides
            sortCommand,                              // Either "OrderBy" or "OrderByDescending"
            [typeof(T), sortByPropInfo.PropertyType], // The types for the generic method: entity type (T) and property type
            items.Expression,                         // The original IQueryable expression
            Expression.Quote(orderByExpression)       // The lambda expression (x => x.Property) to be applied in the sorting
        );

        // Create the sorted query and return it as IOrderedQueryable.
        // This will defer execution until the IQueryable is actually enumerated (e.g., when ToList() is called).
        return (IOrderedQueryable<T>)items.Provider.CreateQuery<T>(resultExpression);
    }
}
