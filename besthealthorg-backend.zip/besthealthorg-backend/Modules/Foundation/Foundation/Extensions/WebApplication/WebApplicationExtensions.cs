using System.Text.RegularExpressions;

namespace NwadHealth.Besthealthorg.Foundation.Extensions.WebApp;

/// <summary>
/// Represents the HttpVerb used for the request
/// </summary>
public enum HttpVerb
{
    Get = 0,
    Post = 1,
    Put = 2,
    Delete = 3,
    Patch = 4,
}

/// <summary>
/// Represents a URL rewrite
/// </summary>
/// <param name="Verb">The HTTP verb that this rewrite applies to</param>
/// <param name="FromPathPattern">The pattern that if matched, the path is rewritten</param>
/// <param name="ToPath">The new path to rewrite to</param>
public record UrlRewrite(
    HttpVerb Verb,
    string FromPathPattern,
    string ToPath
);

public static class WebApplicationExtensions
{
    private static readonly TimeSpan REGEX_TIMEOUT = TimeSpan.FromMilliseconds(100);

    /// <summary>
    /// Sets up the path rewrite middleware, this MUST be the first part of your HTTP pipeline
    /// </summary>
    /// <param name="app">The instance being extended</param>
    /// <param name="rewrites">The rewrite rules to configure</param>
    /// <returns>The WebApplication with the path rewrite middleware attached</returns>
    public static WebApplication UsePacePathRewrite(this WebApplication app, IEnumerable<UrlRewrite> rewrites)
    {
        app.Use(async (context, next) =>
        {
            HttpVerb? verb = context.Request.Method.ToLower() switch
            {
                "get" => HttpVerb.Get,
                "post" => HttpVerb.Post,
                "put" => HttpVerb.Put,
                "delete" => HttpVerb.Delete,
                "patch" => HttpVerb.Patch,
                _ => null
            };

            var match = rewrites.FirstOrDefault(rewrite =>
                rewrite.Verb == verb && Regex.IsMatch(context.Request.Path, rewrite.FromPathPattern, RegexOptions.IgnoreCase, REGEX_TIMEOUT));

            if (match is not null)
            {
                context.Request.Path = match.ToPath;
            }

            await next(context);
        });

        return app;
    }
}
