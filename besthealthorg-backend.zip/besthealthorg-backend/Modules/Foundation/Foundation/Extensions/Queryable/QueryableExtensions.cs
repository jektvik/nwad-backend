using System.Linq.Expressions;

namespace NwadHealth.Besthealthorg.Foundation.Extensions.Queryable;

/// <summary>
/// Provides extensions for IQueryable
/// </summary>
public static class QueryableExtensions
{
    /// <summary>
    /// Conditionally adds a where clause to the query
    /// </summary>
    /// <typeparam name="T">The type of the query</typeparam>
    /// <param name="predicate">The predicate to use for filtering</param>
    /// <param name="shouldAddPredicate">Whether the predicate should be added</param>
    /// <returns>The query, conditionally with the where clause added</returns>
    public static IQueryable<T> MaybeWhere<T>(this IQueryable<T> query, Expression<Func<T, bool>> predicate, bool shouldAddPredicate)
    {
        if (!shouldAddPredicate)
        {
            return query;
        }

        return query.Where<T>(predicate);
    }
}
