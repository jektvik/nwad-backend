namespace NwadHealth.Besthealthorg.Foundation.Extensions.Controller;

/// <summary>
/// Provides extensions for HttpContext
/// </summary>
public static class HttpContextExtensions
{
    /// <summary>
    /// Retrieves the id of the currently authenticated identity from the HttpContext.
    /// </summary>
    /// <param name="context">The instance being extended</param>
    /// <returns>The identity id</returns>
    /// <exception cref="InvalidOperationException">Thrown if there is no identity id in the context. E.g. used in unauthorized endpoint</exception>
    public static string CurrentIdentityId(this HttpContext context) =>
        context.User.Identity?.Name ?? throw new InvalidOperationException("No identity id was found. Is the endpoint authorized?");
}
