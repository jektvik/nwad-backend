using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.Foundation.SendGrid;
using Microsoft.Extensions.DependencyInjection.Extensions;
using SendGrid.Extensions.DependencyInjection;

namespace NwadHealth.Besthealthorg.Foundation.Extensions.ServiceCollection;

/// <summary>
/// Provides extensions for IServiceCollection
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Makes the IMailer (specifically SendGridMailer) available for dependency injection
    /// </summary>
    /// <param name="services">The instance being extended</param>
    /// <param name="sendGridApiKey">The SendGrid API key to use for authorization</param>
    public static IServiceCollection AddSendGridMailer(this IServiceCollection services, string sendGridApiKey)
    {
        services.AddSendGrid(options => options.ApiKey = sendGridApiKey);

        services.TryAddScoped<IMailer, SendGridMailer>();

        return services;
    }

    /// <summary>
    /// Returns whether or not the service collection contains a service of a specific type
    /// </summary>
    /// <typeparam name="TService">The type of the service to check for</typeparam>
    /// <param name="services">The instance being extended</param>
    public static bool HasService<TService>(this IServiceCollection services)
    {
        return services.Any(service => service.ServiceType == typeof(TService));
    }
}
