namespace Foundation.Extensions;

/// <summary>
/// Provides extension methods for IEnumerable to calculate the difference between two collections.
/// </summary>
public static class EnumerableExtensions
{
    /// <summary>
    /// Compares two collections (existing and new) based on a specified key and a comparison function.
    /// The method categorizes items into new (inserts), modified (updates), removed (deletes), and unchanged.
    /// </summary>
    /// <typeparam name="TExisting">The type of the items in the existing collection.</typeparam>
    /// <typeparam name="TNew">The type of the items in the new collection.</typeparam>
    /// <typeparam name="TKey">The type of the key used to match items between collections.</typeparam>
    /// <param name="existingItems">The existing collection (source) to compare against.</param>
    /// <param name="newItemsList">The new collection (destination) to compare with the existing collection.</param>
    /// <param name="existingKeySelector">A function to select the key from items in the existing collection.</param>
    /// <param name="newKeySelector">A function to select the key from items in the new collection.</param>
    /// <param name="comparisonFunc">
    /// A function to compare an existing item with a new item to determine if they are considered the same (unchanged)
    /// or need to be updated.
    /// </param>
    /// <returns>
    /// A tuple containing four lists:
    /// <list type="bullet">
    /// <item><description><c>newItems</c>: Items that exist in the new collection but not in the existing collection (inserts).</description></item>
    /// <item><description><c>modifiedItems</c>: Pairs of items that exist in both collections but have differences (updates).</description></item>
    /// <item><description><c>removedItems</c>: Items that exist in the existing collection but not in the new collection (deletes).</description></item>
    /// <item><description><c>unchangedItems</c>: Items that exist in both collections and are considered the same (unchanged).</description></item>
    /// </list>
    /// </returns>
    public static (
        IList<TNew> newItems,
        IList<Tuple<TExisting, TNew>> modifiedItems,
        IList<TExisting> removedItems,
        IList<TExisting> unchangedItems)
        Diff<TExisting, TNew, TKey>(
            this IEnumerable<TExisting> existingItems,
            IEnumerable<TNew> newItemsList,
            Func<TExisting, TKey> existingKeySelector,
            Func<TNew, TKey> newKeySelector,
            Func<TExisting, TNew, bool> comparisonFunc)
                where TKey : IEquatable<TKey>
    {
        // Create a dictionary from the existing items for lookup by key
        var existingItemsDict = existingItems.ToDictionary(existingKeySelector, v => v);

        var newItems = new List<TNew>();
        var modifiedItems = new List<Tuple<TExisting, TNew>>();
        var unchangedItems = new List<TExisting>();

        foreach (var newItem in newItemsList)
        {
            // Get the key for the new item
            var newItemKey = newKeySelector(newItem);

            // Check if the key exists in the dictionary of existing items
            if (existingItemsDict.Remove(newItemKey, out var existingItem))
            {
                // If the items match based on the comparison function, mark as unchanged
                if (comparisonFunc(existingItem, newItem))
                {
                    unchangedItems.Add(existingItem);
                }
                else
                {
                    // If the items differ, mark as modified
                    modifiedItems.Add(Tuple.Create(existingItem, newItem));
                }
            }
            else
            {
                // If the item is new, add it to the new items list
                newItems.Add(newItem);
            }
        }

        // Remaining items in the dictionary are those that were removed in the new list
        var removedItems = existingItemsDict.Values.ToList();

        return (newItems, modifiedItems, removedItems, unchangedItems);
    }
}
