using NwadHealth.Besthealthorg.Foundation.Pagination;

namespace NwadHealth.Besthealthorg.Foundation.Extensions
{
  public static class PaginatedItemsExtensions
  {
    public static PaginatedItems<TResult> MapItems<T, TResult>(
      this PaginatedItems<T> paginatedItems,
      Func<T, TResult> transform)
      where T : class
      where TResult : class
    {
      var transformedItems = paginatedItems.Data.Select(transform).ToList();
      return new(
        pageIndex: paginatedItems.PageIndex,
        pageSize: paginatedItems.PageSize,
        count: paginatedItems.Count,
        data: transformedItems);
    }
  }
}
