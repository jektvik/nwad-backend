using NwadHealth.Besthealthorg.Foundation.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace NwadHealth.Besthealthorg.Foundation.Extensions.Controller;

/// <summary>
/// ControllerBase extensions for creating error responses
/// </summary>
public static class ErrorResponseExtensions
{
    /// <summary>
    /// Created a country code not set error result
    /// </summary>
    public static IActionResult CountryCodeNotSetError(this ControllerBase controller) =>
        controller.BadRequest(CreateErrorResponseDto("country_code_not_set", "The authenticated user does not have a country set"));

    /// <summary>
    /// Creates an unexpected error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>An unexpected error result</returns>
    public static IActionResult UnexpectedError(this ControllerBase controller) =>
        controller.StatusCode(500, CreateErrorResponseDto("unexpected_error", "An unexpected error occured"));

    /// <summary>
    /// Creates an invalid sortby value error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <param name="sortByValue">The value which caused the error to occur</param>
    /// <returns>An invalid sortby value error result</returns>
    public static IActionResult InvalidSortByValueError(this ControllerBase controller, string? sortByValue) =>
        controller.BadRequest(CreateErrorResponseDto(
            "invalid_sort_value",
            $"The sort value '{sortByValue}' is invalid"));

    public static ErrorResponseDto CreateErrorResponseDto(string errorCode, string errorMessage)
    {
        return new()
        {
            ErrorCode = errorCode,
            Error = errorMessage
        };
    }
}
