using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Linq;

namespace NwadHealth.Besthealthorg.Foundation.Extensions.Cosmos;

/// <summary>
/// Provides extensions for Cosmos Containers
/// </summary>
public static class ContainerExtensions
{
    /// <summary>
    /// Gets an enumerable of items by the provided query and type from the container
    /// </summary>
    /// <typeparam name="T">The type of the items in the container</typeparam>
    /// <typeparam name="U">The type of the items to return</typeparam>
    /// <param name="container">The instance being extended</param>
    /// <param name="buildQuery">The function used for building the query</param>
    /// <returns>An enumerable of type U</returns>
    public static async Task<IEnumerable<U>> GetByQuery<T, U>(this Container container, Func<IQueryable<T>, IQueryable<U>> buildQuery)
    {
        var query = buildQuery(container.GetItemLinqQueryable<T>());
        var iterator = query.ToFeedIterator();

        var result = new List<U>();

        while (iterator.HasMoreResults)
        {
            result.AddRange(await iterator.ReadNextAsync());
        }

        return result;
    }

    /// <summary>
    /// Gets an enumerable of items by the provided query and type from the container
    /// </summary>
    /// <typeparam name="T">The type of the items in the container</typeparam>
    /// <param name="container">The instance being extended</param>
    /// <param name="buildQuery">The function used for building the query</param>
    /// <returns>An enumerable of type T</returns>
    public static async Task<IEnumerable<T>> GetByQuery<T>(this Container container, Func<IQueryable<T>, IQueryable<T>> buildQuery) =>
        await container.GetByQuery<T, T>(buildQuery);

    /// <summary>
    /// Gets an enumerable of every item in the container
    /// </summary>
    /// <typeparam name="T">The type of the items in the container</typeparam>
    /// <param name="container">The instance being extended</param>
    /// <returns>An enumerable of type T</returns>
    public static async Task<IEnumerable<T>> GetAll<T>(this Container container) =>
        await container.GetByQuery<T>(q => q);

    /// <summary>
    /// Sets TTL on items that match the given query
    /// </summary>
    /// <typeparam name="T">The type of the items in the container</typeparam>
    /// <param name="container">The instance being extended</param>
    /// <param name="partitionKey">The partition key of the documents</param>
    /// <param name="expiryTime">The time the documents should expire</param>
    /// <param name="buildQuery">The function used for building the query, must select the document ID</param>
    public static async Task SetTTLByQuery<T>(
        this Container container,
        PartitionKey partitionKey,
        DateTimeOffset expiryTime,
        Func<IQueryable<T>, IQueryable<Guid>> buildQuery)
    {
        var documentIds = await container.GetByQuery(buildQuery);
        var ttlSeconds = (int)Math.Floor(expiryTime.Subtract(DateTimeOffset.UtcNow).TotalSeconds);
        var patchOperations = new PatchOperation[] { PatchOperation.Add("/ttl", ttlSeconds) };
        var patchOption = new PatchItemRequestOptions { EnableContentResponseOnWrite = false };

        foreach (var documentId in documentIds)
        {
            await container.PatchItemAsync<T>(documentId.ToString(),
                partitionKey,
                patchOperations: patchOperations,
                patchOption);
        }
    }
}
