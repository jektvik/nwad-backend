namespace NwadHealth.Besthealthorg.Foundation.CustomTypes;

/// <summary>
/// A record struct that represents a non-empty string.
/// </summary>
public readonly record struct NonEmptyString
{
    private readonly string _value;

    /// <summary>
    /// Initializes a new instance of the <see cref="NonEmptyString"/> struct.
    /// </summary>
    /// <param name="value">The string value to be encapsulated by the struct. Must not be null or empty.</param>
    /// <exception cref="ArgumentException">Thrown when the value is null or an empty string.</exception>
    public NonEmptyString(string value)
    {
        if (string.IsNullOrEmpty(value))
        {
            throw new ArgumentException("Value cannot be null or empty", nameof(value));
        }

        _value = value;
    }

    /// <summary>
    /// Implicitly converts a <see cref="NonEmptyString"/> to a <see cref="string"/>.
    /// </summary>
    /// <param name="nonEmptyString">The <see cref="NonEmptyString"/> instance to convert.</param>
    /// <returns>The string value encapsulated by the <see cref="NonEmptyString"/>.</returns>
    public static implicit operator string(NonEmptyString nonEmptyString) => nonEmptyString._value;

    /// <summary>
    /// Implicitly converts a <see cref="string"/> to a <see cref="NonEmptyString"/>.
    /// </summary>
    /// <param name="value">The string value to encapsulate. Must not be null or empty.</param>
    /// <returns>A <see cref="NonEmptyString"/> instance containing the provided string value.</returns>
    /// <exception cref="ArgumentException">Thrown when the value is null or an empty string.</exception>
    public static implicit operator NonEmptyString(string value) => new (value);

    /// <summary>
    /// Returns the string representation of the <see cref="NonEmptyString"/>.
    /// </summary>
    /// <returns>The encapsulated string value.</returns>
    public override string ToString() => _value;
}
