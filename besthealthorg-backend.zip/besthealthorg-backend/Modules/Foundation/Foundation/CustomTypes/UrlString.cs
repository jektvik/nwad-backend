using System.Text.RegularExpressions;
using NwadHealth.Besthealthorg.Foundation.Exceptions;

namespace NwadHealth.Besthealthorg.Foundation.CustomTypes;

/// <summary>
/// A record struct that encapsulates a URL string.
/// </summary>
/// <remarks>
/// This struct ensures that the provided string is a valid URL. If the string is null, empty, or not a valid URL, an <see cref="ArgumentNotUrlException"/> is thrown.
/// </remarks>
public readonly record struct UrlString
{
    private const string RegexPattern = @"^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$";

    private static readonly Regex UrlRegex = new(RegexPattern, RegexOptions.Compiled, TimeSpan.FromMilliseconds(100));

    private readonly string _url;

    /// <summary>
    /// Initializes a new instance of the <see cref="UrlString"/> struct.
    /// </summary>
    /// <param name="url">The URL string to be encapsulated by the struct.</param>
    /// <exception cref="ArgumentNotUrlException">Thrown when the provided string is null, empty, or not a valid URL.</exception>
    public UrlString(string url)
    {
        if (!IsUrl(url))
        {
            throw new ArgumentNotUrlException(url, nameof(url));
        }

        _url = url;
    }

    private static bool IsUrl(string url)
    {
        return UrlRegex.IsMatch(url);
    }

    /// <summary>
    /// Implicitly converts a <see cref="UrlString"/> to a <see cref="string"/>.
    /// </summary>
    /// <param name="urlString">The <see cref="UrlString"/> instance to convert.</param>
    /// <returns>The URL string encapsulated by the <see cref="UrlString"/>.</returns>
    public static implicit operator string(UrlString urlString) => urlString._url;

    /// <summary>
    /// Implicitly converts a nullable <see cref="string"/> to a nullable <see cref="UrlString"/>.
    /// </summary>
    /// <param name="url">The URL string to encapsulate. Can be null.</param>
    /// <returns>A nullable <see cref="UrlString"/> instance containing the provided string value, or null if the input is null.</returns>
    /// <exception cref="ArgumentNotUrlException">Thrown when the provided string is not a valid URL.</exception>
    public static implicit operator UrlString?(string? url) => (url is not null) ? new (url) : null;

    /// <summary>
    /// Implicitly converts a <see cref="string"/> to a <see cref="UrlString"/>.
    /// </summary>
    /// <param name="url">The URL string to encapsulate.</param>
    /// <returns>A <see cref="UrlString"/> instance containing the provided string value.</returns>
    /// <exception cref="ArgumentNotUrlException">Thrown when the provided string is not a valid URL.</exception>
    public static implicit operator UrlString(string url) => new(url);

    /// <summary>
    /// Returns the string representation of the <see cref="UrlString"/>.
    /// </summary>
    /// <returns>The encapsulated URL string.</returns>
    public override string ToString() => _url;
}
