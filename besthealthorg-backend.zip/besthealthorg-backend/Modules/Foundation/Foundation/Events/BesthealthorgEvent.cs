namespace NwadHealth.Besthealthorg.Foundation.Events;

/// <summary>
/// Represents an event sent by BESTHEALTHORG modules
/// </summary>
public class PaceEvent
{
    /// <summary>
    /// Informs the event receiver of how the <see cref="Data"/> property should be deserialized
    /// </summary>
    public string Type { get; set; } = string.Empty;

    /// <summary>
    /// The event Id
    /// </summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>
    /// The time at which the event was sent
    /// </summary>
    public DateTimeOffset Time { get; set; }

    /// <summary>
    /// The ID of the identity the event affects, if available
    /// </summary>
    public string? IdentityId { get; set; }

    /// <summary>
    /// The serialized event data. <see cref="Type"/> informs how to deserialize
    /// </summary>
    public string Data { get; set; } = string.Empty;

    /// <summary>
    /// Extra metadata describing the event
    /// </summary>
    public Dictionary<string, string> Metadata { get; set; } = new();
}
