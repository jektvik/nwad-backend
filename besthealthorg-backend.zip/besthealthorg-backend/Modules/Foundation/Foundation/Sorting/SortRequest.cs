namespace NwadHealth.Besthealthorg.Foundation.Sorting;

/// <summary>
/// Represents a sort request that encapsulates the details for sorting a collection.
/// </summary>
/// <param name="SortBy">
/// The name of the property that data should be sorted. This can be any valid property name of the entity being sorted.
/// </param>
/// <param name="SortOrder">
/// Specifies the direction of sorting, either ascending (<see cref="SortOrder.Asc"/>) or descending (<see cref="SortOrder.Desc"/>).
/// Defaults to <see cref="SortOrder.Asc"/>
/// </param>
public record SortRequest(string? SortBy, SortOrder SortOrder = SortOrder.Asc);
