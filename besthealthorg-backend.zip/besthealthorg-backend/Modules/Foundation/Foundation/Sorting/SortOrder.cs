using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace NwadHealth.Besthealthorg.Foundation.Sorting;

/// <summary>
/// Enum for sort order
/// </summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum SortOrder
{
  /// <summary>
  /// Ascending sort order
  /// </summary>
  [EnumMember(Value = "asc")]
  Asc = 0,

  /// <summary>
  /// Descending sort order
  /// </summary>
  [EnumMember(Value = "desc")]
  Desc = 1,
}
