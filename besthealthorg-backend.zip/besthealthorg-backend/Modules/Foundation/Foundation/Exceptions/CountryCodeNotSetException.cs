namespace NwadHealth.Besthealthorg.Foundation.Exceptions;

/// <summary>
/// Exception thrown when the user's country code is not set.
/// </summary>
public class CountryCodeNotSetException : InvalidOperationException
{
    private const string DefaultMessage = "User country code is not set.";

    /// <summary>
    /// Initializes a new instance of the <see cref="CountryCodeNotSetException"/> class
    /// with a default error message.
    /// </summary>
    public CountryCodeNotSetException() : base(DefaultMessage)
    {
    }
}
