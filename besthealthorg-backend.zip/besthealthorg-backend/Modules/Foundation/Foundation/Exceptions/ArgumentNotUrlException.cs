namespace NwadHealth.Besthealthorg.Foundation.Exceptions;

public class ArgumentNotUrlException(string url, string param)
    : ArgumentException($"The provided argument '{url}' is not a valid URL.", param);
