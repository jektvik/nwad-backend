using NwadHealth.Besthealthorg.Foundation.Dtos;
using Xunit;

namespace NwadHealth.Besthealthorg.Foundation.UnitTest;

public class ErrorResponseDtoTests
{
    [Fact]
    public void ErrorResponseDto_HasCorrectProperties()
    {
        const string errorCodeExpectedName = "ErrorCode";
        const string errorExpectedName = "Error";

        var dto = new ErrorResponseDto();

        var type = dto.GetType();
        var properties = type
            .GetProperties()
            .Select(p => (p.Name, p.PropertyType, p.CanRead && p.CanWrite));

        Assert.Empty(type.GetFields());

        // Guard against global replace
        var actualErrorCodeName = nameof(dto.ErrorCode);
        var actualErrorName = nameof(dto.Error);

        Assert.Equal(errorCodeExpectedName, actualErrorCodeName);
        Assert.Equal(errorExpectedName, actualErrorName);

        Assert.Contains((errorCodeExpectedName, typeof(string), true), properties);
        Assert.Contains((errorExpectedName, typeof(string), true), properties);
        Assert.Equal(2, properties.Count());
    }
}
