using NwadHealth.Besthealthorg.Foundation.Extensions.Queryable;
using Moq;
using Xunit;
using System.Linq.Expressions;

namespace NwadHealth.Besthealthorg.Foundation.UnitTest;

public class QueryableExtensionsTests
{
    [Fact]
    public void MaybeWhere_WhenConditionIsFalse_DoesNotFilter()
    {
        var queryable = (new[] { -1, 0, 1 }).AsQueryable<int>();

        var result = queryable.MaybeWhere(x => x > 0, false).ToList();

        Assert.Equal(-1, result[0]);
        Assert.Equal(0, result[1]);
        Assert.Equal(1, result[2]);
    }

    [Fact]
    public void MaybeWhere_WhenConditionIsTrue_Filters()
    {
        var queryable = (new[] { -1, 0, 1 }).AsQueryable<int>();

        var result = queryable.MaybeWhere(x => x > 0, true).ToList();

        Assert.Equal(1, result[0]);
    }
}
