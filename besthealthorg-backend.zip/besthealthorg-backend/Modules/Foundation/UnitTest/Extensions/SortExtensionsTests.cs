using Xunit;
using NwadHealth.Besthealthorg.Foundation.Extensions;
using NwadHealth.Besthealthorg.Foundation.Sorting;

namespace NwadHealth.Besthealthorg.Foundation.UnitTest.Extensions;

public class SortExtensionsTests
{
    private class Article
    {
        public int Id { get; init; }
        public string Title { get; set; } = null!;
    }

    [Fact]
    public void SortBy_SortsByPropertyAscending()
    {
        var articles = new List<Article>
        {
            new() { Id = 3, Title = "C" },
            new() { Id = 1, Title = "A" },
            new() { Id = 2, Title = "B" }
        }.AsQueryable();

        var sortedArticles = articles.SortBy("Title", SortOrder.Asc).ToList();

        Assert.Collection(sortedArticles,
            article => Assert.Equal(1, article.Id),
            article => Assert.Equal(2, article.Id),
            article => Assert.Equal(3, article.Id));
    }

    [Fact]
    public void SortBy_SortsByPropertyDescending()
    {
        var articles = new List<Article>
        {
            new() { Id = 3, Title = "C" },
            new() { Id = 1, Title = "A" },
            new() { Id = 2, Title = "B" }
        }.AsQueryable();

        var sortedArticles = articles.SortBy("Title", SortOrder.Desc).ToList();

        Assert.Collection(sortedArticles,
            article => Assert.Equal(3, article.Id),
            article => Assert.Equal(2, article.Id),
            article => Assert.Equal(1, article.Id));
    }

    [Fact]
    public void SortBy_InvalidProperty_ThrowsArgumentException()
    {
        var articles = new List<Article>
        {
            new() { Id = 1, Title = "A" }
        }.AsQueryable();

        var ex = Assert.Throws<ArgumentException>(() =>
            articles.SortBy("NonExistentProperty", SortOrder.Asc).ToList());
        Assert.Equal("No property 'NonExistentProperty' found on type 'Article'", ex.Message);
    }

    [Fact]
    public void SortBy_EmptySortBy_ReturnsOriginalItems()
    {
        var articles = new List<Article>
        {
            new() { Id = 2, Title = "B" },
            new() { Id = 1, Title = "A" }
        }.AsQueryable();

        var sortedArticles = articles.SortBy(string.Empty, SortOrder.Asc).ToList();

        Assert.Equal(articles.ToList(), sortedArticles);
    }

    [Fact]
    public void SortBy_InvalidSortOrder_ThrowsArgumentException()
    {
        var articles = new List<Article>
        {
            new() { Id = 1, Title = "A" }
        }.AsQueryable();

        var ex = Assert.Throws<ArgumentException>(() =>
            articles.SortBy("Title", (SortOrder)999).ToList());

        Assert.Equal("Invalid sort order: 999", ex.Message);
    }
}
