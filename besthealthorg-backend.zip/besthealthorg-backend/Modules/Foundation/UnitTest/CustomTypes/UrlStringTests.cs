using NwadHealth.Besthealthorg.Foundation.CustomTypes;
using NwadHealth.Besthealthorg.Foundation.Exceptions;
using Xunit;
using Xunit.Abstractions;

namespace NwadHealth.Besthealthorg.Foundation.UnitTest;

public class UrlStringTests
{
    private readonly ITestOutputHelper _testOutputHelper;

    public UrlStringTests(ITestOutputHelper testOutputHelper)
    {
        _testOutputHelper = testOutputHelper;
    }

    [Theory]
    [InlineData("http://example.com")]
    [InlineData("https://example.com")]
    [InlineData("https://www.example.com")]
    [InlineData("www.example.com")]
    [InlineData("example.com")]
    [InlineData("http://example.com:8080")]
    [InlineData("https://example.com/path/to/resource?query=string&other=param")]
    [InlineData("https://example.com/pathParam/323?query=query&other=anotherParam")]
    [InlineData("http://sub.example.com")]
    [InlineData("https://sub.domain.example.co.uk")]
    public void UrlString_WhenValidUrl_StructShouldBeCreated(string testUrl)
    {
        var urlString = new UrlString(testUrl);

        Assert.Equal(testUrl, urlString.ToString());
    }

    [Theory]
    [InlineData("http://example")]
    [InlineData("http://example.")]
    [InlineData("kekw://aaa.com")]
    [InlineData("kekw@kekw.com")]
    [InlineData(":///aa.com")]
    [InlineData("")]
    public void UrlString_WhenInvalidUrl_ThrowException(string invalidUrl)
    {
        _testOutputHelper.WriteLine(invalidUrl);
        Assert.Throws<ArgumentNotUrlException>(() => new UrlString(invalidUrl));
    }

    [Fact]
    public void UrlString_WhenImplicitlyConstructedFromString_ShouldReturnUrlString()
    {
        const string testUrl = "https://example.com";
        UrlString urlString = testUrl;

        string convertedUrlString = urlString;

        Assert.Equal(testUrl, convertedUrlString);
    }

    [Fact]
    public void UrlString_WhenNullableImplicitOperator_ShouldReturnUrlNull()
    {
        const string? testUrl = null;

        Assert.Null<UrlString>(testUrl);
    }
}
