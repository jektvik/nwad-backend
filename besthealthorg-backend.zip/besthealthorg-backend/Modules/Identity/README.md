# IdentityModule

## Upgrading from 1.X.X to 2.X.X

The identity profile has been renamed to identity properties, in order to free up the name "profile" for a dedicated profile module.
This means that now the identity module requires the existing profiles to be moved from the `profiles` container to the `identityProperties` container.

To do this the following steps are required

1. Create a new CosmosDB container with the correct settings (defaults are seen below, if you have customized container settings, use your customized settings instead)
   1. Click new container
   1. Set container id to `identityProperties`
   1. Set partition key to `/id`
   1. Open advanced and select "My application uses an older Cosmos .NET or Java SDK version" in order to configure a partition key of up to 101 bytes
   1. Create the container
   1. Go to "Scale & Settings" -> "Settings" -> set "Time to Live" to `On (no default)`
   1. Save
1. Migrate data from the `profiles` container to the newly created `identityProperties` container (below guide uses the CosmosDB data migration tool (https://github.com/AzureCosmosDB/data-migration-desktop-tool/tree/2.1.4), feel free to migrate your own way)
   1. Create a file called `migrationsettings.json` with the following content
   ```json
   {
       "Source": "cosmos-nosql",
       "SourceSettings": {
            "ConnectionString": "<your CosmosDB connection string>",
            "Database": "identity",
            "Container": "profiles",
            "PartitionKeyPath": "/id"
        },
        "Sink": "cosmos-nosql",
        "SinkSettings": {
            "ConnectionString": "<your CosmosDB connection string>",
            "Database": "identity",
            "Container": "identityProperties",
            "PartitionKeyPath": "/id"
        }
    }
   ```
   1. Run the `dmt` tool in the same folder as the `migrationsettings.json` file
1. Update PACE identity module to version 2.X.X
1. Update your IaC (if any) to deploy the `identityProperties` container instead of `profiles`
1. Redeploy the backend
1. Make sure that data is read from the `identityProperties` container, then delete the `profiles` container

## Using the Identity package set

This package set provides functionality for IAM, without being tied to a specific IAM provider.

To use this plugin first install the `NwadHealth.Pace.IdentityModule` package, which is located in the NwadHealth NuGet feed.


**Configuring the package**

The main configuration model `Configuration.cs` can be found here:

> pace-backend\Identity\Module\Domain\Entities\Configuration.cs

`CosmosDbConnectionString` is output from the IaC deployment and should be set on the model creation as shown below. <br>
The container names are set to values matching those of IaC provided by PACE reference implementation, if you wish to change them remember to align them with your infstracture. 


Consider changing the `AuditLogRetentionTime` as your project might have a specific requirement for this.

Where you configure your services (usually `Program.cs`) add the following code:

> **Note:** `SomePlugin` is a placeholder. See [Using a PACE IAM plugin](#Using-a-PACE-IAM-plugin) or [Creating a custom IAM plugin](#Creating-a-custom-IAM-plugin)

```CSharp
using NwadHealth.Pace.IdentityModule.Infrastructure;
using NwadHealth.Pace.IdentityModule.Domain.Entities;

...
var config = new Configuration("<CosmosDbConnectionString>");

IIdentityPlugin plugin = new SomePlugin(); // SomePlugin is a placeholder!

builder.Services.AddPaceIdentity(config, plugin);

...

var app = builder.Build();

app.UsePaceIdentity();
```

### Using a PACE IAM plugin

This package set can be used together with one of the following plugins:

- [`NwadHealth.Pace.IdentityModule.Infrastructure.Auth0`](Plugins/Auth0/README.md)

You can see how to use the specific plugin in the getting started guide for that plugin.

### Creating a custom IAM plugin

In order to create a custom IAM implementation, you need to do the following:

- Create your own implementation of `NwadHealth.Pace.IdentityModule.ApplicationLogic.Interfaces.IIdentityProvider`
- Create your own implementation of `NwadHealth.Pace.IdentityModule.Domain.Entities.Identity`
- Create your own implementation of `NwadHealth.Pace.IdentityModule.Infrastructure.IIdentityPlugin`
  - `IdentityProviderType` should return the type of your custom `IIdentityProvider`
  - `ConfigureServices` should configure the authentication and authorization mechanisms using `AddAuthentication` and `AddAuthorization`
    - The identity id must be made available through `HttpContext.User.Identity.Name`. For JWT authentication this can be done by setting `NameClaimType = ClaimTypes.NameIdentifier` in the `TokenValidationParameters` and putting the identitys id in the `sub` claim.
- Create your own register/login endpoints

**Example:**
```CSharp
// MyIdentity.cs
public class MyIdentity : Identity
{
    public override string Id { get; init; }
    public override bool EmailVerified { get; init; }
}

// MyIdentityProvider.cs
public class MyIdentityProvider : IIdentityProvider
{
    public Task<Identity?> FetchIdentity(string identityId)
    {
        var identityDbModel = IdentityDatabase.Identities.FirstOrDefault(u => u.Id.ToString() == identityId);

        if (identityDbModel is null)
        {
            return Task.FromResult<Identity?>(null);
        }

        var identity = new MyIdentity()
        {
            Id = identityDbModel.Id.ToString()
        };

        return Task.FromResult<Identity?>(identity);
    }

    public Task<bool> IsEmailVerificationRequired()
    {
        return Task.FromResult(false);
    }

    public Task ResendVerificationEmail(string identityId)
    {
        throw new NotSupportedException();
    }
    
    public Task DeleteIdentity(string identityId)
    {
        throw new NotSupportedException();
    }
}

// MyIdentityPlugin.cs
public class MyIdentityPlugin : IIdentityPlugin
{
    public Type IdentityProviderType => typeof(MyIdentityProvider);

    private readonly SymmetricSecurityKey _signingKey;

    public MyIdentityPlugin(SymmetricSecurityKey signingKey)
    {
        _signingKey = signingKey;
    }

    public void ConfigureServices(IServiceCollection services)
    {
        services
          .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
          .AddJwtBearer(options =>
          {
              options.TokenValidationParameters = new TokenValidationParameters
              {
                  IssuerSigningKey = new SymmetricSecurityKey(jwtKey),
                  NameClaimType = ClaimTypes.NameIdentifier,
                  ValidateIssuer = false, // False for example brievity, requires issuer to be set in token
                  ValidateAudience = false,  // False for example brievity, requires audience to be set in token
              };
          });

        services.AddAuthorization();
    }
}

// Example custom login logic
public static string CreateTokenForIdentity(int identityId, byte[] signingKey)
{
    var key = new SymmetricSecurityKey(signingKey);
    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512);

    var claims = new List<Claim>
    {
        new Claim("sub", identityId.ToString())
    };

    var token = new JwtSecurityToken(
        "issuer",
        claims: claims,
        expires: DateTime.UtcNow.AddHours(1),
        signingCredentials: creds);

    return new JwtSecurityTokenHandler().WriteToken(token);
}
```


## Events Published

* `IdentityDeletedEvent` when the user's account is deleted
    
* `EmailChangedEvent` when the user changes their email address


## Role based authorization
Pace identity module uses middleware to automatically fetch and cache roles for users as well as making the role available for authorization choices.

In case no roles are assigned to a user, the `Default` role is applied.

> **Note:** If you do not wish to use this feature, no action is required

> **Note:** If you make an API call with a user without a role, and later assign a role and call again, the `Default` role is cached. You need to either clear the cache by getting an IRolesMemoryCache from the service collection and calling the `ClearCache` method or restarting the application.

To use this functionality you need to specify in your controller which roles should have access to an endpoint like so: `[Authorize(Roles = "roleId1, roleId2")]` 

You can configure a list of available roles in the `roles` container of CosmosDB by adding documents with the following content

```json 
{
  "id": "example" // id is used for RBAC e.g. `[Authorize(Roles = "example")]`,
  "name": "Example Role" // Display name / translation key clients can use, to localize UI
}
```

#### Assinging roles to users
To assign a role to a user two CosmosDB containers need to have correct entries created, `roles` container must be populated with available roles and `roleAssignments` container must have entries that pair the user with a role  

Currently the module does not provide functionality for adding roles and role assignments, instead you should manually insert them in CosmosDB as follows:


1. Locate the CosmosDB in use
1. Locate the database matching `CosmosDbDatabaseName`
1. Locate the container matching `CosmosDbRolesContainer`
1. Insert the roles (example of a role below).

   ``` json
   {
    "id": "NwadAdmin",
    "name": "Nwad Admin"
   }
   ```
1. After adding the roles you can assign them by creating entries in RoleAssignment container
1. Locate the container matching `CosmosDbRoleAssignmentsContainer`
1. Insert the role Assignments (example of a roleAssignments below).

   ``` json
   {
    "id": "<Identity Id>",
    "roleId": "NwadAdmin",
   }
   ```

## Adding countries 
Currently the module does not provide functionality for adding countries, instead you should manually insert them in CosmosDB as follows:

1. Locate the CosmosDB in use
1. Locate the database matching `CosmosDbDatabaseName`
1. Locate the container matching `CosmosDbCountriesContainer`
1. Insert the countries (example of a country below).

   ``` json
   {
    "id": "dk",
    "name": "Denmark"
   }
   ```

# Old PR trace

PR's from before 2023-05-02 can be found in the archived repository: https://github.com/NwadHealthGit/pace-identity-backend
