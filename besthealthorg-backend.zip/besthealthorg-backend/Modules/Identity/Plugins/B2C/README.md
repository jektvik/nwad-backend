# PACE Identity B2C plugin

The PACE Identity B2C plugin provides functionality for using B2C as identity provider.

## Plugin setup

### General requirements

The B2C plugin must be used in conjunction with the [Identity module](/Identity/README.md).

### Required infrastructure

- Azure B2C Tenant [Microsoft documentation](https://learn.microsoft.com/en-us/azure/active-directory-b2c/tutorial-create-tenant)
  - The following user flows must be created, and have the `Email Addresses`, `Identity Provider Access Token` and `User's Object ID` claims enabled (for the flows which they are available).
    - Sign up flow
    - Sign in flow
    - Password reset flow
    - Sign up and sign in flow
  - At least two app registrations are required, one for the client(s) and one for the server.
    - Server app registration
      - Select: _Accounts in this organizational directory only_
      - (Certificates & secrets tab) Generate a new client secret for authenticating with the graph API.
      - (Expose an API tab) set Application ID URI and add a scope required by the clients, e.g. `https://paceb2cstable.onmicrosoft.com/api/access`
      - (API permissions tab) Grant the server access to the graph API, by enabling at least the following Application Permissions: `User.ManageIdentities.All`, `User.Read.All`, `User.ReadBasic.All`, `User.ReadWrite.All` and granting admin consent.
    - Client app registration
      - Select: _Accounts in any identity provider or organizational directory (for authenticating users with user flows)_
      - (Authentication tab) Redirect URIs must be set for the relevant client platforms.
      - (API permissions tab) Add a delegated permission to the scope you created for the server app registration and grant admin consent.

### Installation

Install the `NwadHealth.Pace.IdentityModule.Infrastructure.B2C` NuGet package by following the [instructions](/README.md#sdk-modules) in the main README.

### Application configuration

To configure the B2C plugin in your application, pass an instance of `B2CPlugin` to the `AddPaceIdentity` call.
Instantiating the B2C config requires an instance of [B2CConfiguration](https://effective-robot-19m1v3p.pages.github.io/classNwadHealth_1_1Pace_1_1IdentityModule_1_1Infrastructure_1_1B2C_1_1B2CConfiguration.html).

The configuration requires at a minimum:
  - The B2C instance, e.g. `https://paceb2cstable.b2clogin.com`.
  - The B2C domain, e.g. `paceb2cstable.onmicrosoft.com`.
  - The B2C tenant id.
  - The B2C client id.
  - The B2C client secret.
  - The name of the sign up and sign in user flow.
  
#### Example

```CSharp
using NwadHealth.Pace.IdentityModule.Domain.Entities;
using NwadHealth.Pace.IdentityModule.Infrastructure.B2C;
using NwadHealth.Pace.IdentityModule.Infrastructure;

... // other setup

var b2cConfig = new B2CConfiguration
{
    Instance = configuration["B2CInstance"],
    Domain = configuration["B2CDomain"],
    TenantId = configuration["B2CTenantId"],
    ClientId = configuration["B2CClientId"],
    ClientSecret = configuration["ConnectionStrings:B2CClientSecret"],
    SignUpSignInPolicyId = configuration["B2CSignUpSignInPolicyId"]
};

services.AddPaceIdentity(identityConfig, new B2CPlugin(b2cConfig));

... // other setup

app.UsePaceIdentity();

... // other setup

app.Run();
```

## Events published

See [Identity module](/Identity/README.md).


## Application lifecylce

See [Identity module](/Identity/README.md).
