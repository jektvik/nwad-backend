namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.B2C;

/// <summary>
/// Represents an error that happens during communication with the Graph API
/// </summary>
public class B2CGraphApiException : Exception
{
    /// <summary>
    /// Initializes the B2CGraphApiException
    /// </summary>
    /// <param name="message">The message that describes the error.</param>
    /// <param name="innerException">The exception that is the cause of the current exception</param>
    public B2CGraphApiException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
