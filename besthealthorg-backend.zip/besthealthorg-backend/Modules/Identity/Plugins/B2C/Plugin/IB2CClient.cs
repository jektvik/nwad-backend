using Microsoft.Graph.Models;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.B2C;

/// <summary>
/// Represents a client for consuming the B2C API
/// </summary>
public interface IB2CClient
{
    /// <summary>
    /// Attempts to fetch a B2C user using the Microsoft Graph API
    /// </summary>
    /// <param name="userId">The id of the user to fetch</param>
    /// <returns>The fetched user or null if it does not exist</returns>
    Task<User?> FetchUserById(string userId);

    /// <summary>
    /// Attempts to fetch a B2C user using the Microsoft Graph API
    /// </summary>
    /// <param name="email">The email of the user to fetch</param>
    /// <returns>The fetched user or null if it does not exist</returns>
    Task<User?> FetchUserByEmail(string email);

    /// <summary>
    /// Attempts to change the email of an identity using the Microsoft Graph API
    /// </summary>
    /// <param name="userId">The id of the user to change email for</param>
    /// <param name="newEmail">The new email to set for the user </param>
    /// <returns>The updated user object</returns>
    Task<User?> ChangeEmail(string userId, string newEmail);

    /// <summary>
    /// Attempts to delete a user using the Microsoft Graph API
    /// </summary>
    /// <param name="userId">The id of the user to delete</param>
    Task DeleteUser(string userId);

    /// <summary>
    /// Attempts to create a user using the Microsoft Graph API
    /// </summary>
    /// <param name="user">The user to create</param>
    Task<User> CreateUser(User user);
}
