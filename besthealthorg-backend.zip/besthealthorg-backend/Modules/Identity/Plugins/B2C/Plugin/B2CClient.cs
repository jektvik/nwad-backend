using Azure.Identity;
using Microsoft.Graph;
using Microsoft.Graph.Models;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.B2C;

/// <summary>
/// A client for consuming the B2C API
/// </summary>
public class B2CClient : IB2CClient
{
    private static readonly string[] DEFAULT_SELECT = ["id", "createdDateTime", "identities"];

    private readonly GraphServiceClient _graphClient;
    private readonly B2CConfiguration _config;

    /// <summary>
    /// Initializes the B2CClient
    /// </summary>
    /// <param name="config">The B2C configuration</param>
    public B2CClient(B2CConfiguration config)
    {
        var creds = new ClientSecretCredential(
            config.TenantId,
            config.ClientId,
            config.ClientSecret
        );

        _graphClient = new(creds);
        _config = config;
    }

    /// <inheritdoc />
    public async Task<User?> FetchUserById(string userId)
    {
        return await _graphClient.Users[$"{userId}"].GetAsync(conf => conf.QueryParameters.Select = DEFAULT_SELECT);
    }

    /// <inheritdoc />
    public async Task<User?> FetchUserByEmail(string email)
    {
        var users = await _graphClient.Users.GetAsync(conf =>
        {
            conf.QueryParameters.Select = DEFAULT_SELECT;
            conf.QueryParameters.Filter = $"identities/any(i:i/issuerAssignedId eq '{email}' and i/issuer eq '{_config.Domain}')";
        });

        return users?.Value?.SingleOrDefault();
    }

    /// <inheritdoc />
    public async Task<User?> ChangeEmail(string userId, string newEmail)
    {
        return await _graphClient.Users[$"{userId}"].PatchAsync(new()
        {
            Identities = [
                new()
                {
                    IssuerAssignedId = newEmail,
                    SignInType = "emailAddress",
                    Issuer = _config.Domain
                }
            ]
        });
    }

    /// <inheritdoc />
    public async Task DeleteUser(string userId) => await _graphClient.Users[$"{userId}"].DeleteAsync();

    /// <inheritdoc />
    public async Task<User> CreateUser(User user) => (await _graphClient.Users.PostAsync(user))!;
}
