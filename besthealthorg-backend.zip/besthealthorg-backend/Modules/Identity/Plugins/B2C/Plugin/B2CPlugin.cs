using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Identity.Web;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.B2C;

/// <summary>
/// Plugin to be used with the Identity module, in order to integrate with B2C
/// </summary>
public class B2CPlugin : IIdentityPlugin
{
    /// <summary>
    /// The type that implements IIdentityProvider
    /// </summary>
    public Type IdentityProviderType => typeof(B2CIdentityProvider);

    private readonly B2CConfiguration _config;

    /// <summary>
    /// Initializes an instance of the plugin
    /// </summary>
    /// <param name="config">The required configurations</param>
    public B2CPlugin(B2CConfiguration config)
    {
        _config = config;
    }

    /// <summary>
    /// Configures authentication and authorization using Auth0.
    /// </summary>
    /// <param name="services">The IServiceCollection for which Auth0 should be configured</param>
    public void ConfigureServices(IServiceCollection services)
    {
        services
            .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddMicrosoftIdentityWebApi(ConfigureJwt, ConfigureMicrosoftIdentity);

        services.AddAuthorization(_config.ConfigureAuthorization);

        services.AddSingleton(_config);

        services.AddScoped<IB2CClient, B2CClient>();
    }

    private void ConfigureMicrosoftIdentity(MicrosoftIdentityOptions options)
    {
        options.Instance = _config.Instance;
        options.Domain = _config.Domain;
        options.ClientId = _config.ClientId;
        options.ClientSecret = _config.ClientSecret;
        options.SignUpSignInPolicyId = _config.SignUpSignInPolicyId;
    }

    private static void ConfigureJwt(JwtBearerOptions options)
    {
        options.TokenValidationParameters.NameClaimType = ClaimTypes.NameIdentifier;
    }
}
