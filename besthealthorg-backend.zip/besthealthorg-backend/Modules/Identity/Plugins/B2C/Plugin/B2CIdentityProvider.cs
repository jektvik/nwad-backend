using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Graph.Models;
using Microsoft.Graph.Models.ODataErrors;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.B2C;

/// <summary>
/// A B2C implementation of <see cref="IIdentityProvider"/>
/// </summary>
public class B2CIdentityProvider : IIdentityProvider
{
    private const string EMAIL_SIGN_IN_TYPE = "emailAddress";
    private readonly IB2CClient _b2cClient;
    private readonly B2CConfiguration _config;

    /// <summary>
    /// initializes the provider
    /// </summary>
    /// <param name="b2cClient">The client to use for communication with Graph API</param>
    /// <param name="config">The B2CConfiguration to use</param>
    public B2CIdentityProvider(IB2CClient b2cClient, B2CConfiguration config)
    {
        _b2cClient = b2cClient;
        _config = config;
    }

    /// <inheritdoc />
    public async Task<IIdentity?> FetchIdentity(string identityId)
    {
        EnsureValidIdentityId(identityId);

        try
        {
            var user = await _b2cClient.FetchUserById(identityId);

            if (user is null)
            {
                return null;
            }

            return new B2CIdentity
            {
                Id = user.Id!,
                Email = user.Identities!.First(identity => identity.SignInType == EMAIL_SIGN_IN_TYPE).IssuerAssignedId!,
                CreatedAt = (DateTimeOffset)user.CreatedDateTime!
            };
        }
        catch (ODataError e) when (e.ResponseStatusCode == 404)
        {
            return null;
        }
        catch (Exception e)
        {
            throw new B2CGraphApiException("Failed to fetch identity", e);
        }
    }

    /// <inheritdoc />
    public async Task<IIdentity?> FetchIdentityByEmail(string email)
    {
        try
        {
            var user = await _b2cClient.FetchUserByEmail(email);

            if (user is null)
            {
                return null;
            }

            return new B2CIdentity
            {
                Id = user.Id!,
                Email = user.Identities!.First(identity => identity.SignInType == EMAIL_SIGN_IN_TYPE).IssuerAssignedId!,
                CreatedAt = (DateTimeOffset)user.CreatedDateTime!
            };
        }
        catch (Exception e)
        {
            throw new B2CGraphApiException("Failed to fetch identity", e);
        }
    }

    /// <inheritdoc />
    public Task ResendVerificationEmail(string identityId)
    {
        throw new NotSupportedException();
    }

    /// <inheritdoc />
    public async Task DeleteIdentity(string identityId)
    {
        EnsureValidIdentityId(identityId);

        try
        {
            await _b2cClient.DeleteUser(identityId);
        }
        catch (Exception e)
        {
            throw new B2CGraphApiException("Failed to delete identity", e);
        }
    }

    /// <inheritdoc />
    public async Task ChangeEmail(string identityId, string newEmail)
    {
        EnsureValidIdentityId(identityId);

        try
        {
            await _b2cClient.ChangeEmail(identityId, newEmail);
        }
        catch (ODataError e) when (e.ResponseStatusCode == 400)
        {
            throw new ArgumentException("New email has invalid format", nameof(newEmail));
        }
        catch (ODataError e) when (e.ResponseStatusCode == 404)
        {
            throw new IdentityNotFoundException(identityId);
        }
        catch (Exception e)
        {
            throw new B2CGraphApiException("Failed to change email", e);
        }
    }

    /// <inheritdoc />
    public async Task<IIdentity> CreateIdentity(string email, string password, bool emailVerified)
    {
        try
        {
            var body = new User
            {
                AccountEnabled = true,
                DisplayName = "unknown",
                Identities = [
                    new()
                    {
                        IssuerAssignedId = email,
                        Issuer = _config.Domain,
                        SignInType = EMAIL_SIGN_IN_TYPE
                    }
                ],
                PasswordProfile = new()
                {
                    Password = password
                }
            };

            var createdUser = await _b2cClient.CreateUser(body);

            return new B2CIdentity
            {
                Id = createdUser.Id!,
                Email = body.Identities.First(identity => identity.SignInType == EMAIL_SIGN_IN_TYPE).IssuerAssignedId!,
                CreatedAt = DateTimeOffset.UtcNow
            };
        }
        catch (Exception e)
        {
            throw new B2CGraphApiException("Failed to create user", e);
        }
    }

    /// <inheritdoc />
    public Task<string> CreateResetPasswordTicket(string identityId, bool emailVerified, string clientId)
    {
        throw new NotSupportedException();
    }

    private static void EnsureValidIdentityId(string identityId)
    {
        if (string.IsNullOrEmpty(identityId))
        {
            throw new ArgumentException("IdentityId cannot be null or empty", nameof(identityId));
        }
    }
}
