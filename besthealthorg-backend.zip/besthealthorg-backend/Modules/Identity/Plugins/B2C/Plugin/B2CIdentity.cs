using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.B2C;

/// <summary>
/// Represents a B2C identity
/// </summary>
public class B2CIdentity : IIdentity
{
    /// <summary>
    /// The unique id of the Identity
    /// </summary>
    public required string Id { get; init; }

    /// <summary>
    /// The email of the identity
    /// </summary>
    public required string Email { get; init; }

    /// <summary>
    /// Whether the identity has verified their email
    /// </summary>
    public bool EmailVerified => true;

    /// <summary>
    /// The time of user creation
    /// </summary>
    public required DateTimeOffset CreatedAt { get; init; }
}
