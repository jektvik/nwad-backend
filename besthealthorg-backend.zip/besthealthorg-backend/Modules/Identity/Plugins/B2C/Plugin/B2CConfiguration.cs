using Microsoft.AspNetCore.Authorization;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.B2C;

/// <summary>
/// Represents the required configuration for setting up B2C integration
/// </summary>
public class B2CConfiguration
{
    /// <summary>
    /// The B2C instance
    /// </summary>
    public required string Instance { get; init; }

    /// <summary>
    /// The B2C domain
    /// </summary>
    public required string Domain { get; init; }

    /// <summary>
    /// The B2C tenant ID
    /// </summary>
    public required string TenantId { get; init; }

    /// <summary>
    /// The B2C client ID of your backend app registration
    /// </summary>
    public required string ClientId { get; init; }

    /// <summary>
    /// The client secret
    /// </summary>
    public required string ClientSecret { get; init; }

    /// <summary>
    /// The sign up sign in policy ID (name)
    /// </summary>
    public required string SignUpSignInPolicyId { get; init; }

    /// <summary>
    /// The action used to configure authorization. The action is passed to IServiceCollection.AddAuthorization
    /// </summary>
    public Action<AuthorizationOptions> ConfigureAuthorization { get; init; } = _ => { };
}
