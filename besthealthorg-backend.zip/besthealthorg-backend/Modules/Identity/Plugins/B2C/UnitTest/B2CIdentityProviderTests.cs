using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.B2C;
using Microsoft.Graph.Models.ODataErrors;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class B2CIdentityProviderTests
{
    private readonly B2CConfiguration _defaultConfig = new()
    {
        ClientSecret = "",
        TenantId = "",
        Instance = "",
        ClientId = "",
        SignUpSignInPolicyId = "",
        Domain = ""
    };

    private readonly Microsoft.Graph.Models.User _user = new()
    {
        Id = "identityId",
        Identities = [
            new()
            {
                SignInType = "emailAddress",
                IssuerAssignedId = "email@test.com"
            }
        ],
        CreatedDateTime = DateTimeOffset.UtcNow
    };

    private readonly Mock<IB2CClient> _b2cClientMock = new Mock<IB2CClient>();
    private readonly B2CIdentityProvider _b2cIdentityProvider;

    public B2CIdentityProviderTests()
    {
        _b2cIdentityProvider = new B2CIdentityProvider(_b2cClientMock.Object, _defaultConfig);
    }

    #region FetchIdentity

    [Fact]
    public async Task FetchIdentity_WithEmptyIdentityId_ThrowsArgumentException()
    {
        var exception = await Assert.ThrowsAsync<ArgumentException>(
            async () => await _b2cIdentityProvider.FetchIdentity(""));

        Assert.Equal("IdentityId cannot be null or empty (Parameter 'identityId')", exception.Message);
    }

    [Fact]
    public async Task FetchIdentity_WhenFetchUserByIdThrows_ThrowsB2CManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        _b2cClientMock
            .Setup(mock => mock.FetchUserById(It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var exception = await Assert.ThrowsAsync<B2CGraphApiException>(
            async () => await _b2cIdentityProvider.FetchIdentity("identityId"));

        Assert.Equal("Failed to fetch identity", exception.Message);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task FetchIdentity_WithValidParameters_CallsFetchUserByIdB2CClientAndReturnsIdentity()
    {
        _b2cClientMock
            .Setup(mock => mock.FetchUserById(It.IsAny<string>()))
            .ReturnsAsync(_user);

        var returnedIdentity = await _b2cIdentityProvider.FetchIdentity(_user.Id!);

        _b2cClientMock.Verify(mock => mock.FetchUserById(_user.Id!), Times.Once());
        Assert.Equal(_user.Id, returnedIdentity?.Id);
        Assert.Equal(_user.Identities![0].IssuerAssignedId, returnedIdentity?.Email);
        Assert.Equal(_user.CreatedDateTime, returnedIdentity?.CreatedAt);
    }

    #endregion FetchIdentity

    #region FetchIdentityByEmail

    [Fact]
    public async Task FetchIdentityByEmail_WhenFetchUserByEmailThrows_ThrowsB2CManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        _b2cClientMock
            .Setup(mock => mock.FetchUserByEmail(It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var exception = await Assert.ThrowsAsync<B2CGraphApiException>(
            async () => await _b2cIdentityProvider.FetchIdentityByEmail("email"));

        Assert.Equal("Failed to fetch identity", exception.Message);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task FetchIdentityByEmail_WhenFetchUserByEmailReturnsNull_ReturnsNull()
    {
        _b2cClientMock
            .Setup(mock => mock.FetchUserByEmail(It.IsAny<string>()))
            .ReturnsAsync((Microsoft.Graph.Models.User?)null);

        var returnedIdentity = await _b2cIdentityProvider.FetchIdentityByEmail("email");

        Assert.Null(returnedIdentity);
    }

    [Fact]
    public async Task FetchIdentityByEmail_WithValidParameters_CallsFetchUserByEmailB2CClientAndReturnsIdentity()
    {
        _b2cClientMock
            .Setup(mock => mock.FetchUserByEmail(It.IsAny<string>()))
            .ReturnsAsync(_user);

        var returnedIdentity = await _b2cIdentityProvider.FetchIdentityByEmail("email");

        _b2cClientMock.Verify(mock => mock.FetchUserByEmail("email"), Times.Once());
        Assert.Equal(_user.Identities![0].IssuerAssignedId, returnedIdentity?.Email);
    }

    #endregion FetchIdentityByEmail

    #region ResendVerificationEmail

    [Fact]
    public async Task ResendVerificationEmail_ThrowsNotSupportedException()
    {
        await Assert.ThrowsAsync<NotSupportedException>(async () => await _b2cIdentityProvider.ResendVerificationEmail(""));
    }

    #endregion ResendVerificationEmail

    #region CreateIdentity

    [Fact]
    public async Task CreateIdentity_WhenCreateUserThrows_ThrowsB2CManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        _b2cClientMock
            .Setup(mock => mock.CreateUser(It.IsAny<Microsoft.Graph.Models.User>()))
            .ThrowsAsync(exceptionToThrow);

        var exception = await Assert.ThrowsAsync<B2CGraphApiException>(
            async () => await _b2cIdentityProvider.CreateIdentity("email","password",true));

        Assert.Equal("Failed to create user", exception.Message);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task CreateIdentity_WithValidParameters_CallsCreateIdentityOnAuth0Client()
    {
        _b2cClientMock
            .Setup(mock => mock.CreateUser(It.IsAny<Microsoft.Graph.Models.User>()))
            .ReturnsAsync(new Microsoft.Graph.Models.User());

        await _b2cIdentityProvider.CreateIdentity("email", "password", true);

        var expectedUser = new Microsoft.Graph.Models.User {
            AccountEnabled = true,
            DisplayName = "unknown",
            Identities = [
                new()
                {
                    IssuerAssignedId = "email",
                    Issuer = _defaultConfig.Domain,
                    SignInType = "emailAddress"
                }
            ],
            PasswordProfile = new()
            {
                Password = "password"
            }
        };

        _b2cClientMock.Verify(mock => mock.CreateUser(It.Is<Microsoft.Graph.Models.User>(u =>
            u.AccountEnabled == true &&
            u.DisplayName == "unknown" &&
            u.Identities!.Single().IssuerAssignedId == "email" &&
            u.Identities!.Single().Issuer == _defaultConfig.Domain &&
            u.Identities!.Single().SignInType == "emailAddress" &&
            u.PasswordProfile!.Password == "password")),
        Times.Once());
    }

    #endregion CreateIdentity

    #region CreateResetPasswordTicket

    [Fact]
    public async Task CreateResetPasswordTicket_ThrowsNotSupportedException()
    {
        await Assert.ThrowsAsync<NotSupportedException>(async () => await _b2cIdentityProvider.CreateResetPasswordTicket("", true, ""));
    }

    #endregion CreateResetPasswordTicket

    #region DeleteIdentity

    [Fact]
    public async Task DeleteIdentity_WithInvalidIdentityId_ThrowsArgumentException()
    {
        var exception = await Assert.ThrowsAsync<ArgumentException>(
            async () => await _b2cIdentityProvider.DeleteIdentity(""));

        Assert.Equal("IdentityId cannot be null or empty (Parameter 'identityId')", exception.Message);
    }

    [Fact]
    public async Task DeleteIdentity_WhenDeleteIdentityThrows_ThrowsB2CManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        _b2cClientMock
            .Setup(mock => mock.DeleteUser(It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var exception = await Assert.ThrowsAsync<B2CGraphApiException>(
            async () => await _b2cIdentityProvider.DeleteIdentity("identityId"));

        Assert.Equal("Failed to delete identity", exception.Message);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task DeleteIdentity_WithValidParameters_CallsDeleteIdentityOnB2CClient()
    {
        const string identityId = "identityId";

        await _b2cIdentityProvider.DeleteIdentity(identityId);

        _b2cClientMock.Verify(mock => mock.DeleteUser(identityId), Times.Once());
    }

    #endregion DeleteIdentity

    #region ChangeEmail

    [Fact]
    public async Task ChangeEmail_WithInvalidIdentityId_ThrowsArgumentException()
    {
        var exception = await Assert.ThrowsAsync<ArgumentException>(
            async () => await _b2cIdentityProvider.ChangeEmail("", "newEmail"));

        Assert.Equal("IdentityId cannot be null or empty (Parameter 'identityId')", exception.Message);
    }

    [Fact]
    public async Task ChangeEmail_WhenChangeEmailThrows_ThrowsB2CManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        _b2cClientMock
            .Setup(mock => mock.ChangeEmail(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var exception = await Assert.ThrowsAsync<B2CGraphApiException>(
            async () => await _b2cIdentityProvider.ChangeEmail("identityId", "newEmail"));

        Assert.Equal("Failed to change email", exception.Message);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task ChangeEmail_WhenIdentityWasNotFound_ThrowsIdentityNotFoundException()
    {
        var exceptionToThrow = new ODataError()
        {
            ResponseStatusCode = 404
        };

        _b2cClientMock
            .Setup(mock => mock.ChangeEmail(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var exception = await Assert.ThrowsAsync<IdentityNotFoundException>(
            async () => await _b2cIdentityProvider.ChangeEmail("identityId", "newEmail"));

        Assert.Equal("The identity could not be found", exception.Message);
    }

    [Fact]
    public async Task ChangeEmail_WhenEmailIsInvalid_ThrowsArgumentException()
    {
        var exceptionToThrow = new ODataError()
        {
            ResponseStatusCode = 400
        };

        _b2cClientMock
            .Setup(mock => mock.ChangeEmail(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var exception = await Assert.ThrowsAsync<ArgumentException>(
            async () => await _b2cIdentityProvider.ChangeEmail("identityId", "newEmail"));

        Assert.Equal("New email has invalid format (Parameter 'newEmail')", exception.Message);
    }

    [Fact]
    public async Task ChangeEmail_WithValidParameters_CallsChangeEmailOnB2CClient()
    {
        const string identityId = "identityId";
        const string newEmail = "newEmail";

        _b2cClientMock
            .Setup(mock => mock.ChangeEmail(It.IsAny<string>(), It.IsAny<string>()));

        await _b2cIdentityProvider.ChangeEmail(identityId, newEmail);

        _b2cClientMock.Verify(mock => mock.ChangeEmail(identityId, newEmail), Times.Once());
    }

    #endregion ChangeEmail
}
