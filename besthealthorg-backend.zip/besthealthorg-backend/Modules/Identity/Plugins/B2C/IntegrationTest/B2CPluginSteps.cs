using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.B2C;
using Microsoft.Extensions.DependencyInjection;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.IntegrationTest;

[Binding]
public sealed class B2CPluginSteps
{
    private readonly ScenarioContext _context;

    private IIdentity? _fetchedIdentity;
    private Exception? _error;
    private IIdentityProvider? _identityProvider;

    private string? _createdIdentity;

    public B2CPluginSteps(ScenarioContext context)
    {
        _context = context;
    }

    [Given("Plugin is configured to use besthealthorg-test B2C tenant")]
    public void GivenPluginIsConfiguredToUsePaceTestB2CTenant()
    {
        var config = new B2CConfiguration
        {
            Instance = "https://paceb2cstable.b2clogin.com",
            Domain = "paceb2cstable.onmicrosoft.com",
            TenantId = "a0a26327-738e-407f-aab7-b7976a6327ad",
            ClientId = "619835b4-b8e6-4963-a3e6-3b0d6d5ef216",
            ClientSecret = "LsO8Q~Lu_zM2jolxsrWg3MI-t7YeiZ8~2GPtYarN",
            SignUpSignInPolicyId = "B2C_1_susi"
        };

        var services = new ServiceCollection();
        var plugin = new B2CPlugin(config);

        services.AddScoped<IIdentityProvider, B2CIdentityProvider>();
        plugin.ConfigureServices(services);

        var scope = services
            .BuildServiceProvider()
            .CreateScope();

        _identityProvider =
            scope
            .ServiceProvider
            .GetRequiredService<IIdentityProvider>();
    }

    [When("I fetch an identity that exists")]
    public async Task WhenIFetchAnIdentityThatExists()
    {
        _fetchedIdentity = await _identityProvider!.FetchIdentity("9c6b0696-558c-426f-aee3-299cf04b2f86");
    }

    [Then("Plugin returns the identity")]
    public void ThenPluginReturnsTheIdentity()
    {
        Assert.NotNull(_fetchedIdentity);
    }

    [When("I fetch an identity that does not exist")]
    public async Task WhenIFetchAnIdentityThatDoesNotExist()
    {
        _fetchedIdentity = await _identityProvider!.FetchIdentity("9c6asd96-558c-426f-aee3-299cf04b2f86");
    }

    [Then("Plugin says that the identity does not exist")]
    public void ThenPluginSaysThatIdentityDoesNotExist()
    {
        Assert.Null(_fetchedIdentity);
    }

    [Then("Plugin says error: identity does not exist")]
    public void ThenPluginSaysErrorIdentityDoesNotExist()
    {
        Assert.IsType<IdentityNotFoundException>(_error);
    }

    [Given("an identity exists")]
    public async Task GivenAnIdentityThatShouldBeDeleted()
    {
        var identity = await _identityProvider!.CreateIdentity("b2ctest@nwadhealth.com", "StronkPassword123!", true);
        _createdIdentity = identity.Id;
    }

    [When("I delete the identity")]
    public async Task WhenIDeleteTheIdentity()
    {
        await _identityProvider!.DeleteIdentity(_createdIdentity!);
    }

    [Then("The identity no longer exists")]
    public async Task ThenTheIdentityNoLongerExists()
    {
        Assert.Null(await _identityProvider!.FetchIdentity(_createdIdentity!));
    }

    [When("I change the email of the identity")]
    public async Task WhenIChangeTheEmailOfTheIdentity()
    {
        await _identityProvider!.ChangeEmail(_createdIdentity!, "b2ctest+changed@nwadhealth.com");
    }

    [When("I change the email of the identity to an invalid format")]
    public async Task WhenIChangeTheEmailOfTheIdentityToAnInvalidFormat()
    {
        _error = await Record.ExceptionAsync(() => _identityProvider!.ChangeEmail(_createdIdentity!, "blablatest.com"));
    }

    [Then("the email of the identity is updated")]
    public async Task ThenTheEmailOfTheIdentityIsUpdated()
    {
        var identity = await _identityProvider!.FetchIdentity(_createdIdentity!);

        Assert.Equal("b2ctest+changed@nwadhealth.com".ToLower(), identity!.Email.ToLower());
    }

    [Then("the plugin says error: email has invalid format")]
    public void ThenThePluginSaysErrorEmailHasInvalidFormat()
    {
        Assert.IsType<ArgumentException>(_error);

        var argError = _error as ArgumentException;

        Assert.Equal("newEmail", argError!.ParamName);
    }

    [AfterScenario]
    public async Task AfterScenario()
    {
        if (_createdIdentity is not null)
        {
            try
            {
                await _identityProvider!.DeleteIdentity(_createdIdentity);
            }
            catch
            {
                // Intentionally left blank
            }
        }
    }
}
