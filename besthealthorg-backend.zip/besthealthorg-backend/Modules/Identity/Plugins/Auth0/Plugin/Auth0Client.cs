using System.Net.Http.Json;
using System.Text.Json;
using System.Web;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0.Dtos;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;

/// <summary>
/// A client for consuming the Auth0 API
/// </summary>
public class Auth0Client : IAuth0Client
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<Auth0Client> _logger;

    /// <summary>
    /// Initializes the Auth0Client
    /// </summary>
    /// <param name="httpClient">The HTTP client to use for communicating with the API</param>
    /// <param name="logger">The logger to use</param>
    public Auth0Client(HttpClient httpClient, ILogger<Auth0Client> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
    }

    /// <summary>
    /// Requests Auth0 to resend the verification email
    /// </summary>
    /// <param name="identityId">The id of the identity for which to resend the email verification. Must have the format 'provider|identityid'</param>
    public async Task<(HttpResponseMessage response, Auth0ErrorResponseDto? error)> ResendVerificationEmail(string identityId)
    {
        _logger.LogInformation("Resending verification email via Auth0. URI: api/v2/jobs/verification-email");

        var (resp, _, respError) = await Post<dynamic>("api/v2/jobs/verification-email", JsonContent.Create(new { user_id = identityId }));

        return (resp, respError);
    }

    /// <summary>
    /// Attempts to fetch a identity using the Auth0 management API
    /// </summary>
    /// <param name="identityId">The id of the identity to fetch</param>
    /// <returns>a tuple of the raw HTTP response as well as the fetched identity</returns>
    public async Task<(HttpResponseMessage response, Auth0IdentityResponseDto? identity, Auth0ErrorResponseDto? error)> FetchIdentityById(string identityId)
    {
        _logger.LogInformation("Fetching identity by ID via Auth0. URI: api/v2/users/<identityId>");
        return await Get<Auth0IdentityResponseDto>($"api/v2/users/{identityId}");
    }

    /// <summary>
    /// Attempts to fetch a identity using the Auth0 management API
    /// </summary>
    /// <param name="email">The email of the identity to fetch</param>
    /// <returns>a tuple of the raw HTTP response as well as the fetched identity</returns>
    public async Task<(HttpResponseMessage response, IEnumerable<Auth0IdentityResponseDto>? identity, Auth0ErrorResponseDto? error)> FetchIdentityByEmail(
        string email)
    {
        _logger.LogInformation("Fetching identity by email via Auth0. URI: api/v2/users-by-email");

        return await Get<IEnumerable<Auth0IdentityResponseDto>>($"api/v2/users-by-email?email={HttpUtility.UrlEncode(email)}");
    }

    /// <summary>
    /// Attempts to fetch rules using the Auth0 management API
    /// </summary>
    /// <returns>A list of Auth0 rules</returns>
    public async Task<(HttpResponseMessage response, IEnumerable<Auth0RuleResponseDto>? rules, Auth0ErrorResponseDto? error)> FetchRules()
    {
        _logger.LogInformation("Fetching rules via Auth0. URI: api/v2/rules");
        return await Get<IEnumerable<Auth0RuleResponseDto>>("api/v2/rules");
    }

    /// <summary>
    /// Attempts to delete a identity using the Auth0 management API
    /// </summary>
    /// <param name="identityId">The ID of the identity to delete</param>
    /// <returns>A tuple of the raw HTTP response as well as Auth0 error</returns>
    public async Task<(HttpResponseMessage response, Auth0ErrorResponseDto? error)> DeleteIdentity(string identityId)
    {
        _logger.LogInformation("Deleting identity by ID via Auth0. URI: api/v2/users/<identityId>");
        var (resp, _, respError) = await Delete<dynamic>($"api/v2/users/{identityId}");

        return (resp, respError);
    }

    /// <summary>
    /// Attempts to change the email of an identity using the Auth0 management API
    /// </summary>
    /// <param name="identityId">The ID of the identity to change email for</param>
    /// <param name="newEmail">The new email to set for the identity</param>
    /// <returns>A tuple of the raw HTTP response as well as Auth0 error</returns>
    public async Task<(HttpResponseMessage response, Auth0ErrorResponseDto? error)> ChangeEmail(string identityId, string newEmail)
    {
        _logger.LogInformation("Changing email via Auth0. URI: api/v2/users/<identityId>");

        var requestDto = new
        {
            email = newEmail,
            verify_email = true
        };

        var (resp, _, respError) = await Patch<Auth0TokenResponseDto>($"api/v2/users/{identityId}", JsonContent.Create(requestDto));

        return (resp, respError);
    }

    /// <summary>
    /// Attempts to create identity using the Auth0 managment API
    /// </summary>
    /// <param name="email">The email to create the identity with</param>
    /// <param name="password">The password to set for the identity</param>
    /// <param name="auth0Connection">Name of the connection this user should be created in</param>
    /// <param name="emailVerified">Wheter the identity should be crated with verified email</param>
    /// <returns>A tuple of the raw HTTP response as well as Auth0 error</returns>
    public async Task<(HttpResponseMessage response, Auth0IdentityResponseDto?, Auth0ErrorResponseDto? error)> CreateIdentity(
        string email,
        string password,
        string auth0Connection,
        bool emailVerified)
    {
        var (resp, identity, respError) = await Post<Auth0IdentityResponseDto>(
             "api/v2/users",
             JsonContent.Create(new { email, password, connection = auth0Connection, email_verified = emailVerified }));

        return (resp, identity, respError);
    }

    /// <summary>
    /// Attempts to create password reset ticket using the Auth0 management API
    /// </summary>
    /// <param name="identityId">The ID of the identity to generate the ticket for</param>
    /// <param name="emailVerified">Whether to set the email_verified attribute to true (true) or whether it should not be updated (false)</param>
    /// <param name="clientId">Client id of the auth0 application for which to use the login url</param>
    /// <returns>A tuple of the raw HTTP response as well as Auth0 error</returns>
    public async Task<(HttpResponseMessage response, Auth0ResetPasswordTicketResponseDto? ticketDto, Auth0ErrorResponseDto? error)> CreateResetPasswordTicket(
        string identityId,
        bool emailVerified,
        string clientId)
    {
        var (resp, ticketDto, respError) = await Post<Auth0ResetPasswordTicketResponseDto>(
              "api/v2/tickets/password-change",
              JsonContent.Create(new { user_id = identityId, mark_email_as_verified = emailVerified, client_id = clientId }));

        return (resp, ticketDto!, respError);
    }

    private async Task<(HttpResponseMessage, ResponseType?, Auth0ErrorResponseDto?)> Get<ResponseType>(string requestUri)
    {
        return await SendRequest<ResponseType>(new(HttpMethod.Get, requestUri));
    }

    private async Task<(HttpResponseMessage, ResponseType?, Auth0ErrorResponseDto?)> Delete<ResponseType>(string requestUri)
    {
        return await SendRequest<ResponseType>(new(HttpMethod.Delete, requestUri));
    }

    private async Task<(HttpResponseMessage, ResponseType?, Auth0ErrorResponseDto?)> Post<ResponseType>(string requestUri, HttpContent? content)
    {
        var message = new HttpRequestMessage(HttpMethod.Post, requestUri)
        {
            Content = content
        };

        return await SendRequest<ResponseType>(message);
    }

    private async Task<(HttpResponseMessage, ResponseType?, Auth0ErrorResponseDto?)> Patch<ResponseType>(string requestUri, HttpContent? content)
    {
        var message = new HttpRequestMessage(HttpMethod.Patch, requestUri)
        {
            Content = content
        };

        return await SendRequest<ResponseType>(message);
    }

    private async Task<(HttpResponseMessage, ResponseType?, Auth0ErrorResponseDto?)> SendRequest<ResponseType>(HttpRequestMessage message)
    {
        _logger.LogInformation("Sending HTTP request");

        var resp = await _httpClient.SendAsync(message);
        var respContent = await resp.Content.ReadAsStringAsync();

        ResponseType? respData;
        Auth0ErrorResponseDto? respError;

        if (resp.IsSuccessStatusCode)
        {
            _logger.LogInformation("Received success response");
            respData = (!string.IsNullOrEmpty(respContent)) ? JsonSerializer.Deserialize<ResponseType>(respContent) : default;
            respError = default;
        }
        else
        {
            _logger.LogInformation("Received error response. Body: {body}", respContent);
            respData = default;
            respError = (!string.IsNullOrEmpty(respContent)) ? JsonSerializer.Deserialize<Auth0ErrorResponseDto>(respContent) : default;
        }

        return (resp, respData, respError);
    }
}
