namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;

/// <summary>
/// Library of Auth0 error codes
/// </summary>
public static class Auth0ErrorCode
{
    /// <summary>
    /// The identity was not found
    /// </summary>
    public const string InexistentIdentity = "inexistent_user";

    /// <summary>
    /// The request body is invalid
    /// </summary>
    public const string InvalidBody = "invalid_body";
}
