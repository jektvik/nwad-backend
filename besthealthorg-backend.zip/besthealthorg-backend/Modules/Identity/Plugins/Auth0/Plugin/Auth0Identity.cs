using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;

/// <summary>
/// A client for consuming the Auth0 API
/// </summary>
public class Auth0Identity : IIdentity
{
    /// <summary>
    /// The unique id of the Identity
    /// </summary>
    public string Id { get; init; } = string.Empty;

    /// <summary>
    /// The email of the identity
    /// </summary>
    public string Email { get; init; } = string.Empty;

    /// <summary>
    /// Whether the identity has verified their email
    /// </summary>
    public bool EmailVerified { get; init; }

    /// <summary>
    /// The time of user creation
    /// </summary>
    public DateTimeOffset CreatedAt { get; init; }
}
