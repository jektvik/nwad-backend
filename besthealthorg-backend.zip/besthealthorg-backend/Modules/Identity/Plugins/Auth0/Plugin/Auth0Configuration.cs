using Microsoft.AspNetCore.Authorization;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;

/// <summary>
/// Represents the required configuration for setting up Auth0 integration
/// </summary>
public class Auth0Configuration
{
    /// <summary>
    /// Required for Hcp Portal
    /// Name of the auth0 user database where identity should be created
    /// </summary>
    /// requred for <see cref="Auth0IdentityProvider.CreateIdentity(string, string, bool)"></see>
    public string Auth0Connection { get; set; } = string.Empty;

    /// <summary>
    /// The authority/issuer of the tokens
    /// </summary>
    public string Authority { get; }

    /// <summary>
    /// The intended audience of the tokens
    /// </summary>
    public string Audience { get; }

    /// <summary>
    /// The Auth0 client id
    /// </summary>
    public string ClientId { get; }

    /// <summary>
    /// The Auth0 client secret
    /// </summary>
    public string ClientSecret { get; }

    /// <summary>
    /// The action used to configure authorization.
    /// The action is passed to IServiceCollection.AddAuthorization.
    /// Defaults to the null function (NOOP)
    /// </summary>
    public Action<AuthorizationOptions> ConfigureAuthorization { get; init; } = (_) => { };

    /// <summary>
    /// The Auth0 tenant base URL
    /// </summary>
    public string TenantBaseUrl { get; }

    /// <summary>
    /// The management API audience
    /// </summary>
    public string ManagementApiAudience
    {
        get { return $"{TenantBaseUrl}api/v2/"; }
    }

    /// <summary>
    /// The grant type used for requesting management API tokens
    /// </summary>
    public static string ManagementApiGrantType
    {
        get { return "client_credentials"; }
    }

    /// <summary>
    /// Initializes the Auth0 configration
    /// </summary>
    /// <param name="authority">The authority/issuer of the token. Must match "domain" from Auth0, prefixed with https://</param>
    /// <param name="audience">The intended audience of the tokens. Must match "identifier" from Auth0</param>
    /// <param name="clientId">The Auth0 client id. Used for contacting the Auth0 management API</param>
    /// <param name="clientSecret">The Auth0 client secret. Used for cantacting the Auth0 management API</param>
    /// <param name="tenantBaseUrl">The Auth0 tenant base URL.</param>
    /// <exception cref="ArgumentException">Thrown when authority, audience, clientId or clientSecret is null or empty</exception>
    /// <exception cref="ArgumentException">Thrown when authority does not start with "https://" or does not end with "/"</exception>
    public Auth0Configuration(string authority, string audience, string clientId, string clientSecret, string tenantBaseUrl)
    {
        if (string.IsNullOrEmpty(authority))
        {
            throw new ArgumentException("Authority cannot be null or empty", nameof(authority));
        }

        if (!authority.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
        {
            throw new ArgumentException("Authority must start with 'https://'", nameof(authority));
        }

        if (authority.Last() != '/')
        {
            throw new ArgumentException("Authority must end with '/'", nameof(authority));
        }

        Authority = authority;

        if (string.IsNullOrEmpty(audience))
        {
            throw new ArgumentException("Audience cannot be null or empty", nameof(audience));
        }

        Audience = audience;

        if (string.IsNullOrEmpty(clientId))
        {
            throw new ArgumentException("ClientId cannot be null or empty", nameof(clientId));
        }

        ClientId = clientId;

        if (string.IsNullOrEmpty(clientSecret))
        {
            throw new ArgumentException("ClientSecret cannot be null or empty", nameof(clientSecret));
        }

        ClientSecret = clientSecret;

        if (string.IsNullOrEmpty(tenantBaseUrl))
        {
            throw new ArgumentException("Tenant base URL cannot be null or empty", nameof(tenantBaseUrl));
        }

        if (!tenantBaseUrl.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
        {
            throw new ArgumentException("Tenant base URL must start with 'https://'", nameof(tenantBaseUrl));
        }

        if (tenantBaseUrl.Last() != '/')
        {
            throw new ArgumentException("Tenant base URL must end with '/'", nameof(tenantBaseUrl));
        }

        TenantBaseUrl = tenantBaseUrl;
    }
}
