using System.IdentityModel.Tokens.Jwt;
using System.Net.Http.Json;
using Microsoft.Extensions.Logging;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0.Dtos;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;

/// <summary>
/// A delegating handler that automatically fetches an Auth0 management API token and adds it to the request.
/// The token is reused until it is about to expire
/// </summary>
public class Auth0AuthenticationHandler : DelegatingHandler
{
    private readonly HttpClient _httpClient;
    private readonly Auth0Configuration _config;
    private readonly ILogger<Auth0AuthenticationHandler> _logger;

    private string? _token;
    private DateTime? _tokenExpiresAt;

    /// <summary>
    /// Initializes the handler
    /// </summary>
    /// <param name="httpClient">The HTTP client for fetching token</param>
    /// <param name="config">The Auth0 configuration to use</param>
    /// <param name="logger">The logger to use</param>
    public Auth0AuthenticationHandler(HttpClient httpClient, Auth0Configuration config, ILogger<Auth0AuthenticationHandler> logger)
    {
        _httpClient = httpClient;
        _config = config;
        _logger = logger;
    }

    /// <summary>
    /// Adds a management JWT to the request before sending it
    /// </summary>
    /// <param name="request">The request that will have the token added</param>
    /// <param name="cancellationToken">The cancellation token</param>
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        if (_token is null || _tokenExpiresAt < DateTime.UtcNow)
        {
            _logger.LogInformation("Did not have a valid Auth0 management API token, fetching a new one");

            _token = await FetchManagementApiJwt();

            var handler = new JwtSecurityTokenHandler();
            var jwtSecurityToken = handler.ReadJwtToken(_token);

            _tokenExpiresAt = jwtSecurityToken.ValidTo.AddSeconds(-60).ToUniversalTime();
        }

        request.Headers.Authorization = new("Bearer", _token);

        return await base.SendAsync(request, cancellationToken);
    }

    private async Task<string> FetchManagementApiJwt()
    {
        var body = new
        {
            client_id = _config.ClientId,
            client_secret = _config.ClientSecret,
            audience = _config.ManagementApiAudience,
            grant_type = Auth0Configuration.ManagementApiGrantType
        };

        var resp = await _httpClient.PostAsync("/oauth/token", JsonContent.Create(body));
        var tokenDto = await resp.Content.ReadFromJsonAsync<Auth0TokenResponseDto>();

        if (!resp.IsSuccessStatusCode || tokenDto is null)
        {
            throw new Auth0ManagementApiException("Failed to acquire Auth0 management API token", resp);
        }

        return tokenDto.AccessToken;
    }
}
