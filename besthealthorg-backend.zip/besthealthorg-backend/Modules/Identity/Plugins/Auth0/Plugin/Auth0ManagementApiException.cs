namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;

/// <summary>
/// Represents an error that happens during communication with the Auth0 management API
/// </summary>
public class Auth0ManagementApiException : Exception
{
    /// <summary>
    /// The HTTP response received during the Auth0 request
    /// </summary>
    /// <remarks>Note: will be lost on serialization</remarks>
    public HttpResponseMessage? HttpResponse { get; }

    /// <summary>
    /// Initializes the Auth0ManagementApiException
    /// </summary>
    /// <param name="message">The message that describes the error.</param>
    /// <param name="httpResponse">The HTTP response received during Auth0 communication</param>
    public Auth0ManagementApiException(string message, HttpResponseMessage httpResponse)
        : base(message)
    {
        HttpResponse = httpResponse;
    }

    /// <summary>
    /// Initializes the Auth0ManagementApiException
    /// </summary>
    /// <param name="message">The message that describes the error.</param>
    /// <param name="innerException">The exception that is the cause of the current exception</param>
    public Auth0ManagementApiException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
