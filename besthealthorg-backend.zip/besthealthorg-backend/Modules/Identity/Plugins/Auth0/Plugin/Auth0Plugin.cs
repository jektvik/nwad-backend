using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.DependencyInjection;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;

/// <summary>
/// Plugin to be used with the Identity module, in order to integrate with Auth0
/// </summary>
public class Auth0Plugin : IIdentityPlugin
{
    /// <summary>
    /// The type that implements IIdentityProvider
    /// </summary>
    public Type IdentityProviderType
    {
        get { return typeof(Auth0IdentityProvider); }
    }

    private readonly Auth0Configuration _config;

    /// <summary>
    /// Initializes an instance of the plugin
    /// </summary>
    /// <param name="config">The required configurations</param>
    public Auth0Plugin(Auth0Configuration config)
    {
        _config = config;
    }

    /// <summary>
    /// Configures authentication and authorization using Auth0.
    /// Also sets up the scopes you want to be able to check for when authorizing endpoints
    /// </summary>
    /// <param name="services">The IServiceCollection for which Auth0 should be configured</param>
    public void ConfigureServices(IServiceCollection services)
    {
        services
            .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.Authority = _config.Authority;
                options.Audience = _config.Audience;
                options.TokenValidationParameters = new()
                {
                    NameClaimType = ClaimTypes.NameIdentifier
                };
            });

        services.AddAuthorization(_config.ConfigureAuthorization);

        services.AddSingleton(_config);
        services.AddTransient<Auth0AuthenticationHandler>();

        var configureHttpClient = (HttpClient httpClient) =>
        {
            httpClient.BaseAddress = new(_config.TenantBaseUrl);
            httpClient.Timeout = new(0, 0, 30);
            httpClient.DefaultRequestHeaders.Clear();
        };

        services.AddHttpClient<Auth0AuthenticationHandler>(configureHttpClient);

        services
            .AddHttpClient<IAuth0Client, Auth0Client>(configureHttpClient)
            .AddHttpMessageHandler<Auth0AuthenticationHandler>();
    }
}
