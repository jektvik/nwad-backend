using System.Text.Json.Serialization;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0.Dtos;

/// <summary>
/// Represents the response from Auth0 rule endpoints
/// </summary>
public class Auth0RuleResponseDto
{
    /// <summary>
    /// Whether the rule is enabled
    /// </summary>
    [JsonPropertyName("enabled")]
    public bool Enabled { get; set; }

    /// <summary>
    /// The name of the rule
    /// </summary>
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;
}
