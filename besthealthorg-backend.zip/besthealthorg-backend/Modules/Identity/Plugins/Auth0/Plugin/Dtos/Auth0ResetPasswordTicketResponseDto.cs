﻿using System.Text.Json.Serialization;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0.Dtos;

/// <summary>
/// Represents the response from an Auth0 reset password ticket
/// </summary>
public class Auth0ResetPasswordTicketResponseDto
{
    /// <summary>
    /// The reset password ticket url
    /// </summary>
    [JsonPropertyName("ticket")]
    public string TicketUrl { get; set; } = string.Empty;
}
