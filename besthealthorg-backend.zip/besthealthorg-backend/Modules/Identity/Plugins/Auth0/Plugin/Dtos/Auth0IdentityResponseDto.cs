using System.Text.Json.Serialization;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0.Dtos;

/// <summary>
/// Represents the response from an Auth0 get identity request
/// </summary>
public class Auth0IdentityResponseDto
{
    /// <summary>
    /// The identity Id
    /// </summary>
    [JsonPropertyName("user_id")]
    public string UserId { get; set; } = string.Empty;

    /// <summary>
    /// The email address of the identity
    /// </summary>
    [JsonPropertyName("email")]
    public string Email { get; set; } = string.Empty;

    /// <summary>
    /// Whether the identity has verified their email
    /// </summary>
    [JsonPropertyName("email_verified")]
    public bool EmailVerified { get; set; }

    /// <summary>
    /// The time of user creation
    /// </summary>
    [JsonPropertyName("created_at")]
    public DateTimeOffset CreatedAt { get; set; }

    /// <summary>
    /// Converts auth0 response dto to auth0 domain model
    /// </summary>
    /// <param name="dto">The dto to convert</param>
    /// <returns>Auth0 domain model</returns>
    public static Auth0Identity ToDomain(Auth0IdentityResponseDto dto)
    {
        return new()
        {
            Id = dto.UserId,
            Email = dto.Email,
            EmailVerified = dto.EmailVerified,
            CreatedAt = dto.CreatedAt,
        };
    }
}
