using System.Text.Json.Serialization;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0.Dtos;

/// <summary>
/// Represents the error response from an Auth0 management endpoint
/// </summary>
public class Auth0ErrorResponseDto
{
    /// <summary>
    /// The HTTP status code of the response
    /// </summary>
    [JsonPropertyName("statusCode")]
    public int StatusCode { get; set; }

    /// <summary>
    /// The error name of the response
    /// </summary>
    [JsonPropertyName("error")]
    public string Error { get; set; } = string.Empty;

    /// <summary>
    /// The error message of the response
    /// </summary>
    [JsonPropertyName("message")]
    public string Message { get; set; } = string.Empty;

    /// <summary>
    /// The error code of the response
    /// </summary>
    [JsonPropertyName("errorCode")]
    public string ErrorCode { get; set; } = string.Empty;
}
