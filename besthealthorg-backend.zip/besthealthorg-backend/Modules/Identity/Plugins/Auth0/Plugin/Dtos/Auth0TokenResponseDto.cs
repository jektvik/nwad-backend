using System.Text.Json.Serialization;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0.Dtos;

/// <summary>
/// Represents the response from an Auth0 authentication request
/// </summary>
public class Auth0TokenResponseDto
{
    /// <summary>
    /// The access token used for authorization
    /// </summary>
    [JsonPropertyName("access_token")]
    public string AccessToken { get; set; } = string.Empty;
}
