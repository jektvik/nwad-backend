using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0.Dtos;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;

/// <summary>
/// Represents a client for consuming the Auth0 API
/// </summary>
public interface IAuth0Client
{
    /// <summary>
    /// Requests the Auth0 management API to resend the verification email
    /// </summary>
    /// <param name="identityId">The id of the identity for which to resend the email verification. Must have the format 'provider|identityid'</param>
    /// <returns>A tuple of the raw HTTP response and Auth0 error</returns>
    Task<(HttpResponseMessage response, Auth0ErrorResponseDto? error)> ResendVerificationEmail(string identityId);

    /// <summary>
    /// Attempts to fetch a identity using the Auth0 management API
    /// </summary>
    /// <param name="identityId">The id of the identity to fetch</param>
    /// <returns>a tuple of the raw HTTP response as well as the fetched identity and Auth0 error</returns>
    Task<(HttpResponseMessage response, Auth0IdentityResponseDto? identity, Auth0ErrorResponseDto? error)> FetchIdentityById(string identityId);

    /// <summary>
    /// Attempts to fetch a identity using the Auth0 management API
    /// </summary>
    /// <param name="email">The email of the identity to fetch</param>
    /// <returns>a tuple of the raw HTTP response as well as the fetched identity and Auth0 error</returns>
    Task<(HttpResponseMessage response, IEnumerable<Auth0IdentityResponseDto>? identity, Auth0ErrorResponseDto? error)> FetchIdentityByEmail(string email);

    /// <summary>
    /// Attempts to fetch rules using the Auth0 management API
    /// </summary>
    /// <returns>A list of Auth0 rules</returns>
    Task<(HttpResponseMessage response, IEnumerable<Auth0RuleResponseDto>? rules, Auth0ErrorResponseDto? error)> FetchRules();

    /// <summary>
    /// Attempts to delete a identity using the Auth0 management API
    /// </summary>
    /// <param name="identityId">The ID of the identity to delete</param>
    /// <returns>A tuple of the raw HTTP response as well as Auth0 error</returns>
    Task<(HttpResponseMessage response, Auth0ErrorResponseDto? error)> DeleteIdentity(string identityId);

    /// <summary>
    /// Attempts to change the email of an identity using the Auth0 management API
    /// </summary>
    /// <param name="identityId">The ID of the identity to change email for</param>
    /// <param name="newEmail">The new email to set for the identity</param>
    /// <returns>A tuple of the raw HTTP response as well as Auth0 error</returns>
    Task<(HttpResponseMessage response, Auth0ErrorResponseDto? error)> ChangeEmail(string identityId, string newEmail);

    /// <summary>
    /// Attempts to create identity using the Auth0 managment API
    /// </summary>
    /// <param name="email">The email to create the identity with</param>
    /// <param name="password">The password to set for the identity</param>
    /// <param name="auth0Connection">Name of the connection this user should be created in</param>
    /// <param name="emailVerified">Wheter the identity should be crated with verified email</param>
    /// <returns>A tuple of the raw HTTP response as well as Auth0 error</returns>
    Task<(HttpResponseMessage response, Auth0IdentityResponseDto?, Auth0ErrorResponseDto? error)> CreateIdentity(
        string email,
        string password,
        string auth0Connection,
        bool emailVerified);

    /// <summary>
    /// Attempts to create password reset ticket using the Auth0 management API
    /// </summary>
    /// <param name="identityId">The ID of the identity to generate the ticket for</param>
    /// <param name="emailVerified">Whether to set the email_verified attribute to true (true) or whether it should not be updated (false)</param>
    /// <param name="clientId">Client id of the auth0 application for which to use the login url</param>
    /// <returns>A tuple of the raw HTTP response as well as Auth0 error</returns>
    Task<(HttpResponseMessage response, Auth0ResetPasswordTicketResponseDto? ticketDto, Auth0ErrorResponseDto? error)> CreateResetPasswordTicket(
        string identityId,
        bool emailVerified,
        string clientId);
}
