using System.Net;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0.Dtos;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;

/// <summary>
/// An Auth0 implementation of <see cref="IIdentityProvider"/>
/// </summary>
public class Auth0IdentityProvider : IIdentityProvider
{
    private readonly IAuth0Client _auth0Client;
    private readonly Auth0Configuration _auth0Configuration;
    private readonly ILogger<Auth0IdentityProvider> _logger;

    /// <summary>
    /// initializes the provider
    /// </summary>
    /// <param name="auth0Client">The client to use for communication with Auth0 API</param>
    /// <param name="configuration">The configuration to use</param>
    /// <param name="logger">The logger to use</param>
    public Auth0IdentityProvider(IAuth0Client auth0Client, Auth0Configuration configuration, ILogger<Auth0IdentityProvider> logger)
    {
        _auth0Client = auth0Client;
        _auth0Configuration = configuration;
        _logger = logger;
    }

    /// <summary>
    /// Fetches the identity with the given id from Auth0
    /// </summary>
    /// <param name="identityId">The id of the identity to fetch the identity for</param>
    /// <returns>The identity or null if it doesn't exist</returns>
    /// <exception cref="ArgumentException">Thrown when identityId is null or empty or when identityId doesn't contain a '|'</exception>
    /// <exception cref="Auth0ManagementApiException">Thrown when acquiring an Auth0 management API token fails</exception>
    /// <exception cref="Auth0ManagementApiException">Thrown when the fetch identity request fails</exception>
    public Task<IIdentity?> FetchIdentity(string identityId)
    {
        _logger.LogInformation("Fetching identity");
        EnsureValidIdentityId(identityId);

        return FetchIdentityInternal(identityId);
    }

    /// <summary>
    /// Fetches the identity with the given email from Auth0
    /// </summary>
    /// <param name="email">The email of the identity to fetch the identity for</param>
    /// <returns>The identity or null if it doesn't exist</returns>
    /// <exception cref="Auth0ManagementApiException">Thrown when acquiring an Auth0 management API token fails</exception>
    /// <exception cref="Auth0ManagementApiException">Thrown when the fetch identity request fails</exception>
    public Task<IIdentity?> FetchIdentityByEmail(string email)
    {
        _logger.LogInformation("Fetching identity by email");

        return FetchIdentityByEmailInternal(email);
    }

    /// <summary>
    /// Requests Auth0 to resend the verification email
    /// </summary>
    /// <param name="identityId">The id of the identity for which to resend verification email. Must have the format 'provider|identityid'</param>
    /// <exception cref="ArgumentException">Thrown when identityId is null or empty or when identityId doesn't contain a '|'</exception>
    /// <exception cref="Auth0ManagementApiException">Thrown when acquiring an Auth0 management API token fails</exception>
    /// <exception cref="Auth0ManagementApiException">Thrown when the resend request fails</exception>
    public Task ResendVerificationEmail(string identityId)
    {
        _logger.LogInformation("Resending verification email");
        EnsureValidIdentityId(identityId);

        return ResendVerificationEmailInternal(identityId);
    }

    /// <summary>
    /// Requests Auth0 delete the identity with the given id
    /// </summary>
    /// <param name="identityId">The id of the identity to delete. Must have the format 'provider|identityid'</param>
    /// <exception cref="ArgumentException">Thrown when identityId is null or empty or when identityId doesn't contain a '|'</exception>
    /// <exception cref="Auth0ManagementApiException">Thrown when acquiring an Auth0 management API token fails</exception>
    /// <exception cref="Auth0ManagementApiException">Thrown when the delete request fails</exception>
    public Task DeleteIdentity(string identityId)
    {
        _logger.LogInformation("Deleting identity");
        EnsureValidIdentityId(identityId);

        return DeleteIdentityInternal(identityId);
    }

    /// <summary>
    /// Changes the email address of the identity
    /// </summary>
    /// <param name="identityId">The id of the identity to change the email for</param>
    /// <param name="newEmail">The new email address to set</param>
    public Task ChangeEmail(string identityId, string newEmail)
    {
        _logger.LogInformation("Changing email");
        EnsureValidIdentityId(identityId);

        return ChangeEmailInternal(identityId, newEmail);
    }

    /// <summary>
    /// Requests the identity provider to create a new identity
    /// </summary>
    /// <param name="email">The email of the identity</param>
    /// <param name="password">The password of the identity</param>
    /// <param name="emailVerified">Whether to create the identity with verified email or not</param>
    /// <returns>Identity</returns>
    public Task<IIdentity> CreateIdentity(string email, string password, bool emailVerified)
    {
        return CreateIdentityInternal(email, password, _auth0Configuration.Auth0Connection, emailVerified);
    }

    private async Task<IIdentity> CreateIdentityInternal(string email, string password, string auth0Connection, bool emailVerified)
    {
        try
        {
            var (identityResp, identity, _) = await _auth0Client.CreateIdentity(email, password, auth0Connection, emailVerified);

            if (!identityResp.IsSuccessStatusCode || identity is null)
            {
                throw new Auth0ManagementApiException("Failed to create identity", identityResp);
            }

            return Auth0IdentityResponseDto.ToDomain(identity);
        }
        catch (Auth0ManagementApiException)
        {
            throw;
        }
        catch (Exception e)
        {
            throw new Auth0ManagementApiException("Failed to create identity", e);
        }
    }

    /// <summary>
    /// Requests the identity provider to create a password reset ticket
    /// </summary>
    /// <param name="identityId">The id of the identity for which to create a password reset ticket</param>
    /// <param name="emailVerified">Whether to set the email_verified attribute to true (true) or whether it should not be updated (false).</param>
    /// <param name="clientId">Client id of the auth0 application for which to use the login url</param>
    /// <returns>Reset password ticket url</returns>
    public Task<string> CreateResetPasswordTicket(string identityId, bool emailVerified, string clientId)
    {
        return CreateResetPasswordTicketInternal(identityId, emailVerified, clientId);
    }

    private async Task<string> CreateResetPasswordTicketInternal(string identityId, bool emailVerified, string clientId)
    {
        try
        {
            var (requestResp, ticketDto, _) = await _auth0Client.CreateResetPasswordTicket(identityId, emailVerified, clientId);

            if (!requestResp.IsSuccessStatusCode || ticketDto is null)
            {
                throw new Auth0ManagementApiException("Failed to create password reset link", requestResp);
            }

            return ticketDto.TicketUrl;
        }
        catch (Auth0ManagementApiException)
        {
            throw;
        }
        catch (Exception e)
        {
            throw new Auth0ManagementApiException("Failed to create password reset link", e);
        }
    }

    private async Task<IIdentity?> FetchIdentityInternal(string identityId)
    {
        try
        {
            var (identityResp, identity, _) = await _auth0Client.FetchIdentityById(identityId);

            if (identityResp.StatusCode == HttpStatusCode.NotFound)
            {
                _logger.LogInformation("Identity was not found");
                return null;
            }

            if (!identityResp.IsSuccessStatusCode || identity is null)
            {
                throw new Auth0ManagementApiException("Failed to fetch identity", identityResp);
            }

            return Auth0IdentityResponseDto.ToDomain(identity);
        }
        catch (Auth0ManagementApiException)
        {
            throw;
        }
        catch (Exception e)
        {
            throw new Auth0ManagementApiException("Failed to fetch identity", e);
        }
    }

    private async Task<IIdentity?> FetchIdentityByEmailInternal(string email)
    {
        try
        {
            var (identityResp, identities, _) = await _auth0Client.FetchIdentityByEmail(email);

            if (identityResp.StatusCode == HttpStatusCode.NotFound)
            {
                _logger.LogInformation("Identity was not found");
                return null;
            }

            if (!identityResp.IsSuccessStatusCode || identities is null)
            {
                throw new Auth0ManagementApiException("Failed to fetch identity", identityResp);
            }

            var identity = identities.FirstOrDefault();

            if (identity is null)
            {
                return null;
            }

            return Auth0IdentityResponseDto.ToDomain(identity);
        }
        catch (Auth0ManagementApiException)
        {
            throw;
        }
        catch (Exception e)
        {
            throw new Auth0ManagementApiException("Failed to fetch identity", e);
        }
    }

    private async Task ResendVerificationEmailInternal(string identityId)
    {
        try
        {
            var (resendResp, error) = await _auth0Client.ResendVerificationEmail(identityId);

            if (!resendResp.IsSuccessStatusCode)
            {
                if (error?.ErrorCode == Auth0ErrorCode.InexistentIdentity)
                {
                    _logger.LogError("Identity was not found");
                    throw new IdentityNotFoundException(identityId);
                }

                throw new Auth0ManagementApiException("Failed to resend verification email", resendResp);
            }
        }
        catch (IdentityNotFoundException)
        {
            throw;
        }
        catch (Auth0ManagementApiException)
        {
            throw;
        }
        catch (Exception e)
        {
            throw new Auth0ManagementApiException("Failed to resend verification email", e);
        }
    }

    private async Task DeleteIdentityInternal(string identityId)
    {
        try
        {
            var (resendResp, _) = await _auth0Client.DeleteIdentity(identityId);

            if (!resendResp.IsSuccessStatusCode)
            {
                throw new Auth0ManagementApiException("Failed to delete identity", resendResp);
            }
        }
        catch (Auth0ManagementApiException)
        {
            throw;
        }
        catch (Exception e)
        {
            throw new Auth0ManagementApiException("Failed to delete identity", e);
        }
    }

    private async Task ChangeEmailInternal(string identityId, string newEmail)
    {
        (HttpResponseMessage? changeEmailResp, Auth0ErrorResponseDto? error) = (default, default);

        try
        {
            (changeEmailResp, error) = await _auth0Client.ChangeEmail(identityId, newEmail);
        }
        catch (Exception e)
        {
            throw new Auth0ManagementApiException("Failed to change email", e);
        }

        if (!changeEmailResp.IsSuccessStatusCode)
        {
            switch (error?.ErrorCode)
            {
                case Auth0ErrorCode.InexistentIdentity:
                    _logger.LogError("Identity was not found");
                    throw new IdentityNotFoundException(identityId);

                case Auth0ErrorCode.InvalidBody:
                    _logger.LogError("New email has invalid format");
                    throw new ArgumentException("New email has invalid format", nameof(newEmail));
            }

            throw new Auth0ManagementApiException("Failed to change email", changeEmailResp);
        }
    }

    private void EnsureValidIdentityId(string identityId)
    {
        _logger.LogInformation("Checking identity id");

        if (string.IsNullOrEmpty(identityId))
        {
            throw new ArgumentException("IdentityId cannot be null or empty", nameof(identityId));
        }

        if (!identityId.Contains('|'))
        {
            throw new ArgumentException("IdentityId must have the format 'provider|identityid'", nameof(identityId));
        }
    }
}
