# PACE Identity Auth0 plugin

This is a plugin for the PACE identity package set, that provides the functionality for using Auth0 as IAM provider.

This package provides an `IIdentityPlugin` (`Auth0Plugin`) for use with the PACE Identity Module. This plugin is found in the namespace `NwadHealth.Pace.IdentityModule.Infrastructure.Auth0`.

The plugin requires an `Auth0Configuration` to be provided. This class wraps the required configurations required for communicating with Auth0.


## Using the plugin

To use this plugin first install the `NwadHealth.Pace.IdentityModule.Infrastructure.Auth0` package, which is located in the NwadHealth NuGet feed.

**Configure the feed**

**Note: This is only required if you aren't already connected to the feed**

```
dotnet nuget add source https://pkgs.dev.azure.com/NwadHealth/_packaging/NwadHealthNuGetFeed/nuget/v3/index.json --name NwadHealthNuGetFeed
```

**Install the package**

**Note: if you get a 401 response, it might be because you have not been granted access to the feed.**

**If you DO have access to the feed, try running below command with the `--interactive` flag**

```
dotnet add package NwadHealth.Pace.IdentityModule.Infrastructure.Auth0  
```

**Configuring and loading the plugin**

Where you configure your services (usually `Program.cs`) add the following code:

```CSharp
using NwadHealth.Pace.IdentityModule.Infrastructure.Auth0;

...

var auth0Config = new Auth0Configuration(
    "<Authority from Auth0>",
    "<Audience from Auth0>",
    "<Client ID from Auth0>",
    "<Client secret from Auth0>",
    "<Tenant base URL from Auth0>"
)
{
    ConfigureAuthorization = configAction // Optional, used for configuring the authorization pipeline, e.g. setting up policies. Defaults to the null function (NOOP)
};

var plugin = new Auth0Plugin(config);

builder.Services.AddPaceIdentity(new Configuration(<ServiceBus connection string>), plugin);

...

var app = builder.Build();

...

app.UsePaceIdentity();

...
```

With the configuration above, you would now be able to use the `[Authorize]` attribute.

In order to authorize against a policy using `[Authorize(Policy = "SomePolicy")]`, you must provide an action in the `Auth0Configuration.ConfigureAuthorization` that sets up the policy as descibed here: https://learn.microsoft.com/en-us/aspnet/core/security/authorization/policies?view=aspnetcore-6.0

### Auth0 management API access

Some functionality of this plugin depends on the Auth0 management API, hence why client id and secret needs to be configured.


If you plan to use this functionality you need to enable the management API for your application as well as enabling the following scopes:

**NOTE: if using the endpoints provided by the identity package set, some or all of these might be required, even if you don't directly call the methods**

|Method|Required management API scope|
|-|-|
|`Auth0IdentityProvider.FetchIdentity`|`read:users`|
|`Auth0IdentityProvider.ResendVerificationEmail`|`update:users`|
|`Auth0IdentityProvider.DeleteIdentity`|`delete:users`|

If the correct scopes are not configured for the Auth0 management API an `Auth0ManagementApiException` is thrown with the `HttpResponse` property containing the response from the Auth0 management API. E.g. if using `Auth0IdentityProvider.ResendVerificationEmail` with missing scope

```js
{
    "statusCode":403,
    "error":"Forbidden",
    "message":"Insufficient scope, expected any of: update:users",
    "errorCode":"insufficient_scope"
}
```

**How to enable the management API:**

![](./img/enable_management_api.png)

# Old PR trace

PR's from before 2023-02-14 can be found in the archived repository: https://github.com/TriforkeHealth/pace-identity-infrastructure-auth0-backend
