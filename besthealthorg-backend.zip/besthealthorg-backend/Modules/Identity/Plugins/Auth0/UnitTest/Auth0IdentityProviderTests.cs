using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0.Dtos;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class Auth0IdentityProviderTests
{
    #region FetchIdentity

    [Theory]
    [InlineData("", "IdentityId cannot be null or empty")]
    [InlineData("identityId", "IdentityId must have the format 'provider|identityid'")]
    public async Task
    FetchIdentity_WithInvalidIdentityId_ThrowsArgumentException(string identityId, string expectedError)
    {
        var auth0ClientMock = new Mock<IAuth0Client>();
        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<ArgumentException>(
            async () => await auth0IdentityProvider.FetchIdentity(identityId));

        Assert.Equal($"{expectedError} (Parameter 'identityId')", exception.Message);
    }

    [Fact]
    public async Task
    FetchIdentity_WhenFetchIdentityByIdThrows_ThrowsAuth0ManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.FetchIdentityById(It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.FetchIdentity("provider|identityId"));

        Assert.Equal("Failed to fetch identity", exception.Message);
        Assert.Null(exception.HttpResponse);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task
    FetchIdentity_WhenFetchIdentityByIdReturnsFailureHttpCode_ThrowsAuth0ManagementApiExceptionWithHttpResponse()
    {
        var fetchIdentityResp = new HttpResponseMessage(HttpStatusCode.Forbidden);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.FetchIdentityById(It.IsAny<string>()))
            .ReturnsAsync((fetchIdentityResp, null, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.FetchIdentity("provider|identityId"));

        Assert.Equal("Failed to fetch identity", exception.Message);
        Assert.Null(exception.InnerException);
        Assert.Equal(fetchIdentityResp, exception.HttpResponse);
    }

    [Fact]
    public async Task
    FetchIdentity_WhenFetchIdentityByIdReturnsNotFound_ReturnsNull()
    {
        var identity = new Auth0IdentityResponseDto
        {
            EmailVerified = true
        };

        var fetchIdentityResp = new HttpResponseMessage(HttpStatusCode.NotFound);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.FetchIdentityById(It.IsAny<string>()))
            .ReturnsAsync((fetchIdentityResp, identity, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var returnedIdentity = await auth0IdentityProvider.FetchIdentity("provider|identityId");

        Assert.Null(returnedIdentity);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task
    FetchIdentity_WithValidParameters_CallsFetchIdentityByIdAuth0ClientAndReturnsIdentity(bool expectedVerifiedValue)
    {
        const string identityId = "provider|identityId";
        var identity = new Auth0IdentityResponseDto
        {
            UserId =identityId,
            EmailVerified = expectedVerifiedValue
        };

        var fetchIdentityResp = new HttpResponseMessage(HttpStatusCode.Created);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.FetchIdentityById(It.IsAny<string>()))
            .ReturnsAsync((fetchIdentityResp, identity, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());
        var returnedIdentity = await auth0IdentityProvider.FetchIdentity(identityId);

        auth0ClientMock.Verify(mock => mock.FetchIdentityById(identityId), Times.Once());
        Assert.Equal(identityId, returnedIdentity?.Id);
        Assert.Equal(expectedVerifiedValue, identity?.EmailVerified);
    }

    #endregion FetchIdentity

    #region FetchIdentityByEmail

    [Fact]
    public async Task
    FetchIdentityByEmail_WhenFetchIdentityByEmailThrows_ThrowsAuth0ManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.FetchIdentityByEmail(It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.FetchIdentityByEmail("email"));

        Assert.Equal("Failed to fetch identity", exception.Message);
        Assert.Null(exception.HttpResponse);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task
    FetchIdentityByEmail_WhenFetchIdentityByEmailReturnsFailureHttpCode_ThrowsAuth0ManagementApiExceptionWithHttpResponse()
    {
        var fetchIdentityResp = new HttpResponseMessage(HttpStatusCode.Forbidden);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.FetchIdentityByEmail(It.IsAny<string>()))
            .ReturnsAsync((fetchIdentityResp, null, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.FetchIdentityByEmail("email"));

        Assert.Equal("Failed to fetch identity", exception.Message);
        Assert.Null(exception.InnerException);
        Assert.Equal(fetchIdentityResp, exception.HttpResponse);
    }

    [Fact]
    public async Task
    FetchIdentityByEmail_WhenFetchIdentityByEmailReturnsNotFound_ReturnsNull()
    {
        var identities = new List<Auth0IdentityResponseDto>();

        var fetchIdentityResp = new HttpResponseMessage(HttpStatusCode.NotFound);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.FetchIdentityByEmail(It.IsAny<string>()))
            .ReturnsAsync((fetchIdentityResp, identities, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var returnedIdentity = await auth0IdentityProvider.FetchIdentityByEmail("email");

        Assert.Null(returnedIdentity);
    }

    [Fact]
    public async Task
    FetchIdentityByEmail_WhenFetchIdentityByEmailReturnsNull_ReturnsNull()
    {
        var identities = new List<Auth0IdentityResponseDto>();

        var fetchIdentityResp = new HttpResponseMessage(HttpStatusCode.OK);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.FetchIdentityByEmail(It.IsAny<string>()))
            .ReturnsAsync((fetchIdentityResp, identities, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var returnedIdentity = await auth0IdentityProvider.FetchIdentityByEmail("email");

        Assert.Null(returnedIdentity);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task
    FetchIdentityByEmail_WithValidParameters_CallsFetchIdentityByEmailAuth0ClientAndReturnsIdentity(bool expectedVerifiedValue)
    {
        const string email = "email";

        var identities = new List<Auth0IdentityResponseDto>
        {
            new() { Email=email, EmailVerified = expectedVerifiedValue}
        };

        var fetchIdentityResp = new HttpResponseMessage(HttpStatusCode.Created);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.FetchIdentityByEmail(It.IsAny<string>()))
            .ReturnsAsync((fetchIdentityResp, identities, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());
        var returnedIdentity = await auth0IdentityProvider.FetchIdentityByEmail(email);

        auth0ClientMock.Verify(mock => mock.FetchIdentityByEmail(email), Times.Once());
        Assert.Equal(email, returnedIdentity?.Email);
        Assert.Equal(expectedVerifiedValue, identities.FirstOrDefault()?.EmailVerified);
    }

    #endregion FetchIdentityByEmail

    #region ResendVerificationEmail

    [Theory]
    [InlineData("", "IdentityId cannot be null or empty")]
    [InlineData("identityId", "IdentityId must have the format 'provider|identityid'")]
    public async Task
    ResendVerificationEmail_WithInvalidIdentityId_ThrowsArgumentException(string identityId, string expectedError)
    {
        var auth0ClientMock = new Mock<IAuth0Client>();
        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<ArgumentException>(
            async () => await auth0IdentityProvider.ResendVerificationEmail(identityId));

        Assert.Equal($"{expectedError} (Parameter 'identityId')", exception.Message);
    }

    [Fact]
    public async Task
    ResendVerificationEmail_WhenResendVerificationEmailThrows_ThrowsAuth0ManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.ResendVerificationEmail(It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.ResendVerificationEmail("provider|identityId"));

        Assert.Equal("Failed to resend verification email", exception.Message);
        Assert.Null(exception.HttpResponse);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task
    ResendVerificationEmail_WhenResendVerificationEmailReturnsFailureHttpCode_ThrowsAuth0ManagementApiExceptionWithHttpResponse()
    {
        var resendEmailResp = new HttpResponseMessage(HttpStatusCode.BadRequest);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.ResendVerificationEmail(It.IsAny<string>()))
            .ReturnsAsync((resendEmailResp, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
           new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.ResendVerificationEmail("provider|identityId"));

        Assert.Equal("Failed to resend verification email", exception.Message);
        Assert.Null(exception.InnerException);
        Assert.Equal(resendEmailResp, exception.HttpResponse);
    }

    [Fact]
    public async Task
    ResendVerificationEmail_WhenIdentityWasNotFound_ThrowsIdentityNotFoundException()
    {
        var resendEmailResp = new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.BadRequest,
            Content = JsonContent.Create(new { ErrorCode = Auth0ErrorCode.InexistentIdentity })
        };

        var auth0Error = new Auth0ErrorResponseDto
        {
            ErrorCode = Auth0ErrorCode.InexistentIdentity
        };

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.ResendVerificationEmail(It.IsAny<string>()))
            .ReturnsAsync((resendEmailResp, auth0Error));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        await Assert.ThrowsAsync<IdentityNotFoundException>(
            async () => await auth0IdentityProvider.ResendVerificationEmail("provider|identityId"));
    }

    [Fact]
    public async Task
    ResendVerificationEmail_WithValidParameters_CallsResendVerificationEmailOnAuth0Client()
    {
        const string identityId = "provider|identityId";
        var resendEmailResp = new HttpResponseMessage(HttpStatusCode.Created);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.ResendVerificationEmail(It.IsAny<string>()))
            .ReturnsAsync((resendEmailResp, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
           new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        await auth0IdentityProvider.ResendVerificationEmail(identityId);

        auth0ClientMock.Verify(mock => mock.ResendVerificationEmail(identityId), Times.Once());
    }

    #endregion ResendVerificationEmail

    #region CreateIdentity

    [Fact]
    public async Task
    CreateIdentity_WhenCreateIdentityThrows_ThrowsAuth0ManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.CreateIdentity(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()))
            .ThrowsAsync(exceptionToThrow);

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.CreateIdentity("email","password",true));

        Assert.Equal("Failed to create identity", exception.Message);
        Assert.Null(exception.HttpResponse);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task
    CreateIdentity_WhenCreateIdentityReturnsFailureHttpCode_ThrowsAuth0ManagementApiExceptionWithHttpResponse()
    {
        var createIdentityResp = new HttpResponseMessage(HttpStatusCode.Forbidden);
        var auth0IdentityRespDto = new Auth0IdentityResponseDto();

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.CreateIdentity(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()))
            .ReturnsAsync((createIdentityResp, auth0IdentityRespDto, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.CreateIdentity("email", "password", true));

        Assert.Equal("Failed to create identity", exception.Message);
        Assert.Null(exception.InnerException);
        Assert.Equal(createIdentityResp, exception.HttpResponse);
    }

    [Fact]
    public async Task
    CreateIdentity_WithValidParameters_CallsCreateIdentityOnAuth0Client()
    {
        var createIdentityResp = new HttpResponseMessage(HttpStatusCode.Created);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.CreateIdentity(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()))
            .ReturnsAsync((createIdentityResp, new Auth0IdentityResponseDto(),null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
           new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        await auth0IdentityProvider.CreateIdentity("email", "password", true);

        auth0ClientMock.Verify(mock => mock.CreateIdentity("email", "password", It.IsAny<string>(), true), Times.Once());
    }

    #endregion CreateIdentity

    #region CreateResetPasswordTicket

    [Fact]
    public async Task
    CreateResetPasswordTicket_WhenCreateResetPasswordTicketThrows_ThrowsAuth0ManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.CreateResetPasswordTicket(It.IsAny<string>(), It.IsAny<bool>(), It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.CreateResetPasswordTicket("IenitityId", true, "clientId"));

        Assert.Equal("Failed to create password reset link", exception.Message);
        Assert.Null(exception.HttpResponse);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task
    CreateResetPasswordTicket_WhenCreateResetPasswordTicketReturnsFailureHttpCode_ThrowsAuth0ManagementApiExceptionWithHttpResponse()
    {
        var createResetPasswordTicket = new HttpResponseMessage(HttpStatusCode.Forbidden);
        var auth0ResetTicketDto = new Auth0ResetPasswordTicketResponseDto();

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.CreateResetPasswordTicket(It.IsAny<string>(), It.IsAny<bool>(), It.IsAny<string>()))
            .ReturnsAsync((createResetPasswordTicket, auth0ResetTicketDto, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.CreateResetPasswordTicket("identityId", true, "clientId"));

        Assert.Equal("Failed to create password reset link", exception.Message);
        Assert.Null(exception.InnerException);
        Assert.Equal(createResetPasswordTicket, exception.HttpResponse);
    }

    [Fact]
    public async Task
    CreateResetPasswordTicket_WithValidParameters_CallsCreateResetPasswordTicketOnAuth0Client()
    {
        var createResetPasswordTicketResp = new HttpResponseMessage(HttpStatusCode.Created);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.CreateResetPasswordTicket(It.IsAny<string>(), It.IsAny<bool>(), It.IsAny<string>()))
            .ReturnsAsync((createResetPasswordTicketResp, new Auth0ResetPasswordTicketResponseDto(), null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
           new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        await auth0IdentityProvider.CreateResetPasswordTicket("identityId", true, "clientId");

        auth0ClientMock.Verify(mock => mock.CreateResetPasswordTicket(It.IsAny<string>(), It.IsAny<bool>(), It.IsAny<string>()), Times.Once());
    }

    #endregion CreateResetPasswordTicket

    #region DeleteIdentity

    [Theory]
    [InlineData("", "IdentityId cannot be null or empty")]
    [InlineData("identityId", "IdentityId must have the format 'provider|identityid'")]
    public async Task
    DeleteIdentity_WithInvalidIdentityId_ThrowsArgumentException(string identityId, string expectedError)
    {
        var auth0ClientMock = new Mock<IAuth0Client>();
        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
           new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<ArgumentException>(
            async () => await auth0IdentityProvider.DeleteIdentity(identityId));

        Assert.Equal($"{expectedError} (Parameter 'identityId')", exception.Message);
    }

    [Fact]
    public async Task
    DeleteIdentity_WhenDeleteIdentityThrows_ThrowsAuth0ManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.DeleteIdentity(It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
           new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.DeleteIdentity("provider|identityId"));

        Assert.Equal("Failed to delete identity", exception.Message);
        Assert.Null(exception.HttpResponse);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task
    DeleteIdentity_WhenDeleteIdentityReturnsFailureHttpCode_ThrowsAuth0ManagementApiExceptionWithHttpResponse()
    {
        var deleteIdentityResp = new HttpResponseMessage(HttpStatusCode.Forbidden);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.DeleteIdentity(It.IsAny<string>()))
            .ReturnsAsync((deleteIdentityResp , null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.DeleteIdentity("provider|identityId"));

        Assert.Equal("Failed to delete identity", exception.Message);
        Assert.Null(exception.InnerException);
        Assert.Equal(deleteIdentityResp , exception.HttpResponse);
    }

    [Fact]
    public async Task
    DeleteIdentity_WithValidParameters_CallsDeleteIdentityOnAuth0Client()
    {
        const string identityId = "provider|identityId";
        var fetchIdentityResp = new HttpResponseMessage(HttpStatusCode.Created);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.DeleteIdentity(It.IsAny<string>()))
            .ReturnsAsync((fetchIdentityResp, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
           new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        await auth0IdentityProvider.DeleteIdentity(identityId);

        auth0ClientMock.Verify(mock => mock.DeleteIdentity(identityId), Times.Once());
    }

    #endregion DeleteIdentity

    #region ChangeEmail

    [Theory]
    [InlineData("", "IdentityId cannot be null or empty")]
    [InlineData("identityId", "IdentityId must have the format 'provider|identityid'")]
    public async Task
    ChangeEmail_WithInvalidIdentityId_ThrowsArgumentException(string identityId, string expectedError)
    {
        var auth0ClientMock = new Mock<IAuth0Client>();
        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
           new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<ArgumentException>(
            async () => await auth0IdentityProvider.ChangeEmail(identityId, "newEmail"));

        Assert.Equal($"{expectedError} (Parameter 'identityId')", exception.Message);
    }

    [Fact]
    public async Task
    ChangeEmail_WhenChangeEmailThrows_ThrowsAuth0ManagementApiExceptionWithInnerException()
    {
        var exceptionToThrow = new Exception();

        var auth0ClientMock = new Mock<IAuth0Client>();

        auth0ClientMock
            .Setup(mock => mock.ChangeEmail(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(exceptionToThrow);

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.ChangeEmail("provider|identityId", "newEmail"));

        Assert.Equal("Failed to change email", exception.Message);
        Assert.Null(exception.HttpResponse);
        Assert.Equal(exceptionToThrow, exception.InnerException);
    }

    [Fact]
    public async Task
    ChangeEmail_WhenChangeEmailReturnsFailureHttpCode_ThrowsAuth0ManagementApiExceptionWithHttpResponse()
    {
        var resendEmailResp = new HttpResponseMessage(HttpStatusCode.BadRequest);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.ChangeEmail(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync((resendEmailResp, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        var exception = await Assert.ThrowsAsync<Auth0ManagementApiException>(
            async () => await auth0IdentityProvider.ChangeEmail("provider|identityId", "newEmail"));

        Assert.Equal("Failed to change email", exception.Message);
        Assert.Null(exception.InnerException);
        Assert.Equal(resendEmailResp, exception.HttpResponse);
    }

    [Fact]
    public async Task
    ChangeEmail_WhenIdentityWasNotFound_ThrowsIdentityNotFoundException()
    {
        var changeEmailResp = new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.BadRequest,
            Content = JsonContent.Create(new { ErrorCode = Auth0ErrorCode.InexistentIdentity })
        };

        var auth0Error = new Auth0ErrorResponseDto
        {
            ErrorCode = Auth0ErrorCode.InexistentIdentity
        };

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.ChangeEmail(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync((changeEmailResp, auth0Error));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        await Assert.ThrowsAsync<IdentityNotFoundException>(
            async () => await auth0IdentityProvider.ChangeEmail("provider|identityId", "newEmail"));
    }

    [Fact]
    public async Task
    ChangeEmail_WhenEmailIsInvalid_ThrowsArgumentException()
    {
        var changeEmailResp = new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.BadRequest,
            Content = JsonContent.Create(new { ErrorCode = Auth0ErrorCode.InvalidBody })
        };

        var auth0Error = new Auth0ErrorResponseDto
        {
            ErrorCode = Auth0ErrorCode.InvalidBody
        };

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.ChangeEmail(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync((changeEmailResp, auth0Error));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        await Assert.ThrowsAsync<ArgumentException>(
            async () => await auth0IdentityProvider.ChangeEmail("provider|identityId", "newEmail"));
    }

    [Fact]
    public async Task
    ChangeEmail_WithValidParameters_CallsChangeEmailOnAuth0Client()
    {
        const string identityId = "provider|identityId";
        const string newEmail = "newEmail";
        var resendEmailResp = new HttpResponseMessage(HttpStatusCode.Created);

        var auth0ClientMock = new Mock<IAuth0Client>();
        auth0ClientMock
            .Setup(mock => mock.ChangeEmail(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync((resendEmailResp, null));

        var auth0IdentityProvider = new Auth0IdentityProvider(
            auth0ClientMock.Object,
            new Auth0Configuration("https://auth/", "audience", "client", "secret", "https://base/"),
            Mock.Of<ILogger<Auth0IdentityProvider>>());

        await auth0IdentityProvider.ChangeEmail(identityId, newEmail);

        auth0ClientMock.Verify(mock => mock.ChangeEmail(identityId, newEmail), Times.Once());
    }

    #endregion ChangeEmail
}
