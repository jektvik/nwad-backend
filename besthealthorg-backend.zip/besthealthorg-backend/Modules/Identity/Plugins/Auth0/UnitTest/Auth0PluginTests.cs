using Xunit;
using Microsoft.Extensions.DependencyInjection;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;
using Microsoft.AspNetCore.Authorization;
using NwadHealth.Besthealthorg.IdentityModule.UnitTest.TestHelpers;
using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class Auth0PluginTests
{
    #region IdentityProviderType

    [Fact]
    public void IdentityProviderType_ReturnsAuth0IdentityProvider()
    {
        var config = Auth0ConfigurationTestHelper.CreateAuth0Configuration();
        var plugin = new Auth0Plugin(config);

        Assert.Equal(typeof(Auth0IdentityProvider), plugin.IdentityProviderType);
    }

    #endregion IdentityProviderType

    #region ConfigureServices

    [Fact]
    public void ConfigureServices_ConfiguresJwtBearerOptionsCorrectly()
    {
        var (authority, audience, clientId, clientSecret, tenantBaseUrl) = Auth0ConfigurationTestHelper.CreateValidParams();
        var config = new Auth0Configuration(authority, audience, clientId, clientSecret,  tenantBaseUrl);

        var services = new ServiceCollection();

        var auth0Plugin = new Auth0Plugin(config);
        auth0Plugin.ConfigureServices(services);

        var serviceProvider = services.BuildServiceProvider();

        var jwtConf = serviceProvider.GetRequiredService<Microsoft.Extensions.Options.IConfigureOptions<JwtBearerOptions>>();
        var opts = new JwtBearerOptions();

        ((jwtConf as dynamic)?.Action as System.Action<JwtBearerOptions>)?.Invoke(opts);

        Assert.Equal(authority, opts.Authority);
        Assert.Equal(audience, opts.Audience);
    }

    [Fact]
    public void ConfigureServices_UsesConfigureFunctionFromConfiguration()
    {
        var called = false;

        var (authority, audience, clientId, clientSecret,  tenantBaseUrl) = Auth0ConfigurationTestHelper.CreateValidParams();
        var config = new Auth0Configuration(authority, audience, clientId, clientSecret,  tenantBaseUrl)
        {
            ConfigureAuthorization = (_) => called = true
        };

        var services = new ServiceCollection();

        var auth0Plugin = new Auth0Plugin(config);
        auth0Plugin.ConfigureServices(services);

        var serviceProvider = services.BuildServiceProvider();

        var authConf = serviceProvider.GetRequiredService<Microsoft.Extensions.Options.IConfigureOptions<AuthorizationOptions>>();
        var opts = new AuthorizationOptions();

        ((authConf as dynamic)?.Action as System.Action<AuthorizationOptions>)?.Invoke(opts);

        Assert.True(called);
    }

    [Fact]
    public void ConfigureServices_AddsIAuth0Client()
    {
        var config = Auth0ConfigurationTestHelper.CreateAuth0Configuration();
        var services = new ServiceCollection();

        var auth0Plugin = new Auth0Plugin(config);
        auth0Plugin.ConfigureServices(services);

        var serviceProvider = services.BuildServiceProvider();
        var auth0Client = serviceProvider.GetRequiredService<IAuth0Client>();

        Assert.NotNull(auth0Client);
    }

    #endregion ConfigureServices
}
