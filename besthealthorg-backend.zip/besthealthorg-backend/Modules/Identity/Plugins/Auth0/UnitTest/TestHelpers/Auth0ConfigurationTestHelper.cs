using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest.TestHelpers;

public static class Auth0ConfigurationTestHelper
{
    public static (string, string, string, string, string) CreateValidParams()
    {
        return ("hTtPs://authority/", "audience", "clientId", "clientSecret", "https://tenantBaseUrl/");
    }

    public static Auth0Configuration CreateAuth0Configuration()
    {
        var (authority, audience, clientId, clientSecret, tenantBaseUrl) = CreateValidParams();
        return new(authority, audience, clientId, clientSecret, tenantBaseUrl);
    }
}
