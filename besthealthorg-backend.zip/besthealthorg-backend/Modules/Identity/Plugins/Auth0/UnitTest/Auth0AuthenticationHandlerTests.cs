using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;
using NwadHealth.Besthealthorg.IdentityModule.UnitTest.TestHelpers;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class Auth0AuthenticationHandlerTests
{
    private class TestHandler : DelegatingHandler
    {
        public HttpRequestMessage? RecentlyHandledRequest { get; set; }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            RecentlyHandledRequest = request;
            return Task.FromResult<HttpResponseMessage>(new());
        }
    }

    [Fact]
    public async Task SendAsync_WhenFailingToGetNewToken_ThrowsAuth0ManagementApiException()
    {
        var config = Auth0ConfigurationTestHelper.CreateAuth0Configuration();

        const string baseAddress = "https://baseAddress.com/";
        var expectedRequestAddress = new Uri($"{baseAddress}oauth/token");

        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage(HttpStatusCode.BadGateway)
        {
            Content = JsonContent.Create(new { Bla = "something" })
        });

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var innerHandler = new TestHandler();

        var auth0AuthenticationHandler = new Auth0AuthenticationHandler(
            httpClient,
            config,
            Mock.Of<ILogger<Auth0AuthenticationHandler>>()
        )
        {
            InnerHandler = innerHandler
        };

        var invoker = new HttpMessageInvoker(auth0AuthenticationHandler);
        var ex = await Assert.ThrowsAsync<Auth0ManagementApiException>(async () => await invoker.SendAsync(new(), new()));

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );

        Assert.Equal("Failed to acquire Auth0 management API token", ex.Message);
    }

    [Fact]
    public async Task SendAsync_WhenExistingTokenIsNull_FetchesNewTokenAndAddsToRequest()
    {
        var config = Auth0ConfigurationTestHelper.CreateAuth0Configuration();

        const string baseAddress = "https://baseAddress.com/";
        var expectedRequestAddress = new Uri($"{baseAddress}oauth/token");

        var jwt = JwtHelper.CreateValidToken("id");

        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage(HttpStatusCode.OK)
        {
            Content = JsonContent.Create(new { access_token = jwt })
        });

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var innerHandler = new TestHandler();

        var auth0AuthenticationHandler = new Auth0AuthenticationHandler(
            httpClient,
            config,
            Mock.Of<ILogger<Auth0AuthenticationHandler>>()
        )
        {
            InnerHandler = innerHandler
        };

        var invoker = new HttpMessageInvoker(auth0AuthenticationHandler);
        await invoker.SendAsync(new(), new());

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );

        var actualJwt = innerHandler.RecentlyHandledRequest!.Headers.Authorization!.Parameter;

        Assert.Equal(jwt, actualJwt);
    }

    [Fact]
    public async Task SendAsync_WhenExistingTokenIsExpired_FetchesNewTokenAndAddsToRequest()
    {
        var config = Auth0ConfigurationTestHelper.CreateAuth0Configuration();

        const string baseAddress = "https://baseAddress.com/";
        var expectedRequestAddress = new Uri($"{baseAddress}oauth/token");

        var expiredJwt = JwtHelper.CreateValidToken("id", -1);
        var validJwt = JwtHelper.CreateValidToken("id");

        var responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
        {
            Content = JsonContent.Create(new { access_token = expiredJwt })
        };

        var httpHandlerMock = CreateHttpMessageHandlerMock(responseMessage);

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var innerHandler = new TestHandler();

        var auth0AuthenticationHandler = new Auth0AuthenticationHandler(
            httpClient,
            config,
            Mock.Of<ILogger<Auth0AuthenticationHandler>>()
        )
        {
            InnerHandler = innerHandler
        };

        var invoker = new HttpMessageInvoker(auth0AuthenticationHandler);
        await invoker.SendAsync(new(), new());

        responseMessage.Content = JsonContent.Create(new { access_token = validJwt });
        await invoker.SendAsync(new(), new());

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Exactly(2),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );

        var actualJwt = innerHandler.RecentlyHandledRequest!.Headers.Authorization!.Parameter;

        Assert.Equal(validJwt, actualJwt);
    }

    [Fact]
    public async Task SendAsync_WhenExistingTokenIsValid_AddsExistingTokenToRequest()
    {
        var config = Auth0ConfigurationTestHelper.CreateAuth0Configuration();

        const string baseAddress = "https://baseAddress.com/";
        var expectedRequestAddress = new Uri($"{baseAddress}oauth/token");

        var firstValidJwt = JwtHelper.CreateValidToken("id");
        var secondValidJwt = JwtHelper.CreateValidToken("id");

        var responseMessage = new HttpResponseMessage(HttpStatusCode.OK)
        {
            Content = JsonContent.Create(new { access_token = firstValidJwt })
        };

        var httpHandlerMock = CreateHttpMessageHandlerMock(responseMessage);

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var innerHandler = new TestHandler();

        var auth0AuthenticationHandler = new Auth0AuthenticationHandler(
            httpClient,
            config,
            Mock.Of<ILogger<Auth0AuthenticationHandler>>()
        )
        {
            InnerHandler = innerHandler
        };

        var invoker = new HttpMessageInvoker(auth0AuthenticationHandler);
        await invoker.SendAsync(new(), new());

        var actualJwt = innerHandler.RecentlyHandledRequest!.Headers.Authorization!.Parameter;
        Assert.Equal(firstValidJwt, actualJwt);

        responseMessage.Content = JsonContent.Create(new { access_token = secondValidJwt });
        await invoker.SendAsync(new(), new());

        actualJwt = innerHandler.RecentlyHandledRequest!.Headers.Authorization!.Parameter;
        Assert.Equal(firstValidJwt, actualJwt);

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );
    }

    private static Mock<HttpMessageHandler> CreateHttpMessageHandlerMock(HttpResponseMessage response)
    {
        var mock = new Mock<HttpMessageHandler>(MockBehavior.Strict);

        mock
            .Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(() => response)
            .Verifiable();

        return mock;
    }
}
