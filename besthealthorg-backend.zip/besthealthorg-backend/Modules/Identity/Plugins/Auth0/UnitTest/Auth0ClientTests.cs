using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class Auth0ClientTests
{
    #region ResendVerificationEmail

    [Fact]
    public async Task ResendVerificationEmail_SendsRequestToCorrectEndpoint()
    {
        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage());
        const string baseAddress = "https://baseAddress.com/";
        var expectedRequestAddress = new Uri($"{baseAddress}api/v2/jobs/verification-email");

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());

        await auth0Client.ResendVerificationEmail("identityId");

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );
    }

    [Fact]
    public async Task ResendVerificationEmail_SendsCorrectBody()
    {
        const string identityId = "identityId";
        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage());

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new("https://test.com/")
        };

        var expectedBody = JsonSerializer.Serialize(new
        {
            user_id = identityId
        });

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());

        await auth0Client.ResendVerificationEmail(identityId);

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req =>
                    req.Method == HttpMethod.Post && req.Content!.ReadAsStringAsync().Result == expectedBody),
                ItExpr.IsAny<CancellationToken>()
            );
    }

    [Fact]
    public async Task ResendVerificationEmail_ReturnsAuth0Error_IfResponseIndicatesFailure()
    {
        const string errorCode = "errorCode";

        var response = new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.NotFound,
            Content = JsonContent.Create(new { ErrorCode = errorCode })
        };

        var httpHandlerMock = CreateHttpMessageHandlerMock(response);

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new("https://baseAddress.com/")
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());
        var (_, error) = await auth0Client.ResendVerificationEmail("identityId");

        Assert.Equal(errorCode, error?.ErrorCode);
    }

    #endregion ResendVerificationEmail

    #region FetchIdentityById

    [Fact]
    public async Task FetchIdentityById_SendsRequestToCorrectEndpoint()
    {
        const string identityId = "identityId";
        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage());
        const string baseAddress = "https://baseAddress.com/";
        var expectedRequestAddress = new Uri($"{baseAddress}api/v2/users/{identityId}");

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());

        await auth0Client.FetchIdentityById(identityId);

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Get && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );
    }

    [Fact]
    public async Task FetchIdentityById_ReturnsAuth0Error_IfResponseIndicatesFailure()
    {
        const string errorCode = "errorCode";

        var response = new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.BadGateway,
            Content = JsonContent.Create(new { ErrorCode = errorCode })
        };

        var httpHandlerMock = CreateHttpMessageHandlerMock(response);

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new("https://baseAddress.com/")
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());
        var (_, _, error) = await auth0Client.FetchIdentityById("identityId");

        Assert.Equal(errorCode, error?.ErrorCode);
    }

    #endregion FetchIdentityById

    #region FetchIdentityByEmail

    [Fact]
    public async Task FetchIdentityByEmail_SendsRequestToCorrectEndpoint()
    {
        const string email = "email";
        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage());
        const string baseAddress = "https://baseAddress.com/";
        var expectedRequestAddress = new Uri($"{baseAddress}api/v2/users-by-email?email={email}");

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());

        await auth0Client.FetchIdentityByEmail(email);

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Get && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );
    }

    [Fact]
    public async Task FetchIdentityByEmail_ReturnsAuth0Error_IfResponseIndicatesFailure()
    {
        const string errorCode = "errorCode";

        var response = new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.BadGateway,
            Content = JsonContent.Create(new { ErrorCode = errorCode })
        };

        var httpHandlerMock = CreateHttpMessageHandlerMock(response);

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new("https://baseAddress.com/")
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());
        var (_, _, error) = await auth0Client.FetchIdentityByEmail("email");

        Assert.Equal(errorCode, error?.ErrorCode);
    }

    #endregion FetchIdentityByEmail

    #region FetchRules

    [Fact]
    public async Task FetchRules_SendsRequestToCorrectEndpoint()
    {
        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage());
        const string baseAddress = "https://baseAddress.com/";
        var expectedRequestAddress = new Uri($"{baseAddress}api/v2/rules");

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());

        await auth0Client.FetchRules();

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Get && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );
    }

    [Fact]
    public async Task FetchRules_ReturnsAuth0Error_IfResponseIndicatesFailure()
    {
        const string errorCode = "errorCode";

        var response = new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.BadGateway,
            Content = JsonContent.Create(new { ErrorCode = errorCode })
        };

        var httpHandlerMock = CreateHttpMessageHandlerMock(response);

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new("https://baseAddress.com/")
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());
        var (_, _, error) = await auth0Client.FetchRules();

        Assert.Equal(errorCode, error?.ErrorCode);
    }

    #endregion FetchRules

    #region DeleteIdentity

    [Fact]
    public async Task DeleteIdentity_SendsRequestToCorrectEndpoint()
    {
        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage());
        const string baseAddress = "https://baseAddress.com/";
        const string identityId = "user-123";
        var expectedRequestAddress = new Uri($"{baseAddress}api/v2/users/{identityId}");

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());

        await auth0Client.DeleteIdentity(identityId);

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Delete && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );
    }

    [Fact]
    public async Task DeleteIdentity_ReturnsAuth0Error_IfResponseIndicatesFailure()
    {
        const string errorCode = "errorCode";

        var response = new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.BadGateway,
            Content = JsonContent.Create(new { ErrorCode = errorCode })
        };

        var httpHandlerMock = CreateHttpMessageHandlerMock(response);

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new("https://baseAddress.com/")
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());
        var (_, error) = await auth0Client.DeleteIdentity("identityId");

        Assert.Equal(errorCode, error?.ErrorCode);
    }

    #endregion DeleteIdentity

    #region ChangeEmail

    [Fact]
    public async Task ChangeEmail_SendsRequestToCorrectEndpoint()
    {
        const string identityId = "identityId";
        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage());
        const string baseAddress = "https://baseAddress.com/";
        var expectedRequestAddress = new Uri($"{baseAddress}api/v2/users/{identityId}");

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());

        await auth0Client.ChangeEmail(identityId, "newEmail");

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Patch && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );
    }

    [Fact]
    public async Task ChangeEmail_SendsCorrectBody()
    {
        const string identityId = "identityId";
        const string newEmail = "newEmail";
        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage());
        const string baseAddress = "https://baseAddress.com/";

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());

        var expectedBody = JsonSerializer.Serialize(new
        {
            email = newEmail,
            verify_email = true
        });

        await auth0Client.ChangeEmail(identityId, newEmail);

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req =>
                    req.Method == HttpMethod.Patch && req.Content!.ReadAsStringAsync().Result == expectedBody),
                ItExpr.IsAny<CancellationToken>()
            );
    }

    [Fact]
    public async Task ChangeEmail_ReturnsAuth0Error_IfResponseIndicatesFailure()
    {
        const string errorCode = "errorCode";

        var response = new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.BadRequest,
            Content = JsonContent.Create(new { ErrorCode = errorCode })
        };

        var httpHandlerMock = CreateHttpMessageHandlerMock(response);

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new("https://baseAddress.com/")
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());
        var (_, error) = await auth0Client.ChangeEmail("identityId", "newEmail");

        Assert.Equal(errorCode, error?.ErrorCode);
    }

    #endregion ChangeEmail

    #region CreateIdentity

    [Fact]
    public async Task CreateIdentity_SendsRequestToCorrectEndpoint()
    {
        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage());
        const string baseAddress = "https://baseAddress.com/";
        var expectedRequestAddress = new Uri($"{baseAddress}api/v2/users");

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());

        await auth0Client.CreateIdentity( "email", "password", "auth0Conn", true);

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );
    }

    [Fact]
    public async Task CreateIdentity_ReturnsAuth0Error_IfResponseIndicatesFailure()
    {
        const string errorCode = "errorCode";

        var response = new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.BadGateway,
            Content = JsonContent.Create(new { ErrorCode = errorCode })
        };

        var httpHandlerMock = CreateHttpMessageHandlerMock(response);

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new("https://baseAddress.com/")
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());
        var (_, _, error) = await auth0Client.CreateIdentity("email", "password", "auth0Conn", true);

        Assert.Equal(errorCode, error?.ErrorCode);
    }

    #endregion CreateIdentity

    #region CreateResetPasswordTicket

    [Fact]
    public async Task CreateResetPasswordTicket_SendsRequestToCorrectEndpoint()
    {
        var httpHandlerMock = CreateHttpMessageHandlerMock(new HttpResponseMessage());
        const string baseAddress = "https://baseAddress.com/";
        var expectedRequestAddress = new Uri($"{baseAddress}api/v2/tickets/password-change");

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new(baseAddress)
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());

        await auth0Client.CreateResetPasswordTicket("identityId", true, "clientId");

        httpHandlerMock
            .Protected()
            .Verify(
                "SendAsync",
                Times.Once(),
                ItExpr.Is<HttpRequestMessage>(req => req.Method == HttpMethod.Post && req.RequestUri == expectedRequestAddress),
                ItExpr.IsAny<CancellationToken>()
            );
    }

    [Fact]
    public async Task CreateResetPasswordTicket_ReturnsAuth0Error_IfResponseIndicatesFailure()
    {
        const string errorCode = "errorCode";

        var response = new HttpResponseMessage
        {
            StatusCode = HttpStatusCode.BadGateway,
            Content = JsonContent.Create(new { ErrorCode = errorCode })
        };

        var httpHandlerMock = CreateHttpMessageHandlerMock(response);

        var httpClient = new HttpClient(httpHandlerMock.Object)
        {
            BaseAddress = new("https://baseAddress.com/")
        };

        var auth0Client = new Auth0Client(httpClient, Mock.Of<ILogger<Auth0Client>>());
        var (_, _, error) = await auth0Client.CreateResetPasswordTicket("identityId", true, "clientId");

        Assert.Equal(errorCode, error?.ErrorCode);
    }

    #endregion CreateResetPasswordTicket

    private static Mock<HttpMessageHandler> CreateHttpMessageHandlerMock(HttpResponseMessage response)
    {
        var mock = new Mock<HttpMessageHandler>(MockBehavior.Strict);

        mock
            .Protected()
            .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(response)
            .Verifiable();

        return mock;
    }
}
