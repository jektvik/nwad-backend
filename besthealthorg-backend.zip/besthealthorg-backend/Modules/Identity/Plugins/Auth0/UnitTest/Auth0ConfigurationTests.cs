using System;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;
using NwadHealth.Besthealthorg.IdentityModule.UnitTest.TestHelpers;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class Auth0ConfigurationTests
{
    #region InstantiateAuth0Configuration

    [Fact]
    public void InstantiateAuth0Configuration_WithValidParameters_SetsCorrectValues()
    {
        Auth0Configuration? config = null;
        var (authority, audience, clientId, clientSecret, tenantBaseUrl) = Auth0ConfigurationTestHelper.CreateValidParams();

        var exception = Record.Exception(() => config = new(authority, audience, clientId, clientSecret, tenantBaseUrl));

        Assert.Null(exception);
        Assert.Equal(authority, config?.Authority);
        Assert.Equal(audience, config?.Audience);
        Assert.Equal(clientId, config?.ClientId);
        Assert.Equal(clientSecret, config?.ClientSecret);
        Assert.Equal(tenantBaseUrl, config?.TenantBaseUrl);
    }

    [Theory]
    [InlineData("", "Authority cannot be null or empty")]
    [InlineData("auth", "Authority must start with 'https://'")]
    [InlineData("https://auth", "Authority must end with '/'")]
    public void InstantiateAuth0Configuration_WithInvalidAuthority_ThrowsArgumentException(string authority, string expectedMessage)
    {
        var (_, audience, clientId, clientSecret, tenantBaseUrl) = Auth0ConfigurationTestHelper.CreateValidParams();

        var exception = Assert.Throws<ArgumentException>(() =>
            new Auth0Configuration(authority, audience, clientId, clientSecret, tenantBaseUrl));

        Assert.Equal($"{expectedMessage} (Parameter 'authority')", exception.Message);
    }

    [Fact]
    public void InstantiateAuth0Configuration_WithInvalidAudience_ThrowsArgumentException()
    {
        var (authority, _, clientId, clientSecret, tenantBaseUrl) = Auth0ConfigurationTestHelper.CreateValidParams();

        var exception = Assert.Throws<ArgumentException>(() =>
            new Auth0Configuration(authority, string.Empty, clientId, clientSecret, tenantBaseUrl));

        Assert.Equal("Audience cannot be null or empty (Parameter 'audience')", exception.Message);
    }

    [Fact]
    public void InstantiateAuth0Configuration_WithInvalidClientId_ThrowsArgumentException()
    {
        var (authority, audience, _, clientSecret, tenantBaseUrl) = Auth0ConfigurationTestHelper.CreateValidParams();

        var exception = Assert.Throws<ArgumentException>(() =>
            new Auth0Configuration(authority, audience, string.Empty, clientSecret, tenantBaseUrl));

        Assert.Equal("ClientId cannot be null or empty (Parameter 'clientId')", exception.Message);
    }

    [Fact]
    public void InstantiateAuth0Configuration_WithInvalidClientSecret_ThrowsArgumentException()
    {
        var (authority, audience, clientId, _, tenantBaseUrl) = Auth0ConfigurationTestHelper.CreateValidParams();

        var exception = Assert.Throws<ArgumentException>(() =>
            new Auth0Configuration(authority, audience, clientId, string.Empty, tenantBaseUrl));

        Assert.Equal("ClientSecret cannot be null or empty (Parameter 'clientSecret')", exception.Message);
    }

    [Theory]
    [InlineData("", "Tenant base URL cannot be null or empty")]
    [InlineData("auth", "Tenant base URL must start with 'https://'")]
    [InlineData("https://auth", "Tenant base URL must end with '/'")]
    public void
    InstantiateAuth0Configuration_WithInvalidManagementAudience_ThrowsArgumentException(string tenantBaseUrl, string expectedMessage)
    {
        var (authority, audience, clientId, clientSecret, _) = Auth0ConfigurationTestHelper.CreateValidParams();

        var exception = Assert.Throws<ArgumentException>(() =>
            new Auth0Configuration(authority, audience, clientId, clientSecret, tenantBaseUrl));

        Assert.Equal($"{expectedMessage} (Parameter 'tenantBaseUrl')", exception.Message);
    }

    #endregion InstantiateAuth0Configuration

    #region ManagementApiAudience

    [Fact]
    public void ManagementApiAudience_IsBuiltCorrectly()
    {
        var config = Auth0ConfigurationTestHelper.CreateAuth0Configuration();

        Assert.Equal($"{config.TenantBaseUrl}api/v2/", config.ManagementApiAudience);
    }

    #endregion ManagementApiAudience

    #region ManagementApiGrantType

    [Fact]
    public void ManageMentApiGrantType_IsClientCredentials()
    {
        Assert.Equal("client_credentials", Auth0Configuration.ManagementApiGrantType);
    }

    #endregion ManagementApiGrantType
}
