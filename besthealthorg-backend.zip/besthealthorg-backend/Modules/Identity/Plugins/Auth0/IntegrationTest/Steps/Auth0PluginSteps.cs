using System.Net.Http.Json;
using System.Text.Json.Serialization;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Auth0;
using Microsoft.Extensions.DependencyInjection;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.IntegrationTest;

[Binding]
public sealed class Auth0PluginSteps
{
    private class CreateAccountResp
    {
        [JsonPropertyName("user_id")]
        public string IdentityId { get; set; } = string.Empty;

        [JsonPropertyName("email_verified")]
        public bool EmailVerified { get; set; }
    }

    private readonly ScenarioContext _context;

    private IIdentity? _fetchedIdentity;
    private Exception? _error;
    private IIdentityProvider? _identityProvider;
    private HttpClient? _auth0TestClient;
    private IAuth0Client? _auth0Client;

    private string? _identityIdToDelete;
    private string? _identityIdToChangeEmailFor;

    public Auth0PluginSteps(ScenarioContext context)
    {
        _context = context;
    }

    [Given("Plugin is configured to use besthealthorg-test tenant")]
    public void GivenPluginIsConfiguredToUsePaceTestTenant()
    {
        var config = new Auth0Configuration(
            "https://besthealthorg-test.eu.auth0.com/",
            "https://api-resource-test-pacestabletestsa.com",
            "JxZ7RF6Z7lfMovwAc0CS7UMLOUCG448Q",
            "TenmWaILRtHUcOUrkBTruG0_roYj80FsxYWUbaK8hBMn-_5BPlOA7qZuhl1SbqJ8",
            "https://besthealthorg-test.eu.auth0.com/"
        );

        var services = new ServiceCollection();
        var plugin = new Auth0Plugin(config);
        plugin.ConfigureServices(services);

        services.AddScoped<IIdentityProvider, Auth0IdentityProvider>();

        services
            .AddHttpClient("Auth0TestClient", httpClient =>
            {
                httpClient.BaseAddress = new(config.TenantBaseUrl);
                httpClient.Timeout = new(0, 0, 30);
                httpClient.DefaultRequestHeaders.Clear();
            })
            .AddHttpMessageHandler<Auth0AuthenticationHandler>();

        var scope = services
            .BuildServiceProvider()
            .CreateScope();

        _identityProvider =
            scope
            .ServiceProvider
            .GetRequiredService<IIdentityProvider>();

        _auth0Client =
            scope
            .ServiceProvider
            .GetRequiredService<IAuth0Client>();

        _auth0TestClient = scope.ServiceProvider.GetRequiredService<IHttpClientFactory>().CreateClient("Auth0TestClient");
    }

    [When("I fetch an identity with a verified email address")]
    public async Task WhenIFetchAnIdentityWithAVerifiedEmailAddress()
    {
        _fetchedIdentity = await _identityProvider!.FetchIdentity("auth0|6500460ecf2663ddf13cd71a");
    }

    [Then("Plugin says that identity has verified their email")]
    public void ThenPluginSaysThatIdentityHasVerifiedTheirEmail()
    {
        Assert.True(_fetchedIdentity?.EmailVerified);
    }

    [When("I fetch an identity with a not verified email address")]
    public async Task WhenIFetchAnIdentityWithANotVerifiedEmailAddress()
    {
        _fetchedIdentity = await _identityProvider!.FetchIdentity("auth0|650045fa4afd8cebbecc86c7");
    }

    [Then("Plugin says that identity has not verified their email")]
    public void ThenPluginSaysThatIdentityHasNotVerifiedTheirEmail()
    {
        Assert.False(_fetchedIdentity?.EmailVerified);
    }

    [When("I fetch an identity that does not exist")]
    public async Task WhenIFetchAnIdentityThatDoesNotExist()
    {
        _fetchedIdentity = await _identityProvider!.FetchIdentity("auth0|1234568");
    }

    [Then("Plugin says that identity does not exist")]
    public void ThenPluginSaysThatIdentityDoesNotExist()
    {
        Assert.Null(_fetchedIdentity);
    }

    [When("I attempt to resend email verification for an identity that does not exist")]
    public async Task WhenIAttemptToResendEmailVerificationForAnIdentitythatDoesNotExist()
    {
        _error = await Record.ExceptionAsync(() => _identityProvider!.ResendVerificationEmail("auth0|12345678"));
    }

    [Then("Plugin says error: identity does not exist")]
    public void ThenPluginSaysErrorIdentityDoesNotExist()
    {
        Assert.IsType<IdentityNotFoundException>(_error);
    }

    [Given("An identity that should be deleted")]
    public async Task GivenAnIdentityThatShouldBeDeleted()
    {
        var body = new
        {
            email = "Auth0DeleteAccount@test.com",
            password = "Test123!",
            connection = "Besthealthorg-test-DB-pacestabletestsa"
        };

        var resp = await _auth0TestClient!.PostAsync($"/api/v2/users", JsonContent.Create(body));

        Assert.True(resp.IsSuccessStatusCode);

        var respObject = await resp.Content.ReadFromJsonAsync<CreateAccountResp>();
        _identityIdToDelete = respObject?.IdentityId;
    }

    [When("I delete the identity")]
    public async Task WhenIDeleteTheIdentity()
    {
        await _identityProvider!.DeleteIdentity(_identityIdToDelete!);
    }

    [Then("The identity no longer exists")]
    public async Task ThenTheIdentityNoLongerExists()
    {
        Assert.Null(await _identityProvider!.FetchIdentity(_identityIdToDelete!));
    }

    [Given("an identity with a verified email")]
    public async Task GivenAnIdentityWithAVerifiedEmail()
    {
        var body = new
        {
            email = "Auth0ChangeEmail@test.com",
            password = "Test123!",
            connection = "Besthealthorg-test-DB-pacestabletestsa",
            email_verified = true
        };

        var resp = await _auth0TestClient!.PostAsync($"/api/v2/users", JsonContent.Create(body));

        Assert.True(resp.IsSuccessStatusCode);

        var respObject = await resp.Content.ReadFromJsonAsync<CreateAccountResp>();
        _identityIdToChangeEmailFor = respObject!.IdentityId;

        Assert.True(respObject!.EmailVerified);
    }

    [When("I change the email of the identity")]
    public async Task WhenIChangeTheEmailOfTheIdentity()
    {
        await _identityProvider!.ChangeEmail(_identityIdToChangeEmailFor!, "Auth0ChangeEmailUpdated@test.com");
    }

    [When("I change the email of the identity to an invalid format")]
    public async Task WhenIChangeTheEmailOfTheIdentityToAnInvalidFormat()
    {
        _error = await Record.ExceptionAsync(() => _identityProvider!.ChangeEmail(_identityIdToChangeEmailFor!, "blablatest.com"));
    }

    [Then("the email of the identity is updated and not verified")]
    public async Task ThenTheEmailOfTheIdentityIsUpdatedAndNotVerified()
    {
        var identity = await _identityProvider!.FetchIdentity(_identityIdToChangeEmailFor!);

        Assert.Equal("Auth0ChangeEmailUpdated@test.com".ToLower(), identity!.Email.ToLower());
        Assert.False(identity!.EmailVerified);
    }

    [Then("the plugin says error: email has invalid format")]
    public void ThenThePluginSaysErrorEmailHasInvalidFormat()
    {
        Assert.IsType<ArgumentException>(_error);

        var argError = _error as ArgumentException;

        Assert.Equal("newEmail", argError!.ParamName);
    }

    [AfterScenario]
    public async Task AfterScenario()
    {
        if (_identityIdToChangeEmailFor is not null)
        {
            await _identityProvider!.DeleteIdentity(_identityIdToChangeEmailFor);
        }
    }
}
