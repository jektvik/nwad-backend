using NwadHealth.Besthealthorg.Foundation.Extensions.Cosmos;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.DbModels;
using Microsoft.Azure.Cosmos;
using TechTalk.SpecFlow;
using Xunit;
using Xunit.Abstractions;

namespace NwadHealth.Besthealthorg.IdentityModule.IntegrationTest;

[Binding]
public sealed class SharedSteps : IClassFixture<IdentityWebApplicationFactory>
{
    private readonly ScenarioContext _context;
    private readonly CosmosClient _cosmosClient;
    private readonly Container _identityPropertiesContainer;
    private readonly Container _roleAssignmentsContainer;
    private readonly Container _rolesContainer;
    private readonly IdentityWebApplicationFactory _factory;
    private readonly ITestOutputHelper _outputHelper;

    public SharedSteps(ScenarioContext context, IdentityWebApplicationFactory factory, ITestOutputHelper outputHelper)
    {
        _context = context;
        _factory = factory;
        _outputHelper = outputHelper;
        var config = IdentityWebApplicationFactory.Configuration;

        _cosmosClient = IdentityWebApplicationFactory.AzureClientProvider.GetCosmosClient(config.CosmosDbConnectionString);
        _identityPropertiesContainer = _cosmosClient.GetContainer(config.CosmosDbDatabaseName, config.CosmosDbIdentityPropertiesContainerName);
        _roleAssignmentsContainer = _cosmosClient.GetContainer(config.CosmosDbDatabaseName, config.CosmosDbRoleAssignmentsContainer);
        _rolesContainer = _cosmosClient.GetContainer(config.CosmosDbDatabaseName, config.CosmosDbRolesContainer);
    }

    [Given("A running backend")]
    public void GivenARunningBackend()
    {
        _context.Set(_factory.CreateClient());
    }

    [Given("I subscribe to the identity events")]
    public void GivenISubscribeToTheIdentityEvents()
    {
        using var scope = _factory.Services.CreateScope();

        var subscriber = scope.ServiceProvider.GetRequiredService<IIdentityEventSubscriber>();

        subscriber.EmailChanged += (_, emailChangedEvent) =>
        {
            _context.Set(emailChangedEvent);
        };

        subscriber.IdentityDeleted += (_, identityDeletedEvent) =>
        {
            _context.Set(identityDeletedEvent);
        };
    }

    [BeforeScenario]
    [BeforeScenario("ResetIdentityProperties")]
    private async Task ResetDatabase()
    {
        _outputHelper.WriteLine("Resetting Identity Properties");
        foreach (var identityProperties in await _identityPropertiesContainer.GetAll<IdentityPropertiesDocument>())
        {
            await _identityPropertiesContainer.DeleteItemAsync<IdentityPropertiesDocument>(
                 id: identityProperties.Id,
                 partitionKey: new PartitionKey(identityProperties.Id));
        }

        foreach (var roleAssignment in await _roleAssignmentsContainer.GetAll<RoleAssignment>())
        {
            await _roleAssignmentsContainer.DeleteItemAsync<RoleAssignment>(
                id: roleAssignment.Id,
                partitionKey: new PartitionKey(roleAssignment.Id));
        }

        foreach (var role in await _rolesContainer.GetAll<RoleDocument>())
        {
            await _rolesContainer.DeleteItemAsync<RoleDocument>(
                id: role.Id,
                partitionKey: new PartitionKey(role.Id));
        }
    }
}
