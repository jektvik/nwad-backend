using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Events;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.IntegrationTest;

[Binding]
public sealed class IdentitySteps
{
    private readonly ScenarioContext _context;

    public IdentitySteps(ScenarioContext context)
    {
        _context = context;
    }

    [When("I request to delete the authorized user")]
    public async Task WhenIRequestToDeleteTheAuthorizedUser()
    {
        _context.Set(await _context.Get<HttpClient>().DeleteAsync("identity"));
    }

    [When("I request to change my email")]
    public async Task WhenIRequestToChangeMyEmail()
    {
        _context.Set(await _context.Get<HttpClient>().PatchAsync("Identity/change-email", JsonContent.Create(new ChangeEmailRequestDto("newEmail"))));
    }

    [When("I request to change my email to an invalid format")]
    public async Task WhenIRequestToChangeMyEmailToAnInvalidFormat()
    {
        _context.Set(await _context.Get<HttpClient>().PatchAsync("Identity/change-email", JsonContent.Create(new ChangeEmailRequestDto("invalidEmail"))));
    }

    [When("I request to change my email to the same email")]
    public async Task WhenIRequestToChangeMyEmailToTheSameEmail()
    {
        _context.Set(await _context.Get<HttpClient>().PatchAsync("Identity/change-email", JsonContent.Create(new ChangeEmailRequestDto("test@mail.com"))));
    }

    [When("I request a verification email to be resent")]
    public async Task WhenIRequestAVerificationEmailToBeResent()
    {
        _context.Set(await _context.Get<HttpClient>().PostAsync("Identity/resend-verification-email", null));
    }

    [When("I request the email verification status")]
    public async Task WhenIRequestTheEmailVerificationStatus()
    {
        _context.Set(await _context.Get<HttpClient>().GetAsync("Identity/email-verification-status"));
    }

    [Then("^Backend tells me that the user (has|has not) verified their email")]
    public async Task ThenBackendTellsMeThatTheUserHasOrHasNotVerifiedTheirEmail(string hasOrHasNot)
    {
        var expected = hasOrHasNot == "has";
        var verificationStatusResponse = _context.Get<HttpResponseMessage>();

        Assert.True(verificationStatusResponse!.IsSuccessStatusCode);

        var data = await verificationStatusResponse.Content.ReadFromJsonAsync<EmailVerificationStatusResponseDto>();

        Assert.Equal(expected, data!.Verified);
    }

    [Then("I receive a change email event with the expected data")]
    public void ThenIReceiveAChangeEmailEventWithTheExpectedData()
    {
        var emailChangedEvent = _context.Get<EmailChangedEvent>();

        Assert.NotNull(emailChangedEvent);
        Assert.Equal("verified", emailChangedEvent.IdentityId);
        Assert.Equal("newEmail", emailChangedEvent.NewEmail);
    }

    [Then("I receive a delete identity event with the expected data")]
    public void ThenIReceiveADeleteIdentityEventWithTheExpectedData()
    {
        var identityDeletedEvent = _context.Get<IdentityDeletedEvent>();

        Assert.NotNull(identityDeletedEvent);
        Assert.Equal("authorized", identityDeletedEvent.Identity.Id);
    }
}
