using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.IntegrationTest;

[Binding]
public sealed class ConfigurationSteps
{
    private readonly ScenarioContext _context;

    public ConfigurationSteps(ScenarioContext context)
    {
        _context = context;
    }

    [When("I request the identity configuration")]
    public async Task WhenIRequestTheIdentityConfiguration()
    {
        _context.Set(await _context.Get<HttpClient>().GetAsync("Identity/configuration"));
    }

    [Then("^I can see that email verification (is|is not) required")]
    public async Task ThenICanSeeThatEmailVerificationIsOrIsNotRequired(string isOrIsNot)
    {
        var expected = isOrIsNot == "is";
        var configResponse = _context.Get<HttpResponseMessage>();

        Assert.True(configResponse!.IsSuccessStatusCode);

        var data = await configResponse.Content.ReadFromJsonAsync<ConfigurationResponseDto>();

        Assert.Equal(expected, data!.IsEmailVerificationRequired);
    }

    [Then("I get a list of supported countries")]
    public async Task ThenIGetAListOfSupportedCountries()
    {
        var expectedSupportedCountries = new List<string> { "dk", "sw", "gb", "de", "it", "lv", "sk", "gr", "th", "us" };
        var configResponse = _context.Get<HttpResponseMessage>();

        Assert.True(configResponse!.IsSuccessStatusCode);

        var data = await configResponse.Content.ReadFromJsonAsync<ConfigurationResponseDto>();

        Assert.Equal(expectedSupportedCountries, data!.SupportedCountries);
    }
}
