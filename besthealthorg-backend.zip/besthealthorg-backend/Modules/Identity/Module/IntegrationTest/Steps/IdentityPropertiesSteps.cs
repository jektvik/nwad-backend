using System.Net;
using NwadHealth.Besthealthorg.ConsentModule.Infrastructure.Repositories;
using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.IntegrationTest;

[Binding]
public sealed class IdentityPropertiesSteps
{
    private readonly ScenarioContext _context;
    private readonly IIdentityPropertiesRepository _identityPropertiesRepo;

    private const string UserCountryCode = "dk";
    public const string KeyUserCountryCode = "user_country_code";

    public IdentityPropertiesSteps(ScenarioContext context)
    {
        _context = context;
        _identityPropertiesRepo = new IdentityPropertiesRepository(IdentityWebApplicationFactory.Configuration, IdentityWebApplicationFactory.AzureClientProvider);
    }

    [Given("I have identity properties")]
    public async Task GivenIHaveIdentityProperties()
    {
        var identityProperties = await _identityPropertiesRepo.Create(new()
        {
            IdentityId = _context.Get<string>("userId"),
            CountryCode = UserCountryCode,
        });

        _context.Set(identityProperties);
        _context.Set(identityProperties.CountryCode, KeyUserCountryCode);
    }

    [When("I request to create identity properties")]
    public async Task WhenIRequestToCreateIdentityProperties()
    {
        var requestDto = new IdentityPropertiesRequestDto("dk");
        _context.Set(await _context.Get<HttpClient>().PostAsJsonAsync("identityProperties", requestDto));
    }

    [When("I request to create identity properties with an unsupported country")]
    public async Task WhenIRequestToCreateIdentityPropertiesWithAnUnsupportedCountry()
    {
        var requestDto = new IdentityPropertiesRequestDto("xx");
        _context.Set(await _context.Get<HttpClient>().PostAsJsonAsync("identityProperties", requestDto));
    }

    [When("I request my identity properties")]
    public async Task WhenIRequestMyIdentityProperties()
    {
        _context.Set(await _context.Get<HttpClient>().GetAsync("identityProperties"));
    }

    [When("I request my identity properties with role")]
    public async Task WhenIRequestMyIdentityPropertiesWithRole()
    {
        _context.Set(await _context.Get<HttpClient>().GetAsync($"identityProperties"));
    }

    [Then("the backend tells me that the identity properties were created")]
    public async Task ThenTheBackendTellsMeThatTheIdentityPropertiesWereCreated()
    {
        var createIdentityPropertiesResponse = _context.Get<HttpResponseMessage>();
        var responseDto = await createIdentityPropertiesResponse.Content.ReadFromJsonAsync<IdentityPropertiesResponseDto>();

        Assert.Equal(HttpStatusCode.Created, createIdentityPropertiesResponse!.StatusCode);
        Assert.Equal(_context.Get<string>("userId"), responseDto!.IdentityId);
        Assert.Equal("dk", responseDto.Country);
    }

    [Then("the backend tells me that this country is unsupported")]
    public async Task ThenTheBackendTellsMeThatThisCountryIsUnsupported()
    {
        var createIdentityPropertiesResponse = _context.Get<HttpResponseMessage>();
        var responseDto = await createIdentityPropertiesResponse.Content.ReadFromJsonAsync<ErrorResponseDto>();

        Assert.Equal(HttpStatusCode.BadRequest, createIdentityPropertiesResponse!.StatusCode);
        Assert.Equal("unsupported_country", responseDto!.ErrorCode);
        Assert.Equal("This country is not on the list of supported countries", responseDto!.Error);
    }

    [Then("the backend responds with the identity properties")]
    public async Task ThenTheBackendRespondsWithTheIdentityProperties()
    {
        var responseDto = await _context.Get<HttpResponseMessage>().Content.ReadFromJsonAsync<IdentityPropertiesResponseDto>();

        Assert.Equal(_context.Get<string>("userId"), responseDto!.IdentityId);
        Assert.Equal("dk", responseDto!.Country);
    }

    [Then("the backend responds with the identity properties with role")]
    public async Task ThenTheBackendRespondsWithTheIdentityPropertiesWithRole()
    {
        var responseDto = await _context.Get<HttpResponseMessage>().Content.ReadFromJsonAsync<IdentityPropertiesWithRoleResponseDto>();

        Assert.Equal(_context.Get<string>("userId"), responseDto!.IdentityId);
        Assert.Equal("dk", responseDto!.Country);
        Assert.Equal("NwadAdmin", responseDto.Role!.ElementAt(0).Id);
        Assert.Equal("Nwad Admin", responseDto.Role!.ElementAt(0).Name);
    }

    [Then("my identity properties are deleted")]
    public async Task ThenMyIdentityPropertiesAreDeleted()
    {
        Assert.Null(await _identityPropertiesRepo.GetIdentityPropertiesByIdentityId(_context.Get<string>("userId")));
    }
}
