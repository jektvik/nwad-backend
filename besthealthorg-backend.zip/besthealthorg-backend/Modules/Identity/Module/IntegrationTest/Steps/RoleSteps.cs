﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.DbModels;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;
using Microsoft.Azure.Cosmos;
using System.Net;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.IntegrationTest.Steps;

[Binding]
public class RoleSteps
{
    private readonly ScenarioContext _context;
    private readonly CosmosClient _cosmosClient;
    private readonly Container _roleAssignmentsContainer;
    private readonly Container _rolesContainer;

    public RoleSteps(ScenarioContext context)
    {
        _context = context;
        var config = IdentityWebApplicationFactory.Configuration;
        _cosmosClient = IdentityWebApplicationFactory.AzureClientProvider.GetCosmosClient(config.CosmosDbConnectionString);
        _roleAssignmentsContainer = _cosmosClient.GetContainer(config.CosmosDbDatabaseName, config.CosmosDbRoleAssignmentsContainer);
        _rolesContainer = _cosmosClient.GetContainer(config.CosmosDbDatabaseName, config.CosmosDbRolesContainer);
    }

    [Given("I have role assigned")]
    public async Task GivenIHaveRoleAssigned()
    {
        var userId = _context.Get<string>("userId");
        var roleAssignment = new RoleAssignment() { Id = userId, RoleId = "NwadAdmin" };

        await _roleAssignmentsContainer.CreateItemAsync(roleAssignment);
    }

    [Given("the roles exist in db")]
    public async Task GivenTheRolesExistInDb()
    {
        List<RoleDocument> roles = new List<RoleDocument> 
        {
            new()
            {
                Id = "NwadAdmin",
                Name = "Nwad Admin",

            },
            new()
            {
                Id = "CustomerAdmin",
                Name = "Customer Admin",

            },
            new()
            {
                Id = "Hcp",
                Name = "HCP",

            },
            new()
            {
                Id = "Patient",
                Name = "Patient",

            }
        };

        foreach (var role in roles)
        {
            try
            {
                await _rolesContainer.CreateItemAsync(role);
            }
            catch (CosmosException ex)
            {
                if (ex.StatusCode != HttpStatusCode.Conflict)
                {
                    throw;
                }
            }
        }
    }

    [When("I request my role")]
    public async Task WhenIRequestMyRole()
    {
        _context.Set(await _context.Get<HttpClient>().GetAsync("Identity/get-role"));
    }

    [Then("the backend responds with my role")]
    public async Task ThenTheBackendRespondsWithMyRole()
    {
        var role = await _context.Get<HttpResponseMessage>().Content.ReadFromJsonAsync<List<RoleResponseDto>>();

        Assert.Equal("NwadAdmin", role![0].Id);
        Assert.Equal("Nwad Admin", role![0].Name);
    }
}
