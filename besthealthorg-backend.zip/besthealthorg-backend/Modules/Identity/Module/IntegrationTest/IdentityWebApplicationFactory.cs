using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using NwadHealth.Besthealthorg.TestUtilities.IntegrationTestHelpers;

namespace NwadHealth.Besthealthorg.IdentityModule.IntegrationTest;

public class IdentityWebApplicationFactory : PaceWebApplicationFactory
{
    public static Configuration Configuration { get; } = new(CosmosDbConnectionString) { IsEmailVerificationRequired = true };

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        base.ConfigureWebHost(builder);

        builder.ConfigureServices(services =>
        {
            services
                .AddControllers()
                .AddApplicationPart(typeof(Frameworks.Controllers.IdentityController).Assembly);

            var plugin = new TestIdentityPlugin(JwtHelper.TokenSigningKey);

            services.AddPaceIdentity(Configuration, plugin);
        });

        builder.Configure(app =>
        {
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UsePaceIdentity();
            app.UseEndpoints(endpoints => endpoints.MapControllers());
        });
    }
}
