﻿namespace NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

/// <summary>
/// Represents country entitiy
/// </summary>
public class Country
{
    private string _id = string.Empty;

    /// <summary>
    ///Two letter country code in ISO 3166-1 alpha-2 format, eg: "dk" for Denmark
    /// </summary>
    /// <exception cref="ArgumentException">Thrown when id is initiliazed with more than 2 characters</exception>
    public string Id
    {
        get { return _id; }

        init
        {
            if (value.Length != 2)
            {
                throw new ArgumentException($"You tried to set {value.Length} characters long id, The id of the country must me exactly 2 characters long");
            }

            _id = value;
        }
    }

    /// <summary>
    /// Full country name
    /// </summary>
    public string Name { get; set; } = string.Empty;
}
