namespace NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

/// <summary>
/// Represents identity properties stored in the data store
/// </summary>
public class IdentityPropertiesDocument
{
    /// <summary>
    /// The id of the identity properties, this is equal to the identity id
    /// </summary>
    public string Id { get; set; } = string.Empty;

    /// <summary>
    /// The country of the identity properties
    /// </summary>
    public string? Country { get; set; } = string.Empty;

    /// <summary>
    /// Converts an identity properties domain model to an identity properties database model
    /// </summary>
    /// <param name="identityProperties">The identity properties domain model to convert</param>
    /// <returns>An IdentityPropertiesDocument created from the identity properties</returns>
    public static IdentityPropertiesDocument FromDomain(IdentityProperties identityProperties)
    {
        return new()
        {
            Id = identityProperties.IdentityId,
            Country = identityProperties.CountryCode,
        };
    }

    /// <summary>
    /// Converts an identity properties database model to an identity properties domain model
    /// </summary>
    /// <returns>An identity properties created from the identity properties document</returns>
    public IdentityProperties ToDomain()
    {
        return new()
        {
            IdentityId = Id,
            CountryCode = Country,
        };
    }
}
