namespace NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

/// <summary>
/// The Identity domain model
/// </summary>
public interface IIdentity
{
    /// <summary>
    /// The unique id of the Identity
    /// </summary>
    string Id { get; }

    /// <summary>
    /// The email of the Identity
    /// </summary>
    string Email { get; }

    /// <summary>
    /// Whether the identity has verified their email
    /// </summary>
    bool EmailVerified { get; }

    /// <summary>
    /// The time of user creation
    /// </summary>
    DateTimeOffset CreatedAt { get; }
}
