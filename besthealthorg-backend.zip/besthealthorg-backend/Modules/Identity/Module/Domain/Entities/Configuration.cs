namespace NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

/// <summary>
/// Represents the configuration of the identity module
/// </summary>
public class Configuration
{
    /// <summary>
    /// Whether email verification is required before login
    /// </summary>
    public bool IsEmailVerificationRequired { get; set; }

    /// <summary>
    /// The connection string for the CosmosDB, where identity properties and audit logs are written
    /// </summary>
    public string CosmosDbConnectionString { get; }

    /// <summary>
    /// The name of the CosmosDB database
    /// </summary>
    public string CosmosDbDatabaseName { get; } = "identity";

    /// <summary>
    /// The name of the CosmosDB container, where audit logs should be written
    /// </summary>
    public string CosmosDbAuditContainerName { get; } = "audit-logs";

    /// <summary>
    /// The name of the CosmosDB container, where identity properties should be stored
    /// </summary>
    public string CosmosDbIdentityPropertiesContainerName { get; } = "identityProperties";

    /// <summary>
    /// The name of the CosmosDB container, where list of countries should be stored
    /// </summary>
    public string CosmosDbCountriesContainer { get; } = "countries";

    /// <summary>
    /// The name of the CosmosDB container, where role assignments should be stored
    /// </summary>
    public string CosmosDbRoleAssignmentsContainer { get; } = "roleAssignments";

    /// <summary>
    /// The name of the CosmosDB container, where list of roles should be stored
    /// </summary>
    public string CosmosDbRolesContainer { get; } = "roles";

    /// <summary>
    /// The amount of time to retain audit logs after identity deletion, in years
    /// </summary>
    public int AuditLogRetentionTime { get; set; } = 2;

    /// <summary>
    /// Initializes the configuration
    /// </summary>
    /// <param name="cosmosDbConnectionString">The connection string of the CosmosDb to write audit log to</param>
    public Configuration(string cosmosDbConnectionString)
    {
        if (string.IsNullOrEmpty(cosmosDbConnectionString))
        {
            throw new ArgumentException("CosmosDB connection string cannot be null or empty", nameof(cosmosDbConnectionString));
        }

        CosmosDbConnectionString = cosmosDbConnectionString;
    }
}
