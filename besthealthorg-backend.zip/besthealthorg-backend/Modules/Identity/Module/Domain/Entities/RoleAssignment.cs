﻿namespace NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

/// <summary>
/// The role assignment domain model
/// </summary>
public class RoleAssignment
{
    /// <summary>
    /// Id belonging to an identity
    /// </summary>
    public string Id { get; set; } = string.Empty;

    /// <summary>
    /// Id corresponding to a role
    /// </summary>
    public string RoleId { get; set; } = string.Empty;
}
