﻿namespace NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

/// <summary>
/// Represents role domain model
/// </summary>
public class Role
{
    /// <summary>
    /// Default role for users
    /// </summary>
    public static readonly Role Default = new() { Id = "Unassigned", Name = "Unassigned" };

    /// <summary>
    /// Unique identifier
    /// </summary>
    public string Id { get; init; } = string.Empty;

    /// <summary>
    /// Name of the role
    /// </summary>
    public string Name { get; init; } = string.Empty;
}
