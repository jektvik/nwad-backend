namespace NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

/// <summary>
/// The identity properties domain model
/// </summary>
public class IdentityProperties
{
    /// <summary>
    /// The identity id that the identity properties belongs to
    /// </summary>
    public string IdentityId { get; set; } = string.Empty;

    /// <summary>
    /// The identities country code
    /// </summary>
    public string? CountryCode { get; set; }
}
