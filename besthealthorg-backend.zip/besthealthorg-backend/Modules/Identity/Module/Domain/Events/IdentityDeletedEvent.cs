using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.Domain.Events;

/// <summary>
/// Represents the event of an identity deleted event
/// </summary>
public class IdentityDeletedEvent : EventArgs
{
    /// <summary>
    /// The type string associated with this event data type
    /// </summary>
    public static string Type => "Besthealthorg.IdentityDeletedEvent";

    /// <summary>
    /// The deleted identity
    /// </summary>
    public required IIdentity Identity { get; init; }

    /// <summary>
    /// An ID used for substituting the identity ID when anonymizing data
    /// The anonymization ID is provided by the event publisher, so different parts of a system can anonymize different parts of the identitys data,
    /// while maintaining the ability to correlate the data.
    /// DO NOT CREATE A LINK BETWEEN THE ANONYMIZATION ID AND THE IDENTITY ID, IF THE ANONYMIZATION ID CAN BE FOUND BY KNOWING THE IDENTITY ID,
    /// DATA IS NOT ANONYMIZED
    /// </summary>
    public string AnonymizationId { get; } = $"Anonymized{Guid.NewGuid()}";
}
