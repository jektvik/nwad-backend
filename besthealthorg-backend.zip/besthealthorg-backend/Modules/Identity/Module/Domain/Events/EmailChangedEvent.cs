namespace NwadHealth.Besthealthorg.IdentityModule.Domain.Events;

/// <summary>
/// Represents the event of an email changed event
/// </summary>
public class EmailChangedEvent: EventArgs
{
    /// <summary>
    /// The type string associated with this event data type
    /// </summary>
    public static string Type => "Besthealthorg.EmailChangedEvent";

    /// <summary>
    /// The id of the identity that changed their email
    /// </summary>
    public required string IdentityId { get; init; }

    /// <summary>
    /// The new email
    /// </summary>
    public required string NewEmail { get; init; }

    /// <summary>
    /// The old email
    /// </summary>
    public required string OldEmail { get; init; }
}
