using System.Linq;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class IdentityModuleExtensionsTests
{
    #region AddPaceIdentity

    [Fact]
    public void AddPaceIdentity_AddsIIdentityProvider_WithTypeFromIIdentityPlugin()
    {
        var identityProvider = Mock.Of<IIdentityProvider>();

        var identityPluginMock = new Mock<IIdentityPlugin>();
        identityPluginMock
            .SetupGet(mock => mock.IdentityProviderType)
            .Returns(identityProvider.GetType());

        var services = new ServiceCollection();

        services.AddPaceIdentity(new Configuration("conn"), identityPluginMock.Object);

        var identityProviderFromServices = services.FirstOrDefault(service =>
            service.ServiceType == typeof(IIdentityProvider) && service.ImplementationType == identityProvider.GetType());

        Assert.NotNull(identityProviderFromServices);
        Assert.Equal(ServiceLifetime.Scoped, identityProviderFromServices?.Lifetime);
    }

    [Fact]
    public void AddPaceIdentity_AddsConfigurationAsSingleton()
    {
        var identityProvider = Mock.Of<IIdentityProvider>();

        var identityPluginMock = new Mock<IIdentityPlugin>();
        identityPluginMock
            .SetupGet(mock => mock.IdentityProviderType)
            .Returns(identityProvider.GetType());

        var services = new ServiceCollection();

        services.AddPaceIdentity(new Configuration("conn"), identityPluginMock.Object);

        var configurationFromServices = services.FirstOrDefault(service =>
            service.ServiceType == typeof(Configuration));

        Assert.NotNull(configurationFromServices);
        Assert.Equal(ServiceLifetime.Singleton, configurationFromServices?.Lifetime);
    }

    [Fact]
    public void AddPaceIdentity_CallsConfigureServices_FromIIdentityPlugin()
    {
        var identityProvider = Mock.Of<IIdentityProvider>();

        var identityPluginMock = new Mock<IIdentityPlugin>();
        identityPluginMock
            .SetupGet(mock => mock.IdentityProviderType)
            .Returns(identityProvider.GetType());

        var services = new ServiceCollection();

        services.AddPaceIdentity(new Configuration("conn"), identityPluginMock.Object);

        identityPluginMock.Verify(mock => mock.ConfigureServices(services), Times.Once());
    }

    [Fact]
    public void AddPaceIdentity_AddsExpectedServices()
    {
        var identityProvider = Mock.Of<IIdentityProvider>();

        var identityPluginMock = new Mock<IIdentityPlugin>();
        identityPluginMock
            .SetupGet(mock => mock.IdentityProviderType)
            .Returns(identityProvider.GetType());

        var services = new ServiceCollection();

        services.AddPaceIdentity(new Configuration("conn"), identityPluginMock.Object);

        var configInteractor = services
            .FirstOrDefault(FilterByServiceAndImplType<IGetConfigurationInteractor, GetConfigurationInteractor>);

        var resendVerificationEmailInteractor = services
            .FirstOrDefault(FilterByServiceAndImplType<IResendVerificationEmailInteractor, ResendVerificationEmailInteractor>);

        var emailVerificationStatusInteractor = services
            .FirstOrDefault(FilterByServiceAndImplType<IGetEmailVerificationStatusInteractor, GetEmailVerificationStatusInteractor>);

        var deleteIdentityInteractor = services
            .FirstOrDefault(FilterByServiceAndImplType<IDeleteIdentityInteractor, DeleteIdentityInteractor>);

        Assert.NotNull(configInteractor);
        Assert.NotNull(resendVerificationEmailInteractor);
        Assert.NotNull(emailVerificationStatusInteractor);
        Assert.NotNull(deleteIdentityInteractor);
    }

    #endregion AddPaceIdentity

    private static bool FilterByServiceAndImplType<TService, TImpl>(ServiceDescriptor service)
    {
        return service.ServiceType == typeof(TService) && service.ImplementationType == typeof(TImpl);
    }
}
