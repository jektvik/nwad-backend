﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Cache;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest.Infrastructure
{
    public class RolesMemoryCacheTests
    {
        private readonly Role role = new() {Id="Hcp", Name = "HCP" };
        private readonly string identityId = "id123";

        #region GetRoleByIdenityId

        [Fact]
        public void GetRoleByIdenityId_WhenRoleHaveBeenStored_ReturnsRole()
        {
            var cache = new RolesMemoryCache();
            cache.CacheRoleForIdentity(identityId, role);

            var cachedRole = cache.GetRoleByIdenityId(identityId);

            Assert.NotNull(cachedRole);
            Assert.Equal(role, cachedRole);
        }

        [Fact]
        public void GetRoleByIdenityId_WhenNoRoleIsStored_Returnsnull()
        {
            var cache = new RolesMemoryCache();

            var cachedRole = cache.GetRoleByIdenityId(identityId);

            Assert.Null(cachedRole);
        }

        #endregion GetRoleByIdenityId

        #region Clear

        [Fact]
        public void Clear_RemovesAllCountriesFromCache()
        {
            var cache = new RolesMemoryCache();
            cache.CacheRoleForIdentity(identityId, role);

            cache.Clear();

            Assert.Null(cache.GetRoleByIdenityId(identityId));
        }

        #endregion Clear
    }
}
