using System.Net;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.EventHandlers;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest.Infrastructure;

public class IdentityEventManagerTest
{
    private readonly IdentityEventManager _identityEventManager;

    public IdentityEventManagerTest()
    {
        Mock<ILogger<IdentityEventManager>> loggerMock = new();
        _identityEventManager = new IdentityEventManager(loggerMock.Object);
    }

    [Fact]
    public async Task PublishEmailChangeEvent_WhenCalled_PublishesEmailChangedEvent()
    {
        var identityMock = new Mock<IIdentity>();
        const string newEmail = "newemail@example.com";

        var eventTriggered = false;

        _identityEventManager.EmailChanged += (_, e) =>
        {
            Assert.Equal(identityMock.Object.Id, e.IdentityId);
            Assert.Equal(newEmail, e.NewEmail);
            eventTriggered = true;
        };

        await _identityEventManager.PublishEmailChangeEvent(identityMock.Object, newEmail);

        Assert.True(eventTriggered);
    }

    [Fact]
    public async Task PublishDeletedEvent_WhenCalled_PublishesIdentityDeletedEvent()
    {
        var identityMock = new Mock<IIdentity>();

        var eventTriggered = false;

        _identityEventManager.IdentityDeleted += (_, e) =>
        {
            Assert.Equal(identityMock.Object.Id, e.Identity.Id);
            eventTriggered = true;
        };

        await _identityEventManager.PublishDeletedEvent(identityMock.Object);

        Assert.True(eventTriggered);
    }
}