﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Cache;
using System.Collections.Generic;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest.Infrastructure
{
    public class CountriesMemoryCacheTests
    {
        private readonly List<Country> originalCountries = new()
        {
            new() { Id = "dk", Name = "Denmark" },
            new() { Id = "se", Name = "Sweden" }
        };

        #region GetAllCountries

        [Fact]
        public void GetAllCountries_WhenCountriesHaveBeenStored_ReturnsAllStoredCountries()
        {
            var cache = new CountriesMemoryCache();
            cache.StoreAllCountries(originalCountries);

            var cachedCountries = cache.GetAllCountries();

            Assert.NotNull(cachedCountries);
            Assert.Equal(originalCountries, cachedCountries);
        }

        [Fact]
        public void GetAllCountries_WhenCountriesHaveNotBeenStored_ReturnsNull()
        {
            var cache = new CountriesMemoryCache();

            Assert.Null(cache.GetAllCountries());
        }

        #endregion GetAllCountries

        #region GetCountryByCountryCode

        [Fact]
        public void GetCountryByCountryCode_WhenCountryIsInCache_ReturnsCountry()
        {
            var cache = new CountriesMemoryCache();
            cache.StoreAllCountries(originalCountries);

            Assert.Equal(originalCountries[0], cache.GetCountryByCountryCode("dk"));
            Assert.Equal(originalCountries[1], cache.GetCountryByCountryCode("se"));
        }

        [Fact]
        public void GetCountryByCountryCode_WhenCountriesHaveNotBeenStored_ReturnsNull()
        {
            var cache = new CountriesMemoryCache();

            Assert.Null(cache.GetCountryByCountryCode("dk"));
            Assert.Null(cache.GetCountryByCountryCode("se"));
        }

        [Fact]
        public void GetCountryByCountryCode_WhenCountryDoesNotExist_ReturnsNull()
        {
            var cache = new CountriesMemoryCache();
            cache.StoreAllCountries(originalCountries);

            Assert.Null(cache.GetCountryByCountryCode("no"));
        }

        #endregion GetCountryByCountryCode

        #region Clear

        [Fact]
        public void Clear_RemovesAllCountriesFromCache()
        {
            var cache = new CountriesMemoryCache();
            cache.StoreAllCountries(originalCountries);

            cache.Clear();

            Assert.Null(cache.GetAllCountries());
        }

        #endregion Clear
    }
}
