using System.Collections.Generic;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class GetConfigurationInteractorTests
{
    #region Execute

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task Execute_ReturnsConfigurationFromConstructor(bool expectedStatus)
    {
        var expectedConfig = new Configuration("conn")
        {
            IsEmailVerificationRequired = expectedStatus
        };

        var countryRepoMock = new Mock<ICountryRepository>();
        countryRepoMock.Setup(m => m.GetAll()).ReturnsAsync(new List<Country>());

        var interactor = new GetConfigurationInteractor(expectedConfig, Mock.Of<ILogger<GetConfigurationInteractor>>(), countryRepoMock.Object);
        var config = await interactor.Execute();

        Assert.Equal(expectedStatus, config.IsEmailVerificationRequired);
    }

    #endregion Execute
}
