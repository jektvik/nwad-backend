using System.Threading.Tasks;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class GetIdentityPropertiesInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenIdentityPropertiesDoesNotExist_ReturnsNull()
    {
        const string identityId = "123";

        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();

        identityPropertiesRepoMock
            .Setup(mock => mock.GetIdentityPropertiesByIdentityId(identityId))
            .ReturnsAsync(() => null);

        var interactor = new GetIdentityPropertiesInteractor(identityPropertiesRepoMock.Object, Mock.Of<ILogger<GetIdentityPropertiesInteractor>>());

        Assert.Null(await interactor.Execute(identityId));
    }

    [Fact]
    public async Task Execute_WhenIdentityPropertiesDoesExist_ReturnsIdentityProperties()
    {
        var expectedIdentityProperties = new IdentityProperties
        {
            IdentityId = "123",
            CountryCode = "dk"
        };

        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();

        identityPropertiesRepoMock
            .Setup(mock => mock.GetIdentityPropertiesByIdentityId(expectedIdentityProperties.IdentityId))
            .ReturnsAsync(expectedIdentityProperties);

        var interactor = new GetIdentityPropertiesInteractor(identityPropertiesRepoMock.Object, Mock.Of<ILogger<GetIdentityPropertiesInteractor>>());

        var identityProperties = await interactor.Execute(expectedIdentityProperties.IdentityId);

        Assert.NotNull(identityProperties);
        Assert.Equal(expectedIdentityProperties.IdentityId, identityProperties!.IdentityId);
        Assert.Equal(expectedIdentityProperties.CountryCode, identityProperties!.CountryCode);
    }

    #endregion Execute
}
