using System.Threading.Tasks;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class GetEmailVerificationStatusInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenIdentityWasntFound_ThrowsIdentityNotFoundException()
    {
        const string identityId = "identityId";
        IIdentity? identity = null;

        var identityProviderMock = new Mock<IIdentityProvider>();
        identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(identity);

        var interactor = new GetEmailVerificationStatusInteractor(
            identityProviderMock.Object,
            Mock.Of<ILogger<GetEmailVerificationStatusInteractor>>());

        await Assert.ThrowsAsync<IdentityNotFoundException>(async () => await interactor.Execute(identityId));
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task Execute_WhenIdentityWasFound_ReturnsVerificationStatus(bool expectedStatus)
    {
        const string identityId = "identityId";
        var identityMock = new Mock<IIdentity>();
        identityMock
            .SetupGet(mock => mock.EmailVerified)
            .Returns(expectedStatus);

        var identityProviderMock = new Mock<IIdentityProvider>();
        identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(identityMock.Object);

        var interactor = new GetEmailVerificationStatusInteractor(
            identityProviderMock.Object,
            Mock.Of<ILogger<GetEmailVerificationStatusInteractor>>());

        var status = await interactor.Execute(identityId);

        Assert.Equal(expectedStatus, status);
    }

    #endregion Execute
}
