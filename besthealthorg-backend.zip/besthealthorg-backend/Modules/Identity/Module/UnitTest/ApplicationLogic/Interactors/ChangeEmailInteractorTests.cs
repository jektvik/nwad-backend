using System;
using System.Linq.Expressions;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.Foundation.Events;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Events;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class ChangeEmailInteractorTests
{
    private readonly Mock<IIdentity> _identityMock = new();
    private readonly Mock<IAuditLogRepository> _auditLogRepositoryMock = new();
    private readonly Mock<ILogger<ChangeEmailInteractor>> _loggerMock = new();
    private readonly Mock<IIdentityEventPublisher> _eventPublisherMock = new();
    private readonly Mock<IIdentityProvider> _identityProviderMock = new();

    private readonly ChangeEmailInteractor _interactor;

    public ChangeEmailInteractorTests()
    {
        _interactor = new ChangeEmailInteractor(
            _identityProviderMock.Object,
            _eventPublisherMock.Object,
            _auditLogRepositoryMock.Object,
            _loggerMock.Object);
    }
    #region Execute

    [Fact]
    public async Task Execute_CallsChangeEmailEmailOnIdentityProviderWithProvidedIdAndEmail()
    {
        const string identityId = "identityId";
        const string oldEmail = "oldEmail";
        const string newEmail = "newEmail";

        _identityMock.SetupGet(mock => mock.Id).Returns(identityId);
        _identityMock.SetupGet(mock => mock.Email).Returns(oldEmail);

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(_identityMock.Object);

        _identityProviderMock.Setup(mock => mock.ChangeEmail(It.IsAny<string>(), It.IsAny<string>()));

        await _interactor.Execute(identityId, newEmail);

        _identityProviderMock
            .Verify(mock => mock.ChangeEmail(identityId, newEmail), Times.Once());
    }

    [Fact]
    public async Task Execute_FetchesIdentityAndCallsPublishChangedEmailEventOnEventPublisherWithFetchedIdentity()
    {
        const string identityId = "identityId";
        const string oldEmail = "oldEmail";
        const string newEmail = "newEmail";

        _identityMock.SetupGet(mock => mock.Id).Returns(identityId);
        _identityMock.SetupGet(mock => mock.Email).Returns(oldEmail);

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(_identityMock.Object);

        _identityProviderMock.Setup(mock => mock.ChangeEmail(It.IsAny<string>(), It.IsAny<string>()));

        await _interactor.Execute(identityId, newEmail);

        _eventPublisherMock.Verify(mock => mock.PublishEmailChangeEvent(_identityMock.Object, newEmail), Times.Once());
    }

    [Fact]
    public async Task Execute_WhenIdentityWasNotFound_ThrowsIdentityNotFoundException()
    {
        const string identityId = "identityId";

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(() => null);

        await Assert.ThrowsAsync<IdentityNotFoundException>(async () => await _interactor.Execute(identityId, "newEmail"));
    }

    [Fact]
    public async Task Execute_WhenTheEmailsWereTheSame_ThrowsSameEmailException()
    {
        const string identityId = "identityId";

        _identityMock.SetupGet(mock => mock.Email).Returns("newEmail");

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(_identityMock.Object);

        await Assert.ThrowsAsync<SameEmailException>(async () => await _interactor.Execute(identityId, "newEmail"));
    }

    [Fact]
    public async Task Execute_WhenEmailChangeWasSuccessful_WritesToAuditLog()
    {
        const string identityId = "identityId";
        const string oldEmail = "oldEmail";
        const string newEmail = "newEmail";

        _identityMock.SetupGet(mock => mock.Id).Returns(identityId);
        _identityMock.SetupGet(mock => mock.Email).Returns(oldEmail);

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(_identityMock.Object);

        await _interactor.Execute(identityId, newEmail);
        Expression<Func<PaceEvent, bool>> verifyPaceEvent = paceEvent =>
            paceEvent.Type == EmailChangedEvent.Type &&
            paceEvent.IdentityId == identityId &&
            paceEvent.Metadata["Email"] == oldEmail &&
            paceEvent.Metadata["NewEmail"] == newEmail;

        _auditLogRepositoryMock.Verify(mock =>
            mock.WriteRecord(It.Is(verifyPaceEvent)),
            Times.Once());
    }

    #endregion Execute

}
