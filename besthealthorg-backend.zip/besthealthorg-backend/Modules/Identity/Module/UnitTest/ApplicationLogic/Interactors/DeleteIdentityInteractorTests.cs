using System;
using System.Linq.Expressions;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.Foundation.Events;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Events;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class DeleteIdentityInteractorInteractorTests
{
    private readonly Mock<IIdentityProvider> _identityProviderMock = new();
    private readonly Mock<IIdentityPropertiesRepository> _identityPropertiesRepositoryMock = new();
    private readonly Mock<IIdentityEventPublisher> _eventPublisherMock = new();
    private readonly Mock<IAuditLogRepository> _auditLogRepositoryMock = new();
    private readonly Mock<IRoleAssignmentRepository> _roleAssignmentRepository = new();

    private readonly DeleteIdentityInteractor _interactor;
    private readonly IPAddress _ip = new(new byte[] { 1, 2, 3, 4 });

    public DeleteIdentityInteractorInteractorTests()
    {
        _interactor = new DeleteIdentityInteractor(
            _identityProviderMock.Object,
            _eventPublisherMock.Object,
            _identityPropertiesRepositoryMock.Object,
            _roleAssignmentRepository.Object,
            _auditLogRepositoryMock.Object,
            Mock.Of<ILogger<DeleteIdentityInteractor>>());
    }

    #region Execute

    [Fact]
    public async Task Execute_CallsDeleteIdentityOnIdentityProviderWithProvidedId()
    {
        const string identityId = "identityId";

        var identity = Mock.Of<IIdentity>();

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(identity);

        await _interactor.Execute(identityId, identityId, _ip);

        _identityProviderMock
            .Verify(mock => mock.DeleteIdentity(identityId), Times.Once());
    }

    [Fact]
    public async Task Execute_CallsDeleteIdentityPropertiesWithProvidedId()
    {
        const string identityId = "identityId";

        var identity = Mock.Of<IIdentity>();

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(identity);

        await _interactor.Execute(identityId, identityId, _ip);

        _identityPropertiesRepositoryMock
            .Verify(mock => mock.DeleteIdentityPropertiesByIdentityId(identityId), Times.Once());
    }

    [Fact]
    public async Task Execute_FetchesIdentityAndCallsPublishDeletedEventOnEventPublisherWithFetchedIdentity()
    {
        const string identityId = "identityId";

        var identity = Mock.Of<IIdentity>();

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(identity);

        await _interactor.Execute(identityId, identityId, _ip);

        _eventPublisherMock.Verify(mock => mock.PublishDeletedEvent(identity), Times.Once());
    }

    [Fact]
    public async Task Execute_ThrowsIdentityNotFoundException_IfIdentityWasNotFound()
    {
        const string identityId = "identityId";

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(() => null);

        await Assert.ThrowsAsync<IdentityNotFoundException>(async () =>
            await _interactor.Execute(identityId, identityId, _ip));
    }

    [Fact]
    public async Task Execute_ThrowsException_IfDeleterIdentityWasNotFound()
    {
        const string identityId = "identityId";
        const string deleterIdentityId = "deleterIdentityId";
        var identity = Mock.Of<IIdentity>();

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(() => identity);

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(deleterIdentityId))
            .ReturnsAsync(() => null);

        await Assert.ThrowsAsync<Exception>(async () => await _interactor.Execute(identityId, deleterIdentityId, _ip));
    }

    [Fact]
    public async Task Execute_WhenIdentityDeletedSuccessful_WritesToAuditLog()
    {
        const string identityId = "identityId";
        const string deletedByIdentityId = "identityId";
        const string email = "email";
        var identityMock = new Mock<IIdentity>();

        identityMock.SetupGet(mock => mock.Id).Returns(identityId);
        identityMock.SetupGet(mock => mock.Email).Returns(email);

        _identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(identityMock.Object);

        await _interactor.Execute(identityId, deletedByIdentityId, _ip);

        var deletedByString = JsonSerializer.Serialize(new
        {
            IdentityId = identityMock.Object.Id,
            identityMock.Object.Email,
        });

        Expression<Func<PaceEvent, bool>> verifyPaceEvent = paceEvent =>
            paceEvent.Type == IdentityDeletedEvent.Type &&
            paceEvent.IdentityId == identityId &&
            paceEvent.Metadata["Email"] == email &&
            paceEvent.Metadata["DeletedBy"] == deletedByString;

        _auditLogRepositoryMock.Verify(mock =>
            mock.WriteRecord(It.Is(verifyPaceEvent)),
            Times.Once()
        );
    }

    #endregion Execute
}