using System.Threading.Tasks;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class ResendVerificationEmailInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_CallsResendVerificationEmailOnIdentityProviderWithProvidedId()
    {
        const string identityId = "identityId";

        var identityProviderMock = new Mock<IIdentityProvider>();
        identityProviderMock.Setup(mock => mock.ResendVerificationEmail(It.IsAny<string>()));

        var interactor = new ResendVerificationEmailInteractor(
            identityProviderMock.Object,
            Mock.Of<ILogger<ResendVerificationEmailInteractor>>());

        await interactor.Execute(identityId);

        identityProviderMock
            .Verify(mock => mock.ResendVerificationEmail(identityId), Times.Once());
    }

    #endregion Execute
}
