using System.Threading.Tasks;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Requests;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class CreateIdentityPropertiesInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenIdentityWasNotFound_ThrowsIdentityNotFoundException()
    {
        var request = new CreateIdentityPropertiesRequest
        {
            IdentityId = "123",
            CountryCode = "us"
        };

        var identityProviderMock = new Mock<IIdentityProvider>();

        identityProviderMock
            .Setup(mock => mock.FetchIdentity(It.IsAny<string>()))
            .ReturnsAsync(() => null);

        var countryRepositoryMock = new Mock<ICountryRepository>();

        countryRepositoryMock
            .Setup(mock => mock.GetCountryByCountryCode("us"))
            .ReturnsAsync(new Country
            {
                Id = "us",
                Name = "United States"
            });

        var interactor = new CreateIdentityPropertiesInteractor(
            identityProviderMock.Object,
            Mock.Of<IIdentityPropertiesRepository>(),
            countryRepositoryMock.Object,
            Mock.Of<ILogger<CreateIdentityPropertiesInteractor>>());

        var exception = await Assert.ThrowsAsync<IdentityNotFoundException>(async () => await interactor.Execute(request));

        Assert.Equal(request.IdentityId, exception.Identifier);
    }

    [Fact]
    public async Task Execute_WhenIdentityAlreadyHaveIdentityProperties_ThrowsDuplicateIdentityPropertiesException()
    {
        const string identityId = "123";

        var request = new CreateIdentityPropertiesRequest
        {
            IdentityId = identityId,
            CountryCode = "us"
        };

        var identityMock = new Mock<IIdentity>();

        identityMock
            .SetupGet(mock => mock.Id)
            .Returns(identityId);

        var identityProviderMock = new Mock<IIdentityProvider>();

        identityProviderMock
            .Setup(mock => mock.FetchIdentity(It.IsAny<string>()))
            .ReturnsAsync(() => identityMock.Object);

        var countryRepositoryMock = new Mock<ICountryRepository>();

        countryRepositoryMock
            .Setup(mock => mock.GetCountryByCountryCode("us"))
            .ReturnsAsync(new Country
            {
                Id = "us",
                Name = "United States"
            });

        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();

        identityPropertiesRepoMock
            .Setup(mock => mock.GetIdentityPropertiesByIdentityId(identityId))
            .ReturnsAsync(new IdentityProperties());

        var interactor = new CreateIdentityPropertiesInteractor(
            identityProviderMock.Object,
            identityPropertiesRepoMock.Object,
            countryRepositoryMock.Object,
            Mock.Of<ILogger<CreateIdentityPropertiesInteractor>>());

        var exception = await Assert.ThrowsAsync<DuplicateIdentityPropertiesException>(async () => await interactor.Execute(request));

        Assert.Equal(identityId, exception.IdentityId);
    }

    [Fact]
    public async Task Execute_WithInvalidCountry_ThrowsUnsupportedCountryException()
    {
        var request = new CreateIdentityPropertiesRequest
        {
            IdentityId = "123",
            CountryCode = "dk"
        };

        var countryRepositoryMock = new Mock<ICountryRepository>();

        countryRepositoryMock
            .Setup(mock => mock.GetCountryByCountryCode(It.IsAny<string>()))
            .ReturnsAsync(() => null);

        var interactor = new CreateIdentityPropertiesInteractor(
            Mock.Of<IIdentityProvider>(),
            Mock.Of<IIdentityPropertiesRepository>(),
            countryRepositoryMock.Object,
            Mock.Of<ILogger<CreateIdentityPropertiesInteractor>>());

        var exception = await Assert.ThrowsAsync<UnsupportedCountryException>(async () => await interactor.Execute(request));

        Assert.Equal(request.CountryCode, exception.Country);
    }

    [Fact]
    public async Task Execute_WithValidParams_CreatesAndReturnsIdentityProperties()
    {
        const string identityId = "123";
        const string country = "us";

        var request = new CreateIdentityPropertiesRequest
        {
            IdentityId = identityId,
            CountryCode = country
        };

        var identityMock = new Mock<IIdentity>();

        identityMock
            .SetupGet(mock => mock.Id)
            .Returns(identityId);

        var identityProviderMock = new Mock<IIdentityProvider>();

        identityProviderMock
            .Setup(mock => mock.FetchIdentity(It.IsAny<string>()))
            .ReturnsAsync(() => identityMock.Object);

        var countryRepositoryMock = new Mock<ICountryRepository>();

        countryRepositoryMock
            .Setup(mock => mock.GetCountryByCountryCode(country))
            .ReturnsAsync(new Country
            {
                Id = country,
                Name = "United States"
            });

        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();

        identityPropertiesRepoMock
            .Setup(mock => mock.GetIdentityPropertiesByIdentityId(identityId))
            .ReturnsAsync(() => null);

        identityPropertiesRepoMock
            .Setup(mock => mock.Create(It.IsAny<IdentityProperties>()))
            .ReturnsAsync(new IdentityProperties
            {
                IdentityId = identityId,
                CountryCode = country
            });

        var interactor = new CreateIdentityPropertiesInteractor(
            identityProviderMock.Object,
            identityPropertiesRepoMock.Object,
            countryRepositoryMock.Object,
            Mock.Of<ILogger<CreateIdentityPropertiesInteractor>>());

        var identityProperties = await interactor.Execute(request);

        Assert.Equal(identityId, identityProperties.IdentityId);
        Assert.Equal(country, identityProperties.CountryCode);
    }

    #endregion Execute
}
