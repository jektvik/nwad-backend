﻿using System.Threading.Tasks;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class GetIdentityRoleInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_ReturnsRole()
    {
        const string identityId = "123";
        var actualRole = new Role { Id = "456", Name = "HCP" };

        var roleAssignmentRepository = new Mock<IRoleAssignmentRepository>();
        var roleRepository = new Mock<IRoleRepository>();
        var rolesMemoryCache = new Mock<IRolesMemoryCache>();

        roleAssignmentRepository
            .Setup(mock => mock.GetRoleAssignmentByIdentityId(identityId))
            .ReturnsAsync(() => new RoleAssignment { RoleId = actualRole.Id });

        roleRepository
            .Setup(mock => mock.GetRoleById(It.IsAny<string>()))
            .ReturnsAsync(() => actualRole);

        var interactor = new GetIdentityRoleInteractor(
            roleRepository.Object,
            roleAssignmentRepository.Object,
            rolesMemoryCache.Object,
            Mock.Of<ILogger<GetIdentityRoleInteractor>>());

        var expectedRole = await interactor.Execute(identityId, false);

        Assert.Equal(expectedRole, actualRole);
    }

    [Fact]
    public async Task Execute_WhenRoleIsCached_ReturnsRole()
    {
        const string identityId = "123";
        var actualRole = new Role { Id = "456", Name = "HCP" };

        var roleAssignmentRepository = new Mock<IRoleAssignmentRepository>();
        var roleRepository = new Mock<IRoleRepository>();
        var rolesMemoryCache = new Mock<IRolesMemoryCache>();

        rolesMemoryCache
            .Setup(mock => mock.GetRoleByIdenityId(identityId))
            .Returns(actualRole);

        var interactor = new GetIdentityRoleInteractor(
            roleRepository.Object,
            roleAssignmentRepository.Object,
            rolesMemoryCache.Object,
            Mock.Of<ILogger<GetIdentityRoleInteractor>>());

        var expectedRole = await interactor.Execute(identityId, true);

        Assert.Equal(expectedRole, actualRole);
    }

    [Fact]
    public async Task Execute_WhenRoleAssignmentIsNull_ReturnsNoRoleAssigndedException()
    {
        const string identityId = "123";

        var roleAssignmentRepository = new Mock<IRoleAssignmentRepository>();
        var roleRepository = new Mock<IRoleRepository>();
        var rolesMemoryCache = new Mock<IRolesMemoryCache>();

        roleAssignmentRepository
            .Setup(mock => mock.GetRoleAssignmentByIdentityId(identityId))
            .ReturnsAsync(() => null);

        var interactor = new GetIdentityRoleInteractor(
            roleRepository.Object,
            roleAssignmentRepository.Object,
            rolesMemoryCache.Object,
            Mock.Of<ILogger<GetIdentityRoleInteractor>>());

        await Assert.ThrowsAsync<NoRoleAssigndedException>(async () => await interactor.Execute(identityId, false));
    }

    [Fact]
    public async Task Execute_WhenRoleIsNull_ReturnsNonExistentRoleException()
    {
        const string identityId = "123";
        const string roleId = "456";

        var roleAssignmentRepository = new Mock<IRoleAssignmentRepository>();
        var roleRepository = new Mock<IRoleRepository>();
        var rolesMemoryCache = new Mock<IRolesMemoryCache>();

        roleAssignmentRepository
            .Setup(mock => mock.GetRoleAssignmentByIdentityId(identityId))
            .ReturnsAsync(() => new RoleAssignment());

        roleRepository
            .Setup(mock => mock.GetRoleById(roleId))
            .ReturnsAsync(() => null);

        var interactor = new GetIdentityRoleInteractor(
            roleRepository.Object,
            roleAssignmentRepository.Object,
            rolesMemoryCache.Object,
            Mock.Of<ILogger<GetIdentityRoleInteractor>>());

        await Assert.ThrowsAsync<NonExistentRoleException>(async () => await interactor.Execute(identityId, false));
    }

    #endregion Execute
}
