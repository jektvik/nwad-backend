using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class IdentityNotFoundExceptionTests
{
    #region InstantitateIdentityNotFoundException

    [Fact]
    public void InstantiateIdentityNotFoundException_HasCorrectMessage()
    {
        var ex = new IdentityNotFoundException("id");

        Assert.Equal("The identity could not be found", ex.Message);
    }

    [Fact]
    public void InstantiateIdentityNotFoundException_SetsIdentityId()
    {
        const string expectedIdentifier = "some id";

        var ex = new IdentityNotFoundException(expectedIdentifier);

        Assert.Equal(expectedIdentifier, ex.Identifier);
    }

    #endregion InstantitateIdentityNotFoundException
}
