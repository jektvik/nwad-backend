using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class UnsupportedCountryExceptionTests
{
    #region InstantitateUnsupportedCountryException

    [Fact]
    public void InstantiateUnsupportedCountryException_HasCorrectMessage()
    {
        var ex = new UnsupportedCountryException("id");

        Assert.Equal("The selected country is not supported", ex.Message);
    }

    [Fact]
    public void InstantiateUnsupportedCountryException_SetsIdentityId()
    {
        const string expectedCountry = "some country";

        var ex = new UnsupportedCountryException(expectedCountry);

        Assert.Equal(expectedCountry, ex.Country);
    }

    #endregion InstantitateUnsupportedCountryException
}
