﻿using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class SameEmailExceptionTests
{
    #region InstantitateIdentityNotFoundException

    [Fact]
    public void InstantiateSameEmailException_HasCorrectMessage()
    {
        var ex = new SameEmailException("newEmail");

        Assert.Equal("The new email address is the same as the original one", ex.Message);
    }

    [Fact]
    public void InstantiateSameEmailException_SetsNewEmail()
    {
        const string newEmail = "newEmail";

        var ex = new SameEmailException(newEmail);

        Assert.Equal(newEmail, ex.NewEmail);
    }

    #endregion InstantitateIdentityNotFoundException
}
