using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class DuplicateIdentityPropertiesExceptionTests
{
    #region InstantitateDuplicateIdentityPropertiesException

    [Fact]
    public void InstantiateDuplicateIdentityPropertiesException_HasCorrectMessage()
    {
        var ex = new DuplicateIdentityPropertiesException("id");

        Assert.Equal("The identity with the given id already has identity properties", ex.Message);
    }

    [Fact]
    public void InstantiateDuplicateIdentityPropertiesException_SetsIdentityId()
    {
        const string expectedIdentityId = "some id";

        var ex = new DuplicateIdentityPropertiesException(expectedIdentityId);

        Assert.Equal(expectedIdentityId, ex.IdentityId);
    }

    #endregion InstantitateDuplicateIdentityPropertiesException
}
