﻿using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class NonExistentRoleExceptionTests
{
    #region InstantitateIdentityNotFoundException

    [Fact]
    public void InstantiateNonExistentRoleException_HasCorrectMessage()
    {
        var ex = new NonExistentRoleException("id");

        Assert.Equal("The assigned role does not exist", ex.Message);
    }

    [Fact]
    public void InstantiateNonExistentRoleException_SetsRoleId()
    {
        const string expectedRoleId = "some id";

        var ex = new NonExistentRoleException(expectedRoleId);

        Assert.Equal(expectedRoleId, ex.RoleId);
    }

    #endregion InstantitateIdentityNotFoundException
}
