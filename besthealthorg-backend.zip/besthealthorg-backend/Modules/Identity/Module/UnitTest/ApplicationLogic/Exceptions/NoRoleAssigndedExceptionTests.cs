﻿using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class NoRoleAssigndedExceptionTests
{
    #region InstantitateIdentityNotFoundException

    [Fact]
    public void InstantiateNoRoleAssigndedException_HasCorrectMessage()
    {
        var ex = new NoRoleAssigndedException("id");

        Assert.Equal("No role was assigned for this identity", ex.Message);
    }

    [Fact]
    public void InstantiateNoRoleAssigndedException_SetsIdentityId()
    {
        const string expectedIdentityId = "some id";

        var ex = new NoRoleAssigndedException(expectedIdentityId);

        Assert.Equal(expectedIdentityId, ex.IdentityId);
    }

    #endregion InstantitateIdentityNotFoundException
}
