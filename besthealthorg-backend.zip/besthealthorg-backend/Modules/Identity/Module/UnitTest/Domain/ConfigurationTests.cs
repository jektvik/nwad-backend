using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class ConfigurationTests
{
    #region InstantiateConfiguration

    [Fact]
    public void
    InstantiateConfiguration_WithInvalidCosmosDbConnectionString_ThrowsArgumentException()
    {
        var exception = Assert.Throws<ArgumentException>(() => new Configuration(string.Empty));

        Assert.Equal("CosmosDB connection string cannot be null or empty (Parameter 'cosmosDbConnectionString')", exception.Message);
    }

    [Fact]
    public void InstantiateConfiguration_WithNonEmptyCosmosDbConnectionString_SetsValue()
    {
        var config = new Configuration("conn");

        Assert.Equal("conn", config.CosmosDbConnectionString);
    }

    #endregion InstantiateConfiguration
}
