﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest.Domain;

public class CountryTests
{
    [Fact]
    public void
    InstantiateCountry_WithValidId_CreatesCountry()
    {
        const string id = "dk";
        const string name = "Denmark";

        var testCountry = new Country { Id = id, Name = name };
        Assert.Equal(id, testCountry.Id);
        Assert.Equal(name, testCountry.Name);
    }

    [Theory]
    [InlineData("You tried to set 5 characters long id, The id of the country must me exactly 2 characters long")]
    public void
    InstantiateCountry_WithInvalidId_ThrowsArgumentException(string expectedMessage)
    {
        var exception = Assert.Throws<ArgumentException>(() => new Country { Id="12345", Name="TestName"});

        Assert.Equal(expectedMessage, exception.Message);
    }
}
