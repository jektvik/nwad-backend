using System.Net;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Responses;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Controllers;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class IdentityControllerTests
{
    private const string IdentityId = "identityId";

    private readonly Mock<IGetConfigurationInteractor> _getConfigurationInteractorMock = new();
    private readonly IdentityController _controller = new(Mock.Of<ILogger<IdentityController>>());

    public IdentityControllerTests()
    {
        _controller.ControllerContext = ControllerTestHelper.SetupContext(IdentityId);
    }

    #region GetConfiguration

    [Fact]
    public async Task GetConfiguration_WhenInteractorThrowsUnknownError_Returns500()
    {
        var ex = new Exception();

        _getConfigurationInteractorMock
            .Setup(mock => mock.Execute())
            .ThrowsAsync(ex);

        var resp = await _controller.GetConfiguration(_getConfigurationInteractorMock.Object);
        AssertUtil.AssertErrorResponse<ObjectResult>(resp, 500, "unexpected_error", "An unexpected error occured");
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task GetConfiguration_WhenInteractorSucceeds_ReturnsOkWithConfiguration(bool expectedRequired)
    {
        List<string> expectedSupportedCountries = ["dk", "sw"];

        var denmark = new Country { Id = "dk", Name = "Denmark" };
        var sweden = new Country { Id = "sw", Name = "Sweden" };

        var config = new GetConfigurationResponse
        {
            IsEmailVerificationRequired = expectedRequired,
            SupportedCountries = new List<Country>
            {
                denmark,
                sweden,
            },
        };

        _getConfigurationInteractorMock
            .Setup(mock => mock.Execute())
            .ReturnsAsync(config);

        var resp = await _controller.GetConfiguration(_getConfigurationInteractorMock.Object);

        var okResp = Assert.IsType<OkObjectResult>(resp);
        var configDto = Assert.IsType<ConfigurationResponseDto>(okResp.Value);

        Assert.Equal(expectedRequired, configDto?.IsEmailVerificationRequired);
        Assert.Equal(expectedSupportedCountries, configDto!.SupportedCountries);
    }

    #endregion GetConfiguration

    #region EmailVerificationStatus

    [Fact]
    public async Task EmailVerificationStatus_WhenInteractorThrowsIdentityNotFoundException_ReturnsUnauthorized()
    {
        var ex = new IdentityNotFoundException("identityId");

        var interactorMock = new Mock<IGetEmailVerificationStatusInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ThrowsAsync(ex);

        var resp = await _controller.EmailVerificationStatus(interactorMock.Object);

        Assert.IsType<UnauthorizedResult>(resp);
    }

    [Fact]
    public async Task EmailVerificationStatus_WhenInteractorThrowsUnknownError_Returns500()
    {
        var ex = new Exception();

        var interactorMock = new Mock<IGetEmailVerificationStatusInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ThrowsAsync(ex);

        var resp = await _controller.EmailVerificationStatus(interactorMock.Object);
        AssertUtil.AssertErrorResponse<ObjectResult>(resp, 500, "unexpected_error", "An unexpected error occured");
    }

    [Fact]
    public async Task EmailVerificationStatus_WhenInteractorSucceeds_ReturnsOkWithVerificationStatus()
    {
        var interactorMock = new Mock<IGetEmailVerificationStatusInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ReturnsAsync(true);

        var resp = await _controller.EmailVerificationStatus(interactorMock.Object);

        var okResp = Assert.IsType<OkObjectResult>(resp);
        Assert.IsType<EmailVerificationStatusResponseDto>(okResp.Value);

        var status = Assert.IsType<EmailVerificationStatusResponseDto>(okResp.Value);
        Assert.True(status.Verified);
    }

    #endregion EmailVerificationStatus

    #region ResendVerificationEmail

    [Fact]
    public async Task ResendVerificationEmail_WhenInteractorThrowsIdentityNotFoundException_ReturnsUnauthorized()
    {
        var ex = new IdentityNotFoundException("identityId");

        var interactorMock = new Mock<IResendVerificationEmailInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ThrowsAsync(ex);

        var resp = await _controller.ResendVerificationEmail(interactorMock.Object);
        Assert.IsType<UnauthorizedResult>(resp);
    }

    [Fact]
    public async Task ResendVerificationEmail_WhenInteractorThrowsUnknownError_Returns500()
    {
        var ex = new Exception();

        var interactorMock = new Mock<IResendVerificationEmailInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ThrowsAsync(ex);

        var resp = await _controller.ResendVerificationEmail(interactorMock.Object);
        AssertUtil.AssertErrorResponse<ObjectResult>(resp, 500, "unexpected_error", "An unexpected error occured");
    }

    [Fact]
    public async Task ResendVerificationEmail_WhenInteractorSucceeds_ReturnsAccepted()
    {
        var interactor = Mock.Of<IResendVerificationEmailInteractor>();

        var resp = await _controller.ResendVerificationEmail(interactor);
        Assert.IsType<AcceptedResult>(resp);
    }

    #endregion ResendVerificationEmail

    #region DeleteIdentity

    [Fact]
    public async Task DeleteIdentity_WhenInteractorThrowsIdentityNotFoundException_Returns404()
    {
        var ex = new IdentityNotFoundException(IdentityId);

        var interactorMock = new Mock<IDeleteIdentityInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<IPAddress?>()))
            .ThrowsAsync(ex);

        var resp = await _controller.DeleteIdentity(interactorMock.Object);
        AssertUtil.AssertErrorResponse<NotFoundObjectResult>(resp, StatusCodes.Status404NotFound, "identity_not_found", "The identity was not found");
    }

    [Fact]
    public async Task DeleteIdentity_WhenInteractorThrowsUnknownError_Returns500()
    {
        var ex = new Exception();

        var interactorMock = new Mock<IDeleteIdentityInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<IPAddress?>()))
            .ThrowsAsync(ex);

        var resp = await _controller.DeleteIdentity(interactorMock.Object);
        AssertUtil.AssertErrorResponse<ObjectResult>(resp, StatusCodes.Status500InternalServerError, "unexpected_error", "An unexpected error occured");
    }

    [Fact]
    public async Task DeleteIdentity_WhenInteractorSucceeds_ReturnsNoContent()
    {
        var interactor = Mock.Of<IDeleteIdentityInteractor>();

        Assert.IsType<NoContentResult>(await _controller.DeleteIdentity(interactor));
    }

    [Fact]
    public async Task DeleteIdentityByToken_WhenInteractorSucceeds_PassIdFromToken_ReturnsNoContent()
    {
        var interactor = new Mock<IDeleteIdentityInteractor>();
        var resp = await _controller.DeleteIdentity(interactor.Object);

        interactor.Verify(mock => mock.Execute(IdentityId, IdentityId, It.IsAny<IPAddress>()),Times.Once());
        Assert.IsType<NoContentResult>(resp);
    }

    #endregion DeleteIdentity

    #region ChangeEmail

    [Fact]
    public async Task ChangeEmail_WhenInteractorThrowsIdentityNotFoundException_ReturnsUnauthorized()
    {
        var ex = new IdentityNotFoundException("identityId");

        var interactorMock = new Mock<IChangeEmailInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(ex);

        var resp = await _controller.ChangeEmail(interactorMock.Object, new("newEmail"));
        Assert.IsType<UnauthorizedResult>(resp);
    }

    [Fact]
    public async Task ChangeEmail_WhenInteractorThrowsSameEmailException_ReturnsBadRequest()
    {
        var ex = new SameEmailException("NewEmail");

        var interactorMock = new Mock<IChangeEmailInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(ex);

        var resp = await _controller.ChangeEmail(interactorMock.Object, new("newEmail"));
        AssertUtil.AssertErrorResponse<BadRequestObjectResult>(resp, StatusCodes.Status400BadRequest, "invalid_email", "This user already has this email");
    }

    [Fact]
    public async Task ChangeEmail_WhenInteractorThrowsArgumentExceptionOnEmail_ReturnsBadRequst()
    {
        var ex = new ArgumentException(string.Empty, "newEmail");

        var interactorMock = new Mock<IChangeEmailInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(ex);

        var resp = await _controller.ChangeEmail(interactorMock.Object, new("newEmail"));
        AssertUtil.AssertErrorResponse<BadRequestObjectResult>(resp, StatusCodes.Status400BadRequest, "invalid_email", "The email has an invalid format");
    }

    [Fact]
    public async Task ChangeEmail_WhenInteractorThrowsUnknownError_Returns500()
    {
        var ex = new Exception();

        var interactorMock = new Mock<IChangeEmailInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(ex);

        var resp = await _controller.ChangeEmail(interactorMock.Object, new("newEmail"));
        AssertUtil.AssertErrorResponse<ObjectResult>(resp, StatusCodes.Status500InternalServerError, "unexpected_error", "An unexpected error occured");
    }

    [Fact]
    public async Task ChangeEmail_WhenInteractorSucceeds_ReturnsOk()
    {
        const string newEmail = "newEmail";
        var interactorMock = new Mock<IChangeEmailInteractor>();

        var resp = await _controller.ChangeEmail(interactorMock.Object, new(newEmail));
        Assert.IsType<OkResult>(resp);

        interactorMock.Verify(mock => mock.Execute("identityId", newEmail), Times.Once);
    }

    #endregion ChangeEmail

    #region GetRole

    [Fact]
    public async Task GetRole_WhenInteractorSucceeds_ReturnsOk()
    {
        var expectedRole = new Role { Id = "1", Name = "HCP" };

        var interactorMock = new Mock<IGetIdentityRoleInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(),false))
            .ReturnsAsync(expectedRole);

        var resp = await _controller.GetRole(interactorMock.Object);

        interactorMock.Verify(mock => mock.Execute("identityId",false), Times.Once);

        var okResp = Assert.IsType<OkObjectResult>(resp);
        var actualRole = Assert.IsAssignableFrom<IEnumerable<RoleResponseDto>>(okResp.Value);

        Assert.Equal(expectedRole.Id, actualRole.ElementAt(0).Id);
        Assert.Equal(expectedRole.Name, actualRole.ElementAt(0).Name);
    }

    [Fact]
    public async Task GetRole_WhenInteractorThrowsNoRoleAssigndedException_ReturnsNotFound()
    {
        var ex = new NoRoleAssigndedException("identityId");

        var interactorMock = new Mock<IGetIdentityRoleInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(),false))
            .ThrowsAsync(ex);

        var resp = await _controller.GetRole(interactorMock.Object);
        AssertUtil.AssertErrorResponse<NotFoundObjectResult>(resp, StatusCodes.Status404NotFound, "no_role_assigned", "No role was assigned for this identity");
    }

    [Fact]
    public async Task GetRole_WhenInteractorThrowsNonExistentRoleException_ReturnsUnexpectedError()
    {
        var ex = new NonExistentRoleException("roleId");

        var interactorMock = new Mock<IGetIdentityRoleInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(),false))
            .ThrowsAsync(ex);

        var resp = await _controller.GetRole(interactorMock.Object);
        AssertUtil.AssertErrorResponse<ObjectResult>(resp, StatusCodes.Status500InternalServerError, "non_existent_role","The assigned role does not exist");
    }

    [Fact]
    public async Task GetRole_WhenInteractorThrowsUnexpectedError_Returns500()
    {
        var ex = new Exception();

        var interactorMock = new Mock<IGetIdentityRoleInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(),false))
            .ThrowsAsync(ex);

        var resp = await _controller.GetRole(interactorMock.Object);
        AssertUtil.AssertErrorResponse<ObjectResult>(resp, StatusCodes.Status500InternalServerError, "unexpected_error", "An unexpected error occured");
    }

    #endregion GetRole
}
