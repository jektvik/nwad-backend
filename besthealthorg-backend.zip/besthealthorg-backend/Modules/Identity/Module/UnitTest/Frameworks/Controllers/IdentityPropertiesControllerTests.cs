using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Requests;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Controllers;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.IdentityModule.UnitTest;

public class IdentityPropertiesControllerTests
{
    private readonly IdentityPropertiesController _controller = new(Mock.Of<ILogger<IdentityPropertiesController>>())
    {
        ControllerContext = ControllerTestHelper.SetupContext("identity1"),
    };

    private readonly Mock<IGetIdentityPropertiesInteractor> _getIdentityPropertiesInteractor = new();
    private readonly Mock<IGetIdentityRoleInteractor> _getIdentityRoleInteractor = new();
    private readonly Mock<ICreateIdentityPropertiesInteractor> _createIdentityPropertiesInteractor = new();
    private readonly Mock<IGetIdentityRoleInteractor> _roleInteractorMock = new();

    #region GetIdentityProperties

    [Fact]
    public async Task GetIdentityProperties_WhenIdentityPropertiesDoNotExist_Returns404()
    {
        _getIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ReturnsAsync(() => null);

        var resp = await _controller.GetIdentityPropertiesWithRole(_getIdentityPropertiesInteractor.Object, _getIdentityRoleInteractor.Object);
        AssertUtil.AssertErrorResponse<NotFoundObjectResult>(resp, StatusCodes.Status404NotFound, "no_identity_properties", "No identity properties exists for this identity");
    }

    [Fact]
    public async Task GetIdentityProperties_WhenProfileWasRequested_WhenProfileDoNotExist_ReturnsProfileNotFoundError()
    {
        _getIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ReturnsAsync(() => null);

        var resp = await _controller.GetIdentityPropertiesWithRole(_getIdentityPropertiesInteractor.Object, _getIdentityRoleInteractor.Object);
        AssertUtil.AssertErrorResponse<NotFoundObjectResult>(resp, StatusCodes.Status404NotFound, "no_identity_properties", "No identity properties exists for this identity");
    }

    [Fact]
    public async Task GetIdentityProperties_WhenInteractorThrowsUnknownError_Returns500()
    {
        var ex = new Exception();

        _getIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ThrowsAsync(ex);

        var resp = await _controller.GetIdentityPropertiesWithRole(_getIdentityPropertiesInteractor.Object, _getIdentityRoleInteractor.Object);
        AssertUtil.AssertErrorResponse<ObjectResult>(resp, StatusCodes.Status500InternalServerError, "unexpected_error", "An unexpected error occured");
    }

    [Fact]
    public async Task GetIdentityProperties_WhenIdentityPropertiesExists_Returns200WithIdentityProperties()
    {
        _getIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ReturnsAsync(new IdentityProperties
            {
                IdentityId = "identityId",
                CountryCode = "dk",
            });
        const string roleId = "lul ID";
        const string roleName = "kekw role";

        _getIdentityRoleInteractor
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<bool>()))
            .ReturnsAsync(new Role
            {
                Id = roleId,
                Name = roleName,
            });

        var resp = await _controller.GetIdentityPropertiesWithRole(_getIdentityPropertiesInteractor.Object, _getIdentityRoleInteractor.Object);

        var objectResp = Assert.IsType<OkObjectResult>(resp);
        var dto = Assert.IsType<IdentityPropertiesWithRoleResponseDto>(objectResp.Value);

        Assert.NotNull(dto);
        Assert.Equal("identityId", dto.IdentityId);
        Assert.Equal("dk", dto.Country);
        Assert.Single(dto.Role, role => role is { Id: roleId, Name: roleName });
    }

    #endregion GetIdentityProperties

    #region GetIdentityPropertiesWithRole

    [Fact]
    public async Task GetIdentityPropertiesWithRole_WhenIdentityPropertiesDoNotExist_Returns404()
    {
        _getIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ReturnsAsync(() => null);

        var resp = await _controller.GetIdentityPropertiesWithRole(_getIdentityPropertiesInteractor.Object, _roleInteractorMock.Object);
        AssertUtil.AssertErrorResponse<NotFoundObjectResult>(resp, StatusCodes.Status404NotFound, "no_identity_properties", "No identity properties exists for this identity");
    }

    [Fact]
    public async Task GetIdentityPropertiesWithRole_WhenInteractorThrowsUnknownError_Returns500()
    {
        var ex = new Exception();

        _getIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ThrowsAsync(ex);

        var resp = await _controller.GetIdentityPropertiesWithRole(_getIdentityPropertiesInteractor.Object, _roleInteractorMock.Object);
        AssertUtil.AssertErrorResponse<ObjectResult>(resp, StatusCodes.Status500InternalServerError, "unexpected_error", "An unexpected error occured");
    }

    [Fact]
    public async Task GetIdentityPropertiesWithRole_WhenInteractorSucceeds_Returns200WithIdentityPropertiesWithRole()
    {
        var identityPropertiesToReturn = new IdentityProperties
        {
            IdentityId = "identityId",
            CountryCode = "dk",
        };

        var roleToReturn = new Role { Id = "NwadAdmin", Name = "Nwad Admin" };

        _getIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<string>()))
            .ReturnsAsync(identityPropertiesToReturn);

        _roleInteractorMock.Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<bool>())).ReturnsAsync(roleToReturn);

        var resp = await _controller.GetIdentityPropertiesWithRole(_getIdentityPropertiesInteractor.Object, _roleInteractorMock.Object);

        var objectResp = Assert.IsType<OkObjectResult>(resp);

        var dto = Assert.IsType<IdentityPropertiesWithRoleResponseDto>(objectResp.Value);

        Assert.Equal(identityPropertiesToReturn.IdentityId, dto.IdentityId);
        Assert.Equal(identityPropertiesToReturn.CountryCode, dto.Country);
        Assert.Equal(roleToReturn.Id, dto.Role.ElementAt(0).Id);
    }

    #endregion GetIdentityPropertiesWithRole

    #region CreateIdentityProperties

    [Fact]
    public async Task CreateIdentityProperties_WhenUnsupportedCountryChosen_Returns400()
    {
        _createIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<CreateIdentityPropertiesRequest>()))
            .ThrowsAsync(new UnsupportedCountryException("dk"));

        var resp = await _controller.CreateIdentityProperties(_createIdentityPropertiesInteractor.Object, new IdentityPropertiesRequestDto("dk"));
        AssertUtil.AssertErrorResponse<BadRequestObjectResult>(resp, StatusCodes.Status400BadRequest, "unsupported_country", "This country is not on the list of supported countries");
    }

    [Fact]
    public async Task CreateIdentityProperties_WhenIdentityDoesNotExist_Returns401()
    {
        _createIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<CreateIdentityPropertiesRequest>()))
            .ThrowsAsync(new IdentityNotFoundException("identityId"));

        var resp = await _controller.CreateIdentityProperties(_createIdentityPropertiesInteractor.Object, new IdentityPropertiesRequestDto("dk"));
        Assert.IsType<UnauthorizedResult>(resp);
    }

    [Fact]
    public async Task CreateIdentityProperties_WhenIdentityHasIdentityProperties_Returns409()
    {
        _createIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<CreateIdentityPropertiesRequest>()))
            .ThrowsAsync(new DuplicateIdentityPropertiesException("identityId"));

        var resp = await _controller.CreateIdentityProperties(_createIdentityPropertiesInteractor.Object, new IdentityPropertiesRequestDto("dk"));
        AssertUtil.AssertErrorResponse<ConflictObjectResult>(resp, StatusCodes.Status409Conflict, "duplicate_identity_properties", "This identity already has identity properties");
    }

    [Fact]
    public async Task CreateIdentityProperties_WhenInteractorThrowsUnknownError_Returns500()
    {
        _createIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<CreateIdentityPropertiesRequest>()))
            .ThrowsAsync(new Exception());

        var resp = await _controller.CreateIdentityProperties(_createIdentityPropertiesInteractor.Object, new IdentityPropertiesRequestDto("dk"));

        AssertUtil.AssertErrorResponse<ObjectResult>(resp, StatusCodes.Status500InternalServerError, "unexpected_error", "An unexpected error occured");
    }

    [Fact]
    public async Task CreateIdentityProperties_WhenIdentityDoesNotHaveIdentityProperties_Returns201WithIdentityProperties()
    {
        _createIdentityPropertiesInteractor
            .Setup(mock => mock.Execute(It.IsAny<CreateIdentityPropertiesRequest>()))
            .ReturnsAsync(new IdentityProperties
            {
                IdentityId = "identityId",
                CountryCode = "dk",
            });

        var resp = await _controller.CreateIdentityProperties(_createIdentityPropertiesInteractor.Object, new IdentityPropertiesRequestDto("dk"));

        var result = Assert.IsType<CreatedResult>(resp);
        var dto = Assert.IsType<IdentityPropertiesResponseDto>(result.Value);

        Assert.NotNull(dto);
        Assert.Equal("identityId", dto.IdentityId);
        Assert.Equal("dk", dto.Country);
    }

    #endregion CreateIdentityProperties
}
