using NwadHealth.Besthealthorg.Foundation.Dtos;
using Microsoft.AspNetCore.Http;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Middleware;

/// <summary>
/// Middleware that changes the body of 401 responses to a BESTHEALTHORG error structure
/// </summary>
public class UnauthorizedResponseRewriteMiddleware
{
    private readonly RequestDelegate _next;

    /// <summary>
    /// Initializes the middleware
    /// </summary>
    /// <param name="next">The next part of the HTTP pipeline</param>
    public UnauthorizedResponseRewriteMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    /// <summary>
    /// Executes the middleware
    /// </summary>
    /// <param name="context">The HTTP context being worked on</param>
    /// <returns>A task that completes when the middleware is done executing</returns>
    public async Task InvokeAsync(HttpContext context)
    {
        var oldBody = context.Response.Body;
        var newBody = new MemoryStream();

        context.Response.Body = newBody;

        await _next.Invoke(context);

        context.Response.Body = oldBody;

        if (context.Response.StatusCode == 401)
        {
            await context.Response.WriteAsJsonAsync(new ErrorResponseDto
            {
                ErrorCode = "identity_not_authenticated",
                Error = "You are not authenticated for this API"
            });
        }
        else if (context.Response.StatusCode == 403)
        {
            await context.Response.WriteAsJsonAsync(new ErrorResponseDto
            {
                ErrorCode = "identity_not_authorized",
                Error = "You are not authorized to read/write this data"
            });
        }
        else
        {
            newBody.Position = 0;
            await newBody.CopyToAsync(context.Response.Body);
        }
    }
}
