﻿using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Middleware;

/// <summary>
/// Middleware that fetches the users role from database or cache and adds it to the context
/// </summary>
public class SetRoleMiddleware
{
    private readonly RequestDelegate _next;

    /// <summary>
    /// Initializes the middleware
    /// </summary>
    /// <param name="next">The next part of the HTTP pipeline</param>
    public SetRoleMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    /// <summary>
    /// Executes the middleware
    /// </summary>
    /// <param name="context">The HTTP context being worked on</param>
    /// <param name="getIdentityRoleInteractor">The interactor used for retrieving the roles</param>
    /// <returns>A task that completes when the middleware is done executing</returns>
    public async Task InvokeAsync(HttpContext context, IGetIdentityRoleInteractor getIdentityRoleInteractor)
    {
        var identityId = context.User.Identity?.Name;
        if (identityId is not null)
        {
            Role role;
            try
            {
                role = await getIdentityRoleInteractor.Execute(identityId, true);
            }
            catch
            {
                role = Role.Default;
            }

            context.User.Identities.First().AddClaim(new(ClaimTypes.Role, role.Id));
        }

        await _next.Invoke(context);
    }
}
