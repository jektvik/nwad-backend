﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.DbModels;

/// <summary>
/// Represents role stored in database
/// </summary>
public class RoleDocument
{
    /// <summary>
    /// Unique identifier
    /// </summary>
    public required string Id { get; init; }

    /// <summary>
    /// Name of the role
    /// </summary>
    public required string Name { get; init; }

    /// <summary>
    /// Converts Role database model to role domain model
    /// </summary>
    public Role ToDomain()
    {
        return new()
        {
            Id = Id,
            Name = Name,
        };
    }
}
