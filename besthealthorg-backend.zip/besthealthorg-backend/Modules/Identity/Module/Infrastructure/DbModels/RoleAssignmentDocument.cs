﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.DbModels;

/// <summary>
/// Represents roleAssignment stored in db
/// </summary>
public class RoleAssignmentDocument
{
    /// <summary>
    /// Id belonging to an identity
    /// </summary>
    public required string Id { get; init; }

    /// <summary>
    /// Id corresponding to a role
    /// </summary>
    public required string RoleId { get; init; }

    /// <summary>
    /// Converts RoleAssignment database model into roleAssignment domain model
    /// </summary>
    public RoleAssignment ToDomain()
    {
        return new() { Id = Id, RoleId = RoleId };
    }

    /// <summary>
    /// Converts RoleAssignment domain model into roleAssignment database model
    /// </summary>
    /// <param name="roleAssignmentDocument">The domain model to convert</param>
    public static RoleAssignmentDocument FromDomain(RoleAssignment roleAssignmentDocument)
    {
        return new() { Id = roleAssignmentDocument.Id, RoleId = roleAssignmentDocument.RoleId };
    }
}
