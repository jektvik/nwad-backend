﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Caching.Memory;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Cache;

/// <summary>
/// Class responisble for country caching
/// </summary>
public class CountriesMemoryCache
{
    private readonly MemoryCache _cache;
    private readonly MemoryCacheEntryOptions _options = new MemoryCacheEntryOptions().SetSlidingExpiration(TimeSpan.FromHours(1));

    /// <summary>
    /// Initializer for the cache class
    /// </summary>
    public CountriesMemoryCache()
    {
        _cache = new(new MemoryCacheOptions());
    }

    /// <summary>
    /// Saves the country enumerable in the cache
    /// </summary>
    /// <param name="countries">The countries to cache</param>
    public void StoreAllCountries(IEnumerable<Country> countries)
    {
        _cache.Set("allCountries", countries.ToDictionary(c => c.Id, c => c), _options);
    }

    /// <summary>
    /// Retrieve enumerable of supported countries from the cache
    /// </summary>
    /// <returns>Enumerable of cached countries or null if not cached</returns>
    public IEnumerable<Country>? GetAllCountries()
    {
        return _cache.Get<IDictionary<string, Country>>("allCountries")?.Select(p => p.Value);
    }

    /// <summary>
    /// Find Country in cache by country code
    /// </summary>
    /// <param name="countryCode">Two letter country code in ISO 3166-1 alpha-2 format, eg: "dk" for Denmark</param>
    /// <returns>Country from cache or null if it isn't cached</returns>
    public Country? GetCountryByCountryCode(string countryCode)
    {
        if (!_cache.TryGetValue<IDictionary<string, Country>>("allCountries", out var allCountries))
        {
            return null;
        }

        if (allCountries?.TryGetValue(countryCode, out var country) != true)
        {
            return null;
        }

        return country;
    }

    /// <summary>
    /// Clears all countries from the cache
    /// </summary>
    public void Clear()
    {
        _cache.Clear();
    }
}
