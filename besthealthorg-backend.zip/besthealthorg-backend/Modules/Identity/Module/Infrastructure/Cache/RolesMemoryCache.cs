﻿using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Caching.Memory;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Cache;

/// <summary>
/// Class responisble for roles caching
/// </summary>
public class RolesMemoryCache : IRolesMemoryCache
{
    private readonly MemoryCache _cache;
    private readonly MemoryCacheEntryOptions _options = new MemoryCacheEntryOptions().SetSlidingExpiration(TimeSpan.FromDays(1));

    /// <summary>
    /// Initializer for the cache class
    /// </summary>
    public RolesMemoryCache()
    {
        _cache = new(new MemoryCacheOptions());
    }

    /// <summary>
    /// Saves the user and his/her role in the cache
    /// </summary>
    /// <param name="identityId">Id belonging to an identity</param>
    /// <param name="role">The role to be cached</param>
    public void CacheRoleForIdentity(string identityId, Role role)
    {
        _cache.Set(identityId, role, _options);
    }

    /// <summary>
    /// Find user's role in cache by identity id
    /// </summary>
    /// <param name="identityId">Id belonging to an identity</param>
    /// <returns>Role from cache or null if it isn't cached</returns>
    public Role? GetRoleByIdenityId(string identityId)
    {
        _cache.TryGetValue<Role?>(identityId, out var role);

        return role;
    }

    /// <summary>
    /// Delete all entries in roles memory cache
    /// </summary>
    public void Clear()
    {
        _cache.Clear();
    }
}
