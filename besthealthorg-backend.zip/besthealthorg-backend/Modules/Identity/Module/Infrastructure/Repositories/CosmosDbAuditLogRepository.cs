using System.Net;
using NwadHealth.Besthealthorg.Foundation.Azure;
using NwadHealth.Besthealthorg.Foundation.Events;
using NwadHealth.Besthealthorg.Foundation.Extensions.Cosmos;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Azure.Cosmos;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Repositories;

/// <summary>
/// A CosmosDb implementation of <see cref="IAuditLogRepository" />
/// </summary>
public class CosmosDbAuditLogRepository : IAuditLogRepository
{
    private readonly Configuration _configuration;
    private readonly CosmosClient _client;

    private Container Container
    {
        get { return _client.GetDatabase(_configuration.CosmosDbDatabaseName).GetContainer(_configuration.CosmosDbAuditContainerName); }
    }

    /// <summary>
    /// Initializes the CosmosDbAuditLogRepository
    /// </summary>
    /// <param name="configuration">The configuration to use</param>
    /// <param name="azureClientProvider">The IAzureClientProvider to get the CosmosClient from</param>
    public CosmosDbAuditLogRepository(Configuration configuration, IAzureClientProvider azureClientProvider)
    {
        _configuration = configuration;
        _client = azureClientProvider.GetCosmosClient(_configuration.CosmosDbConnectionString);
    }

    /// <summary>
    /// Writes an event to the CosmosDB audit log
    /// </summary>
    /// <param name="paceEvent">The event to write</param>
    public async Task WriteRecord(PaceEvent paceEvent)
    {
        try
        {
            await Container.CreateItemAsync(
                paceEvent,
                new PartitionKey(paceEvent.IdentityId),
                new ItemRequestOptions { EnableContentResponseOnWrite = false });

            if (paceEvent.Type.Contains("Besthealthorg.IdentityDeletedEvent"))
            {
                await SetRetentionOnRecords(paceEvent.IdentityId!);
            }
        }
        catch (CosmosException ex)
        {
            if (ex.StatusCode == HttpStatusCode.Conflict)
            {
                return;
            }

            throw;
        }
    }

    /// <summary>
    /// Sets retention time on all events containing the identity ID
    /// </summary>
    /// <param name="identityId">The ID of the identity, whose events should be marked</param>
    public async Task SetRetentionOnRecords(string identityId)
    {
        var retainUntil = DateTimeOffset.UtcNow.AddYears(_configuration.AuditLogRetentionTime);

        await Container.SetTTLByQuery<PaceEvent>(
            new PartitionKey(identityId),
            retainUntil,
            query => query.Where(e => e.IdentityId == identityId).Select(e => e.Id)
        );
    }
}
