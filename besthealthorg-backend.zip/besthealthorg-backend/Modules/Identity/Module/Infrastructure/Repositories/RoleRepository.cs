﻿using System.Net;
using NwadHealth.Besthealthorg.Foundation.Azure;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.DbModels;
using Microsoft.Azure.Cosmos;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Repositories;

/// <summary>
/// Represents operations available for retrieval of roles
/// </summary>
public class RoleRepository : IRoleRepository
{
    private readonly Configuration _configuration;
    private readonly CosmosClient _client;

    private Container _container
    {
        get { return _client.GetDatabase(_configuration.CosmosDbDatabaseName).GetContainer(_configuration.CosmosDbRolesContainer); }
    }

    /// <summary>
    /// Initializes the Role repository
    /// </summary>
    /// <param name="configuration">The configuration to use</param>
    /// <param name="azureClientProvider">The IAzureClientProvider to get the CosmosClient from</param>
    public RoleRepository(Configuration configuration, IAzureClientProvider azureClientProvider)
    {
        _configuration = configuration;
        _client = azureClientProvider.GetCosmosClient(configuration.CosmosDbConnectionString);
    }

    /// <summary>
    /// Retrieves a role by id
    /// </summary>
    /// <param name="roleId">Id corresponding to a role</param>
    /// <returns>The role or null if role with provided id does not exist</returns>
    public async Task<Role?> GetRoleById(string roleId)
    {
        try
        {
            var itemResponse = await _container.ReadItemAsync<RoleDocument>(id: roleId, partitionKey: new PartitionKey(roleId));

            return itemResponse.Resource.ToDomain();
        }
        catch (CosmosException ex)
        {
            if (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }

            throw;
        }
    }
}
