using Microsoft.Azure.Cosmos;
using System.Net;
using NwadHealth.Besthealthorg.Foundation.Azure;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;

namespace NwadHealth.Besthealthorg.ConsentModule.Infrastructure.Repositories;

/// <summary>
/// Represents operations available for storage/retrieval of identity properties
/// </summary>
public class IdentityPropertiesRepository : IIdentityPropertiesRepository
{
    private readonly Configuration _configuration;
    private readonly CosmosClient _client;

    private static ItemRequestOptions DefaultItemRequestOptions
    {
        get { return new() { EnableContentResponseOnWrite = false }; }
    }

    private Container _container
    {
        get { return _client.GetDatabase(_configuration.CosmosDbDatabaseName).GetContainer(_configuration.CosmosDbIdentityPropertiesContainerName); }
    }

    /// <summary>
    /// Initializes the identity properties repository
    /// </summary>
    /// <param name="configuration">The configuration to use</param>
    /// <param name="azureClientProvider">The IAzureClientProvider to get the CosmosClient from</param>
    public IdentityPropertiesRepository(Configuration configuration, IAzureClientProvider azureClientProvider)
    {
        _configuration = configuration;
        _client = azureClientProvider.GetCosmosClient(configuration.CosmosDbConnectionString);
    }

    /// <summary>
    /// Creates a identity properties in the data store
    /// </summary>
    /// <param name="identityProperties">The identity properties to create</param>
    /// <returns>Identity properties</returns>
    public async Task<IdentityProperties> Create(IdentityProperties identityProperties)
    {
        var document = IdentityPropertiesDocument.FromDomain(identityProperties);
        var response = await _container.CreateItemAsync(document, new PartitionKey(document.Id));

        return response.Resource.ToDomain();
    }

    /// <summary>
    /// Finds identity properties by identity id
    /// </summary>
    /// <param name="identityId">The Id of the identity to get the identity properties for</param>
    /// <returns>The identity properties beloning to the identity specified id or null if they don't exist</returns>
    public async Task<IdentityProperties?> GetIdentityPropertiesByIdentityId(string identityId)
    {
        try
        {
            var itemResponse = await _container.ReadItemAsync<IdentityPropertiesDocument>(identityId, new PartitionKey(identityId));

            return itemResponse.Resource.ToDomain();
        }
        catch (CosmosException ex)
        {
            if (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }

            throw;
        }
    }

    /// <summary>
    /// Deletes identity properties by identity id if they exists
    /// </summary>
    /// <param name="identityId">The Id of the identity to delete the identity properties for</param>
    public async Task DeleteIdentityPropertiesByIdentityId(string identityId)
    {
        try
        {
            await _container.DeleteItemAsync<IdentityPropertiesDocument>(identityId, new PartitionKey(identityId), DefaultItemRequestOptions);
        }
        catch (CosmosException e) when (e.StatusCode == HttpStatusCode.NotFound)
        {
            // Intentionally left blank: deleting identity properties that don't exist is a noop
        }
    }
}
