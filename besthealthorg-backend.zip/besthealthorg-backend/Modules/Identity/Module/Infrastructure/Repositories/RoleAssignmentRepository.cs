﻿using System.Net;
using NwadHealth.Besthealthorg.Foundation.Azure;
using NwadHealth.Besthealthorg.Foundation.Extensions.Cosmos;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.DbModels;
using Microsoft.Azure.Cosmos;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Repositories;

/// <summary>
/// Represents operations available for retrieval of role assignments
/// </summary>
public class RoleAssignmentRepository : IRoleAssignmentRepository
{
    private readonly Configuration _configuration;
    private readonly CosmosClient _client;

    private static ItemRequestOptions DefaultItemRequestOptions => new() { EnableContentResponseOnWrite = false };

    private Container _container => _client.GetDatabase(_configuration.CosmosDbDatabaseName).GetContainer(_configuration.CosmosDbRoleAssignmentsContainer);

    /// <summary>
    /// Initializes the Role Assignment repository
    /// </summary>
    /// <param name="configuration">The configuration to use</param>
    /// <param name="azureClientProvider">The IAzureClientProvider to get the CosmosClient from</param>
    public RoleAssignmentRepository(Configuration configuration, IAzureClientProvider azureClientProvider)
    {
        _configuration = configuration;
        _client = azureClientProvider.GetCosmosClient(configuration.CosmosDbConnectionString);
    }

    /// <summary>
    /// Retrieves a role assignment for identity id
    /// </summary>
    /// <param name="identityId">The identity id representing the user</param>
    /// <returns>The role assignment or null if the identity does not have any role assigned</returns>
    public async Task<RoleAssignment?> GetRoleAssignmentByIdentityId(string identityId)
    {
        try
        {
            var itemResponse = await _container.ReadItemAsync<RoleAssignmentDocument>(id: identityId, partitionKey: new PartitionKey(identityId));
            return itemResponse.Resource.ToDomain();
        }
        catch (CosmosException ex)
        {
            if (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }

            throw;
        }
    }

    /// <summary>
    /// Retrieves role assignments for a given role id
    /// </summary>
    /// <param name="roleId">The role id to filter the assignments by</param>
    /// <returns>Collection of role assignments</returns>
    public async Task<IEnumerable<RoleAssignment>> GetRoleAssignmentsByRoleId(string roleId)
    {
       return await _container.GetByQuery<RoleAssignment>(query => query.Where(roleAssignment => roleAssignment.RoleId == roleId));
    }

    /// <summary>
    /// Creates a role assignment in the data store
    /// </summary>
    /// <param name="roleAssignment">The role assignment to create</param>
    /// <returns>The role assignment</returns>
    public async Task<RoleAssignment> CreateRoleAssignment(RoleAssignment roleAssignment)
    {
        var document = RoleAssignmentDocument.FromDomain(roleAssignment);
        var response = await _container.CreateItemAsync(document, new PartitionKey(document.Id));

        return response.Resource.ToDomain();
    }

    /// <summary>
    /// Deletes a role assignment from the data store
    /// </summary>
    /// <param name="identityId">The identity whose role assignment should be deleted</param>
    public async Task DeleteRoleAssignmentByIdentityId(string identityId)
    {
        try
        {
            await _container.DeleteItemAsync<RoleAssignmentDocument>(identityId, new PartitionKey(identityId), DefaultItemRequestOptions);
        }
        catch (CosmosException e) when (e.StatusCode == HttpStatusCode.NotFound)
        {
            // Intentionally left blank: deleting role assignment that don't exist is a noop
        }
    }
}
