﻿using System.Net;
using NwadHealth.Besthealthorg.Foundation.Azure;
using NwadHealth.Besthealthorg.Foundation.Extensions.Cosmos;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Cache;
using Microsoft.Azure.Cosmos;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Repositories;

/// <summary>
/// Represents operations available for storage/retrieval of Countries
/// </summary>
public class CountryRepository : ICountryRepository
{
    private readonly CountriesMemoryCache _memoryCache;
    private readonly Configuration _configuration;
    private readonly CosmosClient _client;

    private Container _container
    {
        get { return _client.GetDatabase(_configuration.CosmosDbDatabaseName).GetContainer(_configuration.CosmosDbCountriesContainer); }
    }

    /// <summary>
    /// Initializes the Countries repository
    /// </summary>
    /// <param name="configuration">The configuration to use</param>
    /// <param name="azureClientProvider">The IAzureClientProvider to get the CosmosClient from</param>
    /// <param name="countriesMemoryCache">Cache service provided from DI</param>
    public CountryRepository(Configuration configuration, IAzureClientProvider azureClientProvider, CountriesMemoryCache countriesMemoryCache)
    {
        _configuration = configuration;
        _client = azureClientProvider.GetCosmosClient(configuration.CosmosDbConnectionString);
        _memoryCache = countriesMemoryCache;
    }

    /// <summary>
    /// Retrieves a supported country by country code
    /// </summary>
    /// <param name="countryCode">The code of the country to fetch</param>
    /// <returns>The country or null if it doesn't exist</returns>
    public async Task<Country?> GetCountryByCountryCode(string countryCode)
    {
        try
        {
            var cachedCountry = _memoryCache.GetCountryByCountryCode(countryCode);
            return cachedCountry ?? await _container.ReadItemAsync<Country>(id: countryCode, partitionKey: new PartitionKey(countryCode));
        }
        catch (CosmosException ex)
        {
            if (ex.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }

            throw;
        }
    }

    /// <summary>
    /// Retrieves list of stored countries
    /// </summary>
    /// <returns>A list of stored countries</returns>
    public async Task<IEnumerable<Country>> GetAll()
    {
        var storedCountries = _memoryCache.GetAllCountries();

        if (storedCountries is not null)
        {
            return storedCountries;
        }

        var result = await _container.GetAll<Country>();
        _memoryCache.StoreAllCountries(result);

        return result;
    }
}
