using NwadHealth.Besthealthorg.ConsentModule.Infrastructure.Repositories;
using NwadHealth.Besthealthorg.Foundation.Azure;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.EventHandlers;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Cache;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Middleware;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure;

/// <summary>
/// Provides extension methods for configuring the IdentityModule
/// </summary>
public static class IdentityModuleExtensions
{
    /// <summary>
    /// Configures the required services for the Identity Module
    /// </summary>
    /// <param name="services">The IServiceCollection to be configured</param>
    /// <param name="config">The identity module configuration</param>
    /// <param name="plugin">The plugin to configure</param>
    /// <returns>The same IServiceCollection the method was called on, with configuration set</returns>
    public static IServiceCollection AddPaceIdentity(this IServiceCollection services, Configuration config,
        IIdentityPlugin plugin)
    {
        //Singletons
        services.TryAddSingleton<IAzureClientProvider, AzureClientProvider>();
        services.AddSingleton<CountriesMemoryCache>();
        services.AddSingleton<IRolesMemoryCache, RolesMemoryCache>();
        services.AddSingleton(config);

        services.AddSingleton<IdentityEventManager>();
        services.AddSingleton<IIdentityEventSubscriber>(x => x.GetRequiredService<IdentityEventManager>());
        services.AddSingleton<IIdentityEventPublisher>(x => x.GetRequiredService<IdentityEventManager>());

        // Repositories
        services.AddScoped<IIdentityPropertiesRepository, IdentityPropertiesRepository>();
        services.AddScoped<ICountryRepository, CountryRepository>();
        services.AddScoped<IRoleAssignmentRepository, RoleAssignmentRepository>();
        services.AddScoped<IRoleRepository, RoleRepository>();
        services.AddScoped<IAuditLogRepository, CosmosDbAuditLogRepository>();

        // Interactors
        services.AddScoped<IGetConfigurationInteractor, GetConfigurationInteractor>();
        services.AddScoped<IResendVerificationEmailInteractor, ResendVerificationEmailInteractor>();
        services.AddScoped<IGetEmailVerificationStatusInteractor, GetEmailVerificationStatusInteractor>();
        services.AddScoped<IDeleteIdentityInteractor, DeleteIdentityInteractor>();
        services.AddScoped<ICreateIdentityPropertiesInteractor, CreateIdentityPropertiesInteractor>();
        services.AddScoped<IGetIdentityPropertiesInteractor, GetIdentityPropertiesInteractor>();
        services.AddScoped<IChangeEmailInteractor, ChangeEmailInteractor>();
        services.AddScoped<IGetIdentityRoleInteractor, GetIdentityRoleInteractor>();

        services.Configure<ForwardedHeadersOptions>(options =>
            options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto);

        plugin.ConfigureServices(services);

        services.AddScoped(typeof(IIdentityProvider), plugin.IdentityProviderType);

        return services;
    }

    /// <summary>
    /// Prepares the application to use the Identity Module
    /// </summary>
    /// <param name="app">The IApplicationBuilder to be prepared</param>
    /// <returns>The same IApplicationBuilder the method was called on, prepared for the Identity Module</returns>
    public static IApplicationBuilder UsePaceIdentity(this IApplicationBuilder app)
    {
        app.UseMiddleware<UnauthorizedResponseRewriteMiddleware>();
        app.UseAuthentication();
        app.UseMiddleware<SetRoleMiddleware>();
        app.UseAuthorization();
        return app;
    }
}
