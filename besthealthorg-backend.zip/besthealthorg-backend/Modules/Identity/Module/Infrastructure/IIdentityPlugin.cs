using Microsoft.Extensions.DependencyInjection;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure;

/// <summary>
/// Represents a plugin used with the Identity module
/// </summary>
public interface IIdentityPlugin
{
    /// <summary>
    /// The type that implements IIdentityProvider
    /// </summary>
    Type IdentityProviderType { get; }

    /// <summary>
    /// Configures services required by the plugin
    /// </summary>
    /// <param name="services">The IServiceCollection the services should be configured in</param>
    void ConfigureServices(IServiceCollection services);
}
