﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Responses;

/// <summary>
/// Represents the data returned by the <see cref="Interactors.IGetConfigurationInteractor"></see> for retrieving configuration
/// </summary>
public class GetConfigurationResponse
{
    /// <summary>
    /// Whether email verification is required before login
    /// </summary>
    public bool IsEmailVerificationRequired { get; set; }

    /// <summary>
    /// List of supported countries
    /// </summary>
    public IEnumerable<Country> SupportedCountries { get; set; } = new List<Country>();
}
