namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Requests;

/// <summary>
/// Represents the data required by the <see cref="Interactors.ICreateIdentityPropertiesInteractor"></see> for creating identity properties
/// </summary>
public class CreateIdentityPropertiesRequest
{
    /// <summary>
    /// The id of the identity to create identity properties for
    /// </summary>
    public string IdentityId { get; set; } = string.Empty;

    /// <summary>
    /// The country code to set on the identity properties
    /// </summary>
    public string? CountryCode { get; set; }
}
