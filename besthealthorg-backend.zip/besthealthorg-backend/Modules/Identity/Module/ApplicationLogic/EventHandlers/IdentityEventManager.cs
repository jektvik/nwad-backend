using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Events;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.EventHandlers;

/// <summary>
/// Handles identity-related events, including publishing and subscribing to events related to identity changes.
/// </summary>
/// <remarks>
/// This class implements both <see cref="IIdentityEventPublisher"/> and <see cref="IIdentityEventSubscriber"/>,
/// allowing it to act as a central point for handling identity events within the application.
/// It can publish events when an identity's email is changed or an identity is deleted, and it can also subscribe to these events.
/// </remarks>
/// <param name="logger">The logger used</param>
public class IdentityEventManager(ILogger<IdentityEventManager> logger): IIdentityEventPublisher, IIdentityEventSubscriber
{
    /// <inheritdoc />
    public event EventHandler<IdentityDeletedEvent>? IdentityDeleted;

    /// <inheritdoc />
    public event EventHandler<EmailChangedEvent>? EmailChanged;

    /// <summary>
    /// Publishes an email changed event
    /// </summary>
    /// <param name="identity">The identity that was deleted</param>
    /// <param name="newEmail">The new email of the identity</param>
    public Task PublishEmailChangeEvent(IIdentity identity, string newEmail)
    {
        logger.LogInformation("Publishing email changed event");

        var emailChangedEvent = new EmailChangedEvent
        {
            IdentityId = identity.Id,
            OldEmail = identity.Email,
            NewEmail = newEmail,
        };

        OnEmailChanged(emailChangedEvent);

        return Task.CompletedTask;
    }

    /// <summary>
    /// Publishes an account deleted event
    /// </summary>
    /// <param name="identity">The identity that was deleted</param>
    public Task PublishDeletedEvent(IIdentity identity)
    {
        logger.LogInformation("Publishing identity deleted event");
        var deleteEvent = new IdentityDeletedEvent
        {
            Identity = identity,
        };

        OnIdentityDeleted(deleteEvent);
        return Task.CompletedTask;
    }

    /// <summary>
    /// Publishes an email changed event
    /// </summary>
    /// <param name="emailChangedEvent">The email changed event</param>
    private void OnEmailChanged(EmailChangedEvent emailChangedEvent)
    {
        EmailChanged?.Invoke(this, emailChangedEvent);
    }

    /// <summary>
    /// Publishes an identity deleted event
    /// </summary>
    /// <param name="identityDeletedEvent">The identity deleted event</param>
    private void OnIdentityDeleted(IdentityDeletedEvent identityDeletedEvent)
    {
        IdentityDeleted?.Invoke(this, identityDeletedEvent);
    }
}
