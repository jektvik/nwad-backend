using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;

/// <summary>
/// An interface representing an event publisher used for sending Identity related events
/// </summary>
public interface IIdentityEventPublisher
{
    /// <summary>
    /// Publishes an email changed event
    /// </summary>
    /// <param name="identity">The identity that was deleted</param>
    /// <param name="newEmail">The new email of the identity</param>
    Task PublishEmailChangeEvent(IIdentity identity, string newEmail);

    /// <summary>
    /// Publishes an account deleted event
    /// </summary>
    /// <param name="identity">The identity that was deleted</param>
    Task PublishDeletedEvent(IIdentity identity);
}
