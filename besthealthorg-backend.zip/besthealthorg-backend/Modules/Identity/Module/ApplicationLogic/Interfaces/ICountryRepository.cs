﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing the required interactions with a data store
/// </summary>
public interface ICountryRepository
{
    /// <summary>
    /// Retrieves a supported country by country code
    /// </summary>
    /// <param name="countryCode">The two letter ISO 3166-1 alpha-2 code of country to fetch, e.g. "dk" for Denmark</param>
    /// <returns>The country or null if it doesn't exist</returns>
    Task<Country?> GetCountryByCountryCode(string countryCode);

    /// <summary>
    /// Used to retrieve all supported countries from datastore
    /// </summary>
    /// <returns>Returns a list of supported countries</returns>
    Task<IEnumerable<Country>> GetAll();
}
