﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;

/// <summary>
/// Interface responisble for role caching
/// </summary>
public interface IRolesMemoryCache
{
    /// <summary>
    /// Saves the user and his/her role in the cache
    /// </summary>
    /// <param name="identityId">Id belonging to an identity</param>
    /// <param name="role">The role to be cached</param>
    public void CacheRoleForIdentity(string identityId, Role role);

    /// <summary>
    /// Find user's role in cache by identity id
    /// </summary>
    /// <param name="identityId">Id belonging to an identity</param>
    /// <returns>Role from cache or null if it isn't cached</returns>
    public Role? GetRoleByIdenityId(string identityId);

    /// <summary>
    /// Delete all entries in roles memory cache
    /// </summary>
    public void Clear();
}
