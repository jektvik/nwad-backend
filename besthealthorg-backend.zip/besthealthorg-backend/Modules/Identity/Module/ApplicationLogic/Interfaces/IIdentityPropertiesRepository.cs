﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing the required interactions with a identity properties data store
/// </summary>
public interface IIdentityPropertiesRepository
{
    /// <summary>
    /// Creates a identity properties in the data store
    /// </summary>
    /// <param name="identityProperties">The identity properties to create</param>
    /// <returns>Identity properties or null</returns>
    Task<IdentityProperties> Create(IdentityProperties identityProperties);

    /// <summary>
    /// Finds a identity properties by identity id
    /// </summary>
    /// <param name="identityId">The Id of the identity to get the identity properties for</param>
    /// <returns>The identity properties beloning to the identity specified id or null if it doesn't exist</returns>
    Task<IdentityProperties?> GetIdentityPropertiesByIdentityId(string identityId);

    /// <summary>
    /// Deletes a identity properties by identity id if it exists
    /// </summary>
    /// <param name="identityId">The Id of the identity to delete the identity properties for</param>
    Task DeleteIdentityPropertiesByIdentityId(string identityId);
}
