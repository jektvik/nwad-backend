using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;

/// <summary>
/// An interface representing an identity provider
/// </summary>
public interface IIdentityProvider
{
    /// <summary>
    /// Requests the identity provider to create a new identity
    /// </summary>
    /// <param name="email">The email of the identity</param>
    /// <param name="password">The password of the identity</param>
    /// <param name="emailVerified">Whether to create the identity with verified email or not</param>
    /// <returns>Identity</returns>
    Task<IIdentity> CreateIdentity(string email, string password, bool emailVerified);

    /// <summary>
    /// Requests the identity provider to create a password reset ticket
    /// </summary>
    /// <param name="identityId">The id of the identity for which to create a password reset ticket</param>
    /// <param name="emailVerified">Whether to set the email_verified attribute to true (true) or whether it should not be updated (false).</param>
    /// <param name="clientId">Client id of the auth0 application for which to use the login url</param>
    /// <returns>Reset password ticket url</returns>
    Task<string> CreateResetPasswordTicket(string identityId, bool emailVerified, string clientId);

    /// <summary>
    /// Requests the identity provider to resend the verification email
    /// </summary>
    /// <param name="identityId">The id of the identity for which to resend verification email</param>
    Task ResendVerificationEmail(string identityId);

    /// <summary>
    /// Fetches the identity with the given id from the identity provider
    /// </summary>
    /// <param name="identityId">The id of the identity to fetch the identity for</param>
    /// <returns>The identity or null if it doesn't exist</returns>
    Task<IIdentity?> FetchIdentity(string identityId);

    /// <summary>
    /// Fetches the identity with the given email from the identity provider
    /// </summary>
    /// <param name="email">The email of the identity to fetch the identity for</param>
    /// <returns>The identity or null if it doesn't exist</returns>
    Task<IIdentity?> FetchIdentityByEmail(string email);

    /// <summary>
    /// Requests the identity provider to delete the identity
    /// </summary>
    /// <param name="identityId">The id of the identity to delete</param>
    Task DeleteIdentity(string identityId);

    /// <summary>
    /// Changes the email address of the identity
    /// </summary>
    /// <param name="identityId">The id of the identity to change the email for</param>
    /// <param name="newEmail">The new email address to set</param>
    Task ChangeEmail(string identityId, string newEmail);
}
