﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing the required interactions with a data store
/// </summary>
public interface IRoleAssignmentRepository
{
    /// <summary>
    /// Get role assignment for given user
    /// </summary>
    /// <param name="identityId">Id representing the user</param>
    /// <returns>Role assignment or null if no role assignment was found</returns>
    public Task<RoleAssignment?> GetRoleAssignmentByIdentityId(string identityId);

    /// <summary>
    /// Get role assignments for given role id
    /// </summary>
    /// <param name="roleId">The role id to filter the assignments by</param>
    /// <returns>Collection of role assignments</returns>
    public Task<IEnumerable<RoleAssignment>> GetRoleAssignmentsByRoleId(string roleId);

    /// <summary>
    /// Attempts to create a new role assignment
    /// </summary>
    /// <param name="roleAssignment">The assignment to create</param>
    /// <returns>The created role assignment or null</returns>
    public Task<RoleAssignment> CreateRoleAssignment(RoleAssignment roleAssignment);

    /// <summary>
    /// Deletes a role assignment from the data store
    /// </summary>
    /// <param name="identityId">The identity whose role assignment should be deleted</param>
    public Task DeleteRoleAssignmentByIdentityId(string identityId);
}
