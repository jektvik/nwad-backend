﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing the required interactions with a data store
/// </summary>
public interface IRoleRepository
{
    /// <summary>
    /// Find role by role Id
    /// </summary>
    /// <param name="roleId">Id corresponding to the role</param>
    /// <returns>Role or null if no role was found</returns>
    public Task<Role?> GetRoleById(string roleId);
}
