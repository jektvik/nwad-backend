using NwadHealth.Besthealthorg.IdentityModule.Domain.Events;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;

/// <summary>
/// An interface representing an event subscriber used for receiving Identity related events
/// </summary>
public interface IIdentityEventSubscriber
{
    /// <summary>
    /// An event that is triggered when an identity is deleted
    /// </summary>
    public event EventHandler<IdentityDeletedEvent>? IdentityDeleted;

    /// <summary>
    /// An event that is triggered when an identity's email is changed
    /// </summary>
    public event EventHandler<EmailChangedEvent>? EmailChanged;
}
