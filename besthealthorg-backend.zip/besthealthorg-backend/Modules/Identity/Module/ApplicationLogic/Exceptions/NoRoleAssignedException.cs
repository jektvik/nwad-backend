﻿namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when role is being fetched for an user that does not have one assigned
/// </summary>
public class NoRoleAssigndedException : Exception
{
    private const string MESSAGE = "No role was assigned for this identity";

    /// <summary>
    /// The identity that caused the exception to occur
    /// </summary>
    public string IdentityId { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="identityId">The identity id for which the exception occured</param>
    public NoRoleAssigndedException(string identityId) : base(MESSAGE)
    {
        IdentityId = identityId;
    }
}
