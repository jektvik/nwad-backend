namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when trying to create identity properties for an identity that already has one
/// </summary>
public class DuplicateIdentityPropertiesException : Exception
{
    private const string MESSAGE = "The identity with the given id already has identity properties";

    /// <summary>
    /// The identity id for which the exception occured
    /// </summary>
    public string? IdentityId { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="identityId">The identity id for which the exception occured</param>
    public DuplicateIdentityPropertiesException(string identityId) : base(MESSAGE)
    {
        IdentityId = identityId;
    }
}
