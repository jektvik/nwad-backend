namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when the identity was not found in the identity provider
/// </summary>
public class IdentityNotFoundException : Exception
{
    private const string MESSAGE = "The identity could not be found";

    /// <summary>
    /// The identifier used to lookup the identity e.g. an email or an identity id
    /// </summary>
    public string Identifier { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="identifier">The identity id for which the exception occured</param>
    public IdentityNotFoundException(string identifier) : base(MESSAGE)
    {
        Identifier = identifier;
    }
}
