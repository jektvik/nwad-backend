namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when trying to select a country that is unsupported
/// </summary>
public class UnsupportedCountryException : Exception
{
    private const string MESSAGE = "The selected country is not supported";

    /// <summary>
    /// The country that caused the exception to occur
    /// </summary>
    public string? Country { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="country">The country that caused the exception to occur</param>
    public UnsupportedCountryException(string country) : base(MESSAGE)
    {
        Country = country;
    }
}
