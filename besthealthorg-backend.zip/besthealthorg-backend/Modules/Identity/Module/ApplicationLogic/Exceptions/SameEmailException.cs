﻿namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when the user attempts to change the email to his original one
/// </summary>
public class SameEmailException : Exception
{
    private const string MESSAGE = "The new email address is the same as the original one";

    /// <summary>
    /// The new email that caused the exception to occur
    /// </summary>
    public string NewEmail { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="newEmail">The new email that caused the exception to occur</param>
    public SameEmailException(string newEmail) : base(MESSAGE)
    {
        NewEmail = newEmail;
    }
}
