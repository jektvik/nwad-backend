﻿namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when role is being fetched by Id that does not exists in database
/// </summary>
public class NonExistentRoleException : Exception
{
    private const string MESSAGE = "The assigned role does not exist";

    /// <summary>
    /// The RoleId that caused the exception to occur
    /// </summary>
    public string RoleId { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="roleId">The role Id that caused the exception to occur</param>
    public NonExistentRoleException(string roleId) : base(MESSAGE)
    {
        RoleId = roleId;
    }
}
