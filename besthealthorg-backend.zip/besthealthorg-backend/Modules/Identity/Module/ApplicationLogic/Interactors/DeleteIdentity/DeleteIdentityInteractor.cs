using System.Globalization;
using System.Net;
using System.Text.Json;
using NwadHealth.Besthealthorg.Foundation.Events;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Events;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for deleting an Identity via the identity provider
/// </summary>
public class DeleteIdentityInteractor : IDeleteIdentityInteractor
{
    private readonly IIdentityProvider _identityProvider;
    private readonly IIdentityEventPublisher _eventPublisher;
    private readonly IIdentityPropertiesRepository _identityPropertiesRepository;
    private readonly IRoleAssignmentRepository _roleAssignmentRepository;
    private readonly ILogger<DeleteIdentityInteractor> _logger;
    private readonly IAuditLogRepository _auditLogRepository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="identityProvider">The identity provider to use</param>
    /// <param name="eventPublisher">The event publisher to use</param>
    /// <param name="identityPropertiesRepository">The data store to use for deleting the users identity properties</param>
    /// <param name="roleAssignmentRepository">The data store to use for deleting the users identity properties</param>
    /// <param name="auditLogRepository">The repository responsible for persisting audit logs</param>
    /// <param name="logger">The logger to use</param>
    public DeleteIdentityInteractor(
        IIdentityProvider identityProvider,
        IIdentityEventPublisher eventPublisher,
        IIdentityPropertiesRepository identityPropertiesRepository,
        IRoleAssignmentRepository roleAssignmentRepository,
        IAuditLogRepository auditLogRepository,
        ILogger<DeleteIdentityInteractor> logger)
    {
        _identityProvider = identityProvider;
        _eventPublisher = eventPublisher;
        _identityPropertiesRepository = identityPropertiesRepository;
        _roleAssignmentRepository = roleAssignmentRepository;
        _logger = logger;
        _auditLogRepository = auditLogRepository;
    }

    /// <summary>
    /// Requests the identity provider to delete the identity
    /// </summary>
    /// <param name="identityId">The id for the identity to delete</param>
    /// <param name="deletedByIdentityId">The id of the identity which requested the deletion</param>
    /// <param name="ipAddress">The IP address that initiated the deletion</param>
    /// <returns>A task that completes when the identity provider has been contacted</returns>
    /// <exception cref="IdentityNotFoundException">Thrown if the identity to delete was not found</exception>
    public async Task Execute(string identityId, string deletedByIdentityId,  IPAddress? ipAddress)
    {
        _logger.LogInformation("Executing DeleteIdentityInteractor...");

        var identity = await _identityProvider.FetchIdentity(identityId);

        if (identity is null)
        {
            throw new IdentityNotFoundException(identityId);
        }

        var deletedByIdentity = (identityId == deletedByIdentityId) ? identity : await _identityProvider.FetchIdentity(deletedByIdentityId);

        if (deletedByIdentity is null)
        {
            throw new("The identity trying to delete this account does not exist");
        }

        await _identityPropertiesRepository.DeleteIdentityPropertiesByIdentityId(identityId);
        await _roleAssignmentRepository.DeleteRoleAssignmentByIdentityId(identityId);
        await _identityProvider.DeleteIdentity(identityId);
        await _eventPublisher.PublishDeletedEvent(identity);
        _ = WriteToAuditLog(identity, deletedByIdentity, ipAddress);
    }

    private async Task WriteToAuditLog(IIdentity identity, IIdentity deletedByIdentity, IPAddress? ipAddress)
    {
        var deletedByIdentityJson = SerializeDeletedByIdentity(deletedByIdentity);

        var metaData = PrepareMetadata(identity, ipAddress, deletedByIdentityJson);

        var identityDeletedEvent = new PaceEvent
        {
            Type = IdentityDeletedEvent.Type,
            Time = DateTimeOffset.Now,
            IdentityId = identity.Id,
            Metadata = metaData,
        };

        _logger.LogInformation("Writing identity deleted event to audit log");

        await _auditLogRepository.WriteRecord(identityDeletedEvent);
    }

    private static string SerializeDeletedByIdentity(IIdentity deletedByIdentity)
    {
        return JsonSerializer.Serialize(new
        {
            IdentityId = deletedByIdentity.Id,
            // ReSharper disable once RedundantAnonymousTypePropertyName
            Email = deletedByIdentity.Email,
        });
    }

    private static Dictionary<string, string> PrepareMetadata(IIdentity identity, IPAddress? ipAddress, string deletedByIdentityJson)
    {
        return new()
        {
            { "Email", identity.Email },
            { "UserCreationTime", identity.CreatedAt.ToString("o", CultureInfo.InvariantCulture) },
            { "IpAddress", ipAddress?.MapToIPv4().ToString() ?? string.Empty },
            { "DeletedBy", deletedByIdentityJson },
        };
    }
}
