using System.Net;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of deleting an identity
/// </summary>
public interface IDeleteIdentityInteractor
{
    /// <summary>
    /// Requests the identity provider to delete the identity
    /// </summary>
    /// <param name="identityId">The id of the identity to delete</param>
    /// <param name="deletedByIdentityId">The id of the identity which requested the deletion</param>
    /// <param name="ipAddress">The IP address that initiated the deletion</param>
    /// <returns>A task that completes when the identity provider has been contacted</returns>
    Task Execute(string identityId, string deletedByIdentityId, IPAddress? ipAddress);
}
