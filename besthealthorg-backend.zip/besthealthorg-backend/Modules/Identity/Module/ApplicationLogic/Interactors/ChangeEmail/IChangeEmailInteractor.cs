namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic for changing the email of an identity
/// </summary>
public interface IChangeEmailInteractor
{
    /// <summary>
    /// Attempts to change the email of the given identity id
    /// </summary>
    /// <param name="identityId">The id of the identity to change email for</param>
    /// <param name="newEmail">The new email to set</param>
    Task Execute(string identityId, string newEmail);
}
