using NwadHealth.Besthealthorg.Foundation.Events;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Events;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for changing the email of an identity
/// </summary>
public class ChangeEmailInteractor : IChangeEmailInteractor
{
    private readonly IIdentityProvider _identityProvider;
    private readonly IIdentityEventPublisher _eventPublisher;
    private readonly ILogger<ChangeEmailInteractor> _logger;
    private readonly IAuditLogRepository _auditLogRepository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="identityProvider">The identity provider to use</param>
    /// <param name="eventPublisher">The event publisher to use</param>
    /// <param name="auditLogRepository">The repository responsible for persisting audit logs</param>
    /// <param name="logger">The logger to use</param>
    public ChangeEmailInteractor(
        IIdentityProvider identityProvider,
        IIdentityEventPublisher eventPublisher,
        IAuditLogRepository auditLogRepository,
        ILogger<ChangeEmailInteractor> logger)
    {
        _identityProvider = identityProvider;
        _eventPublisher = eventPublisher;
        _auditLogRepository = auditLogRepository;
        _logger = logger;
    }

    /// <summary>
    /// Attempts to change the email of the given identity id
    /// </summary>
    /// <param name="identityId">The id of the identity to change email for</param>
    /// <param name="newEmail">The new email to set</param>
    /// <exception cref="IdentityNotFoundException">Thrown if the identity to create identity properties for was not found</exception>
    /// <exception cref="SameEmailException">Thrown when the newEmail matches current email</exception>
    public async Task Execute(string identityId, string newEmail)
    {
        _logger.LogInformation("Executing ChangeEmailInteractor...");
        var identity = await _identityProvider.FetchIdentity(identityId);

        if (identity is null)
        {
            throw new IdentityNotFoundException(identityId);
        }

        if (identity.Email == newEmail)
        {
            throw new SameEmailException(newEmail);
        }

        await _identityProvider.ChangeEmail(identityId, newEmail);
        await _eventPublisher.PublishEmailChangeEvent(identity, newEmail);
        await WriteToAuditLog(identity, newEmail);
    }

    private async Task WriteToAuditLog(IIdentity identity, string newEmail)
    {
        var emailChangedEvent = new PaceEvent
        {
            Type = EmailChangedEvent.Type,
            IdentityId = identity.Id,
            Time = DateTimeOffset.UtcNow,
            Metadata = PrepareMetadata(identity, newEmail),
        };

        _logger.LogInformation("Writing change email event to audit log");

        await _auditLogRepository.WriteRecord(emailChangedEvent);
    }

    private static Dictionary<string, string> PrepareMetadata(IIdentity identity, string newEmail)
    {
        return new()
        {
            { "Email", identity.Email },
            { "NewEmail", newEmail },
        };
    }
}
