using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Responses;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for getting the identity configuration
/// </summary>
public class GetConfigurationInteractor : IGetConfigurationInteractor
{
    private readonly Configuration _config;
    private readonly ILogger<GetConfigurationInteractor> _logger;
    private readonly ICountryRepository _countryRepository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="config">The configuration</param>
    /// <param name="logger">The logger to use</param>
    /// <param name="countryRepository">The country repository</param>
    public GetConfigurationInteractor(Configuration config, ILogger<GetConfigurationInteractor> logger, ICountryRepository countryRepository)
    {
        _config = config;
        _logger = logger;
        _countryRepository = countryRepository;
    }

    /// <summary>
    /// Gets the identity configuration
    /// </summary>
    /// <returns>The configuration response</returns>
    public async Task<GetConfigurationResponse> Execute()
    {
        _logger.LogInformation("Executing GetConfigurationInteractor...");

        var countries = await _countryRepository.GetAll();

        return new GetConfigurationResponse
        {
            IsEmailVerificationRequired = _config.IsEmailVerificationRequired,
            SupportedCountries = countries
        };
    }
}
