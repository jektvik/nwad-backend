using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Responses;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of retrieving the configuration
/// </summary>
public interface IGetConfigurationInteractor
{
    /// <summary>
    /// Gets the configuration
    /// </summary>
    /// <returns>The configuration</returns>
    Task<GetConfigurationResponse> Execute();
}
