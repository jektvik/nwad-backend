using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Requests;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for creating identity properties for an identity
/// </summary>
public class CreateIdentityPropertiesInteractor : ICreateIdentityPropertiesInteractor
{
    private readonly IIdentityProvider _identityProvider;
    private readonly IIdentityPropertiesRepository _identityPropertiesRepository;
    private readonly ICountryRepository _countryRepository;
    private readonly ILogger<CreateIdentityPropertiesInteractor> _logger;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="identityProvider">The identity provider to use</param>
    /// <param name="identityPropertiesRepository">The data store to use for storing identity properties</param>
    /// <param name="countryRepository">The data store to use for retrieving countries</param>
    /// <param name="logger">The logger to use</param>
    public CreateIdentityPropertiesInteractor(
        IIdentityProvider identityProvider,
        IIdentityPropertiesRepository identityPropertiesRepository,
        ICountryRepository countryRepository,
        ILogger<CreateIdentityPropertiesInteractor> logger)
    {
        _identityProvider = identityProvider;
        _identityPropertiesRepository = identityPropertiesRepository;
        _countryRepository = countryRepository;
        _logger = logger;
    }

    /// <summary>
    /// Attempts to create new identity properties for the given identity id
    /// </summary>
    /// <param name="request">The required data for the new identity properties</param>
    /// <returns>The newly created identity properties</returns>
    /// <exception cref="UnsupportedCountryException">Thrown if selected country is not supported</exception>
    /// <exception cref="IdentityNotFoundException">Thrown if the identity to create identity properties for was not found</exception>
    /// <exception cref="DuplicateIdentityPropertiesException">Thrown if the identity already has identity properties</exception>
    public async Task<IdentityProperties> Execute(CreateIdentityPropertiesRequest request)
    {
        _logger.LogInformation("Executing CreateIdentityPropertiesInteractor...");

        var country = (request.CountryCode is null) ? null : await _countryRepository.GetCountryByCountryCode(request.CountryCode);

        if (country is null && request.CountryCode is not null)
        {
            throw new UnsupportedCountryException(request.CountryCode);
        }

        var identity = await _identityProvider.FetchIdentity(request.IdentityId);

        if (identity is null)
        {
            throw new IdentityNotFoundException(request.IdentityId);
        }

        var existingIdentityProperties = await _identityPropertiesRepository.GetIdentityPropertiesByIdentityId(request.IdentityId);

        if (existingIdentityProperties is not null)
        {
            throw new DuplicateIdentityPropertiesException(request.IdentityId);
        }

        return await _identityPropertiesRepository.Create(new()
        {
            IdentityId = request.IdentityId,
            CountryCode = request.CountryCode
        });
    }
}
