using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Requests;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic for creating identity properties for an identity
/// </summary>
public interface ICreateIdentityPropertiesInteractor
{
    /// <summary>
    /// Attempts to create a new identityProperties for the given identity id
    /// </summary>
    /// <param name="request">The required data for the new identityProperties</param>
    /// <returns>The newly created identityProperties</returns>
    Task<IdentityProperties> Execute(CreateIdentityPropertiesRequest request);
}
