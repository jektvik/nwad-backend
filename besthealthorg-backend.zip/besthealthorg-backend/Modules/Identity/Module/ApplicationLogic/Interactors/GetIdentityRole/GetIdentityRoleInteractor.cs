﻿using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for getting role for an identity
/// </summary>
public class GetIdentityRoleInteractor : IGetIdentityRoleInteractor
{
    private readonly IRoleRepository _roleRepository;
    private readonly IRoleAssignmentRepository _roleAssignmentRepository;
    private readonly IRolesMemoryCache _rolesMemoryCache;
    private readonly ILogger<GetIdentityRoleInteractor> _logger;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="roleRepository">The data store to use for retrieving roles</param>
    /// <param name="roleAssignmentRepository">The data store to use for retrieving identitys role assignment</param>
    /// <param name="rolesMemoryCache">The cache to use for retrieving and caching of roles</param>
    /// <param name="logger">The logger to use</param>
    public GetIdentityRoleInteractor(
        IRoleRepository roleRepository,
        IRoleAssignmentRepository roleAssignmentRepository,
        IRolesMemoryCache rolesMemoryCache,
        ILogger<GetIdentityRoleInteractor> logger)
    {
        _roleRepository = roleRepository;
        _roleAssignmentRepository = roleAssignmentRepository;
        _rolesMemoryCache = rolesMemoryCache;
        _logger = logger;
    }

    /// <summary>
    /// Attempts to get the role for the given identity id
    /// </summary>
    /// <param name="identityId">The id of the identity to get the role for</param>
    /// <param name="lookInCache">Whether the role should be fetched from cache or not</param>
    /// <returns>The role belonging to the given identity</returns>
    /// <exception cref="NoRoleAssigndedException">Thrown when the identity does not have a role assigned</exception>
    /// <exception cref="NonExistentRoleException">Thrown when the identity has a role assigned but the role cannot be fetched by role id</exception>
    public async Task<Role> Execute(string identityId, bool lookInCache)
    {
        _logger.LogInformation("Executing GetIdentityRoleInteractor...");

        var role = lookInCache ? _rolesMemoryCache.GetRoleByIdenityId(identityId) : null;

        if (role is not null)
        {
            _rolesMemoryCache.CacheRoleForIdentity(identityId, role);
            return role;
        }

        var roleAssignment = await _roleAssignmentRepository.GetRoleAssignmentByIdentityId(identityId);
        if (roleAssignment is null)
        {
            _rolesMemoryCache.CacheRoleForIdentity(identityId, Role.Default);
            throw new NoRoleAssigndedException(identityId);
        }

        role = await _roleRepository.GetRoleById(roleAssignment.RoleId);
        if (role is null)
        {
            _rolesMemoryCache.CacheRoleForIdentity(identityId, Role.Default);
            throw new NonExistentRoleException(roleAssignment.RoleId);
        }

        _rolesMemoryCache.CacheRoleForIdentity(identityId, role);

        return role;
    }
}
