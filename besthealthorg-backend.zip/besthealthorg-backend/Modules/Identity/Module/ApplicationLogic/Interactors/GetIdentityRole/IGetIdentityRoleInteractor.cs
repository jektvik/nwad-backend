﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic for getting role for an identity
/// </summary>
public interface IGetIdentityRoleInteractor
{
    /// <summary>
    /// Attempts to get the role for the given identity id
    /// </summary>
    /// <param name="identityId">The id of the identity to get the role for</param>
    /// <param name="lookInCache">Whether the role should be fetched from cache or not</param>
    /// <returns>The role belonging to the given identity</returns>
    Task<Role> Execute(string identityId, bool lookInCache);
}
