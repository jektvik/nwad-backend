using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic for getting identity properties for an identity
/// </summary>
public interface IGetIdentityPropertiesInteractor
{
    /// <summary>
    /// Attempts to get the identity properties for the given identity id
    /// </summary>
    /// <param name="identityId">The id of the identity to get the identity properties for</param>
    /// <returns>The identity properties belonging to the given identity or null if none were found</returns>
    Task<IdentityProperties?> Execute(string identityId);
}
