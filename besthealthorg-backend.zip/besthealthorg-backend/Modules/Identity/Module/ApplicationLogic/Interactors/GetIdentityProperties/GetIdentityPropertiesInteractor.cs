using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for getting identity properties for an identity
/// </summary>
public class GetIdentityPropertiesInteractor : IGetIdentityPropertiesInteractor
{
    private readonly IIdentityPropertiesRepository _identityPropertiesRepository;
    private readonly ILogger<GetIdentityPropertiesInteractor> _logger;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="identityPropertiesRepository">The data store to use for retrieving identity properties</param>
    /// <param name="logger">The logger to use</param>
    public GetIdentityPropertiesInteractor(IIdentityPropertiesRepository identityPropertiesRepository, ILogger<GetIdentityPropertiesInteractor> logger)
    {
        _identityPropertiesRepository = identityPropertiesRepository;
        _logger = logger;
    }

    /// <summary>
    /// Attempts to get the identity properties for the given identity id
    /// </summary>
    /// <param name="identityId">The id of the identity to get the identity properties for</param>
    /// <returns>The identity properties belonging to the given identity or null if none were found</returns>
    public async Task<IdentityProperties?> Execute(string identityId)
    {
        _logger.LogInformation("Executing GetIdentityPropertiesInteractor...");

        return await _identityPropertiesRepository.GetIdentityPropertiesByIdentityId(identityId);
    }
}
