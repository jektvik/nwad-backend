using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for fetching email verification status from the identity provider
/// </summary>
public class GetEmailVerificationStatusInteractor : IGetEmailVerificationStatusInteractor
{
    private readonly IIdentityProvider _identityProvider;
    private readonly ILogger<GetEmailVerificationStatusInteractor> _logger;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="identityProvider">The identity provider to use</param>
    /// <param name="logger">The logger to use</param>
    public GetEmailVerificationStatusInteractor(IIdentityProvider identityProvider, ILogger<GetEmailVerificationStatusInteractor> logger)
    {
        _identityProvider = identityProvider;
        _logger = logger;
    }

    /// <summary>
    /// Fetches the email verification status from the identity provider
    /// </summary>
    /// <param name="identityId">The id of the identity, for which to fetch verification status</param>
    /// <returns>The email verification status</returns>
    /// <exception cref="IdentityNotFoundException">The identity does not exist</exception>
    public async Task<bool> Execute(string identityId)
    {
        _logger.LogInformation("Executing GetEmailVerificationStatusInteractor...");

        var identity = await _identityProvider.FetchIdentity(identityId);

        if (identity is null)
        {
            _logger.LogError("The identity does not exist");
            throw new IdentityNotFoundException(identityId);
        }

        return identity.EmailVerified;
    }
}
