namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of resending email verification
/// </summary>
public interface IGetEmailVerificationStatusInteractor
{
    /// <summary>
    /// Requests the identity provider to resend verification email
    /// </summary>
    /// <param name="identityId">The id of the identity, for which to resend verification email</param>
    /// <returns>The email verification status</returns>
    Task<bool> Execute(string identityId);
}
