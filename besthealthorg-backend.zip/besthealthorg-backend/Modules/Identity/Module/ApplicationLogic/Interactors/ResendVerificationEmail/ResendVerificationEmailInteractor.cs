using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for resending verification email via the identity provider
/// </summary>
public class ResendVerificationEmailInteractor : IResendVerificationEmailInteractor
{
    private readonly IIdentityProvider _identityProvider;
    private readonly ILogger<ResendVerificationEmailInteractor> _logger;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="identityProvider">The identity provider to use</param>
    /// <param name="logger">The logger to use</param>
    public ResendVerificationEmailInteractor(IIdentityProvider identityProvider, ILogger<ResendVerificationEmailInteractor> logger)
    {
        _identityProvider = identityProvider;
        _logger = logger;
    }

    /// <summary>
    /// Requests the identity provider to resend verification email
    /// </summary>
    /// <param name="identityId">The id of the identity, for which to resend verification email</param>
    /// <returns>A task that completes when the identity provider has been contacted</returns>
    public async Task Execute(string identityId)
    {
        _logger.LogInformation("Executing ResendVerificationEmailInteractor...");

        await _identityProvider.ResendVerificationEmail(identityId);
    }
}
