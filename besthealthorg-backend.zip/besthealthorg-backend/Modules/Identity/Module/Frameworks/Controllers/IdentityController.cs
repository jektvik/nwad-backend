using NwadHealth.Besthealthorg.Foundation.Extensions.Controller;
using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;

namespace NwadHealth.Besthealthorg.IdentityModule.Frameworks.Controllers;

/// <summary>
/// Contains endpoints relating to the Identity domain
/// </summary>
[ApiController]
[Route("[controller]")]
public class IdentityController : ControllerBase
{
    private readonly ILogger<IdentityController> _logger;

    /// <summary>
    /// Initializes the IdentityController
    /// </summary>
    /// <param name="logger">The logger to use</param>
    public IdentityController(ILogger<IdentityController> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Gets the identity configuration
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <response code="200">The configuration was retrieved successfully</response>
    /// <response code="500">Unexpected error</response>
    [HttpGet("configuration", Name = "GetConfiguration")]
    [Produces("application/json")]
    [ProducesResponseType(typeof(ConfigurationResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetConfiguration([FromServices] IGetConfigurationInteractor interactor)
    {
        _logger.LogInformation("Processing request to GetConfiguration");

        try
        {
            var interactorData = await interactor.Execute();
            var response = new ConfigurationResponseDto
            {
                IsEmailVerificationRequired = interactorData.IsEmailVerificationRequired,
                SupportedCountries = interactorData.SupportedCountries.Select(c => c.Id)
            };

            return Ok(response);
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during GetConfiguration request processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Gets the identities email verification status
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <response code="200">The verification status was fetched successfully</response>
    /// <response code="401">Identity is not authorized</response>
    /// <response code="500">Unexpected error</response>
    [HttpGet("email-verification-status", Name = "EmailVerificationStatus")]
    [Authorize]
    [Produces("application/json")]
    [ProducesResponseType(typeof(EmailVerificationStatusResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> EmailVerificationStatus([FromServices] IGetEmailVerificationStatusInteractor interactor)
    {
        _logger.LogInformation("Processing request to EmailVerificationStatus");

        try
        {
            var status = await interactor.Execute(HttpContext.CurrentIdentityId());

            return Ok(new EmailVerificationStatusResponseDto
            {
                Verified = status
            });
        }
        catch (IdentityNotFoundException)
        {
            return Unauthorized();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during EmailVerificationStatus request processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Resends the email verification email to the identity
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <response code="202">The identity provider received the request for resending verification</response>
    /// <response code="401">Identity is not authorized</response>
    /// <response code="500">Unexpected error</response>
    [HttpPost("resend-verification-email", Name = "ResendVerificationEmail")]
    [Authorize]
    [Produces("application/json")]
    [ProducesResponseType(StatusCodes.Status202Accepted)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> ResendVerificationEmail([FromServices] IResendVerificationEmailInteractor interactor)
    {
        _logger.LogInformation("Processing request to ResendVerificationEmail");

        try
        {
            await interactor.Execute(HttpContext.CurrentIdentityId());

            return Accepted();
        }
        catch (IdentityNotFoundException)
        {
            return Unauthorized();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during ResendVerificationEmail request processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Deletes the identity
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <response code="204">The delete request was accepted by the identity provider</response>
    /// <response code="401">Identity is not authorized</response>
    /// <response code="403">Identity is not allowed to delete the identity with the given ID</response>
    /// <response code="404">Identity with the given id was not found</response>
    /// <response code="500">Unexpected error</response>
    [HttpDelete(Name = "DeleteIdentity")]
    [Authorize]
    [Produces("application/json")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> DeleteIdentity([FromServices] IDeleteIdentityInteractor interactor)
    {
        _logger.LogInformation("Processing request to DeleteIdentity");

        return await HandleDeleteIdentityRequest(interactor, HttpContext.CurrentIdentityId(), nameof(DeleteIdentity));
    }

    /// <summary>
    /// Changes the email of the authorized identity
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="dto">The data required to change email</param>
    /// <response code="200">The email was successfully updated</response>
    /// <response code="400">The email format is invalid</response>
    /// <response code="401">Identity is not authorized</response>
    /// <response code="500">Unexpected error</response>
    [HttpPatch("change-email", Name = "ChangeEmail")]
    [Authorize]
    [Produces("application/json")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> ChangeEmail([FromServices] IChangeEmailInteractor interactor, ChangeEmailRequestDto dto)
    {
        _logger.LogInformation("Processing request to ChangeEmail");

        try
        {
            await interactor.Execute(HttpContext.CurrentIdentityId(), dto.NewEmail);

            return Ok();
        }
        catch (IdentityNotFoundException e)
        {
            _logger.LogError(e, "Could not find the identity to change email for");

            return Unauthorized();
        }
        catch (SameEmailException e)
        {
            _logger.LogError(e, "The new email matches the original one");

            return this.SameEmailError();
        }
        catch (ArgumentException e) when (e.ParamName == "newEmail")
        {
            _logger.LogError(e, "New email has invalid format");

            return this.InvalidEmailError();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during ChangeEmail request processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Fetches the role for the identity
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <response code="200">The role was successfully fetched</response>
    /// <response code="401">Identity is not authorized</response>
    /// <response code="404">The identity has no role assigned</response>
    /// <response code="500">Unexpected error</response>
    [HttpGet("get-role", Name = "GetRole")]
    [Authorize]
    [Produces("application/json")]
    [ProducesResponseType(typeof(IEnumerable<RoleResponseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetRole([FromServices] IGetIdentityRoleInteractor interactor)
    {
        _logger.LogInformation("Processing request to GetRole");

        try
        {
            var role = await interactor.Execute(HttpContext.CurrentIdentityId(), false);

            var response = new List<RoleResponseDto>
            {
                RoleResponseDto.FromDomain(role),
            };

            return Ok(response);
        }
        catch (NoRoleAssigndedException e)
        {
            _logger.LogError(e, "No role was assigned for this identity");

            return this.NoRoleAssignedError();
        }
        catch (NonExistentRoleException e)
        {
            _logger.LogError(e, "The assigned role does not exist");
            return this.NonExistentRoleError();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during GetRole request processing");

            return this.UnexpectedError();
        }
    }

    private async Task<IActionResult> HandleDeleteIdentityRequest(IDeleteIdentityInteractor interactor, string identityId, string callerName)
    {
        try
        {
            await interactor.Execute(identityId, identityId, HttpContext.Connection.RemoteIpAddress);

            return NoContent();
        }
        catch (IdentityNotFoundException e)
        {
            _logger.LogError(e, "Could not find the identity to delete");

            return this.IdentityNotFoundError();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during {callerName} request processing", callerName);

            return this.UnexpectedError();
        }
    }
}
