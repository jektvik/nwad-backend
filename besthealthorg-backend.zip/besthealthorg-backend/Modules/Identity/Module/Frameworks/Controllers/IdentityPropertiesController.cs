using NwadHealth.Besthealthorg.Foundation.Extensions.Controller;
using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;

namespace NwadHealth.Besthealthorg.IdentityModule.Frameworks.Controllers;

/// <summary>
/// Contains endpoints relating to the identity properties domain
/// </summary>
[ApiController]
[Route("[controller]")]
public class IdentityPropertiesController : ControllerBase
{
    private readonly ILogger<IdentityPropertiesController> _logger;

    /// <summary>
    /// Initializes the IdentityPropertiesController
    /// </summary>
    /// <param name="logger">The logger to use</param>
    public IdentityPropertiesController(ILogger<IdentityPropertiesController> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Gets the identity properties and role
    /// </summary>
    /// <param name="identityInteractor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="roleInteractor">The business logic to execute during the request. This is provided by DI</param>
    /// <response code="200">The identity properties were retrieved successfully</response>
    /// <response code="401">Client is not authorized</response>
    /// <response code="403">Client is authorized, but not allowed to view this resource</response>
    /// <response code="404">The identity properties do not exist</response>
    /// <response code="500">Unexpected error</response>
    [HttpGet(Name = "GetIdentityPropertiesWithRole")]
    [Authorize]
    [Produces("application/json")]
    [ProducesResponseType(typeof(IdentityPropertiesWithRoleResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetIdentityPropertiesWithRole(
        [FromServices] IGetIdentityPropertiesInteractor identityInteractor,
        [FromServices] IGetIdentityRoleInteractor roleInteractor)
    {
        _logger.LogInformation("Processing request to GetIdentityPropertiesWithRole");

        try
        {
            var identityId = HttpContext.CurrentIdentityId();
            var identityProperties = await identityInteractor.Execute(identityId);

            if (identityProperties is null)
            {
                return this.IdentityPropertiesNotFoundError();
            }

            var role = await roleInteractor.Execute(identityId, true);

            return Ok(
                new IdentityPropertiesWithRoleResponseDto(
                    identityProperties.IdentityId,
                    identityProperties.CountryCode,
                    [RoleResponseDto.FromDomain(role)])
                );
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during GetIdentityPropertiesWithRole request processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Creates identity properties
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="dto">The data to use for the new identity properties</param>
    /// <response code="200">The identity properties were retrieved successfully</response>
    /// <response code="400">The identity properties data is invalid</response>
    /// <response code="401">Client is not authorized</response>
    /// <response code="409">The identity already has identity properties</response>
    /// <response code="500">Unexpected error</response>
    [HttpPost(Name = "CreateIdentityProperties")]
    [HttpPost("/profiles", Name = "CreateIdentityPropertiesOld")]
    [Authorize]
    [Produces("application/json")]
    [ProducesResponseType(typeof(IdentityPropertiesResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status409Conflict)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> CreateIdentityProperties([FromServices] ICreateIdentityPropertiesInteractor interactor, IdentityPropertiesRequestDto dto)
    {
        _logger.LogInformation("Processing request to CreateIdentityProperties");

        try
        {
            var identityProperties = await interactor.Execute(new()
            {
                IdentityId = HttpContext.CurrentIdentityId(),
                CountryCode = dto.Country
            });

            return Created(string.Empty, new IdentityPropertiesResponseDto(identityProperties.IdentityId, identityProperties.CountryCode));
        }
        catch (UnsupportedCountryException e)
        {
            _logger.LogError(e, "The selected country is not supported");

            return this.UnsupportedCountryError();
        }
        catch (IdentityNotFoundException e)
        {
            _logger.LogError(e, "Could not find the identity to create identity properties for");

            return Unauthorized();
        }
        catch (DuplicateIdentityPropertiesException e)
        {
            _logger.LogError(e, "Identity is already associated with identity properties");

            return this.DuplicateIdentityPropertiesError();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during CreateIdentityProperties request processing");

            return this.UnexpectedError();
        }
    }
}
