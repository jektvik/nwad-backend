using Microsoft.AspNetCore.Mvc;
using static NwadHealth.Besthealthorg.Foundation.Extensions.Controller.ErrorResponseExtensions;

namespace NwadHealth.Besthealthorg.IdentityModule.Frameworks;

/// <summary>
/// ControllerBase extensions for creating error responses
/// </summary>
public static class ErrorResponseExtensions
{
    /// <summary>
    /// Creates an identity not found result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>An identity not found result</returns>
    public static IActionResult IdentityNotFoundError(this ControllerBase controller) =>
        controller.NotFound(CreateErrorResponseDto("identity_not_found", "The identity was not found"));

    /// <summary>
    /// Creates an invalid email error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>An invalid email result</returns>
    public static IActionResult InvalidEmailError(this ControllerBase controller) =>
        controller.BadRequest(CreateErrorResponseDto("invalid_email", "The email has an invalid format"));

    /// <summary>
    /// Creates an same email error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>A same email result</returns>
    public static IActionResult SameEmailError(this ControllerBase controller) =>
        controller.BadRequest(CreateErrorResponseDto("invalid_email", "This user already has this email"));

    /// <summary>
    /// Creates an identity properties not found error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>A identity properties not found result</returns>
    public static IActionResult IdentityPropertiesNotFoundError(this ControllerBase controller) =>
        controller.NotFound(CreateErrorResponseDto("no_identity_properties", "No identity properties exists for this identity"));

    /// <summary>
    /// Creates a profile not found error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>A profile not found result</returns>
    public static IActionResult ProfileNotFoundError(this ControllerBase controller) =>
        controller.NotFound(CreateErrorResponseDto("no_profile", "No profile exists for this identity"));

    /// <summary>
    /// Creates an unsupported country error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>An unsupported country result</returns>
    public static IActionResult UnsupportedCountryError(this ControllerBase controller) =>
        controller.BadRequest(CreateErrorResponseDto("unsupported_country", "This country is not on the list of supported countries"));

    /// <summary>
    /// Creates a duplicate identity properties error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>A duplicate identity properties result</returns>
    public static IActionResult DuplicateIdentityPropertiesError(this ControllerBase controller) =>
        controller.Conflict(CreateErrorResponseDto("duplicate_identity_properties", "This identity already has identity properties"));

    /// <summary>
    /// Creates a no role assigned error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>A no role assigned result</returns>
    public static IActionResult NoRoleAssignedError(this ControllerBase controller) =>
        controller.NotFound(CreateErrorResponseDto("no_role_assigned", "No role was assigned for this identity"));

    /// <summary>
    /// Creates a non existent role error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>A non existent role result</returns>
    public static IActionResult NonExistentRoleError(this ControllerBase controller) =>
        controller.StatusCode(500,CreateErrorResponseDto("non_existent_role", "The assigned role does not exist"));
}
