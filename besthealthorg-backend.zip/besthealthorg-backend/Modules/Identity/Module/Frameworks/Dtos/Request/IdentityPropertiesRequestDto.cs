namespace NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Request;

/// <summary>
/// Request DTO for identity properties
/// </summary>
/// <param name="Country">The country of the identity</param>
public record IdentityPropertiesRequestDto(
    string? Country
);
