namespace NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Request;

/// <summary>
/// Request DTO for changing email
/// </summary>
/// <param name="NewEmail">The new email to set for the identity</param>
public record ChangeEmailRequestDto(
    string NewEmail
);
