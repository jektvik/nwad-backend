namespace NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;

/// <summary>
/// Response DTO for get configuration
/// </summary>
public class ConfigurationResponseDto
{
    /// <summary>
    /// Whether email verification is required
    /// </summary>
    public bool IsEmailVerificationRequired { get; set; }

    /// <summary>
    /// List of supported country code in ISO 3166-1 alpha-2 format
    /// </summary>
    public IEnumerable<string> SupportedCountries { get; set; } = new List<string>();
}
