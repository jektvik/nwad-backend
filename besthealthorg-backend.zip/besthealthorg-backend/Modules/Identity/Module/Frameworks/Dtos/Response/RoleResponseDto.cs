﻿using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;

/// <summary>
/// Response DTO for Get-Role endpoint
/// </summary>
public class RoleResponseDto
{
    /// <summary>
    /// Unique identifier
    /// </summary>
    public string Id { get; init; } = string.Empty;

    /// <summary>
    /// Name of the role
    /// </summary>
    public string Name { get; init; } = string.Empty;

    /// <summary>
    /// Converts Role domain model to role response DTO
    /// </summary>
    /// <param name="role">the role domain model to convert</param>
    public static RoleResponseDto FromDomain(Role role)
    {
        return new() { Id = role.Id, Name = role.Name, };
    }
}
