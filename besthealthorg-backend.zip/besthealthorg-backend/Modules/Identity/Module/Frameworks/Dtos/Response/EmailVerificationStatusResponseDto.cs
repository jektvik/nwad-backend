namespace NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;

/// <summary>
/// Response DTO for email verification status
/// </summary>
public class EmailVerificationStatusResponseDto
{
    /// <summary>
    /// Whether the email has been verified
    /// </summary>
    public bool Verified { get; set; }
}
