namespace NwadHealth.Besthealthorg.IdentityModule.Frameworks.Dtos.Response;

/// <summary>
/// Response DTO for identity properties
/// </summary>
/// <param name="IdentityId">The identity id that the identity properties belong to</param>
/// <param name="Country">The country of the identity</param>
/// <param name="Role">The role of the identity</param>
public record IdentityPropertiesWithRoleResponseDto(
    string IdentityId,
    string? Country,
    IEnumerable<RoleResponseDto> Role
);
