::: mermaid
 classDiagram
 class Policy {
    int: id (PK)
    string: name
    int: regionId
 }

 class Version {
    int: policyId (PK)
    int: version (PK)
    Status: status
    DateTime: activeFrom
    DateTime: activeTo
 }

 class Translation {
    int: policyId (PK)
    int: version (PK)
    string: title
    string: text
    iso2CountryCode: country
 }

 class Region {
    int: id (PK)
    string: name
 }

class Country {
    int: regionId 
    iso2CountryCode: country (PK)
 }

Policy <|-- Version
Version <|-- Translation
Region <|-- Country
Region <|-- Policy
:::