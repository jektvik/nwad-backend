# Api design

​
## List pending policies
​
List the pending policies that the user has not yet accepted or rejected
​
| **Parameter** | **Value** | **Comment** | 
| - | - | - |
| URL | `GET /policies?identityId={id}&status={status}`  |  |
| Header | Accept-Language | da ([iso2 country code 639-1](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes)) |
| Header | Accept-Encoding | gzip/deflate (default) |
| Response Header | etag | how best to do caching | 
| Authorized | Yes | |
| Query string | userId, status | |
| userId | **me** or **id** | me will be considered as the id of the user in the provided token |
| status | accepted, rejected, pending | parameter is optional |
| Body | None |  | 
| Response | 200 | List of policies to consider |
| Response | 401 | Unauthorized |

### Response content

```
[ 
    {
        "id": "int"
        "version": "int"
        "title": "string"
        "summary": "string"
        "fullTextLink": "string (link)"
        "status": "string"
        "language": "string" [iso2 country code 639-1](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes)
    }   
]
```

####

* response content should be returned as a pagination object 
    * page - which page are we on
    * pageSize - size of the page
    * links - links that help navigate the pagination
    * data
        * version - id of the consent version, the id specific record that the user will be accepting or rejecting
        * summary 
        * contentContinuation - link to more content in the case where 
        * language - language of the consentPolicy
        * links - this section only really makes sense if we accept policies one by one, because we could put the link for accepting or rejecting the specific policy in the link section


## Submit consent

Submitting consent, this endpoint will be the same regardless of the user accepting or rejecting the policy.
If a user submits the same status for a policy as has already been recorded on the server, we should return 200 (not conflict), there is no reason to initiate an error flow when the expected state matches the one we have - we can just skip storing it.

### Suggestion 1 - NOT THIS ONE

| **Parameter** | **Value** | **Comment** | 
| - | - | - |
| URL | `POST /consents/{policyId}/versions/{version}`  |  |
| Authorized | Yes | |
| Body | language(Iso2 country), consentStatus, clientVersion, clientId, clientPlatform |  | 
| Response | 200 |  Should return 200 even if the current consent status matches the one submitted  |
| Response | 401 | Unauthorized |

### Suggestion 2 - Maybe this one for the Consent overview page (toggling consent on and off) we would prefer if the server didn't always have to handle a form where most of the consents have not changed

| **Parameter** | **Value** | **Comment** | 
| - | - | - |
| URL | `PUT /consents/{policyId}`  |  |
| Authorized | Yes | |
| Body | see 3.1 |  | 
| Response | 200 | Should return 200 even if the current consent status matches the one submitted |
| Response | 401 | Unauthorized |

### Suggestion 3 - NOT THIS ONE

| **Parameter** | **Value** | **Comment** | 
| - | - | - |
| URL | `POST /consents` |  |
| Authorized | Yes | |
| Body | policyId, version, language(Iso2 country), consentStatus, clientVersion, clientId, clientPlatform |  | 
| Response | 200 |  Should return 200 even if the current consent status matches the one submitted |
| Response | 401 | Unauthorized |

### Suggestion 3.1

| **Parameter** | **Value** | **Comment** | 
| - | - | - |
| URL | `POST /consents` |  |
| Authorized | Yes | |
| Body | [{policyId, version, language(Iso2 country), consentStatus, clientVersion , clientId, clientPlatform}] |  | 
| Response | 200 |  Should return 200 even if the current consent status matches the one submitted |
| Response | 400 | If there is an error in the form content |
| Response | 401 | Unauthorized |
| Response | 500 | If any dependent service is unavailable |

```
[
    {
        policyId:
        version:
        language:
        consented: true/false
        (header) applicationVersion: 1.0.1.100 ([string] App Version)
        (header) applicationId: com.<company>.<appname> [string]
        (header) applicationPlatform: iOS/Android/web? (lower case)
    },
    ...
]
```
