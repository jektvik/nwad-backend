using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Infrastructure;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.TestUtilities.IntegrationTestHelpers;
using Microsoft.EntityFrameworkCore;
using Moq;

namespace NwadHealth.Besthealthorg.ConsentModule.IntegrationTest;

public class ConsentWebApplicationFactory : PaceWebApplicationFactory
{
    public static ConsentConfiguration ConsentConfiguration { get; } = new();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        base.ConfigureWebHost(builder);
        base.ConfigureTestAuth(builder);

        builder.ConfigureServices(services =>
        {
            services
                .AddControllers()
                .AddApplicationPart(typeof(Frameworks.Controllers.PolicyController).Assembly);

            services.AddDbContext<ConsentTestDbContext>(o =>
            {
                o.UseSqlServer(SqlDbConnectionString);
                o.EnableSensitiveDataLogging();
            });

            services.AddPaceConsent<ConsentTestDbContext>(ConsentConfiguration);
            services.AddSingleton(Mock.Of<IAuditLogRepository>());
        });

        builder.Configure(app =>
        {
            var scope = app.ApplicationServices.CreateScope();

            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseEndpoints(conf => conf.MapControllers());

            var services = scope.ServiceProvider;
            var context = services.GetRequiredService<ConsentTestDbContext>();
            context.Database.EnsureCreated();

            if (!context.Policies.Any())
            {
                context.SeedPolicies();
            }
        });
    }
}
