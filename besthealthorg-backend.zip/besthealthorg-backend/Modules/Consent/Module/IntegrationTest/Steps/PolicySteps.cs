﻿using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Response;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsentModule.IntegrationTest;

[Binding]
public class PolicySteps(ScenarioContext context, ConsentWebApplicationFactory factory)
{
    private const int InvalidPolicyId = -1;
    private const string Language = "en";

    [When("I request all policies")]
    public async Task WhenIRequestAllPolicies()
    {
        var client = context.Get<HttpClient>();
        var response = await client.GetAsync($"/policies?identityId={context.Get<string>("userId")}");

        context.Set(response);
    }

    [When("I request my {string} policies")]
    public async Task WhenIRequestListOfPoliciesWithStatus(string status)
    {
        var client = context.Get<HttpClient>();

        context.Set(await client.GetAsync($"/policies?identityId={context.Get<string>("userId")}&status={status}"));
    }

    [When("I request all policies with invalid identity id")]
    public async Task WhenRequestAllPoliciesWithInvalidIdentityId()
    {
        var client = context.Get<HttpClient>();
        context.Set(await client.GetAsync("/policies"));
    }

    [When("I request all policies with mismatching identity id")]
    public async Task WhenRequestAllPoliciesWithMismatchingIdentityId()
    {
        const string invalidIdentityId = "-1";
        var client = context.Get<HttpClient>();
        context.Set(await client.GetAsync($"/policies?identityId={invalidIdentityId}"));
    }

    [When("I request all policies with invalid status")]
    public async Task WhenIRequestAllPoliciesWithInvalidStatus()
    {
        var client = context.Get<HttpClient>();
        context.Set(await client.GetAsync($"/policies?identityId={context.Get<string>("userId")}&status=invalidstatus"));
    }

    [When("I request a full text of a policy")]
    public async Task WhenIRequestAFullTextOfAPolicy()
    {
        var client = context.Get<HttpClient>();
        client.DefaultRequestHeaders.Add("Accept-Language", Language);
        context.Set(await client.GetAsync("/policies/1/1/fulltext"));
    }

    [When("I request a full text of a policy with invalid policy id")]
    public async Task WhenIRequestAFullTextOfAPolicyWithInvalidPolicyId()
    {
        var client = context.Get<HttpClient>();
        client.DefaultRequestHeaders.Add("Accept-Language", Language);
        context.Set(await client.GetAsync($"/policies/{InvalidPolicyId}/1/fulltext"));
    }

    [When("I request a full text of a policy with invalid version id")]
    public async Task WhenIRequestAFullTextOfAPolicyWithInvalidVersionId()
    {
        var client = context.Get<HttpClient>();
        client.DefaultRequestHeaders.Add("Accept-Language", Language);
        context.Set(await client.GetAsync($"/policies/{InvalidPolicyId}/1/fulltext"));
    }

    [Then("I get a full text of a policy")]
    public async Task IGetAFullTextOfAPolicy()
    {
        var data = await context.Get<HttpResponseMessage>().Content.ReadFromJsonAsync<PolicyFullTextResponseDto>();

        Assert.Equal(
            "This information may be used to improve products or services, make informed business decisions, or develop new technologies.",
            data!.FullText);
    }

    [Then("I get all policies")]
    public async Task IGetAllPolicies()
    {
        var policies = await context.Get<HttpResponseMessage>().Content.ReadFromJsonAsync<List<Policy>>();
        using var scope = factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ConsentTestDbContext>();
        var policiesFromDbCount = dbContext.Policies.Count();
        Assert.NotNull(policies);
        Assert.Equal(policiesFromDbCount, policies.Count);
    }
}
