﻿using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Events.V1;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.ConsentModule.Infrastructure;
using NwadHealth.Besthealthorg.ConsentModule.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsentModule.IntegrationTest;

[Binding]
public class ConsentSteps
{
    private readonly ScenarioContext _context;
    private readonly ConsentWebApplicationFactory _factory;
    private const int PolicyId = 1;
    private const int InvalidPolicyId = -1;
    private const int PolicyVersion = 1;
    private const int InvalidPolicyVersion = 99;
    private const string Language = "en";
    private const bool Consented = true;

    private const int PoliciesToConsentCount = 2;

    private readonly ConsentRepository _repo;

    public ConsentSteps(ScenarioContext context, ConsentWebApplicationFactory factory)
    {
        _context = context;
        _factory = factory;
        var scope = factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<IConsentDbContext>();

        _repo = new ConsentRepository(dbContext, ConsentWebApplicationFactory.ConsentConfiguration);
    }

    [Given("Consents with status 'pending' exist")]
    public async Task ConsentsWithStatusPendingExist()
    {
        using var scope = _factory.Services.CreateScope();
        var policyRepo = scope.ServiceProvider.GetRequiredService<IGetPoliciesInteractor>();
        var result = await policyRepo.Execute("authorized", ConsentStatus.Pending, "da");
        Assert.NotEmpty(result);
    }

    [Given("I have consents with status {string} for {string}")]
    public async Task GivenGivenIHaveConsentsWithStatusForLanguage(string status, string languageCode)
    {
        var consentStatusEnum = ConsentStatusFromString(status);
        using var scope = _factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ConsentTestDbContext>();
        var random = new Random();

        var valueTuples = dbContext.Policies
            .Include(p => p.Versions)
            .ThenInclude(v => v.Translations)
            .ToList()
            .Select(p => new
            {
                PolicyId = p.Id,
                LatestVersion = p.Versions.Max(v => v.Version),
            })
            .OrderBy(_ => random.Next())
            .Take(PoliciesToConsentCount)
            .Select(p => new AddConsentRequestDto(
                p.PolicyId,
                p.LatestVersion,
                languageCode,
                consentStatusEnum == ConsentStatus.Accepted
            ));

        var client = GetHttpClientWithHeaders();
        var result = await client.PostAsync("consents", JsonContent.Create(valueTuples));

        Assert.True(result.IsSuccessStatusCode);
        _context.Set(result);
    }

    [When("I consent to single policy")]
    public async Task WhenIConsentToSinglePolicy()
    {
        List<AddConsentRequestDto> requestDto = [
            new(PolicyId, PolicyVersion, Language, Consented),
        ];

        var client = GetHttpClientWithHeaders();
        var response = await client.PostAsync("/consents", JsonContent.Create(requestDto));

        Assert.True(response.IsSuccessStatusCode);
        _context.Set(response);
    }

    [When("I consent to multiple policies")]
    public async Task WhenIConsentToMultiplePolicies()
    {
        List<AddConsentRequestDto> requestDto =
        [
            new(1, 1, "en", true),
            new(2, 1, "en", false),
        ];

        var client = GetHttpClientWithHeaders();
        var response = await client.PostAsync("/consents", JsonContent.Create(requestDto));
        _context.Set(response);
    }

    [When("I have previously submitted my {string} consent to a policy")]
    public async Task WhenIHavePreviouslySubmittedMyConsentToAPolicy(string consent)
    {
        List<AddConsentRequestDto> requestDto =
        [
            new(1, 1, "en", bool.Parse(consent)),
        ];

        var client = GetHttpClientWithHeaders();
        var response = await client.PostAsync("/consents", JsonContent.Create(requestDto));

        Assert.True(response.IsSuccessStatusCode);
        _context.Set(response);
    }

    [When("I re-submit my {string} consent to the same policy")]
    public async Task WhenIReSubmitMyConsentToTheSamePolicy(string newConsent)
    {
        await WhenIHavePreviouslySubmittedMyConsentToAPolicy(newConsent);
    }

    [Then("My latest consent is in status {string}")]
    public async Task ThenMyConsentsAreCreated(string newStatus)
    {
        var latestConsent = await _repo.GetAllLatest(_context.Get<string>("userId"));

        var consent = Assert.Single(latestConsent);
        Assert.Equal(bool.Parse(newStatus), consent.Consented);
    }

    [When("I consent to multiple policies with single invalid id")]
    public async Task WhenIConsentToMultiplePoliciesWithSingleInvalidId()
    {
        List<AddConsentRequestDto> requestDto =
        [
            new(InvalidPolicyId, 1, "en", true),
            new(2, 1, "en", false),
        ];

        var client = GetHttpClientWithHeaders();
        _context.Set(await client.PostAsync("/consents", JsonContent.Create(requestDto)));
    }

    [When("I consent to multiple policies with single invalid version id")]
    public async Task WhenIConsentToMultiplePoliciesWithSingleInvalidVersionId()
    {
        List<AddConsentRequestDto> requestDto =
        [
            new(1, InvalidPolicyVersion, "en", true),
            new(2, 1, "en", false),
        ];

        var client = GetHttpClientWithHeaders();

        _context.Set(await client.PostAsync("/consents", JsonContent.Create(requestDto)));
    }

    [When("I consent to multiple policies with single invalid language")]
    public async Task WhenIConsentToMultiplePoliciesWithSingleInvalidLanguage()
    {
        List<AddConsentRequestDto> requestDto =
        [
            new(3, 1, "de", true),
            new(2, 1, "en", false),
        ];

        var client = GetHttpClientWithHeaders();

        _context.Set(await client.PostAsync("/consents", JsonContent.Create(requestDto)));
    }

    [When("I consent to multiple policies with invalid {string}")]
    public async Task WhenIConsentToMultiplePoliciesWithSingleInvalidApplicationVersion(string inputType)
    {
        List<AddConsentRequestDto> requestDto =
        [
            new(1, 1, "en", true),
            new(2, 1, "en", false),
        ];

        HttpClient? client = null;
        switch (inputType)
        {
            case "policyID":
                requestDto.Add(new(-1, 1, "en", true));
                break;
            case "versionID":
                requestDto.Add(new(1, -1, "en", true));
                break;
            case "language":
                requestDto.Add(new(1, 1, "xx", true));
                break;
            case "applicationID":
                client = GetHttpClientWithHeaders(withApplicationId: false);
                break;
            case "applicationPlatform":
                client = GetHttpClientWithHeaders(withPlatform: false);
                break;
            case "applicationVersion":
                client = GetHttpClientWithHeaders(withVersion: false);
                break;
        }

        client ??= GetHttpClientWithHeaders();

        _context.Set(await client.PostAsync("/consents", JsonContent.Create(requestDto)));
    }

    [Then("My consent is created")]
    public async Task ThenMyConsentIsCreated()
    {
        var identityId = _context.Get<string>("userId");

        var dbConsent = await _repo.GetAll(identityId);
        var consent = Assert.Single(dbConsent);
        Assert.Equal(identityId, consent.IdentityId);
        Assert.Equal(PolicyId, consent.PolicyId);
        Assert.Equal(PolicyVersion, consent.PolicyVersion.Version);
        Assert.Equal(Language, consent.LanguageCode);
        Assert.True(consent.Consented);
    }

    [Then("My consents are created")]
    public async Task ThenMyConsentsAreCreated()
    {
        var dbConsent = await _repo.GetAll(_context.Get<string>("userId"));
        Assert.NotEmpty(dbConsent);
        Assert.Equal(2, dbConsent.Count);
    }

    [Then("My consent is not created")]
    public async Task ThenMyConsentIsNotCreated()
    {
        var dbConsent = await _repo.GetAll(_context.Get<string>("userId"));
        Assert.Empty(dbConsent);
    }

    [Then("I receive a consent changed event with the expected data")]
    public void ThenIReceiveAConsentChangedEventWithTheExpectedData()
    {
        var consentChangedEvent = _context.Get<ConsentChangedEvent>();

        Assert.NotNull(consentChangedEvent);
        Assert.Equal("authorized", consentChangedEvent.IdentityId);
        Assert.Equal(PolicyId, consentChangedEvent.PolicyId);
        Assert.Equal(PolicyVersion, consentChangedEvent.PolicyVersion);
        Assert.Equal(Language, consentChangedEvent.PolicyLanguage);
        Assert.Equal(Consented, consentChangedEvent.ConsentChangedTo);
    }

    [Then("I receive all policies with status {string}")]
    public async Task ThenIReceiveMyPoliciesWithGivenConsentStatus(string consentStatus)
    {
        var consentStatusEnum = ConsentStatusFromString(consentStatus);
        var policies = await _context.Get<HttpResponseMessage>().Content.ReadFromJsonAsync<List<PolicyResponseDto>>() ?? [];
        if (consentStatusEnum != ConsentStatus.Pending)
        {
            Assert.Equal(PoliciesToConsentCount, policies.Count);
        }
        Assert.NotEmpty(policies);
        Assert.All(policies, policy => Assert.Equal(consentStatusEnum, ConsentStatusFromString(policy.Status)));
    }

    private HttpClient GetHttpClientWithHeaders(bool withApplicationId = true, bool withPlatform = true, bool withVersion = true)
    {
        var client = _context.Get<HttpClient>();
        if (withApplicationId)
        {
            client.DefaultRequestHeaders.Add("Application-Id", "1");
        }
        if (withPlatform)
        {
            client.DefaultRequestHeaders.Add("Application-Platform", "web");
        }
        if (withVersion)
        {
            client.DefaultRequestHeaders.Add("Application-Version", "1");
        }

        return client;
    }

    private static ConsentStatus ConsentStatusFromString(string consentStatus)
    {
        var capitalisedConsentStatus = char.ToUpper(consentStatus[0]) + consentStatus[1..].ToLower();
        return Enum.Parse<ConsentStatus>(capitalisedConsentStatus);
    }
}
