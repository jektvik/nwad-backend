﻿using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsentModule.Infrastructure;
using Microsoft.EntityFrameworkCore;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsentModule.IntegrationTest;

[Binding]
public sealed class SharedSteps(
    ScenarioContext context,
    ConsentWebApplicationFactory factory
) : IClassFixture<ConsentWebApplicationFactory>
{
    [Given("A running backend")]
    public void GivenARunningBackend()
    {
        context.Set(factory.CreateClient());
    }

    [Given("I subscribe to the consent changed event")]
    public void GivenISubscribeToTheConsentChangedEvent()
    {
        using var scope = factory.Services.CreateScope();

        var subscriber = scope.ServiceProvider.GetRequiredService<IConsentEventSubscriber>();

        subscriber.ConsentChanged += (_, consentChangedEvent) => context.Set(consentChangedEvent);
    }

    [BeforeScenario]
    public void ResetDatabase()
    {
        using var scope = factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<IConsentDbContext>();

        dbContext.Consents.ExecuteDelete();
    }
}
