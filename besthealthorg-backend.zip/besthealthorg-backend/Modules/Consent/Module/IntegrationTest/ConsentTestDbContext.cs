using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Infrastructure;
using Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ConsentModule.IntegrationTest;

/// <summary>
/// DbContext for Consultation integration tests
/// </summary>
public class ConsentTestDbContext(DbContextOptions<ConsentTestDbContext> options) : DbContext(options), IConsentDbContext
{
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        (this as IConsentDbContext).ConfigureDbSets(modelBuilder);
    }

    public DbSet<Consent> Consents { get; set; }
    public DbSet<Policy> Policies { get; set; }
    public DbSet<PolicyVersionTranslation> PolicyTranslations { get; set; }
    public DbSet<PolicyVersion> PolicyVersions { get; set; }
    public DbSet<Region> Regions { get; set; }
}
