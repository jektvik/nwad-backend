using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsentModule.IntegrationTest;

public static class SeedData
{
    public static void SeedPolicies(this ConsentTestDbContext dbContext)
    {
        var analytics = new Policy
        {
            Name = "Analytics",
            Versions = [new() { Version = 1 }],
        };

        var location = new Policy
        {
            Name = "Location",
            Versions = [new() { Version = 1 }],
        };

        var customServices = new Policy
        {
            Name = "Custom services",
            Versions = [new() { Version = 1 }],
        };

        var personalisedAds = new Policy
        {
            Name = "Personalised ads",
            Versions = [new() { Version = 1 }],
        };

        var statistics = new Policy
        {
            Name = "Statistics",
            Versions = [new() { Version = 1 }],
        };
        List<Policy> policies =
        [
            analytics,
            location,
            customServices,
            personalisedAds,
            statistics,
        ];

        // Add policies to the database and save to generate IDs
        dbContext.Policies.AddRange(policies);
        dbContext.SaveChanges();

        List<PolicyVersionTranslation> translations =
        [
            new()
            {
                PolicyVersionId = analytics.Versions[0].Id,
                Title = "Analytics",
                Summary = "Allow data to be collected and analysed for research or statistical purposes.",
                FullText =
                    "This information may be used to improve products or services, make informed business decisions, or develop new technologies.",
                LanguageCode = "en",
            },

            new()
            {
                PolicyVersionId = analytics.Versions[0].Id,
                Title = "Analyse",
                Summary = "Tillad at data bliver indsamlet og analyseret i forbindelse med research og statistik.",
                FullText = "Denne data kan blive brugt til at forbedre produkter eller services, tage informerede beslutninger eller udvikle nye teknologier.",
                LanguageCode = "da",
            },
            new()
            {
                PolicyVersionId = location.Versions[0].Id,
                Title = "Location based content",
                Summary = "Allow this device to access and share its geographical location with the...",
                FullText = "Full text about location.",
                LanguageCode = "en",
            },

            new()
            {
                PolicyVersionId = location.Versions[0].Id,
                Title = "Lokationsbaseret indhold",
                Summary = "Tillad denne enhed at få adgang til og delete geografisk lokation med...",
                FullText = "Fuld tekst om lokation",
                LanguageCode = "da",
            },
            new()
            {
                PolicyVersionId = customServices.Versions[0].Id,
                Title = "Custom services",
                Summary = "Allow the app to collect and analyse your personal data, including browsi...",
                FullText = "Full text about custom services.",
                LanguageCode = "en",
            },

            new()
            {
                PolicyVersionId = customServices.Versions[0].Id,
                Title = "Skræddersyede services",
                Summary = "Tillad denne app at indsamle og analysere din personlige data, inklusiv browsi...",
                FullText = "Fuld tekst om skræddersyede services",
                LanguageCode = "da",
            },
            new()
            {
                PolicyVersionId = personalisedAds.Versions[0].Id,
                Title = "Personalised ads",
                Summary =
                    "Allow the app to collect and analyse your personal data, including browsi...",
                FullText = "Full text about ads.",
                LanguageCode = "en",
            },

            new()
            {
                PolicyVersionId = personalisedAds.Versions[0].Id,
                Title = "Personaliserede reklemer",
                Summary =
                    "Tillad denne app at indsamle og analysere din personlige data, inklusiv browsi...",
                FullText = "Fuld tekst om reklemer",
                LanguageCode = "da",
            },
            new()
            {
                PolicyVersionId = statistics.Versions[0].Id,
                Title = "Statistics",
                Summary =
                    "Allow the app to collect and analyse your personal data, including browsi...",
                FullText = "Full text about statistics.",
                LanguageCode = "en",
            },

            new()
            {
                PolicyVersionId = statistics.Versions[0].Id,
                Title = "Statistik",
                Summary = "Tillad denne app at indsamle og analysere din personlige data, inklusiv browsi...",
                FullText = "Fuld tekst om statistik",
                LanguageCode = "da",
            },
        ];

        dbContext.PolicyTranslations.AddRange(translations);
        dbContext.SaveChanges();
        dbContext.ChangeTracker.Clear();
    }
}
