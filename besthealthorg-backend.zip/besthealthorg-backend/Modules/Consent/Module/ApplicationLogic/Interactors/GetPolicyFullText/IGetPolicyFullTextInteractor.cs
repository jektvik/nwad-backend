﻿namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors.GetPolicyFullText;

/// <summary>
/// The Interface representing the logic for retrieveing full text of a policy
/// </summary>
public interface IGetPolicyFullTextInteractor
{
    /// <summary>
    /// Retrieves the full text of a policy in a specified language from data store
    /// </summary>
    /// <param name="policyId">The id of the policy to get full text from</param>
    /// <param name="versionId">The version of the policy to get full text from</param>
    /// <param name="languageCode">ISO 639-1 two letters language code</param>
    /// <returns>Full Text in specified Language</returns>
    Task<string?> Execute(int policyId, int versionId, string? languageCode);
}
