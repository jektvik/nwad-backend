﻿using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors.GetPolicyFullText;

/// <summary>
/// Class for retrieving full text of policy from data store
/// </summary>
public class GetPolicyFullTextInteractor : IGetPolicyFullTextInteractor
{
    private readonly IPolicyRepository _policyRepository;
    private readonly ConsentConfiguration _configuration;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="policyRepository">The data store to use for retrieving policies</param>
    /// <param name="configuration">The configuration to use</param>
    public GetPolicyFullTextInteractor(IPolicyRepository policyRepository, ConsentConfiguration configuration)
    {
        _policyRepository = policyRepository;
        _configuration = configuration;
    }

    /// <summary>
    /// Method for retrieving full text of policy
    /// </summary>
    /// <param name="policyId">The id of the policy to get full text from</param>
    /// <param name="versionId">The version of the policy to get full text from</param>
    /// <param name="languageCode">ISO 639-1 two letters language code</param>
    /// <returns> full policy text in specified language</returns>
    public async Task<string?> Execute(int policyId, int versionId, string? languageCode)
    {
        var policy = await _policyRepository.GetPolicyById(policyId);
        var latestPolicy = policy?.FindLastestVersionWithTranslation(_configuration.DefaultPolicyLanguageCode, languageCode);

        if (latestPolicy is null ||
            latestPolicy.Version != versionId ||
            (latestPolicy.LanguageCode != languageCode && latestPolicy.LanguageCode != _configuration.DefaultPolicyLanguageCode))
        {
            return null;
        }

        return latestPolicy?.FullText;
    }
}
