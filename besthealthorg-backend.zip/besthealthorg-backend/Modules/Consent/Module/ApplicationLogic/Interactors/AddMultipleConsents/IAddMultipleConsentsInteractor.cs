using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Requests;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of adding multiple Consents
/// </summary>
public interface IAddMultipleConsentsInteractor
{
    /// <summary>
    /// Adds all consents to the data store
    /// </summary>
    /// <param name="requests">A list of consents to add</param>
    /// <returns>The list of created/existing consents</returns>
    Task<IEnumerable<Consent>> Execute(IEnumerable<AddConsentRequest> requests);
}
