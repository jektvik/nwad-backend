using System.Text.Json;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Requests;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Events.V1;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Exceptions;
using NwadHealth.Besthealthorg.Foundation.Events;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using Microsoft.Extensions.Logging;

// ReSharper disable RedundantAnonymousTypePropertyName

namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of adding multiple Consents
/// </summary>
public class AddMultipleConsentsInteractor : IAddMultipleConsentsInteractor
{
    private readonly IConsentRepository _consentRepository;
    private readonly IPolicyRepository _policyRepository;
    private readonly IConsentEventPublisher _consentEventPublisher;
    private readonly IAuditLogRepository _auditLogRepository;
    private readonly ILogger<AddMultipleConsentsInteractor> _logger;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="consentRepository">The data store to use for consents</param>
    /// <param name="policyRepository">The data store to use for retrieving policies</param>
    /// <param name="consentEventPublisher">Publisher for the events related to consent</param>
    /// <param name="auditLogRepository">The audit log repository used for pushing audit events</param>
    /// <param name="logger">The logger to use</param>
    public AddMultipleConsentsInteractor(
        IConsentRepository consentRepository,
        IPolicyRepository policyRepository,
        IConsentEventPublisher consentEventPublisher,
        IAuditLogRepository auditLogRepository,
        ILogger<AddMultipleConsentsInteractor> logger)
    {
        _consentRepository = consentRepository;
        _policyRepository = policyRepository;
        _consentEventPublisher = consentEventPublisher;
        _auditLogRepository = auditLogRepository;
        _logger = logger;
    }

    /// <summary>
    /// Adds all consents to the data store
    /// </summary>
    /// <param name="requests">A list of consents to add</param>
    /// <returns>The list of created/existing consents</returns>
    public async Task<IEnumerable<Consent>> Execute(IEnumerable<AddConsentRequest> requests)
    {
        var requestsList = requests.ToList();
        await EnsureRequestedPoliciesExist(requestsList);

        var addedConsents = new List<Consent>();

        foreach (var request in requestsList)
        {
            var existingConsents = await _consentRepository.Get(
                request.IdentityId,
                request.PolicyId,
                request.PolicyVersion,
                request.LanguageCode);

            if (existingConsents.Count != 0 && existingConsents[0].Consented == request.Consented)
            {
                addedConsents.Add(existingConsents[0]);
                continue;
            }

            var applicationInfo = new ApplicationInformation
            {
                ApplicationId = request.ApplicationId,
                Platform = request.ApplicationPlatform,
                Version = request.ApplicationVersion,
            };

            var consent = new Consent
            {
                IdentityId = request.IdentityId,
                PolicyVersion = new()
                {
                    PolicyId = request.PolicyId,
                    Version = request.PolicyVersion,
                },
                LanguageCode = request.LanguageCode,
                Consented = request.Consented,
                ApplicationInformation = applicationInfo,
            };

            var addedConsent = await _consentRepository.Add(consent);

            await _consentEventPublisher.PublishConsentChangedEvent(consent);
            await WriteToAuditLog(consent);

            addedConsents.Add(addedConsent);
        }

        return addedConsents;
    }

    private async Task EnsureRequestedPoliciesExist(IEnumerable<AddConsentRequest> requests)
    {
        foreach (var request in requests)
        {
            var policy = await _policyRepository.GetPolicyById(request.PolicyId);

            var exists = policy?.VersionWithLanguageExists(request.PolicyVersion, request.LanguageCode) is true;

            if (!exists)
            {
                throw new PolicyDoesNotExistException(request.PolicyId, request.PolicyVersion, request.LanguageCode);
            }
        }
    }

    private async Task WriteToAuditLog(Consent consent)
    {
        var consentData = new
        {
            IdentityId = consent.IdentityId,
            PolicyId = consent.PolicyId,
            PolicyLanguage = consent.LanguageCode,
            PolicyVersion = consent.PolicyVersion.Version,
            ConsentChangedTo = consent.Consented,
        };

        var paceEvent = new PaceEvent
        {
            IdentityId = consent.IdentityId,
            Type = ConsentChangedEvent.Type,
            Time = DateTimeOffset.UtcNow,
            Data = JsonSerializer.Serialize(consentData),
        };

        _logger.LogInformation("Pushing consent change event to audit log");

        await _auditLogRepository.WriteRecord(paceEvent);
    }
}
