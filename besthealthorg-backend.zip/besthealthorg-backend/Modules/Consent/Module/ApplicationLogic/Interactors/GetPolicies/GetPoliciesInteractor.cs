﻿using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents the business logic for retrieving all Policies from a data store
/// </summary>
public class GetPoliciesInteractor : IGetPoliciesInteractor
{
    private readonly IPolicyRepository _policyRepository;
    private readonly IConsentRepository _consentRepository;
    private readonly ConsentConfiguration _consentConfiguration;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="policyRepository">The data store to use for retrieving policies</param>
    /// <param name="consentConfiguration">The configuration to use</param>
    /// <param name="consentRepository">The data store to use for retrieving consents</param>
    public GetPoliciesInteractor(
        IPolicyRepository policyRepository,
        ConsentConfiguration consentConfiguration,
        IConsentRepository consentRepository)
    {
        _policyRepository = policyRepository;
        _consentConfiguration = consentConfiguration;
        _consentRepository = consentRepository;
    }

    /// <summary>
    /// Retrieves and filters policies based on the provided identity, consent status, and language preference.
    /// </summary>
    /// <param name="identityId">The ID of the user whose consents will be evaluated against the policies.</param>
    /// <param name="status">
    /// The desired consent status to filter policies by:
    /// - <c>ConsentStatus.Accepted</c>: Returns policies explicitly accepted by the user.
    /// - <c>ConsentStatus.Rejected</c>: Returns policies explicitly rejected by the user.
    /// - <c>ConsentStatus.Pending</c>: Returns policies for which the user has not provided consent.
    /// - <c>null</c>: Returns all policies, regardless of consent status.
    /// </param>
    /// <param name="language">
    /// The preferred language for policy translations. If a translation in the specified language is unavailable,
    /// the default language is used as a fallback.
    /// </param>
    /// <returns>
    /// An enumerable of <see cref="LatestPolicyModel"/> objects, representing the policies relevant to the user.
    /// Each policy includes:
    /// - The latest version of the policy.
    /// - Translations in the requested or default language.
    /// - A consent status based on the user's consents.
    /// </returns>
    /// <remarks>
    /// This method evaluates the consents provided by the user and maps them to the corresponding policies:
    /// - If a consent exists for a policy/version combination:
    ///   - If the user has given consent, the policy is marked as <c>ConsentStatus.Accepted</c>.
    ///   - If the user has explicitly denied consent, the policy is marked as <c>ConsentStatus.Rejected</c>.
    /// - If no consent exists for a policy/version, the policy is marked as <c>ConsentStatus.Pending</c>.
    /// </remarks>
    /// <exception cref="ArgumentOutOfRangeException">Thrown when an invalid consent status is provided.</exception>
    public async Task<IEnumerable<LatestPolicyModel>> Execute(string identityId, ConsentStatus? status, string? language)
    {
        var policies = await _policyRepository.GetAll();
        var consents = await _consentRepository.GetAllLatest(identityId);

        var consentDictionary = consents.ToDictionary(c => $"{c.PolicyId},{c.PolicyVersion.Version}", c => c);

        return policies
            .Select(p => p.FindLastestVersionWithTranslation(_consentConfiguration.DefaultPolicyLanguageCode, language))
            .Where(p => p is not null)
            .Select(p => p!)
            .Where(p => FilterForStatus(p, status, consentDictionary))
            .Select(p => SetConsentStatus(p, consentDictionary));
    }

    /// <summary>
    /// Filters a policy based on its consent status.
    /// </summary>
    /// <param name="policy">The policy model to evaluate.</param>
    /// <param name="forStatus">The desired consent status to filter for</param>
    /// <param name="consentDictionary">A dictionary of consents indexed by the key format <c>"{PolicyId},{Version}"</c>.</param>
    /// <returns>
    /// <c>true</c> if the policy matches the specified <paramref name="forStatus"/>; <c>false</c> otherwise.
    /// </returns>
    /// <exception cref="ArgumentOutOfRangeException">Thrown when <paramref name="forStatus"/> contains an invalid value.</exception>
    private static bool FilterForStatus(LatestPolicyModel policy, ConsentStatus? forStatus, Dictionary<string, Consent> consentDictionary)
    {
        consentDictionary.TryGetValue($"{policy.PolicyId},{policy.Version}", out var consent);

        return forStatus switch
        {
            ConsentStatus.Accepted => consent?.Consented == true,
            ConsentStatus.Rejected => consent?.Consented == false,
            ConsentStatus.Pending => consent is null,
            _ => true,
        };
    }

    /// <summary>
    /// Updates the consent status of a policy based on its associated consent.
    /// </summary>
    /// <param name="policy">The policy model whose status will be updated.</param>
    /// <param name="consentDictionary">
    /// A dictionary containing consents, indexed by the key format <c>"{PolicyId},{Version}"</c>.
    /// </param>
    /// <returns>The updated <see cref="LatestPolicyModel"/></returns>
    private static LatestPolicyModel SetConsentStatus(LatestPolicyModel policy, Dictionary<string, Consent> consentDictionary)
    {
        consentDictionary.TryGetValue($"{policy.PolicyId},{policy.Version}", out var consent);

        if (consent is null)
        {
            policy.Status = ConsentStatus.Pending;
        }
        else if (consent.Consented)
        {
            policy.Status = ConsentStatus.Accepted;
        }
        else
        {
            policy.Status = ConsentStatus.Rejected;
        }

        return policy;
    }
}
