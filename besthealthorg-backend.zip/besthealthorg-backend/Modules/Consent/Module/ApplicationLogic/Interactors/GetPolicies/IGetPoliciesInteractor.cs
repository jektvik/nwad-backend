﻿using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of retrieving all Consents
/// </summary>
public interface IGetPoliciesInteractor
{
    /// <summary>
    /// Retrieves Policies from the provided data store
    /// </summary>
    /// <param name="identityId">The id of the identity to get policies for</param>
    /// <param name="status">The status of the policies to get</param>
    /// <param name="language">The language of the policies to get</param>
    /// <returns>An enumerable of all Policies</returns>
    Task<IEnumerable<LatestPolicyModel>> Execute(string identityId, ConsentStatus? status, string? language);
}
