﻿using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing the required interactions with a data store
/// </summary>
public interface IPolicyRepository
{
    /// <summary>
    /// Adds a policy to the data store
    /// </summary>
    /// <param name="policy">The policy to create</param>
    Task Create(Policy policy);

    /// <summary>
    /// Gets all policies from the data store
    /// </summary>
    /// <returns>An enumerable of all policies</returns>
    Task<List<Policy>> GetAll();

    /// <summary>
    /// Finds Policy object by Id
    /// </summary>
    /// <param name="policyId">The Id of the policy to get</param>
    /// <returns>The policy with the specified id or null if it doesn't exist</returns>
    Task<Policy?> GetPolicyById(int policyId);
}
