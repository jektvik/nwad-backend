﻿using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces
{
    /// <summary>
    /// An interface representing an event publisher used for sending Consent related events
    /// </summary>
    public interface IConsentEventPublisher
    {
        /// <summary>
        /// Publishes a consent changed event
        /// </summary>
        /// <param name="consent">The consent to publish a changed event for</param>
        Task PublishConsentChangedEvent(Consent consent);
    }
}
