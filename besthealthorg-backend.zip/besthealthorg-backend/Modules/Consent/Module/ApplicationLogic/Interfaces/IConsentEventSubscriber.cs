using NwadHealth.Besthealthorg.ConsentModule.Domain.Events.V1;

namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;

/// <summary>
/// An interface used for subscribing to consent events
/// </summary>
public interface IConsentEventSubscriber
{
    /// <summary>
    /// An event that is triggered when a consent is changed
    /// </summary>
    public event EventHandler<ConsentChangedEvent>? ConsentChanged;
}
