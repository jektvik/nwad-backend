using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing the required interactions with a data store
/// </summary>
public interface IConsentRepository
{
    /// <summary>
    /// Adds an Consent to the data store.
    /// </summary>
    /// <param name="consent">The Consent to add</param>
    /// <returns>True if the Consent was successfully added, otherwise false</returns>
    Task<Consent> Add(Consent consent);

    /// <summary>
    /// Gets an enumerable of active consents associated with the specific identity
    /// </summary>
    /// <param name="identityId">The id of the identity to get consents for</param>
    /// <returns>A list of consents for the given identity</returns>
    Task<List<Consent>> GetAllLatest(string identityId);

    /// <summary>
    /// Gets an enumerable of consents associated with the specific identity, policy, version and langauge
    /// </summary>
    /// <param name="identityId">The identity id to fetch consents for</param>
    /// <param name="policyId">The policy id to fetch consents for</param>
    /// <param name="version">The policy version to fetch consents for</param>
    /// <param name="language">The language to fetch consents for</param>
    /// <returns>A list of consents for the given identity</returns>
    Task<List<Consent>> Get(string identityId, int policyId, int version, string language);

    /// <summary>
    /// Sets retention time on all consent records containing the identityId
    /// </summary>
    /// <param name="identityId">The id of the identity, whose consents should be deleted after the retention period runs out</param>
    Task<int> SetRetentionOnRecords(string identityId);
}
