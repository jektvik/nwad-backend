﻿using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing the required interactions with a data store
/// </summary>
public interface IRegionRepository
{
    /// <summary>
    /// Adds a region to the data store
    /// </summary>
    /// <param name="region">The region to create</param>
    Task Create(Region region);

    /// <summary>
    /// Finds Region object by Id
    /// </summary>
    /// <param name="regionId">The Id of the region to get</param>
    /// <returns>The region with the specified id or null if it doesn't exist</returns>
    Task<Region?> GetRegionById(string regionId);

    /// <summary>
    /// Gets all regions from the data store
    /// </summary>
    /// <returns>An enumerable of all regions</returns>
    Task<IEnumerable<Region>> GetAll();
}
