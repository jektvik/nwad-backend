namespace NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Requests;

/// <summary>
/// Represents the data required by the <see cref="Interactors.IAddMultipleConsentsInteractor"></see> for adding an Consent
/// </summary>
public class AddConsentRequest
{
    /// <summary>
    /// Id representing the user
    /// </summary>
    public string IdentityId { get; set; } = string.Empty;

    /// <summary>
    /// Id of the Policy
    /// </summary>
    public int PolicyId { get; set; }

    /// <summary>
    /// Version of the policy
    /// </summary>
    public int PolicyVersion { get; set; }

    /// <summary>
    /// Language of the policy that the user has accepted/rejected
    /// </summary>
    public string LanguageCode { get; set; } = string.Empty;

    /// <summary>
    /// Indicates whether the user has agreed or disagreed to a policy
    /// </summary>
    public bool Consented { get; set; }

    /// <summary>
    /// The Id of the application that sent the add consent request
    /// </summary>
    public string ApplicationId { get; set; } = string.Empty;

    /// <summary>
    /// The Id of the application that sent the add consent request
    /// </summary>
    public string ApplicationPlatform { get; set; } = string.Empty;

    /// <summary>
    /// The Id of the application that sent the add consent request
    /// </summary>
    public string ApplicationVersion { get; set; } = string.Empty;
}
