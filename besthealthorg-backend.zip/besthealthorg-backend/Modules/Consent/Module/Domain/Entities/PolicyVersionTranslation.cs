﻿namespace NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

/// <summary>
/// The translation of a policy version
/// </summary>
public class PolicyVersionTranslation
{
    /// <summary>
    /// The Id of the policy version that this translation belongs to. Part of the composite primary key
    /// </summary>
    public int PolicyVersionId { get; init; }

    /// <summary>
    /// Iso2 639-1 country code. Part of the composite primary key
    /// </summary>
    public required string LanguageCode { get; init; }

    /// <summary>
    /// The title of the Policy
    /// </summary>
    public required string Title { get; init; }

    /// <summary>
    /// The summary of the Policy
    /// </summary>
    public required string Summary { get; init; }

    /// <summary>
    /// The full text of the Policy
    /// </summary>
    public required string FullText { get; init; }
}
