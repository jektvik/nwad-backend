namespace NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

/// <summary>
/// The Consent domain model
/// </summary>
public class Consent
{
    /// <summary>
    /// Unique id for the Consent record
    /// </summary>
    public Guid Id { get; init; }

    /// <summary>
    /// The Id of the user that has accepted/rejected the policy
    /// </summary>
    public required string IdentityId { get; init; }

    /// <summary>
    /// The Id of the policy that the user has accepted/rejected
    /// </summary>
    public int PolicyId => PolicyVersion.PolicyId;

    /// <summary>
    /// The version of the policy that this consent is for
    /// </summary>
    public int Version => PolicyVersion.Version;

    /// <summary>
    /// Version of the policy
    /// </summary>
    public required PolicyVersion PolicyVersion { get; set; }

    /// <summary>
    /// Language of the policy that the user has accepted/rejected
    /// </summary>
    public required string LanguageCode { get; init; }

    /// <summary>
    /// The time the consent was made
    /// </summary>
    public DateTimeOffset Timestamp { get; } = DateTimeOffset.UtcNow;

    /// <summary>
    /// The status of the consent eg. has the policy been accepted or rejected.
    /// </summary>
    public required bool Consented { get; init; }

    /// <summary>
    /// The information of the client application that the user has accepted/rejected the policy on
    /// </summary>
    public required ApplicationInformation ApplicationInformation { get; init; }
}
