﻿namespace NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

/// <summary>
/// Region object designed to group countries where same policies apply
/// </summary>
public class Region
{
    /// <summary>
    /// Unique Id of the region
    /// </summary>
    public string Id { get; }

    /// <summary>
    /// Name of the region
    /// </summary>
    public required string RegionName { get; set; }
}
