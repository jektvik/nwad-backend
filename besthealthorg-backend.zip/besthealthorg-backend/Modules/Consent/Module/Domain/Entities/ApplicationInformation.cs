namespace NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

/// <summary>
/// The client application information that sent the consent request
/// </summary>
public class ApplicationInformation
{
    /// <summary>
    /// The Id of the application that sent the add consent request
    /// </summary>
    public required string ApplicationId { get; set; }

    /// <summary>
    /// The Id of the application that sent the add consent request
    /// </summary>
    public required string Platform { get; init; }

    /// <summary>
    /// The Id of the application that sent the add consent request
    /// </summary>
    public required string Version { get; init; }
}
