﻿namespace NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

/// <summary>
/// Object that represents a specific version of a Policy
/// </summary>
public class PolicyVersion
{
    /// <summary>
    /// The Id of the policy version
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Foreign key to the policy
    /// </summary>
    public int PolicyId { get; set; }

    /// <summary>
    /// The version of the policy
    /// </summary>
    public required int Version { get; set; }

    /// <summary>
    /// The translations to the policy version
    /// </summary>
    public List<PolicyVersionTranslation> Translations { get; set; } = new();

    /// <summary>
    /// Gets the translation from the policy
    /// </summary>
    /// <param name="language">The langauge to get the translation in</param>
    /// <returns>The requested translation or null if it doesn't exist</returns>
    public PolicyVersionTranslation? GetTranslation(string language)
    {
        return Translations.Find(t => t.LanguageCode == language);
    }
}
