﻿namespace NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

/// <summary>
/// Policy class from which the policy setup is configured
/// </summary>
public class Policy
{
    /// <summary>
    /// Id of the policy
    /// </summary>
    public int Id { get; }

    /// <summary>
    /// Id of the region where policy is applicable
    /// </summary>
    public string? RegionId { get; set; }

    /// <summary>
    /// Friendly name of the policy
    /// The Consumer of the policy should never see this name but rather the name on the Policy translation
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Different versions of a policy
    /// </summary>
    public List<PolicyVersion> Versions { get; set; } = new();

    /// <summary>
    /// Retrieves the latest version of the policy with a translation in the specified language or default language.
    /// </summary>
    /// <param name="defaultLanguage">
    /// The fallback language to use if a translation in the requested language is unavailable.
    /// </param>
    /// <param name="language">
    /// The preferred language for the translation. If <c>null</c>, only the default language is considered.
    /// </param>
    /// <returns>
    /// An instance of <see cref="LatestPolicyModel"/> representing the latest version of the policy with the appropriate translation,
    /// or <c>null</c> if no version or translation is available.
    /// </returns>
    public LatestPolicyModel? FindLastestVersionWithTranslation(string defaultLanguage, string? language)
    {
        foreach (var version in Versions.OrderByDescending(p => p.Version))
        {
            var translation = (version.Translations.Find(x => x.LanguageCode == language) ??
                               version.Translations.Find(x => x.LanguageCode == defaultLanguage));

            if (translation is not null)
            {
                return new()
                {
                    PolicyId = version.PolicyId,
                    Version = version.Version,
                    Title = translation.Title,
                    Status = ConsentStatus.Pending,
                    LanguageCode = translation.LanguageCode,
                    Summary = translation.Summary,
                    FullText = translation.FullText,
                    RegionId = RegionId
                };
            }
        }

        return null;
    }

    /// <summary>
    /// Gets the version from the policy
    /// </summary>
    /// <param name="versionNumber">The version to get</param>
    /// <returns>The requested version or null if it doesn't exist</returns>
    public PolicyVersion? GetVersion(int versionNumber)
    {
        return Versions.Find(v => v.Version == versionNumber);
    }

    /// <summary>
    /// Tells whether the policy exists in the given version in the given language
    /// </summary>
    /// <param name="versionNumber">The version to check</param>
    /// <param name="language">The language to check</param>
    /// <returns>Whether the policy exists in the given combination</returns>
    public bool VersionWithLanguageExists(int versionNumber, string language)
    {
        return GetVersion(versionNumber)?.GetTranslation(language) is not null;
    }
}
