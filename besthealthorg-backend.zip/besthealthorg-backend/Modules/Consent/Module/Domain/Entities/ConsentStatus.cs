﻿namespace NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

/// <summary>
/// Different statuses that a consent can have
/// </summary>
public enum ConsentStatus
{
    /// <summary>
    /// The User consented to a policy
    /// </summary>
    Accepted = 1,

    /// <summary>
    /// The consent was rejected
    /// </summary>
    Rejected = 2,

    /// <summary>
    /// The consent is pending
    /// </summary>
    Pending = 3,
}
