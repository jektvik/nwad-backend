﻿namespace NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

/// <summary>
/// Represents the configuration of the consent module
/// </summary>
public class ConsentConfiguration
{
    /// <summary>
    /// The fallback language, in case the policy does not exist in the requested language
    /// </summary>
    public string DefaultPolicyLanguageCode { get; init; } = "en";

    /// <summary>
    /// The amount of time to retain consent records after identity deletion, in years
    /// </summary>
    public int ConsentRecordRetentionTime { get; init; } = 2;
}
