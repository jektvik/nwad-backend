﻿namespace NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;

/// <summary>
/// Computed Policy Model containing the latest version/data
/// </summary>
public class LatestPolicyModel
{
    /// <summary>
    /// The id of the policy
    /// </summary>
    public required int PolicyId { get; init; }

    /// <summary>
    /// The version of the policy
    /// </summary>
    public required int Version { get; init; }

    /// <summary>
    /// The title of the policy
    /// </summary>
    public required string Title { get; init; }

    /// <summary>
    /// A summary of the policy
    /// </summary>
    public required string Summary { get; init; }

    /// <summary>
    /// Whether the policy is pending, accepted or rejected
    /// </summary>
    public required ConsentStatus Status { get; set; }

    /// <summary>
    /// The language code of the policy
    /// </summary>
    public required string LanguageCode { get; init; }

    /// <summary>
    /// The full text of the policy
    /// </summary>
    public required string FullText { get; init; }

    /// <summary>
    /// Id of the region where policy is applicable
    /// </summary>
    public string? RegionId { get; init; }
}
