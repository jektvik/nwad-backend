﻿namespace NwadHealth.Besthealthorg.ConsentModule.Domain.Events.V1;

/// <summary>
/// Holds required data for consent changed event
/// </summary>
public class ConsentChangedEvent: EventArgs
{
    /// <summary>
    /// The type string associated with this event data type
    /// </summary>
    public static string Type => "Besthealthorg.ConsentChangedEvent";

    /// <summary>
    /// Auth0 Id of the user
    /// </summary>
    public required string IdentityId { get; init; }

    /// <summary>
    /// The new value of user's consent
    /// </summary>
    public required bool ConsentChangedTo { get; init; }

    /// <summary>
    /// Id of the policy that the user changed his consent on
    /// </summary>
    public required int PolicyId { get; init; }

    /// <summary>
    /// Version of the Policy of which the user changed his consent
    /// </summary>
    public required int PolicyVersion { get; init; }

    /// <summary>
    /// The user saw the policy in this language when he changed his consent
    /// </summary>
    public required string PolicyLanguage { get; init; }
}
