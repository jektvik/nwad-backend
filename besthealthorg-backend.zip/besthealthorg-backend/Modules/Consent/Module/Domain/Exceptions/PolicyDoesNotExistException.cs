namespace NwadHealth.Besthealthorg.ConsentModule.Domain.Exceptions;

/// <summary>
/// Represents an error that occurs when the Policy was not found
/// </summary>
public class PolicyDoesNotExistException : Exception
{
    /// <summary>
    /// The policy id for which the exception occured
    /// </summary>
    public int PolicyId { get; }

    /// <summary>
    /// The policy version for which the exception occured
    /// </summary>
    public int PolicyVersion { get; }

    /// <summary>
    /// The language for which the exception occured
    /// </summary>
    public string Language { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="policyId">The policy id for which the exception occured</param>
    /// <param name="policyVersion">The policy version for which the exception occured</param>
    /// <param name="language">The langauge for which the exception occured</param>
    public PolicyDoesNotExistException(int policyId, int policyVersion, string language)
        : base($"Policy with ID {policyId} does not exist in version {policyVersion} in language {language}")
    {
        PolicyId = policyId;
        PolicyVersion = policyVersion;
        Language = language;
    }
}
