using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsentModule.Infrastructure.Repositories;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors.GetPolicyFullText;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.Foundation.Azure;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ConsentModule.Infrastructure;

/// <summary>
/// Provides extension methods for configuring the dependency injection of the ConsentModule
/// </summary>
public static class ConsentModuleExtensions
{
    /// <summary>
    /// Configures the required services for the Consent Module
    /// </summary>
    /// <typeparam name="TConsentDbContext">The DB context for consent</typeparam>
    /// <param name="services">The IServiceCollection to be configured</param>
    /// <param name="config">The consent module configuration</param>
    /// <returns>The same IServiceCollection the method was called on, with configuration set</returns>
    public static IServiceCollection AddPaceConsent<TConsentDbContext>(this IServiceCollection services, ConsentConfiguration config)
        where TConsentDbContext : DbContext, IConsentDbContext
    {
        services.AddScoped<IConsentDbContext>(provider => provider.GetRequiredService<TConsentDbContext>());

        //Singletons
        services.AddSingleton(config);
        services.AddSingleton<ConsentEventManager>();
        services.AddSingleton<IConsentEventPublisher>(p => p.GetRequiredService<ConsentEventManager>());
        services.AddSingleton<IConsentEventSubscriber>(p => p.GetRequiredService<ConsentEventManager>());
        services.TryAddSingleton<IAzureClientProvider, AzureClientProvider>();

        //Repositories
        services.AddScoped<IConsentRepository, ConsentRepository>();
        services.AddScoped<IPolicyRepository, PolicyRepository>();
        services.AddScoped<IRegionRepository, RegionRepository>();

        // Interactors
        services.AddScoped<IGetPoliciesInteractor, GetPoliciesInteractor>();
        services.AddScoped<IGetPolicyFullTextInteractor, GetPolicyFullTextInteractor>();
        services.AddScoped<IAddMultipleConsentsInteractor, AddMultipleConsentsInteractor>();

        return services;
    }

    /// <summary>
    /// Prepares the application to use the consent Module
    /// </summary>
    /// <param name="app">The IApplicationBuilder to be prepared</param>
    /// <returns>The same IApplicationBuilder the method was called on, prepared for the consent Module</returns>
    public static void UsePaceConsent(this IApplicationBuilder app)
    {
        var subscriber = app.ApplicationServices.GetRequiredService<IIdentityEventSubscriber>();

        subscriber.IdentityDeleted += async (_, @event) => await IdentityEventHandlers.OnIdentityDeletedEvent(app.ApplicationServices, @event);
    }
}
