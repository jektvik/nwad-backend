using System.Reflection;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ConsentModule.Infrastructure;

/// <summary>
/// Interface for the Consent DbContext
/// </summary>
public interface IConsentDbContext: IDbContext
{
    /// <summary>
    /// The DbSet representing the Consent table
    /// </summary>
    public DbSet<Consent> Consents { get; set; }

    /// <summary>
    /// The DbSet representing the Policy table
    /// </summary>
    public DbSet<Policy> Policies { get; set; }

    /// <summary>
    /// The DbSet representing the PolicyVersion table
    /// </summary>
    public DbSet<PolicyVersionTranslation> PolicyTranslations { get; set; }

    /// <summary>
    /// The DbSet representing the Region table
    /// </summary>
    public DbSet<PolicyVersion> PolicyVersions { get; set; }

    /// <summary>
    /// The DbSet representing the PolicyVersion table
    /// </summary>
    public DbSet<Region> Regions { get; set; }

    /// <summary>
    /// Configures the database context
    /// </summary>
    /// <param name="modelBuilder">The model builder to configure</param>
    void ConfigureDbSets(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
    }
}
