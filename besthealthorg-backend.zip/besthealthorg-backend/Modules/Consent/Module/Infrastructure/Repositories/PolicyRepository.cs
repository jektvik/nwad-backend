﻿using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ConsentModule.Infrastructure.Repositories;

/// <summary>
/// Represents operations available for storage/retrieval of Consents
/// </summary>
/// <param name="dbContext">The consent db context</param>
public class PolicyRepository(IConsentDbContext dbContext) : IPolicyRepository
{
    /// <summary>
    /// Adds a policy to the data store
    /// </summary>
    /// <param name="policy">The policy to create</param>
    public async Task Create(Policy policy)
    {
        dbContext.Policies.Add(policy);

        await dbContext.SaveChangesAsync();
    }

    /// <summary>
    /// Gets all policies from the data store
    /// </summary>
    /// <returns>An enumerable of all policies</returns>
    public async Task<List<Policy>> GetAll() => await dbContext
        .Policies
        .Include(p => p.Versions)
        .ThenInclude(v => v.Translations)
        .ToListAsync();

    /// <summary>
    /// Finds Policy object by Id
    /// </summary>
    /// <param name="policyId">The Id of the policy to get</param>
    /// <returns>The policy with the specified id or null if it doesn't exist</returns>
    public async Task<Policy?> GetPolicyById(int policyId) =>
        await dbContext.Policies
            .Include(policy => policy.Versions)
            .ThenInclude(policyVersion => policyVersion.Translations)
            .SingleOrDefaultAsync(policy => policy.Id == policyId);
}
