using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Infrastructure.EntityTypeConfigurations;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ConsentModule.Infrastructure.Repositories;

/// <summary>
/// Represents operations available for storage/retrieval of Consents
/// </summary>
/// <param name="dbContext">The consent db context</param>
/// <param name="configuration">The consent configuration</param>
public class ConsentRepository(IConsentDbContext dbContext, ConsentConfiguration configuration) : IConsentRepository
{
    /// <summary>
    /// Create a new consent record
    /// </summary>
    /// <param name="consent">Consent object to be created</param>
    public async Task<Consent> Add(Consent consent)
    {
        var trackedPolicyVersion = dbContext.PolicyVersions
            .Local
            .FirstOrDefault(pv => pv.PolicyId == consent.PolicyVersion.PolicyId && pv.Version == consent.PolicyVersion.Version);

        if (trackedPolicyVersion is not null)
        {
            consent.PolicyVersion = trackedPolicyVersion;
        }
        else
        {
            (dbContext as DbContext)!.Entry(consent.PolicyVersion).State = EntityState.Unchanged;
        }

        var entityEntry = dbContext.Consents.Add(consent);

        await dbContext.SaveChangesAsync();

        return entityEntry.Entity;
    }

    /// <summary>
    /// Returns an enumerable of consents that are addressing the latest versions of policies for a given identity
    /// </summary>
    /// <param name="identityId">the id of the identity to get latest consents for</param>
    public async Task<List<Consent>> GetAllLatest(string identityId) =>
        await dbContext.Consents.Where(consent => consent.IdentityId == identityId)
            .Include(c => c.PolicyVersion)
            .ThenInclude(c => c.Translations)
            .GroupBy(consent => consent.PolicyVersion.PolicyId)
            .Select(group => group
                .OrderByDescending(consent => consent.PolicyVersion.Version)
                .ThenByDescending(consent => consent.Timestamp)
                .First()
            )
            .ToListAsync();

    /// <summary>
    /// Returns an enumerable of all consents for given identity
    /// </summary>
    /// <param name="identityId">the ID of the identity to get all consents for</param>
    public async Task<List<Consent>> GetAll(string identityId) =>
        await dbContext.Consents
            .Include(c => c.PolicyVersion)
            .Where(consent => consent.IdentityId == identityId)
            .ToListAsync();

    /// <summary>
    /// Gets an enumerable consents associated with the specific identity, policy, version and langauge
    /// </summary>
    /// <param name="identityId">The identity id to fetch consents for</param>
    /// <param name="policyId">The policy id to fetch consents for</param>
    /// <param name="version">The policy version to fetch consents for</param>
    /// <param name="language">The language to fetch consents for</param>
    /// <returns>A list of consents for the given identity ordered with the newest first</returns>
    public async Task<List<Consent>> Get(string identityId, int policyId, int version, string language) =>
        await dbContext.Consents
            .Include(c => c.PolicyVersion)
            .Where(c => c.IdentityId == identityId && c.PolicyVersion.PolicyId == policyId && c.PolicyVersion.Version == version && c.LanguageCode == language)
            .OrderByDescending(c => c.Timestamp)
            .ToListAsync();

    /// <summary>
    /// Sets retention time on all consent records containing the identity ID
    /// </summary>
    /// <param name="identityId">The ID of the identity, whose consents should be deleted after the retention period runs out</param>
    public async Task<int> SetRetentionOnRecords(string identityId)
    {
        var retainUntil = DateTime.UtcNow
            .AddYears(configuration.ConsentRecordRetentionTime);

        return await dbContext.Consents
            .Where(c => c.IdentityId == identityId)
            .ExecuteUpdateAsync(
                c => c.SetProperty(p =>
                    EF.Property<DateTime>(p, ConsentEntityTypeConfiguration.RetainUntilDatabaseColumnName), retainUntil)
                );
    }
}
