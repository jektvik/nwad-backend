using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Events.V1;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.ConsentModule.Infrastructure;

/// <summary>
/// Handles consent-related events, including publishing and subscribing to events related to consent changes.
/// </summary>
/// <remarks>
/// This class implements both <see cref="IConsentEventPublisher"/> and <see cref="IConsentEventSubscriber"/>,
/// allowing it to act as a central point for handling consent events within the application.
/// It can publish events when a consent's status is changed.
/// </remarks>
/// <param name="logger">The logger used</param>
public class ConsentEventManager(ILogger<ConsentEventManager> logger) : IConsentEventPublisher, IConsentEventSubscriber
{
    /// <inheritdoc />
    public event EventHandler<ConsentChangedEvent>? ConsentChanged;

    /// <inheritdoc />
    public Task PublishConsentChangedEvent(Consent consent)
    {
        logger.LogInformation("Publishing consent changed event");

        var consentChangedEvent = new ConsentChangedEvent
        {
            IdentityId = consent.IdentityId,
            PolicyId = consent.PolicyId,
            PolicyLanguage = consent.LanguageCode,
            PolicyVersion = consent.PolicyVersion.Version,
            ConsentChangedTo = consent.Consented,
        };

        OnConsentChanged(consentChangedEvent);

        return Task.CompletedTask;
    }

    private void OnConsentChanged(ConsentChangedEvent consentChangedEvent)
    {
        ConsentChanged?.Invoke(this, consentChangedEvent);
    }
}
