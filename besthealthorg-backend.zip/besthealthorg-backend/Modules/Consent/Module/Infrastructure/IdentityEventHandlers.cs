using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Events;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.IdentityModule.Infrastructure;

internal static class IdentityEventHandlers
{
    internal static async Task OnIdentityDeletedEvent(IServiceProvider serviceProvider, IdentityDeletedEvent identityDeletedEvent)
    {
        using var scope = serviceProvider.CreateScope();
        var logger = scope.ServiceProvider.GetRequiredService<ILogger<IdentityDeletedEvent>>();

        var consentRepository = scope.ServiceProvider.GetRequiredService<IConsentRepository>();

        var rowsUpdated = await consentRepository.SetRetentionOnRecords(identityDeletedEvent.Identity.Id);
        logger.LogInformation("Set retention on {RowsUpdated} records for identity {IdentityId}", rowsUpdated, identityDeletedEvent.Identity.Id);
    }
}
