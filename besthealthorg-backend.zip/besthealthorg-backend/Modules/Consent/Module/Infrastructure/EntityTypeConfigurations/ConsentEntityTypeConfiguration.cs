using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace NwadHealth.Besthealthorg.ConsentModule.Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures the Consent entity type for the database
/// </summary>
public class ConsentEntityTypeConfiguration: IEntityTypeConfiguration<Consent>
{
    /// <summary>
    /// The name of the database column that stores the date until which the consent is retained
    /// Configured as a shadow property.
    /// </summary>
    public const string RetainUntilDatabaseColumnName = "RetainUntil";

    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<Consent> builder)
    {
        builder.ToTable("Consent");

        builder.HasKey(consent => consent.Id);

        builder.HasOne(consent => consent.PolicyVersion)
            .WithMany()
            .OnDelete(DeleteBehavior.Cascade)
            .IsRequired();

        builder.Property(consent => consent.IdentityId)
            .IsRequired();

        builder.Property(consent => consent.LanguageCode)
            .IsRequired();

        builder.Property(consent => consent.Timestamp)
            .IsRequired();

        builder.Property(consent => consent.Consented)
            .IsRequired();

        builder.OwnsOne(consent => consent.ApplicationInformation);

        builder.Ignore(consent => consent.PolicyId);

        // Configure the RetainUntil property as a shadow property
        builder.Property<DateTime?>(RetainUntilDatabaseColumnName)
            .IsRequired(false);
    }
}
