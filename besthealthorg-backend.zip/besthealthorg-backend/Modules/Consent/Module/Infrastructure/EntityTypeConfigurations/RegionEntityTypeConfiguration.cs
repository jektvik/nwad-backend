using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures the Region entity type for the database
/// </summary>
public class RegionEntityTypeConfiguration: IEntityTypeConfiguration<Region>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<Region> builder)
    {
        builder.ToTable("Region");

        builder.HasKey(e => e.Id);

        builder.Property(e => e.RegionName)
            .HasMaxLength(100)
            .IsRequired();
    }
}
