using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures the PolicyVersionTranslation entity type for the database
/// </summary>
public class PolicyVersionTranslationsEntityTypeConfiguration: IEntityTypeConfiguration<PolicyVersionTranslation>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<PolicyVersionTranslation> builder)
    {
        builder.ToTable("PolicyVersionTranslation");

        builder.HasKey(policyVersionTranslation => new
        {
            policyVersionTranslation.PolicyVersionId,
            policyVersionTranslation.LanguageCode,
        });

        builder.HasOne<PolicyVersion>()
            .WithMany(p => p.Translations)
            .HasForeignKey(p => p.PolicyVersionId)
            .HasPrincipalKey(p => p.Id)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Property(e => e.LanguageCode)
            .IsRequired();

        builder.Property(e => e.Title)
            .HasMaxLength(100)
            .IsRequired();

        builder.Property(e => e.Summary)
            .HasMaxLength(500)
            .IsRequired();

        builder.Property(e => e.FullText)
            .HasMaxLength(-1)
            .IsRequired();
    }
}
