using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.EntityTypeConfigurations;

/// <summary>
/// EntityTypeConfiguration for the PolicyVersion entity
/// </summary>
public class PolicyVersionEntityTypeConfiguration: IEntityTypeConfiguration<PolicyVersion>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<PolicyVersion> builder)
    {
        builder.ToTable("PolicyVersion");

        builder.HasKey(policyVersion => new { policyVersion.PolicyId, policyVersion.Version });
        builder.HasAlternateKey(policyVersion => policyVersion.Id);

        builder.Property(policyVersion => policyVersion.Id)
            .ValueGeneratedOnAdd();

        builder.HasOne<Policy>()
            .WithMany(p => p.Versions)
            .HasForeignKey(e => e.PolicyId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.Property(e => e.Version)
            .IsRequired();
    }
}
