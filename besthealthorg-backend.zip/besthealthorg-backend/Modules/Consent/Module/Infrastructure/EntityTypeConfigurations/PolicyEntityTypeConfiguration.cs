using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures the Policy entity type for the database
/// </summary>
public class PolicyEntityTypeConfiguration: IEntityTypeConfiguration<Policy>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<Policy> builder)
    {
        builder.ToTable("Policy");

        builder.HasKey(e => e.Id);

        builder.HasOne<Region>()
            .WithMany()
            .HasForeignKey(e => e.RegionId)
            .OnDelete(DeleteBehavior.Cascade)
            .IsRequired(false);

        builder.Property(p => p.Name)
            .HasMaxLength(100)
            .IsRequired();
    }
}
