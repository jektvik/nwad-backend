using System.Collections.Generic;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;

namespace UnitTest;

public static class FakeData
{
    /// <summary>
    /// 1 version with DA and EN translations
    /// </summary>
    public static readonly Policy FakeMarketingPolicy = new Policy
    {
        Name = "Marketing",
        Versions =
        [
            new PolicyVersion
            {
                Version = 1,
                PolicyId = 1,
                Translations =
                [
                    new PolicyVersionTranslation
                    {
                        PolicyVersionId = 1,
                        Title = "Marketing",
                        LanguageCode = "en",
                        Summary = "Summary of marketing",
                        FullText = "Full text about marketing",
                    },

                    new PolicyVersionTranslation
                    {
                        PolicyVersionId = 1,
                        Title = "Marketing",
                        LanguageCode = "da",
                        Summary = "Resume af marketing",
                        FullText = "Fuld tekst om marketing",
                    },
                ],
            }.WithId(1),
        ],
    }.WithId(1);

    /// <summary>
    /// 1 version with DA translation
    /// </summary>
    public static readonly Policy FakeAnalyticsPolicy = new Policy
    {
        Name = "Analytics",
        Versions =
        [
            new PolicyVersion
            {
                Version = 1,
                PolicyId = 2,
                Translations =
                [
                    new PolicyVersionTranslation
                    {
                        PolicyVersionId = 2,
                        Title = "Analytics",
                        LanguageCode = "da",
                        Summary = "Resume af analytics",
                        FullText = "Fuld tekst om analytics",
                    }

                ],
            }.WithId(2),

        ],
    }.WithId(2);

    /// <summary>
    /// 1 version with DA and EN translations
    /// </summary>
    public static readonly Policy FakeStatisticsPolicy = new Policy
    {
        Name = "Statistics",
        Versions =
        [
            new PolicyVersion
            {
                Version = 1,
                PolicyId = 3,
                Translations =
                [
                    new PolicyVersionTranslation
                    {
                        PolicyVersionId = 3,
                        Title = "Statistics",
                        LanguageCode = "da",
                        Summary = "Resume af statistics",
                        FullText = "Fuld tekst om statistics",
                    },
                    new PolicyVersionTranslation
                    {
                        PolicyVersionId = 3,
                        Title = "Statistics",
                        LanguageCode = "en",
                        Summary = "Summary of statistics",
                        FullText = "Full text about statistics",
                    },
                ],
            },
        ],
    }.WithId(3);

    /// <summary>
    /// 1 version with EN translation
    /// </summary>
    public static readonly Policy FakeLocationPolicy = new Policy
    {
        Name = "Location",
        Versions =
        [
            new PolicyVersion
            {
                Version = 1,
                PolicyId = 4,
                Translations =
                [
                    new PolicyVersionTranslation
                    {
                        PolicyVersionId = 4,
                        Title = "Location",
                        LanguageCode = "en",
                        Summary = "Summary of location",
                        FullText = "Full text about location",
                    },
                ],
            }.WithId(4),

        ],
    }.WithId(4);

    /// <summary>
    /// 1 version with no translations
    /// </summary>
    public static readonly Policy FakeNonTranslationsPolicy = new Policy
    {
        Name = "Location",
        Versions =
        [
            new PolicyVersion
            {
                Version = 1,
                PolicyId = 4,
                Translations = [],
            }.WithId(5),

        ],
    }.WithId(5);

    internal static readonly Dictionary<int, Policy?> FakePoliciesDictionary = new()
    {
        { 1, FakeMarketingPolicy.WithId(1) },
        { 2, FakeAnalyticsPolicy.WithId(2) },
        { 3, FakeStatisticsPolicy.WithId(3) },
        { 4, FakeLocationPolicy.WithId(4) },
        { 5, FakeNonTranslationsPolicy.WithId(5) },
    };
}
