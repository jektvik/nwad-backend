﻿using System;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Infrastructure;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsentModule.UnitTest;

public class ConsentEventManagerTests
{
    private readonly Mock<ILogger<ConsentEventManager>> _loggerMock = new();
    private readonly ConsentEventManager _consentEventManager;

    public ConsentEventManagerTests()
    {
        _consentEventManager = new ConsentEventManager(_loggerMock.Object);
    }

    [Fact]
    public async Task PublishConsentChanged_SendsEventOfCorrectTypeAndBody()
    {
        const string identityId = "user123";
        const int policyId = 1;
        const int policyVersion = 1;
        const string policyLanguage = "en";
        const bool consentChangedTo = false;

        var consent = new Consent
        {
            IdentityId = identityId,
            PolicyVersion = new PolicyVersion
            {
                PolicyId = policyId,
                Version = policyVersion,
            },
            LanguageCode = policyLanguage,
            Consented = consentChangedTo,
            Id = Guid.NewGuid(),
            ApplicationInformation = new ApplicationInformation
            {
                ApplicationId = "fake-app-id",
                Platform = "fake-platform",
                Version = "1.0.0",
            },
        };

        await _consentEventManager.PublishConsentChangedEvent(consent);

        _consentEventManager.ConsentChanged += (_, consentChangedEvent) =>
        {
            Assert.NotNull(consentChangedEvent);
            Assert.Equal(identityId, consentChangedEvent.IdentityId);
            Assert.Equal(policyId, consentChangedEvent.PolicyId);
            Assert.Equal(policyVersion, consentChangedEvent.PolicyVersion);
            Assert.Equal(policyLanguage, consentChangedEvent.PolicyLanguage);
            Assert.Equal(consentChangedTo, consentChangedEvent.ConsentChangedTo);
        };
    }
}
