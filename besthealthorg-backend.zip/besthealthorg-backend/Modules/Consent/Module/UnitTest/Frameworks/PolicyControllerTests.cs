using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors.GetPolicyFullText;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Controllers;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsentModule.UnitTest;

public class PolicyControllerTests
{
    private readonly PolicyController _controller = CreateController();
    private readonly Mock<IGetPoliciesInteractor> _getPoliciesInteractorMock = new();
    private readonly Mock<IGetPolicyFullTextInteractor> _getPolicyFullTextInteractorMock = new();
    #region GetPolicies

    [Fact]
    public async Task GetPolicies_GivenInvalidStatus_Returns400()
    {
        const string invalidConsentStatus = "invalid";
        var result = await _controller.GetPolicies(Mock.Of<IGetPoliciesInteractor>(), invalidConsentStatus);

        AssertUtil.AssertErrorResponse<BadRequestObjectResult>(result, 400, "invalid_policy_status", $"{invalidConsentStatus} is not a valid consent status");
    }

    [Fact]
    public async Task GetPolicies_WhenInteractorThrows_Returns500()
    {
        _getPoliciesInteractorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<ConsentStatus>(), It.IsAny<string>()))
            .ThrowsAsync(new Exception());

        var result = await _controller.GetPolicies(_getPoliciesInteractorMock.Object, nameof(ConsentStatusDto.Accepted));

        var objectResult = Assert.IsType<ObjectResult>(result);

        Assert.Equal(StatusCodes.Status500InternalServerError, objectResult.StatusCode);
    }

    [Fact]
    public async Task GetPolicies_WhenInteractorSucceeds_Returns200WithPolicies()
    {
        const int policyId = 1;
        const int version = 1;
        _getPoliciesInteractorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<ConsentStatus>(), It.IsAny<string>()))
            .ReturnsAsync(new List<LatestPolicyModel>
            {
                new()
                {
                    PolicyId = policyId,
                    Version = version,
                    LanguageCode = "en",
                    Status = ConsentStatus.Accepted,
                    Summary = "summary",
                    Title = "title",
                    FullText = "fullText",
                }
            });

        var result = await _controller.GetPolicies(_getPoliciesInteractorMock.Object, nameof(ConsentStatusDto.Accepted));

        var objectResult = Assert.IsType<OkObjectResult>(result);
        var value = Assert.IsType<List<PolicyResponseDto>>(objectResult.Value);

        var latestPolicyDto = value.First();

        Assert.Equal(policyId, int.Parse(latestPolicyDto.Id));
        Assert.Equal("en", latestPolicyDto.Language);
        Assert.Equal("accepted", latestPolicyDto.Status);
        Assert.Equal("summary", latestPolicyDto.Summary);
        Assert.Equal("title", latestPolicyDto.Title);
        Assert.Equal(version, latestPolicyDto.Version);
        Assert.Equal($"https://host/policies/{policyId}/{version}/fulltext", latestPolicyDto.FullTextLink);
    }

    #endregion GetPolicies

    #region GetPolicyFullText

    [Fact]
    public async Task GetPolicyFullText_WhenTextWasNotFound_Returns404()
    {
        _getPolicyFullTextInteractorMock
            .Setup(mock => mock.Execute(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(() => null);

        var result = await _controller.GetPolicyFullText(_getPolicyFullTextInteractorMock.Object, 1, 1);

        Assert.IsType<NotFoundObjectResult>(result);

        AssertUtil.AssertErrorResponse<NotFoundObjectResult>(result, 404, "full_text_not_found", "The requested full text for policy was not found");
    }

    [Fact]
    public async Task GetPolicyFullText_WhenInteractorThrows_Returns500()
    {
        _getPolicyFullTextInteractorMock
            .Setup(mock => mock.Execute(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()))
            .ThrowsAsync(new Exception());

        var result = await _controller.GetPolicyFullText(_getPolicyFullTextInteractorMock.Object, 1, 1);

        var objectResult = Assert.IsType<ObjectResult>(result);

        Assert.Equal(500, objectResult.StatusCode);
    }

    [Fact]
    public async Task GetPolicyFullText_WhenTextWasFound_Returns200WithText()
    {
        _getPolicyFullTextInteractorMock
            .Setup(mock => mock.Execute(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync("fullText");

        var result = await _controller.GetPolicyFullText(_getPolicyFullTextInteractorMock.Object, 1, 1);

        var objectResult = Assert.IsType<OkObjectResult>(result);
        var value = Assert.IsType<PolicyFullTextResponseDto>(objectResult.Value);

        Assert.Equal("fullText", value.FullText);
    }

    #endregion GetPolicyFullText

    private static PolicyController CreateController(string language = "en")
    {
        var controllerContext = ControllerTestHelper.SetupContext("id", [("Accept-Language", language)]);
        controllerContext.HttpContext.Request.Scheme = "https";
        controllerContext.HttpContext.Request.Host = new("host");

        return new(Mock.Of<ILogger<PolicyController>>())
        {
            ControllerContext = controllerContext,
        };
    }
}
