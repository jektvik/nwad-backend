using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Requests;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Exceptions;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Controllers;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsentModule.UnitTest;

public class ConsentControllerTests
{
    #region ConsentToPolicies

    [Theory]
    [InlineData("", "valid", "valid")]
    [InlineData("valid", "", "valid")]
    [InlineData("valid", "valid", "")]
    public async Task ConsentToPolicies_WithMissingApplicationHeader_Returns400(string appId, string appPlatform, string appVersion)
    {
        var controller = CreateController("id", false);

        var interactorMock = new Mock<IAddMultipleConsentsInteractor>();

        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<IEnumerable<AddConsentRequest>>()))
            .ReturnsAsync(new List<Consent>());

        var result = await controller.ConsentToPolicies(
            interactorMock.Object,
            new List<AddConsentRequestDto>(),
            appId,
            appPlatform,
            appVersion
        );

        AssertUtil.AssertErrorResponse<BadRequestObjectResult>(result, 400, "invalid_application_data", "Application id, platform and version must be set");
    }

    [Fact]
    public async Task ConsentToPolicies_WhenInteractorThrowsPolicyDoesNotExistException_Returns400()
    {
        var controller = CreateController();

        var interactorMock = new Mock<IAddMultipleConsentsInteractor>();

        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<IEnumerable<AddConsentRequest>>()))
            .ThrowsAsync(new PolicyDoesNotExistException(1, 1, "en"));

        var result = await controller.ConsentToPolicies(
            interactorMock.Object,
            new List<AddConsentRequestDto>
            {
                new(1, 1, "en", true)
            },
            "appId",
            "appPlatform",
            "appVersion"
        );

        AssertUtil.AssertErrorResponse<BadRequestObjectResult>(result, 400, "policy_does_not_exist", "The policy with ID 1 v1(en) does not exist");
    }

    [Fact]
    public async Task ConsentToPolicies_WhenInteractorThrows_Returns500()
    {
        var controller = CreateController();

        var interactorMock = new Mock<IAddMultipleConsentsInteractor>();

        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<IEnumerable<AddConsentRequest>>()))
            .ThrowsAsync(new Exception());

        var result = await controller.ConsentToPolicies(
            interactorMock.Object,
            new List<AddConsentRequestDto>
            {
                new(1, 1, "en", true)
            },
            "appId",
            "appPlatform",
            "appVersion"
        );

        var objectResult = Assert.IsType<ObjectResult>(result);

        Assert.Equal(500, objectResult.StatusCode);
    }

    [Fact]
    public async Task ConsentToPolicies_WithValidData_Returns200()
    {
        var controller = CreateController();

        var interactorMock = new Mock<IAddMultipleConsentsInteractor>();

        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<IEnumerable<AddConsentRequest>>()))
            .ReturnsAsync((IEnumerable<AddConsentRequest> reqs) =>
            {
                return reqs.Select(req => new Consent
                {
                    Id = Guid.NewGuid(),
                    Consented = req.Consented,
                    IdentityId = req.IdentityId,
                    LanguageCode = req.LanguageCode,
                    PolicyVersion = new PolicyVersion
                    {
                        PolicyId = req.PolicyId,
                        Version = req.PolicyVersion,
                    },
                    ApplicationInformation = new ApplicationInformation
                    {
                        ApplicationId = req.ApplicationId,
                        Platform = req.ApplicationPlatform,
                        Version = req.ApplicationVersion,
                    },
                });
            });

        var body = new List<AddConsentRequestDto>
        {
            new(1, 1, "en",true),
            new(2, 1, "en", false),
        };

        var result = await controller.ConsentToPolicies(
            interactorMock.Object,
            body,
            "appId",
            "appPlatform",
            "appVersion"
        );

        var okObjectResult = Assert.IsType<OkObjectResult>(result);

        var resultValue = Assert.IsType<List<ConsentResponseDto>>(okObjectResult.Value);
        Assert.Collection(resultValue,
            c =>
            {
                Assert.Equal("en", c.Language);
                Assert.True(c.Consented);
                Assert.Equal("1", c.PolicyId);
                Assert.Equal(1, c.PolicyVersion);
            },
            c =>
            {
                Assert.Equal("en", c.Language);
                Assert.False(c.Consented);
                Assert.Equal("2", c.PolicyId);
                Assert.Equal(1, c.PolicyVersion);
            }
        );
    }

    #endregion ConsentToPolicies

    private static ConsentController CreateController(string language = "en", bool includeAcceptLanguageHeader = true)
    {
        var headers = includeAcceptLanguageHeader ? new List<(string, string)> { ("Accept-Language", language) } : null;

        return new(Mock.Of<ILogger<ConsentController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("id", headers)
        };
    }
}
