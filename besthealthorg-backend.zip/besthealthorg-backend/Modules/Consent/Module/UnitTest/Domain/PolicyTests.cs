using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using UnitTest;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsentModule.UnitTest;

public class PolicyTests
{
    private readonly Policy _policy;

    public PolicyTests()
    {
        _policy = new()
        {
            Versions = new()
            {
                new()
                {
                    Version = 1,
                    Translations = new()
                    {
                        new()
                        {
                            LanguageCode = "en",
                            Title = "Policy title",
                            Summary = "Policy summary",
                            FullText = "Policy text",
                        },
                    },
                },
                new()
                {
                    Version = 2,
                    Translations = new()
                    {
                        new()
                        {
                            LanguageCode = "da",
                            Title = "Policy title 2",
                            Summary = "Policy summary 2",
                            FullText = "Policy text 2",
                        },
                    }
                }
            }
        };
    }

    #region GetVersion

    [Fact]
    public void GetVersion_WhenPolicyHasVersion_ReturnsTheVersion()
    {
        var version = _policy.GetVersion(2);

        Assert.Equal(2, version?.Version);
    }

    [Fact]
    public void GetVersion_WhenPolicyDoesNotHaveVersion_ReturnsNull()
    {
        var version = _policy.GetVersion(3);

        Assert.Null(version);
    }

    #endregion GetVersion

    #region VersionWithLanguageExists

    [Fact]
    public void VersionWithLanguageExists_WhenVersionAndLanguageExists_ReturnsTrue()
    {
        Assert.True(_policy.VersionWithLanguageExists(1, "en"));
        Assert.True(_policy.VersionWithLanguageExists(2, "da"));
    }

    [Fact]
    public void VersionWithLanguageExists_WhenVersionDoesNotExist_ReturnsFalse()
    {
        Assert.False(_policy.VersionWithLanguageExists(3, "da"));
    }

    [Fact]
    public void VersionWithLanguageExists_WhenLanguageDoesNotExist_ReturnsFalse()
    {
        Assert.False(_policy.VersionWithLanguageExists(1, "da"));
        Assert.False(_policy.VersionWithLanguageExists(2, "en"));
    }

    #endregion VersionWithLanguageExists
}
