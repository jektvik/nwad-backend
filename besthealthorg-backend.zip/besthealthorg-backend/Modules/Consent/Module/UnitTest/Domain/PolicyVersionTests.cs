﻿using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsentModule.UnitTest.Domain;

public class PolicyVersionTests
{
    private readonly PolicyVersion _version = new()
    {
        Version = 1,
        Translations = new()
        {
            new()
            {
                Title = "Marketing",
                LanguageCode = "en",
                Summary = "Resume af marketing",
                FullText = "Fuld tekst om marketing",
            }
        },
    };

    #region GetTranslation

    [Fact]
    public void GetTranslation_WhenTranslationInLanguageExists_ReturnTranslation()
    {
        var translation = _version.GetTranslation("en");

        Assert.Equal("en", translation?.LanguageCode);
    }

    [Fact]
    public void GetTranslation_WhenTranslationInLanguageDoesNotExists_ReturnNull()
    {
        Assert.Null(_version.GetTranslation("fr"));
    }

    #endregion GetTranslation
}
