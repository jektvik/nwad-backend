﻿using System;
using System.Linq;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using Moq;
using UnitTest;
using Xunit;
// ReSharper disable ParameterOnlyUsedForPreconditionCheck.Local

namespace NwadHealth.Besthealthorg.ConsentModule.UnitTest.ApplicationLogic.Interactors;

public class GetPoliciesInteractorTests
{
    private const string TestIdentityId = "1";

    private readonly Mock<IConsentRepository> _consentRepositoryMock = new();
    private readonly Mock<IPolicyRepository> _policyRepoMock = new();

    private readonly GetPoliciesInteractor _getPoliciesInteractor;

    private const string ConsentLanguageCode = "en";

    private const string DefaultLanguageCode = "en";
    public GetPoliciesInteractorTests()
    {
        var applicationInformation = new ApplicationInformation
        {
            ApplicationId = "fake-app-id",
            Platform = "fake-platform",
            Version = "1.0.0",
        };

        var acceptedConsentForAnalyticsV1 = new Consent
        {
            Id = Guid.NewGuid(),
            IdentityId = TestIdentityId,
            PolicyVersion = FakeData.FakeAnalyticsPolicy.GetVersion(1)!,
            //   PolicyId = FakeData.FakeAnalyticsPolicy.GetVersion(1)!.Id,
            Consented = true,
            LanguageCode = ConsentLanguageCode,
            ApplicationInformation = applicationInformation,
        };

        var acceptedConsentForStatisticsV1 = new Consent
        {
            Id = Guid.NewGuid(),
            IdentityId = TestIdentityId,
            PolicyVersion = FakeData.FakeStatisticsPolicy.GetVersion(1)!,
            //      Version = FakeData.FakeStatisticsPolicy.GetVersion(1)!.Id,
            Consented = true,
            LanguageCode = ConsentLanguageCode,
            ApplicationInformation = applicationInformation,
        };

        var rejectedConsentForMarketingV1 = new Consent
        {
            Id = Guid.NewGuid(),
            IdentityId = TestIdentityId,
            PolicyVersion = FakeData.FakeMarketingPolicy.GetVersion(1)!,
            //  Version = FakeData.FakeMarketingPolicy.GetVersion(1)!.Id,
            Consented = false,
            LanguageCode = ConsentLanguageCode,
            ApplicationInformation = applicationInformation,
        };

        _consentRepositoryMock.Setup(mock => mock.GetAllLatest(TestIdentityId))
            // All consents have EN language code
            .ReturnsAsync([
                acceptedConsentForAnalyticsV1,
                acceptedConsentForStatisticsV1,
                rejectedConsentForMarketingV1,
            ]);

        _policyRepoMock
            .Setup(mock => mock.GetAll())
            // - 1 Policy without translations
            // - 3 Policies with EN translations
            // - 3 Policies with DA translations
            .ReturnsAsync(FakeData.FakePoliciesDictionary.Values.ToList()!);

        _getPoliciesInteractor = new GetPoliciesInteractor(
            _policyRepoMock.Object,
            new ConsentConfiguration
            {
                DefaultPolicyLanguageCode = DefaultLanguageCode,
            },
            _consentRepositoryMock.Object);
    }

    #region Execute

    [Fact]
    public async Task Execute_GivenStatusAccepted_ReturnAcceptedPolicies()
    {
        const string languageCode = "en";
        const ConsentStatus consentStatus = ConsentStatus.Accepted;
        var resultList = await _getPoliciesInteractor.Execute(TestIdentityId, consentStatus, languageCode);

        Assert.All(resultList, item =>
        {
            Assert.Equal(consentStatus, item.Status);
            Assert.Equal(languageCode, item.LanguageCode);
        });
    }

    [Fact]
    public async Task Execute_GivenStatusRejected()
    {
        const string languageCode = "en";
        const ConsentStatus consentStatus = ConsentStatus.Rejected;
        var result = await _getPoliciesInteractor.Execute(TestIdentityId, consentStatus, languageCode);

        Assert.All(result, item =>
        {
            Assert.Equal(consentStatus, item.Status);
            Assert.Equal(languageCode, item.LanguageCode);
        });
    }

    [Fact]
    public async Task Execute_GivenStatusPending()
    {
        const string languageCode = "en";
        const ConsentStatus consentStatus = ConsentStatus.Pending;
        var result = await _getPoliciesInteractor.Execute(TestIdentityId, consentStatus, languageCode);

        Assert.All(result, item =>
        {
            Assert.Equal(consentStatus, item.Status);
            Assert.Equal(languageCode, item.LanguageCode);
        });
    }

    [Fact]
    public async Task Execute_GivenNoStatus()
    {
        const string languageCode = "da";
        var result = await _getPoliciesInteractor.Execute(TestIdentityId, null, languageCode);

        //Based on the fake data, we have consented to 3(positively or negatively), and one is pending
        //for the given languages (languageCode and DefaultLanguageCode)
        const int expectedCount = 4;

        var resultsList = result.ToList();

        Assert.Equal(expectedCount, resultsList.Count);
        Assert.All(resultsList, item => Assert.Contains(item.LanguageCode, new[] { languageCode, DefaultLanguageCode }));
    }

    [Fact]
    public async Task Execute_GivenStatusAcceptedAndNonExistentLanguage_ReturnsPolicyInDefaultLanguage()
    {
        var results = await _getPoliciesInteractor.Execute(TestIdentityId, ConsentStatus.Accepted, "XX");

        Assert.All(results, item =>
        {
            Assert.Equal(DefaultLanguageCode, item.LanguageCode);
            Assert.Equal(ConsentStatus.Accepted, item.Status);
        });
    }

    [Fact]
    public async Task Execute_WithPendingStatusAndNoMatchingTranslation_ReturnsFirstPolicyFound()
    {
        // Arrange
        const string requestedLanguage = "xx";
        const ConsentStatus consentStatus = ConsentStatus.Pending;

        // Act
        var resultList = await _getPoliciesInteractor.Execute(TestIdentityId, consentStatus, requestedLanguage);

        // Assert
        Assert.All(resultList, item =>
        {
            // Should fall back to the default language
            Assert.Equal(DefaultLanguageCode, item.LanguageCode);
            // Status should be pending
            Assert.Equal(ConsentStatus.Pending, item.Status);
        });
    }

    [Fact]
    public async Task Execute_WithPendingStatusAndMissingTranslation_ReturnsEmptyArray()
    {
        _policyRepoMock
            .Setup(mock => mock.GetAll())
            .ReturnsAsync([FakeData.FakeNonTranslationsPolicy]);

        var result = await _getPoliciesInteractor.Execute(TestIdentityId, ConsentStatus.Pending, "en");

        Assert.Empty(result);
    }

    #endregion Execute
}
