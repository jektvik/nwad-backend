using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Requests;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Events.V1;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Exceptions;
using NwadHealth.Besthealthorg.Foundation.Events;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using Microsoft.Extensions.Logging;
using Moq;
using UnitTest;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsentModule.UnitTest;

public class AddMultipleConsentsInteractorTests
{
    private readonly Mock<IPolicyRepository> _policyRepoMock = new ();
    private readonly Mock<IConsentEventPublisher> _eventPublisherMock = new();
    private readonly Mock<IConsentRepository> _consentRepoMock = new();
    private readonly Mock<IAuditLogRepository> _auditLogRepositoryMock = new();
    private readonly Mock<ILogger<AddMultipleConsentsInteractor>> _logger = new();

    private readonly AddMultipleConsentsInteractor _interactor;

    public AddMultipleConsentsInteractorTests()
    {
        _interactor = new AddMultipleConsentsInteractor(_consentRepoMock.Object, _policyRepoMock.Object, _eventPublisherMock.Object, _auditLogRepositoryMock.Object, _logger.Object);

        _policyRepoMock.Setup(mock => mock.GetPolicyById(1)).ReturnsAsync(FakeData.FakeAnalyticsPolicy);
        _policyRepoMock.Setup(mock => mock.GetPolicyById(2)).ReturnsAsync(FakeData.FakeMarketingPolicy);

        _consentRepoMock
            .Setup(mock => mock.Get(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync([]);
    }

    #region Execute

    [Fact]
    public async Task Execute_WithValidData_AddConsentsViaRepo()
    {
        List<AddConsentRequest> consentRequests =
        [
            GenerateFakeAddConsentRequest(consented: true, policyId: 1),
            GenerateFakeAddConsentRequest(consented: false, policyId: 2),
        ];

        _consentRepoMock
            .Setup(mock => mock.Add(It.IsAny<Consent>()))
            .ReturnsAsync((Consent c) => c);

        var result = await _interactor.Execute(consentRequests);

        _consentRepoMock.Verify(mock => mock.Add(It.IsAny<Consent>()), Times.Exactly(2));
        _auditLogRepositoryMock.Verify(mock => mock.WriteRecord(It.IsAny<PaceEvent>()), Times.Exactly(2));

        Assert.Collection(result,
            c => Assert.True(ConsentEquals(GenerateConsentFromRequest(consentRequests[0]), c)),
            c => Assert.True(ConsentEquals(GenerateConsentFromRequest(consentRequests[1]), c))
        );
    }

    [Fact]
    public async Task Execute_GivenNonExistentPolicyId_ThrowsPolicyDoesNotExistException()
    {
        List<AddConsentRequest> consentRequests =
        [
            GenerateFakeAddConsentRequest(consented: true, policyId: 1),
            GenerateFakeAddConsentRequest(consented: false, policyId: 3),
        ];

        var ex = await Assert.ThrowsAsync<PolicyDoesNotExistException>(async () => await _interactor.Execute(consentRequests));

        _consentRepoMock.Verify(mock => mock.Add(It.IsAny<Consent>()), Times.Never);

        Assert.Equal("Policy with ID 3 does not exist in version 1 in language da", ex.Message);
    }

    [Fact]
    public async Task Execute_GivenNonExistentVersion_ThrowsPolicyDoesNotExistException()
    {
        List<AddConsentRequest> consentRequests =
        [
            GenerateFakeAddConsentRequest(consented: true, policyId: 1, policyVersion: 1),
            GenerateFakeAddConsentRequest(consented: false, policyId: 2, policyVersion: 2),
        ];

        var ex = await Assert.ThrowsAsync<PolicyDoesNotExistException>(async () => await _interactor.Execute(consentRequests));

        _consentRepoMock.Verify(mock => mock.Add(It.IsAny<Consent>()), Times.Never);

        Assert.Equal("Policy with ID 2 does not exist in version 2 in language da", ex.Message);
    }

    [Fact]
    public async Task Execute_GivenNonExistentLanguage_ThrowsPolicyDoesNotExistException()
    {
        List<AddConsentRequest> consentRequests = [GenerateFakeAddConsentRequest(language: "xx", consented: true, policyId: 1, policyVersion: 1)];

        var ex = await Assert.ThrowsAsync<PolicyDoesNotExistException>(async () => await _interactor.Execute(consentRequests));

        _consentRepoMock.Verify(mock => mock.Add(It.IsAny<Consent>()), Times.Never);

        Assert.Equal("Policy with ID 1 does not exist in version 1 in language xx", ex.Message);
    }

    [Fact]
    public async Task Execute_ReconsentingToPolicy_DoesNotAddDuplicate_ReturnsExisting()
    {
        List<AddConsentRequest> consentRequests =
        [
            GenerateFakeAddConsentRequest(consented: true, policyId: 1),
            GenerateFakeAddConsentRequest(consented: false, policyId: 2),
        ];

        _consentRepoMock
            .Setup(mock => mock.Get("identity", 2, 1, "en"))
            .ReturnsAsync(consentRequests
                .Where(c => c.PolicyId == 2)
                .Select(GenerateConsentFromRequest)
                .ToList()
            );

        _consentRepoMock.Setup(mock => mock.Add(It.IsAny<Consent>())).ReturnsAsync((Consent c) => c);

        var result = await _interactor.Execute(consentRequests);

        Func<PaceEvent, bool> verifyPaceEvent = paceEvent =>
        {
            var consentData = JsonSerializer.Deserialize<ConsentChangedEvent>(paceEvent.Data)!;

            return paceEvent.Type == ConsentChangedEvent.Type &&
                   consentData.IdentityId == "identity" &&
                   consentData is { PolicyId: 1, PolicyVersion: 1, PolicyLanguage: "da", ConsentChangedTo: true };
        };

        _auditLogRepositoryMock.Verify(mock => mock.WriteRecord(It.Is<PaceEvent>(paceEvent => verifyPaceEvent(paceEvent))));

        _consentRepoMock.Verify(mock => mock.Add(It.Is<Consent>(c => c.PolicyId == 1 && c.Consented && c.IdentityId== "identity")), Times.Once);
        Assert.Collection(result,
            c => Assert.True(ConsentEquals(GenerateConsentFromRequest(consentRequests[0]), c)),
            c => Assert.True(ConsentEquals(GenerateConsentFromRequest(consentRequests[1]), c))
        );
    }

    #endregion Execute

    private static bool ConsentEquals(Consent actual, Consent expected)
    {
        return actual.PolicyId == expected.PolicyId &&
               actual.PolicyVersion.Version == expected.PolicyVersion.Version &&
               actual.PolicyVersion.PolicyId == expected.PolicyVersion.PolicyId &&
               actual.LanguageCode == expected.LanguageCode &&
               actual.Consented == expected.Consented &&
               actual.ApplicationInformation.ApplicationId == expected.ApplicationInformation.ApplicationId &&
               actual.ApplicationInformation.Platform == expected.ApplicationInformation.Platform &&
               actual.ApplicationInformation.Version == expected.ApplicationInformation.Version;
    }

    private static AddConsentRequest GenerateFakeAddConsentRequest(
        string applicationId = "appId",
        string applicationPlatform = "appPlatform",
        string applicationVersion = "appVersion",
        string identityId = "identity",
        string language = "da",
        bool consented = false,
        int policyId = 1,
        int policyVersion = 1)
    {
        return new AddConsentRequest
        {
            ApplicationId = applicationId,
            ApplicationPlatform = applicationPlatform,
            ApplicationVersion = applicationVersion,
            IdentityId = identityId,
            LanguageCode = language,
            Consented = consented,
            PolicyId = policyId,
            PolicyVersion = policyVersion,
        };
    }

    private static Consent GenerateConsentFromRequest(AddConsentRequest request)
    {
        var policyVersion = new PolicyVersion
        {
            PolicyId = request.PolicyId,
            Version = request.PolicyVersion,
        };
        return new Consent
        {
            IdentityId = request.IdentityId,
            PolicyVersion = policyVersion,
            LanguageCode = request.LanguageCode,
            Consented = request.Consented,
            ApplicationInformation = new ApplicationInformation
            {
                ApplicationId = request.ApplicationId,
                Platform = request.ApplicationPlatform,
                Version = request.ApplicationVersion,
            },
            Id = Guid.NewGuid(),
        };
    }
}
