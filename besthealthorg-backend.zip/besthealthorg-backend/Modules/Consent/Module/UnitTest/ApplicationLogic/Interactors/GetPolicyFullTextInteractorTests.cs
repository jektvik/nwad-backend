using System.Collections.Generic;
using System.Threading.Tasks;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors.GetPolicyFullText;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using Moq;
using UnitTest;
using Xunit;

namespace NwadHealth.Besthealthorg.ConsentModule.UnitTest;

public class GetPolicyFullTextInteractorTests
{
    private static readonly Dictionary<int, Policy?> FakePoliciesDictionary = new()
    {
        { 1, FakeData.FakeMarketingPolicy },
        { 2, null },
        { 3, FakeData.FakeAnalyticsPolicy},
    };

    private const string DefaultLanguageCode = "en";

    private readonly GetPolicyFullTextInteractor _interactor;

    public GetPolicyFullTextInteractorTests()
    {
        var consentConfiguration = new ConsentConfiguration
        {
            DefaultPolicyLanguageCode = DefaultLanguageCode,
        };
        var policyRepoMock = new Mock<IPolicyRepository>();

        policyRepoMock
            .Setup(mock => mock.GetPolicyById(It.IsAny<int>()))
            .ReturnsAsync((int policyId) => FakePoliciesDictionary.GetValueOrDefault(policyId));

        _interactor = new GetPolicyFullTextInteractor(policyRepoMock.Object, consentConfiguration);
    }

    #region Execute

    [Fact]
    public async Task Execute_GivenValidParameters_ReturnsCorrectPolicyText()
    {
        const int policyId = 1;
        const string languageCode = "da";
        var result = await _interactor.Execute(policyId, 1, languageCode);

        var expectedFullText = FakePoliciesDictionary
            .GetValueOrDefault(policyId)!
            .FindLastestVersionWithTranslation("en", languageCode)
            ?.FullText;

        Assert.NotNull(result);
        Assert.Equal(expectedFullText, result);
    }

    [Fact]
    public async Task Execute_GivenNonExistentLanguage_ReturnsDefaultLanguagePolicyText()
    {
        const int policyId = 1;
        const string invalidLanguageCode = "gg";
        var result = await _interactor.Execute(policyId, 1, invalidLanguageCode);

        var expectedFullText = FakePoliciesDictionary
            .GetValueOrDefault(policyId)!
            .FindLastestVersionWithTranslation(DefaultLanguageCode, invalidLanguageCode)
            ?.FullText;

        Assert.NotNull(result);
        Assert.Equal(expectedFullText, result);
    }

    [Fact]
    public async Task Execute_GivenNonExistentVersion_ReturnsNull()
    {
        var result = await _interactor.Execute(1, 33, "da");

        Assert.Null(result);
    }

    [Fact]
    public async Task Execute_GivenNonExistantPolicy_ReturnsNull()
    {
        var result = await _interactor.Execute(2, 1, "da");

        Assert.Null(result);
    }

    [Fact]
    public async Task Execute_GivenNonExistentLanguageAndDefaultLanguage_ReturnsNull()
    {
        var result = await _interactor.Execute(3, 1, "gg");

        Assert.Null(result);
    }

    #endregion Execute
}
