using static NwadHealth.Besthealthorg.Foundation.Extensions.Controller.ErrorResponseExtensions;
using Microsoft.AspNetCore.Mvc;

namespace NwadHealth.Besthealthorg.ConsentModule.Frameworks;

/// <summary>
/// ControllerBase extensions for creating error responses
/// </summary>
public static class ErrorResponseExtensions
{
    /// <summary>
    /// Creates an invalid application data error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>An invalid application data result</returns>
    public static IActionResult InvalidApplicationDataError(this ControllerBase controller) =>
        controller.BadRequest(CreateErrorResponseDto("invalid_application_data", "Application id, platform and version must be set"));

    /// <summary>
    /// Creates a policy does not exist error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <param name="id">The id of the policy that was not found</param>
    /// <param name="version">The version of the policy that was not found</param>
    /// <param name="language">The langauge of the policy that was not found</param>
    /// <returns>A policy does not exist result</returns>
    public static IActionResult PolicyDoesNotExistError(this ControllerBase controller, int id, int version, string language) =>
        controller.BadRequest(CreateErrorResponseDto("policy_does_not_exist", $"The policy with ID {id} v{version}({language}) does not exist"));

    /// <summary>
    /// Creates an invalid consent status error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <param name="status">The status that is invalid</param>
    /// <returns>An invalid consent status result</returns>
    public static IActionResult InvalidConsentStatusError(this ControllerBase controller, string? status) =>
        controller.BadRequest(CreateErrorResponseDto("invalid_policy_status", $"{status} is not a valid consent status"));

    /// <summary>
    /// Creates a full text not found error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>A full text not found result</returns>
    public static IActionResult FullTextNotFoundError(this ControllerBase controller) =>
        controller.NotFound(CreateErrorResponseDto("full_text_not_found", "The requested full text for policy was not found"));
}
