﻿namespace NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Response;

/// <summary>
/// Return Object of consenting to policy
/// </summary>
/// <param name="PolicyId">The Id of the Policy</param>
/// <param name="PolicyVersion">The version of the Policy</param>
/// <param name="Language">The language of the Policy</param>
/// <param name="Consented">Whether the user has consented/rejected the Policy</param>
public record ConsentResponseDto(
    string PolicyId,
    int PolicyVersion,
    string Language,
    bool Consented
);
