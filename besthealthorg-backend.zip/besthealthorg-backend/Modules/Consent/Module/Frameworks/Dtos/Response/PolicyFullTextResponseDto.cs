﻿namespace NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Response;

/// <summary>
/// Return object for the policy full text
/// </summary>
/// <param name="FullText">The full text of the polcy</param>
public record PolicyFullTextResponseDto(string FullText);
