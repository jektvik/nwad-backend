﻿namespace NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Response;

/// <summary>
/// The data returned by the <see cref="NwadHealth.Besthealthorg.ConsentModule.Frameworks.Controllers.PolicyController.GetPolicies"/> endpoint
/// </summary>
/// <param name="Id">The id of the policy</param>
/// <param name="Version">The version of the policy</param>
/// <param name="Title">The title of the policy</param>
/// <param name="Summary">The summary of the policy</param>
/// <param name="Status">The status of the policy</param>
/// <param name="Language">The language of the policy</param>
/// <param name="FullTextLink">The link to call for getting the full policy text</param>
/// <param name="RegionId">The id of the region in which this policy is aplicable</param>
public record PolicyResponseDto(
    string Id,
    int Version,
    string Title,
    string Summary,
    string Status,
    string Language,
    string FullTextLink,
    string RegionId
);
