using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos;

/// <summary>
/// Different statuses that a consent can have
/// </summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum ConsentStatusDto
{
    /// <summary>
    /// The User consented to a policy
    /// </summary>
    Accepted = 1,

    /// <summary>
    /// The consent was rejected
    /// </summary>
    Rejected = 2,

    /// <summary>
    /// The consent is pending
    /// </summary>
    Pending = 3,
}
