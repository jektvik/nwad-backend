﻿namespace NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Request;

/// <summary>
/// Body for the AddConsent Put API request
/// </summary>
/// <param name="PolicyId">The id of the policy</param>
/// <param name="Version">The version of the policy</param>
/// <param name="Language">The language of the policy</param>
/// <param name="Consented">Whether the user has consented to the policy</param>
public record AddConsentRequestDto(
    int PolicyId,
    int Version,
    string Language,
    bool Consented
);
