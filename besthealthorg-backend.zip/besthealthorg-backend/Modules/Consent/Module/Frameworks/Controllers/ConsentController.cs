using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Requests;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Exceptions;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.Foundation.Extensions.Controller;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.ConsentModule.Frameworks.Controllers;

/// <summary>
/// Contains endpoints relating to the Consent domain
/// </summary>
[ApiController]
[Route("consents")]
public class ConsentController : ControllerBase
{
    private readonly ILogger<ConsentController> _logger;

    /// <summary>
    /// Initializes the ConsentController
    /// </summary>
    /// <param name="logger">The logger to use</param>
    public ConsentController(ILogger<ConsentController> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Stores consent of a user to a policy
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="body">The request body</param>
    /// <param name="applicationId">The Id of the app that sent the request</param>
    /// <param name="applicationPlatform">The platform of the app that sent the request</param>
    /// <param name="applicationVersion">The version of the app that sent the request</param>
    /// <response code="200">Consent was created successfully</response>
    /// <response code="400">The request is malformed</response>
    /// <response code="500">Unexpected error</response>
    [HttpPost(Name = "ConsentToPolicies")]
    [Consumes("application/json")]
    [Produces("application/json")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    [Authorize]
    public async Task<IActionResult> ConsentToPolicies(
        [FromServices] IAddMultipleConsentsInteractor interactor,
        [FromBody] IEnumerable<AddConsentRequestDto> body,
        [FromHeader(Name = "Application-Id")] string applicationId,
        [FromHeader(Name = "Application-Platform")] string applicationPlatform,
        [FromHeader(Name = "Application-Version")] string applicationVersion)
    {
        _logger.LogInformation("Processing request to ConsentToPolicies");

        try
        {
            if (!IsAllValid(applicationId, applicationPlatform, applicationVersion))
            {
                return this.InvalidApplicationDataError();
            }

            var requests = body
                .Select(consent => new AddConsentRequest
                {
                    IdentityId = HttpContext.CurrentIdentityId(),
                    PolicyId = consent.PolicyId,
                    LanguageCode = consent.Language,
                    PolicyVersion = consent.Version,
                    Consented = consent.Consented,
                    ApplicationId = applicationId,
                    ApplicationPlatform = applicationPlatform,
                    ApplicationVersion = applicationVersion
                });

            var createdConsents = await interactor.Execute(requests);

            var response = createdConsents
                .Select(createdConsent => new ConsentResponseDto(
                    createdConsent.PolicyId.ToString(),
                    createdConsent.PolicyVersion.Version,
                    createdConsent.LanguageCode,
                    createdConsent.Consented
                ));

            return Ok(response.ToList());
        }
        catch (PolicyDoesNotExistException e)
        {
            return this.PolicyDoesNotExistError(e.PolicyId, e.PolicyVersion, e.Language);
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during ConsentToPolicies request processing");

            return this.UnexpectedError();
        }
    }

    private static bool IsAllValid(string applicationId, string applicationPlatform, string applicationVersion)
    {
        return
            !string.IsNullOrEmpty(applicationId) &&
            !string.IsNullOrEmpty(applicationPlatform) &&
            !string.IsNullOrEmpty(applicationVersion);
    }
}
