﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.ConsentModule.ApplicationLogic.Interactors.GetPolicyFullText;
using Microsoft.AspNetCore.Authorization;
using NwadHealth.Besthealthorg.ConsentModule.Domain.Entities;
using NwadHealth.Besthealthorg.ConsentModule.Frameworks.Dtos;
using Microsoft.Extensions.Logging;
using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.Foundation.Extensions.Controller;

namespace NwadHealth.Besthealthorg.ConsentModule.Frameworks.Controllers;

/// <summary>
/// Contains endpoints relating to the Policy domain
/// </summary>
[ApiController]
[Route("policies")]
public class PolicyController : ControllerBase
{
    private readonly ILogger<PolicyController> _logger;

    /// <summary>
    /// Initializes the PolicyController
    /// </summary>
    /// <param name="logger">The logger to use</param>
    public PolicyController(ILogger<PolicyController> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Retrieves all Policies
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="status">The status of the policies to get</param>
    /// <response code="200">Policies were successfully retrieved</response>
    /// <response code="400">Consent status is invalid</response>
    /// <response code="500">Unexpected error</response>
    [HttpGet(Name = "GetPolicies")]
    [Consumes("application/json")]
    [Produces("application/json")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    [Authorize]
    public async Task<IActionResult> GetPolicies(
        [FromServices] IGetPoliciesInteractor interactor,
        [FromQuery] string? status)
    {
        try
        {
            var converted = Enum.TryParse<ConsentStatus>(status, true, out var parsedStatus);

            if (status is not null && !converted)
            {
                return this.InvalidConsentStatusError(status);
            }

            var request = HttpContext.Request;

            var language = HttpContext.GetLanguage();

            var policies = await interactor.Execute(HttpContext.CurrentIdentityId(), parsedStatus, language);
            var response = policies.Select(p =>
            {
                var fullTextLink = $"{request.Scheme}://{request.Host.Value}/policies/{p.PolicyId}/{p.Version}/fulltext";
                return new PolicyResponseDto(
                    Id: p.PolicyId.ToString(),
                    Version: p.Version,
                    Title: p.Title,
                    Summary: p.Summary,
                    //Because [EnumMember] is not supported by the native JSON serializer and i want the value to be lowercase
                    Status: p.Status.ToString().ToLower(),
                    Language: p.LanguageCode,
                    FullTextLink: fullTextLink,
                    RegionId: p.RegionId ?? string.Empty);
            });

            return Ok(response.ToList());
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during GetPolicies request processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Gets Full Text for specified version of policy
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="policyId">The policy to get the full text for</param>
    /// <param name="versionId">The version of the policy to get the text for</param>
    /// <response code="200">The text has been successfully returned</response>
    /// <response code="500">Unexpected error</response>
    [HttpGet("{policyId}/{versionId}/fulltext", Name = "GetPolicyFullText")]
    [Consumes("application/json")]
    [Produces("application/json")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Authorize]
    public async Task<IActionResult> GetPolicyFullText([FromServices] IGetPolicyFullTextInteractor interactor,
        int policyId, int versionId)
    {
        try
        {
            var language = HttpContext.GetLanguage();
            var fullText = await interactor.Execute(policyId, versionId, language);

            if (fullText is null)
            {
                return this.FullTextNotFoundError();
            }

            return Ok(new PolicyFullTextResponseDto(FullText: fullText));
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during GetFullText request processing");

            return this.UnexpectedError();
        }
    }
}
