﻿using Microsoft.AspNetCore.Http;

namespace NwadHealth.Besthealthorg.ConsentModule.Frameworks.Controllers;

/// <summary>
/// HttpContextHelper extensions
/// </summary>
public static class HttpContextExtensions
{
    private const string LANGUAGE_HEADER_NAME = "Accept-Language";

    /// <summary>
    /// Get list of preferred languages
    /// </summary>
    /// <param name="httpContext">The HTTP context to get headers from</param>
    /// <returns>A list of preferred langauges</returns>
    public static string? GetLanguage(this HttpContext httpContext)
    {
        httpContext.Request.Headers.TryGetValue(LANGUAGE_HEADER_NAME, out var language);

        return language;
    }
}
