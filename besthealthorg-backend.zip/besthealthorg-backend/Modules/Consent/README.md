# Consent Module

The PACE Consent module is used for managing optional consent policies to keep track of what usage of data users agree to.

## Module setup

### General requirements

The Consent module requires the application to have authorization enabled (ideally through the [Identity module](/Identity/README.md)).

### Required infrastructure

- Azure CosmosDB instance
  - CosmosDB database
    - CosmosDB container named `policies`
    - CosmosDB container named `consents`
    - CosmosDB container named `regions`

### Installation

Install the `NwadHealth.Pace.ConsentModule` NuGet package by following the [instructions](/README.md#sdk-modules) in the main README.

### Application Configuration

To configure the Consent module in your application, when registering services call the `AddPaceConsent()` extension method on your service provider as well as `UsePaceConsent()` on your web application instance.
`AddPaceConsent` requires an instance of [ConsentConfiguration](https://effective-robot-19m1v3p.pages.github.io/classNwadHealth_1_1Pace_1_1ConsentModule_1_1Domain_1_1Entities_1_1ConsentConfiguration.html)

The configuration requires at a minimum (as constructor params):

- The connection string to the CosmosDB instance where data related to the module will be stored
- The name of the database to use in the CosmosDB instance.

Optional but recommended configuration:

| Property                     | Purpose                                                                                   | Default |
|------------------------------|-------------------------------------------------------------------------------------------|---------|
| `DefaultLanguage`            | The language to use, if a policy is requested in a language where the policy does't exist | `"en"`  |
| `ConsentRecordRetentionTime` | The amount of years to keep evidence of consent after the user revokes their consent      | `2`     |

#### Example

```CSharp
using NwadHealth.Pace.ConsentModule.Infrastructure;
using NwadHealth.Pace.ConsentModule.Domain.Entities;

... // other setup

var config = new ConsentConfiguration("connectionString", "dbName")
{
    DefaultLanguage = "de",
    ConsentRecordRetentionTime = 5
};

builder.services.AddPaceConsent(configuration);

... // other setup

var app = builder.Build();

... // other setup

app.UsePaceConsent();

... // other setup

app.Run(); 
```

### Configuring policies

> **Note: In the current release no region functionality is provided, however we included necessary infrastructure for it such as data-model, repository and configuration.
This is for sake of avoiding migrations issues that could occur had we opted out to include these changes later in the development cycle.**


The module currently does not provide functionality for adding policies, instead you should manually insert them in CosmosDB as follows:

1. Locate the CosmosDB in use
1. Locate the database matching `ConsentConfiguration.DatabaseName`
1. Locate the container matching `ConsentConfiguration.PoliciesContainer` (default: `policies`)
1. Insert the policies (example of a policy below).

   **IMPORTANT: the `id` property must be unique.**

   **IMPORTANT: policies, versions and translations are seen as immutable, this means that if a policy for any reason needs to change, instead of modifying the translation, instead add a new version with the required changes.**

   **IMPORTANT: policies without versions or translations present, will be seen as "non existent".**
   
   **IMPORTANT: In case the policy is not available in the default language either, the module will fall back to the first available language in the policy object.**

   ``` json
   {
       "id": "1",
       "name": "Analytics",
       "versions": [
           {
               "version": 1,
               "translations": [
                   {
                       "title": "Analytics",
                       "summary": "Allow data to be collected and analyzed for research or statistical purposes.",
                       "fullText": "This information may be used to improve products or services, make informed business decisions, or develop new technologies.",
                       "language": "en"
                   },
                   {
                       "title": "Analyse",
                       "summary": "Tillad at data bliver indsamlet og analyseret i forbindelse med research og statistik.",
                       "fullText": "Denne data kan blive brugt til at forbedre produkter eller services, tage informerede beslutninger eller udvikle nye teknologier.",
                       "language": "da"
                   }
               ]
           }
       ],
       "regionId": "1"
   }
   ```

## Events published

See the main [README](/README.md#reacting-to-pace-events) for how to react to events

This module publishes the following events:

- `ConsentChangedEvent` each time a user makes changes their decision for a policy.

## Application lifecycle

When an identity is deleted the consent module will set the retention period to the duration specified in the configuration, on consent records belonging to the deleted identity.


# Old PR trace

PR's from before 2023-05-03 can be found in the archived repository: https://github.com/NwadHealthGit/pace-consent-backend
