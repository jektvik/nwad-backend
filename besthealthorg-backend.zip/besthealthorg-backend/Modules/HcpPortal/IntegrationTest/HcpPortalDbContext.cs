﻿using NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure;
using NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure.Models;
using NwadHealth.Besthealthorg.PermissionModule.Infrastructure;
using NwadHealth.Besthealthorg.PermissionModule.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

// not relevant for db models
#nullable disable warnings

namespace NwadHealth.Besthealthorg.HcpPortalModule.IntegrationTest;

/// <summary>
/// Represents required actions of a provided database context
/// </summary>
public class HcpPortalTestDbContext : DbContext, IHcpPortalDbContext, IPermissionDbContext
{
    /// <summary>
    /// Default constructor
    /// </summary>
    /// <param name="options">Options to use</param>
    public HcpPortalTestDbContext(DbContextOptions<HcpPortalTestDbContext> options) : base(options)
    {
    }

    /// <inheritdoc/>
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        (this as IHcpPortalDbContext).ConfigureDbSets(modelBuilder);
        (this as IPermissionDbContext).ConfigureDbSets(modelBuilder);
    }

    /// <summary>
    /// The collection of HCP portal user invitations
    /// </summary>
    public DbSet<HcpPortalUserInvitationDbModel> HcpPortalUserInvitations { get; set; }

    /// <summary>
    /// The collection of HCP portal user metadata
    /// </summary>
    public DbSet<HcpPortalUserMetadataDbModel> HcpPortalUserMetadata { get; set; }

    public DbSet<DataSharingPermissionDbModel> DataSharingPermissions { get; set; }

    public DbSet<DataSharingPermissionRequestDbModel> DataSharingPermissionRequests { get; set; }
}
