using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.PermissionModule.Domain.Enums;
using NwadHealth.Besthealthorg.PermissionModule.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.IntegrationTest;

[Binding]
public sealed class DataSharingRequestSteps
{
    private readonly ScenarioContext _context;
    private readonly HcpPortalWebApplicationFactory _factory;

    private Guid _requestId;

    private (string Id, string Email) _currentPatientData = ("NonExistent", "NonExistent@mail.com");

    public DataSharingRequestSteps(ScenarioContext context, HcpPortalWebApplicationFactory factory)
    {
        _context = context;
        _factory = factory;
    }

    [Given("a patient exists")]
    public void GivenAPatientExists()
    {
        _currentPatientData = ("authorized", "authorized@mail.com");
    }

    [Given("the patient is already sharing their data with me")]
    public async Task GivenThePatientIsAlreadySharingTheirDataWithMe()
    {
        using var scope = _factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();

        var permission = new DataSharingPermissionDbModel
        {
            Id = Guid.NewGuid(),
            AccessorEmail = "acc@email.com",
            AccessorReferenceName = "AccRefName",
            AccessorIdentityId = _context.Get<string>("userId"),
            SubjectIdentityId = _currentPatientData.Id,
            SubjectReferenceName = "subjectRefName",
            SubjectEmail = _currentPatientData.Email,
            Type = HcpPortalConfiguration.HcpPermissionType,
            CreatedAt = DateTimeOffset.UtcNow,
        };

        await dbContext.DataSharingPermissions.AddAsync(permission);
        await dbContext.SaveChangesAsync();
    }

    [Given("^I have a data sharing request where I am the accessor in status (.*)")]
    public async Task GivenIHaveADataSharingRequestInStatus(DataSharingPermissionRequestStatus status)
    {
        var idFromContext = _context.Get<string>("userId");
        await CreateDataSharingRequest(idFromContext,status);
    }

    [Given("a data sharing request that is not mine exists")]
    public async Task GivenADataSharingRequestThatIsNotMineExists()
    {
        await CreateDataSharingRequest("notMine", DataSharingPermissionRequestStatus.Expired);
    }

    [When("I request the patient to share their data")]
    public async Task WhenIRequestThePatientToShareTheirData()
    {
        var client = _context.Get<HttpClient>();

        var response = await client.PostAsJsonAsync("HcpPortal/DataSharingRequest", new RequestHcpDataSharingRequestDto(_currentPatientData.Email, "identifier"));
        _context.Set(response);
    }

    [When("I request to resend the data sharing request")]
    public async Task WhenIRequestToResendTheDataSharingRequest()
    {
        var client = _context.Get<HttpClient>();
        _context.Set(await client.PostAsync($"HcpPortal/DataSharingRequest/{_requestId}/resend",null));
    }

    [Then("a data sharing request is created")]
    public async Task ThenADataSharingRequestIsCreated()
    {
        using var scope = _factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();

        var requests = await dbContext.DataSharingPermissionRequests
            .Where(r => r.AccessorIdentityId == _context.Get<string>("userId")
                        && r.SubjectIdentityId == _currentPatientData.Id
                        && r.Type == HcpPortalConfiguration.HcpPermissionType)
            .ToListAsync();

        Assert.Single(requests);
    }

    [Then("a data sharing request is resent")]
    public async Task ThenADataSharingRequestIsResent()
    {
        using var scope = _factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();
        var request = await dbContext.DataSharingPermissionRequests.FindAsync(_requestId);

        Assert.NotNull(request);
        Assert.False(request.IsRevoked);
        Assert.False(request.IsRejected);
        Assert.True(request.ExpiresAt > DateTimeOffset.UtcNow);
    }

    private async Task CreateDataSharingRequest(string userId, DataSharingPermissionRequestStatus status)
    {
        using var scope = _factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();

         var (rejected, revoked, days) = status switch
        {
            DataSharingPermissionRequestStatus.Rejected => (true, false, 1),
            DataSharingPermissionRequestStatus.Revoked => (false, true, 1),
            DataSharingPermissionRequestStatus.Pending => (false, false, 1),
            DataSharingPermissionRequestStatus.Expired => (false, false, -1),
            _ => throw new ArgumentOutOfRangeException(nameof(status))
        };

        var request = new DataSharingPermissionRequestDbModel
        {
            Id = Guid.NewGuid(),
            SubjectIdentityId=_currentPatientData.Id,
            SubjectEmail=_currentPatientData.Email,
            ExpiresAt = DateTimeOffset.UtcNow.AddDays(days),
            AccessorIdentityId = userId,
            AccessorEmail = "acc@email.com",
            AccessorReferenceName = "AccRefName",
            Type = HcpPortalConfiguration.HcpPermissionType,
            IsRejected = rejected,
            IsRevoked = revoked
        };

        await dbContext.DataSharingPermissionRequests.AddAsync(request);
        dbContext.SaveChanges();
        _requestId = request.Id;
    }
}
