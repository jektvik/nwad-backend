using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Response;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.IntegrationTest;

[Binding]

public class InvitationSteps : IClassFixture<HcpPortalWebApplicationFactory>
{
    private readonly ScenarioContext _context;
    private readonly HcpPortalWebApplicationFactory _factory;

    public InvitationSteps(ScenarioContext context, HcpPortalWebApplicationFactory factory)
    {
        _context = context;
        _factory = factory;
    }

    [Given("^a valid invitation with role (.*) exists")]
    public async Task GivenAValidInvitationWithRoleExists(string role)
    {
        using var scope = _factory.Services.CreateScope();

        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();

        dbContext.HcpPortalUserInvitations.Add(new()
        {
            ExpiresAt = DateTimeOffset.UtcNow.AddDays(1),
            InternalReferenceName = "InternalReferenceName",
            InvitationSenderId = "InvitationSenderId",
            Language = "en",
            ReceiverEmail = "invitee@nwadhealthdev.com",
            RoleId = role
        });

        await dbContext.SaveChangesAsync();
        var invitationid = dbContext.HcpPortalUserInvitations.First().Id;
        _context.Set(invitationid, "invitationId");
    }

    [When("I corrupt the invitation Id")]
    public void WhenICorruptTheInvitationId()
    {
        _context.Set(Guid.NewGuid(), "invitationId");
    }

    [Given("an expired invitation exists")]
    public async Task GivenAnExpiredInvitationExists()
    {
        using var scope = _factory.Services.CreateScope();

        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();

        dbContext.HcpPortalUserInvitations.Add(new()
        {
            ExpiresAt = DateTimeOffset.UtcNow.AddDays(-1),
            InternalReferenceName = "InternalReferenceName",
            InvitationSenderId = "InvitationSenderId",
            Language = "en",
            ReceiverEmail = "invitee@nwadhealthdev.com",
            RoleId = "CustomerAdmin"
        });

        await dbContext.SaveChangesAsync();
        var invitationid = dbContext.HcpPortalUserInvitations.First().Id;
        _context.Set(invitationid, "invitationId");
    }

    [Given("^an invitation with role (CustomerAdmin|Hcp) and status (expired|revoked) exists")]
    public async Task GivenAnInvitationWithRoleAndStatusExists(string role, string status)
    {
        var (days, revoked) = status switch
        {
            "expired" => (-1, false),
            "revoked" => (1, true),
            _ => throw new NotImplementedException()
        };

        using var scope = _factory.Services.CreateScope();

        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();

        dbContext.HcpPortalUserInvitations.Add(new()
        {
            ExpiresAt = DateTimeOffset.UtcNow.AddDays(days),
            InternalReferenceName = "InternalReferenceName",
            InvitationSenderId = "verified",
            Language = "en",
            IsRevoked = revoked,
            ReceiverEmail = "invitee@nwadhealthdev.com",
            RoleId = role,
        });

        await dbContext.SaveChangesAsync();
        var invitationid = dbContext.HcpPortalUserInvitations.First().Id;
        _context.Set(invitationid, "invitationId");
    }

    [When("I accept the invitation")]
    public async Task WhenIAcceptTheInvitation()
    {
        var client = _context.Get<HttpClient>();
        var invitationId = _context.Get<Guid>("invitationId");

        var response = await client.GetAsync($"HcpPortal/Invitation/accept/{invitationId}");

        _context.Set(response);
    }

    [When("^I revoke the invitation with role (CustomerAdmin|Hcp)")]
    public async Task WhenIRevokeTheInvitationWithRole(string role)
    {
        var client = _context.Get<HttpClient>();
        var invitationId = _context.Get<Guid>("invitationId");

        var response = await client.PostAsJsonAsync($"HcpPortal/Invitation/{role}/revoke", new InvitationIdRequestDto(invitationId));

        _context.Set(response);
    }

    [When("^I resend the invitation with role (CustomerAdmin|Hcp)")]
    public async Task WhenIResendTheInvitationWithRole(string role)
    {
        var client = _context.Get<HttpClient>();
        var invitationId = _context.Get<Guid>("invitationId");

        var response = await client.PostAsJsonAsync($"HcpPortal/Invitation/{role}/resend", new InvitationIdRequestDto(invitationId));

        _context.Set(response);
    }

    [When("^I request the invitations with role (.*)")]
    public async Task WhenIRequestTheInvitationsWithRole(string role)
    {
        var client = _context.Get<HttpClient>();
        var response = await client.GetAsync($"HcpPortal/Invitation/{role}");

        _context.Set(response);
    }

    [When("I attempt to sign up")]
    public async Task WhenIAttemptToSignUp()
    {
        await SignUp("dk");
    }

    [When("I attempt to sign up with invalid country")]
    public async Task WhenIAttemptToSignUpWithInvalidCountry()
    {
        await SignUp("ug");
    }

    private async Task SignUp(string country)
    {
        var client = _context.Get<HttpClient>();
        var invitationId = _context.Get<Guid>("invitationId");

        var dto = new SignUpRequestDto(
           invitationId,
           "OwnName",
           country
       );

        var response = await client.PostAsJsonAsync("HcpPortal/Invitation/signUp", dto);

        _context.Set(response);
    }

    [Then("the backend responds with a password reset ticket url")]
    public async Task TheBackendRespondsWithAPasswordResetTicketUrlAsync()
    {
        var resp = _context.Get<HttpResponseMessage>();
        var data = await resp.Content.ReadFromJsonAsync<SignUpResponseDto>();
        Assert.Equal("resetPasswordUrl", data!.RedirectTo);
    }

    [Then("the backend responds with a redirect to sign-up page")]
    public void TheBackendRespondsWithARedirectToSignUpPage()
    {
        var resp = _context.Get<HttpResponseMessage>();
        Assert.Contains("signup", resp.RequestMessage!.ToString());
    }

    [Then("the backend responds with a redirect to expired invitation page")]
    public void TheBackendRespondsWithARedirectToExpiredInvitationPage()
    {
        var resp = _context.Get<HttpResponseMessage>();
        Assert.Contains("expired", resp.RequestMessage!.ToString());
    }

    [Then("the backend responds with a redirect to revoked invitation page")]
    public void TheBackendRespondsWithARedirectToRevokedInvitationPage()
    {
        var resp = _context.Get<HttpResponseMessage>();
        Assert.Contains("revoked", resp.RequestMessage!.ToString());
    }

    [Then("the backend responds with a redirect to error page")]
    public void TheBackendRespondsWithARedirectToInvalidInvitationPage()
    {
        var resp = _context.Get<HttpResponseMessage>();
        Assert.Contains("error", resp.RequestMessage!.ToString());
    }

    [When("^I request available languages for (.*) invitations")]
    public async Task WhenIRequestAvailableLanguagesForRoleInvitations(string role)
    {
        var client = _context.Get<HttpClient>();

        var response = await client.GetAsync($"HcpPortal/invitation/{role}/languages");

        _context.Set(response);
    }

    [When("I invite a customer admin")]
    public async Task WhenIInviteACustomerAdmin()
    {
        var client = _context.Get<HttpClient>();

        var dto = new InvitationRequestDto(
            "invitee@nwadhealthdev.com",
            "InternalReferenceName",
            "en"
        );

        var response = await client.PostAsJsonAsync("/hcpPortal/invitation/customerAdmin", dto);

        _context.Set(response);
    }

    [When("I invite a customer admin with an invalid invitation language")]
    public async Task WhenIInviteACustomerAdminWithInvalidLanguage()
    {
        var client = _context.Get<HttpClient>();

        var dto = new InvitationRequestDto(
            "invitee@nwadhealthdev.com",
            "InternalReferenceName",
            "ab"
        );

        var response = await client.PostAsJsonAsync("/hcpPortal/invitation/customerAdmin", dto);

        _context.Set(response);
    }

    [Then("^I get the available languages for (.*) invitations")]
    public async Task ThenIGetTheAvailableLanguagesForRoleInvitations(string role)
    {
        var expectedLanguages = role switch
        {
            "CustomerAdmin" => new List<string> { "da", "en" },
            "Hcp" => new List<string> { "en" },
            "Patient" => new List<string> { "en" },
            _ => throw new ArgumentException("Invalid role", nameof(role))
        };

        var response = _context.Get<HttpResponseMessage>();

        var data = await response.Content.ReadFromJsonAsync<IEnumerable<string>>();

        foreach (var lang in expectedLanguages)
        {
            Assert.Contains(lang, data!);
        }
    }

    [Then("^I get invitations with role (.*)")]
    public async Task ThenIGetInvitationsWithRole(string role)
    {
        var response = _context.Get<HttpResponseMessage>();
        var data = await response.Content.ReadFromJsonAsync<PaginatedItems<InvitationResponseDto>>();

        var invitationIds = data!.Data.Select(i => i.Id);

        using var scope = _factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();

        var storedInvitations = dbContext.HcpPortalUserInvitations.Where(inv => invitationIds.Contains(inv.Id)).ToList();

        Assert.NotEmpty(storedInvitations);
        Assert.All(storedInvitations, storedInv => Assert.Equal(role, storedInv.RoleId));
    }

    [Then("^I get the (revoked|resent) invitation with role (.*)")]
    public async Task ThenIGetTheInvitationInStatusWithRole(string status, string role)
    {
        var expectedInvitationStatus = status switch
        {
            "revoked" => InvitationStatus.Revoked,
            "resent" => InvitationStatus.Pending,
            _ => throw new NotImplementedException()
        };

        var response = _context.Get<HttpResponseMessage>();
        var invitationId = _context.Get<Guid>("invitationId");

        var data = await response.Content.ReadFromJsonAsync<InvitationResponseDto>();

        using var scope = _factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();

        var storedInvitation = dbContext.HcpPortalUserInvitations.Where(inv => inv.Id == invitationId).FirstOrDefault();

        Assert.Equal(expectedInvitationStatus.StringValue(), data!.Status);
        Assert.Equal(storedInvitation!.RoleId, role);
    }
}
