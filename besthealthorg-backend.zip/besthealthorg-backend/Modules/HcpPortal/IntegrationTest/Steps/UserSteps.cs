﻿using NwadHealth.Besthealthorg.ConsentModule.Infrastructure.Repositories;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Repositories;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.IntegrationTest;

[Binding]

public class UserSteps : IClassFixture<HcpPortalWebApplicationFactory>
{
    private readonly ScenarioContext _context;
    private readonly HcpPortalWebApplicationFactory _factory;
    private readonly IdentityPropertiesRepository _identityPropertiesRepo;
    private readonly RoleAssignmentRepository _roleAssignmentRepo;
    private readonly string _userIdToDelete = "verified";

    public UserSteps(ScenarioContext context, HcpPortalWebApplicationFactory factory)
    {
        _context = context;
        _factory = factory;
        _identityPropertiesRepo = new IdentityPropertiesRepository(HcpPortalWebApplicationFactory.Configuration, HcpPortalWebApplicationFactory.AzureClientProvider);
        _roleAssignmentRepo = new RoleAssignmentRepository(HcpPortalWebApplicationFactory.Configuration, HcpPortalWebApplicationFactory.AzureClientProvider);
    }

    [When("^I request to delete (CustomerAdmin|Hcp) account")]
    public async Task WhenIRequestToDeleteSomebodysAccount(string role)
    {
        var client = _context.Get<HttpClient>();
        var response = await client.DeleteAsync($"HcpPortal/User/{role}/{_userIdToDelete}");

        _context.Set(response);
    }

    [Given("^an user with role (.*) exists")]
    public async Task GivenAnUserWithRoleExists(string role)
    {
        using var scope = _factory.Services.CreateScope();

        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();

        dbContext.HcpPortalUserMetadata.Add(new()
        {
            IdentityId = "auth0|6579a3c43f2255716297" + role,
            InternalReferenceName = "InternalReferenceName",
            OwnName = "testOwnName",
            Email = "test@mail.com",
            CreatedAt = DateTimeOffset.UtcNow.AddDays(-1),
            Language = "en"
        });

        await _identityPropertiesRepo.Create(new()
        {
            IdentityId = "auth0|6579a3c43f2255716297" + role,
            CountryCode = "dk"
        });

        await _roleAssignmentRepo.CreateRoleAssignment(new()
        {
            Id = "auth0|6579a3c43f2255716297" + role,
            RoleId = role
        });

        await dbContext.SaveChangesAsync();
    }

    [When("^I request the users with role (.*)")]
    public async Task WhenIRequestTheUsersWithRole(string role)
    {
        var client = _context.Get<HttpClient>();
        var response = await client.GetAsync($"HcpPortal/User/{role}");

        _context.Set(response);
    }

    [Then("^I get users with role (.*)")]
    public async Task ThenIGetInvitationsWithRole(string role)
    {
        var response = _context.Get<HttpResponseMessage>();
        var paginatedItems = await response.Content.ReadFromJsonAsync<PaginatedItems<UserResponseDto>>();

        var userIds = paginatedItems!.Data!.Select(i => i.Id);

        using var scope = _factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();

        var storedMetadata = dbContext.HcpPortalUserMetadata.Where(metadata => userIds.Contains(metadata.IdentityId)).ToList();

        var roleAssignments = new List<RoleAssignment>();
        foreach (var id in userIds)
        {
            var roleAssignment = await _roleAssignmentRepo.GetRoleAssignmentByIdentityId(id);
            if (roleAssignment is not null)
            {
                roleAssignments.Add(roleAssignment);
            }
        }

        Assert.NotEmpty(storedMetadata);
        Assert.All(roleAssignments, roles => Assert.Equal(role, roles.RoleId));
    }
}
