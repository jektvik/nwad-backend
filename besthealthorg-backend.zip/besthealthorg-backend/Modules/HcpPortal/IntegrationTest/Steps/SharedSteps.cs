﻿using NwadHealth.Besthealthorg.Foundation.Extensions.Cosmos;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure.Models;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.DbModels;
using Microsoft.Azure.Cosmos;
using Microsoft.EntityFrameworkCore;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.IntegrationTest;

[Binding]
public sealed class SharedSteps : IClassFixture<HcpPortalWebApplicationFactory>
{
    private readonly ScenarioContext _context;
    private readonly HcpPortalWebApplicationFactory _factory;
    private readonly CosmosClient _cosmosClient;
    private readonly Container _roleAssignmentsContainer;
    private readonly string _userIdToDelete = "verified";

    public SharedSteps(ScenarioContext context, HcpPortalWebApplicationFactory factory)
    {
        _context = context;
        _factory = factory;
        var config = HcpPortalWebApplicationFactory.Configuration;
        _cosmosClient = HcpPortalWebApplicationFactory.AzureClientProvider.GetCosmosClient(config.CosmosDbConnectionString);
        _roleAssignmentsContainer = _cosmosClient.GetContainer(config.CosmosDbDatabaseName, config.CosmosDbRoleAssignmentsContainer);
    }

    [Given("A running backend")]
    public void GivenARunningBackend()
    {
        _context.Set(_factory.CreateClient());
    }

    [Given("^I have the (.*) role assigned")]
    public async Task GivenIHaveTheXRoleAsigned(string role)
    {
        var roleAssignment = new RoleAssignmentDocument
        {
            Id = _context.Get<string>("userId"),
            RoleId = role
        };

        await _roleAssignmentsContainer.CreateItemAsync<RoleAssignmentDocument>(roleAssignment, new PartitionKey(roleAssignment.Id));
    }

    [Given("^The user to be deleted has a (CustomerAdmin|Hcp) role assigned")]
    public async Task GivenTheUserToBeDeletedHasACustomerAdminRoleAssigned(string role)
    {
        var roleAssignment = new RoleAssignment() { Id = _userIdToDelete, RoleId = role };

        await _roleAssignmentsContainer.CreateItemAsync(roleAssignment);
    }

    [Given("I have metadata")]
    public async Task GivenIHaveMetadata()
    {
        using var scope = _factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();

        dbContext.HcpPortalUserMetadata.Add(new HcpPortalUserMetadataDbModel
        {
            IdentityId = _context.Get<string>("userId"),
            InternalReferenceName = "ReferenceName",
            OwnName = "OwnName",
            Email="test@mail.com",
            CreatedAt = DateTimeOffset.UtcNow.AddDays(-1),
            Language = "en",
        });

        await dbContext.SaveChangesAsync();
    }

    [BeforeScenario]
    public async Task ResetDatabases()
    {
        var cosmosClient = HcpPortalWebApplicationFactory.AzureClientProvider.GetCosmosClient(HcpPortalWebApplicationFactory.CosmosDbConnectionString);
        var rolesContainer = cosmosClient.GetContainer("identity", "roles");
        var roleAssignmentsContainer = cosmosClient.GetContainer("identity", "roleAssignments");
        var identityPropertiesContainer = cosmosClient.GetContainer("identity", "identityProperties");

        foreach (var roleAssignment in await roleAssignmentsContainer.GetAll<RoleAssignmentDocument>())
        {
            await roleAssignmentsContainer.DeleteItemAsync<RoleAssignmentDocument>(
                 id: roleAssignment.Id,
                 partitionKey: new PartitionKey(roleAssignment.Id));
        }

        foreach (var role in await rolesContainer.GetAll<RoleDocument>())
        {
            await rolesContainer.DeleteItemAsync<RoleDocument>(
                id: role.Id,
                partitionKey: new PartitionKey(role.Id)
            );
        }

        foreach (var property in await identityPropertiesContainer.GetAll<IdentityPropertiesDocument>())
        {
            await identityPropertiesContainer.DeleteItemAsync<IdentityPropertiesDocument>(
                id: property.Id,
                partitionKey: new PartitionKey(property.Id)
            );
        }

        var rolesToSeed = new List<RoleDocument>
        {
            new()
            {
                Id = "NwadAdmin",
                Name = "Nwad Admin"
            },
            new()
            {
                Id = "CustomerAdmin",
                Name = "Customer Admin"
            },
            new()
            {
                Id = "Hcp",
                Name = "HCP"
            },
            new()
            {
                Id = "Patient",
                Name = "Patient"
            }
        };

        foreach (var role in rolesToSeed)
        {
            await rolesContainer.CreateItemAsync<RoleDocument>(role, new PartitionKey(role.Id));
        }

        using var scope = _factory.Services.CreateScope();
        var sqlContext = scope.ServiceProvider.GetRequiredService<HcpPortalTestDbContext>();
        sqlContext.Database.EnsureCreated();
        sqlContext.HcpPortalUserInvitations.ExecuteDelete();
        sqlContext.HcpPortalUserMetadata.ExecuteDelete();
        sqlContext.DataSharingPermissionRequests.ExecuteDelete();
        sqlContext.DataSharingPermissions.ExecuteDelete();
        sqlContext.SaveChanges();
    }
}
