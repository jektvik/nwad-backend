using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using NwadHealth.Besthealthorg.TestUtilities.IntegrationTestHelpers;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace NwadHealth.Besthealthorg.HcpPortalModule.IntegrationTest;

public class HcpPortalWebApplicationFactory : PaceWebApplicationFactory
{
    public static Configuration Configuration { get; } = new(CosmosDbConnectionString) { IsEmailVerificationRequired = true };

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        base.ConfigureWebHost(builder);

        builder.ConfigureServices(services =>
        {
            services
                .AddControllers()
                .AddApplicationPart(typeof(Frameworks.Controllers.InvitationController).Assembly);

            services.AddDbContext<HcpPortalTestDbContext>(o => o.UseSqlServer(SqlDbConnectionString));

            var plugin = new TestIdentityPlugin(JwtHelper.TokenSigningKey);

            services.AddPaceIdentity(Configuration, plugin);

            services.AddPaceHcpPortal<HcpPortalTestDbContext>(
                new HcpPortalConfiguration(
                    "backendApiUrl/",
                    "frontendBaseUrl/",
                    "webAppClientId",
                    "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"
                )
            );

            services.Replace(ServiceDescriptor.Scoped<IMailer, MailerStub>());
        });

        builder.Configure(app =>
        {
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UsePaceIdentity();
            app.UseEndpoints(conf => conf.MapControllers());

            using (var scope = app.ApplicationServices.CreateScope())
            {
                var services = scope.ServiceProvider;
                var context = services.GetRequiredService<HcpPortalTestDbContext>();
                context.Database.EnsureCreated();
                context.SaveChanges();
            }
        });
    }
}
