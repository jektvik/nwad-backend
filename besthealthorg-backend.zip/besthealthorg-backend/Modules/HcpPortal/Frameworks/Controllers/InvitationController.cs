using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.Foundation.Extensions.Controller;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.Foundation.Extensions;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Controllers;

/// <summary>
/// Contains endpoints relating to the HCP Portal invitations
/// </summary>
[ApiController]
[Route("HcpPortal/[controller]")]
public class InvitationController : ControllerBase
{
    private readonly ILogger<InvitationController> _logger;

    /// <summary>
    /// Initializes the HcpPortalController
    /// </summary>
    /// <param name="logger">The logger to use</param>
    public InvitationController(ILogger<InvitationController> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Gets the available languages for customer admin invitations
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    [HttpGet("customerAdmin/languages", Name = "Customer Admin invitation languages")]
    [Authorize(Roles = "NwadAdmin")]
    [ProducesResponseType(typeof(IEnumerable<string>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> CustomerAdminInvitationLanguages([FromServices] IGetAvailableEmailInvitationLanguagesInteractor interactor)
    {
        return Ok(await interactor.Execute(HcpPortalRole.CustomerAdmin.StringValue()));
    }

    /// <summary>
    /// Gets the available languages for HCP invitations
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    [HttpGet("hcp/languages", Name = "HCP invitation languages")]
    [Authorize(Roles = "CustomerAdmin")]
    [ProducesResponseType(typeof(IEnumerable<string>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> HcpInvitationLanguages([FromServices] IGetAvailableEmailInvitationLanguagesInteractor interactor)
    {
        return Ok(await interactor.Execute(HcpPortalRole.Hcp.StringValue()));
    }

    /// <summary>
    /// Invites a customer admin to the HCP portal
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="inviteDto">Dto to create the invitation with</param>
    [HttpPost("customerAdmin", Name = "Invite Customer Admin")]
    [Authorize(Roles = "NwadAdmin")]
    [ProducesResponseType(typeof(InvitationResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status409Conflict)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> InviteCustomerAdmin([FromServices] IInviteCustomerAdminInteractor interactor, InvitationRequestDto inviteDto)
    {
        _logger.LogInformation("Proccessing request to InviteCustomerAdmin");

        return await HandleInvitationRequest(interactor, inviteDto, nameof(InviteCustomerAdmin));
    }

    /// <summary>
    /// Invites an HCP to the HCP portal
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="inviteDto">Request data to create the invitation with</param>
    [HttpPost("hcp", Name = "Invite Health Care Provider")]
    [Authorize(Roles = "CustomerAdmin")]
    [ProducesResponseType(typeof(InvitationResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status409Conflict)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> InviteHcp([FromServices] IInviteHcpInteractor interactor, InvitationRequestDto inviteDto)
    {
        _logger.LogInformation("Proccessing request to InviteHcp");

        return await HandleInvitationRequest(interactor, inviteDto, nameof(InviteHcp));
    }

    /// <summary>
    /// Verify if the link is not expired, revoked, or already accepted
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="invitationId">Guid of the invitation</param>
    [HttpGet("accept/{invitationId}", Name = "Accept Invitation")]
    [ProducesResponseType(StatusCodes.Status301MovedPermanently)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> AcceptInvitation([FromServices] IAcceptInvitationInteractor interactor, Guid invitationId)
    {
        _logger.LogInformation("Proccessing request to AcceptInvitation");

        return Redirect(await interactor.Execute(invitationId));
    }

    /// <summary>
    /// Sign up - create user in auth0...
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="signUpDto">User's metadata</param>
    [HttpPost("signUp", Name = "Sign Up")]
    [ProducesResponseType(typeof(SignUpResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status502BadGateway)]
    public async Task<IActionResult> SignUp([FromServices] ISignUpInteractor interactor, SignUpRequestDto signUpDto)
    {
        _logger.LogInformation("Proccessing request to Sign Up");

        try
        {
            var response = new SignUpResponseDto(await interactor.Execute(signUpDto.InvitationId, signUpDto.OwnName, signUpDto.Country));
            return Created(string.Empty, response);
        }
        catch (InvitationNotFoundException)
        {
            _logger.LogError("Invitation does not exist");

            return this.InvitationNotFoundError();
        }
        catch (InvalidInvitationStatusException)
        {
            _logger.LogError("The invitation is not in pending status");

            return this.InvalidInvitationStatusError();
        }
        catch (ExpiredInvitationException)
        {
            _logger.LogError("The invitation has expired");

            return this.ExpiredInvitationError();
        }
        catch (SignUpFailedException)
        {
            _logger.LogError("Something went wrong during the sign up process");

            return this.SignUpFailedError();
        }
        catch (UnsupportedCountryException)
        {
            _logger.LogError("The selected country is not supported");

            return this.UnsupportedCountryError();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during Sign Up request processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Get non accepted customer admin invitations
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="paginationRequest">The request object containing pagination parameters</param>
    /// <param name="sortRequest">The request object containing sorting parameters</param>
    /// <param name="searchQuery">Keyword used for searching the permission requests</param>
    [HttpGet("customerAdmin", Name = "Get customer admin invitations")]
    [Authorize(Roles = "NwadAdmin")]
    [ProducesResponseType(typeof(PaginatedItems<InvitationResponseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetCustomerAdminInvitations(
        [FromServices] IGetInvitationsInteractor interactor,
        [FromQuery] PaginationRequest paginationRequest,
        [FromQuery] SortRequest sortRequest,
        [FromQuery] string? searchQuery = null)
    {
        _logger.LogInformation("Processing request to Get Customer Admin Invitations");

        try
        {
            var response = await interactor.Execute(HcpPortalRole.CustomerAdmin.StringValue(), paginationRequest, sortRequest, searchQuery);

            return Ok(response.MapItems(InvitationResponseDto.FromDomain));
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during Get Customer Admin Invitations processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Gets non accepted Hcp invitations
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="paginationRequest">The request object containing pagination parameters</param>
    /// <param name="sortRequest">The request object containing sorting parameters</param>
    /// <param name="searchQuery">Keyword used for searching the permission requests</param>
    [HttpGet("Hcp", Name = "Get Hcp invitations")]
    [Authorize(Roles = "CustomerAdmin")]
    [ProducesResponseType(typeof(PaginatedItems<InvitationResponseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetHcpInvitations(
        [FromServices] IGetInvitationsInteractor interactor,
        [FromQuery] PaginationRequest paginationRequest,
        [FromQuery] SortRequest sortRequest,
        [FromQuery] string? searchQuery = null)
    {
        _logger.LogInformation("Processing request to Get Hcp Invitations");

        try
        {
            var response = await interactor.Execute(HcpPortalRole.Hcp.StringValue(), paginationRequest, sortRequest, searchQuery);

            return Ok(response.MapItems(InvitationResponseDto.FromDomain));
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during Get Hcp Invitations processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Revoke Customer Admin invitation
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="invitationIdDto">Request object to extract the invitation Id from</param>
    [HttpPost("customerAdmin/revoke", Name = "Revoke Customer Admin invitation")]
    [Authorize(Roles = "NwadAdmin")]
    [ProducesResponseType(typeof(InvitationResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> RevokeCustomerAdminInvitation(
        [FromServices] IRevokeCustomerAdminInvitationInteractor interactor,
        [FromBody] InvitationIdRequestDto invitationIdDto)
    {
        _logger.LogInformation("Processing request to Revoke Customer Admin Invitation");

        return await HandleRevokeInvitationRequest(interactor, invitationIdDto.InvitationId, nameof(RevokeCustomerAdminInvitation));
    }

    /// <summary>
    /// Revoke Hcp invitation
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="invitationIdDto">Request object to extract the invitation Id from</param>
    [HttpPost("Hcp/revoke", Name = "Revoke Hcp invitation")]
    [Authorize(Roles = "CustomerAdmin")]
    [ProducesResponseType(typeof(InvitationResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> RevokeHcpInvitation(
        [FromServices] IRevokeHcpInvitationInteractor interactor,
        [FromBody] InvitationIdRequestDto invitationIdDto)
    {
        _logger.LogInformation("Proccessing request to Revoke HCP Invitation");

        return await HandleRevokeInvitationRequest(interactor, invitationIdDto.InvitationId, nameof(RevokeHcpInvitation));
    }

    /// <summary>
    /// Resend Customer Admin invitation
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="invitationIdDto">Request object to extract the invitation Id from</param>
    [HttpPost("customerAdmin/resend", Name = "Resend Customer Admin invitation")]
    [Authorize(Roles = "NwadAdmin")]
    [ProducesResponseType(typeof(InvitationResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> ResendCustomerAdminInvitation(
        [FromServices] IResendCustomerAdminInvitationInteractor interactor,
        [FromBody] InvitationIdRequestDto invitationIdDto)
    {
        _logger.LogInformation("Processing request to Resend Customer Admin Invitation");

        return await HandleResendInvitationRequest(interactor, invitationIdDto.InvitationId, nameof(ResendCustomerAdminInvitation));
    }

    /// <summary>
    /// Resend Hcp invitation
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="invitationIdDto">Request object to extract the invitation Id from</param>
    [HttpPost("Hcp/resend", Name = "Resend Hcp invitation")]
    [Authorize(Roles = "CustomerAdmin")]
    [ProducesResponseType(typeof(InvitationResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> ResendHcpInvitation(
        [FromServices] IResendHcpInvitationInteractor interactor,
        [FromBody] InvitationIdRequestDto invitationIdDto)
    {
        _logger.LogInformation("Processing request to Resend HCP Invitation");

        return await HandleResendInvitationRequest(interactor, invitationIdDto.InvitationId, nameof(ResendHcpInvitation));
    }

    private async Task<IActionResult> HandleInvitationRequest(IInvitationInteractorBase interactor, InvitationRequestDto invitationDto, string callerName)
    {
        try
        {
            var hcpPortalUserInvitation = await interactor.Execute(invitationDto.ToDomain(HttpContext.CurrentIdentityId()));

            return Created(string.Empty, InvitationResponseDto.FromDomain(hcpPortalUserInvitation));
        }
        catch (UnsupportedInvitationLanguageException e)
        {
            _logger.LogError(e, "The chosen language is not supported");

            return this.UnsupportedInvitationLanguageError();
        }
        catch (IdentityAlreadyExistsException e)
        {
            _logger.LogError(e, "This user already exists");

            return this.IdentityAlreadyExistsError();
        }
        catch (EmailAlreadyInvitedException e)
        {
            _logger.LogError(e, "Invitation has already been sent to this email address");

            return this.EmailAlreadyInvitedError();
        }
        catch (NoHcpPortalMetadataForIdentityException e)
        {
            _logger.LogError(e, "No HCP portal metadata is associated with this identity");

            return this.NoHcpPortalMetadataForIdentityError();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during {callerName} request processing", callerName);

            return this.UnexpectedError();
        }
    }

    private async Task<IActionResult> HandleRevokeInvitationRequest(IRevokeInvitationInteractorBase interactor, Guid invitationId, string callerName)
    {
        try
        {
            var hcpPortalUserInvitation = await interactor.Execute(invitationId);

            return Ok(InvitationResponseDto.FromDomain(hcpPortalUserInvitation));
        }
        catch (InvalidInvitationStatusException e)
        {
            _logger.LogError(e, "The invitation is not in pending status");

            return this.InvalidInvitationStatusError();
        }
        catch (InvitationNotFoundException e)
        {
            _logger.LogError(e, "Invitation does not exist");

            return this.InvitationNotFoundError();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during {callerName} request processing", callerName);

            return this.UnexpectedError();
        }
    }

    private async Task<IActionResult> HandleResendInvitationRequest(IResendInvitationInteractorBase interactor, Guid invitationId, string callerName)
    {
        try
        {
            var hcpPortalUserInvitation = await interactor.Execute(invitationId, HttpContext.CurrentIdentityId());

            return Ok(InvitationResponseDto.FromDomain(hcpPortalUserInvitation));
        }
        catch (InvalidInvitationStatusException e)
        {
            _logger.LogError(e, "The invitation is not in pending status");

            return this.InvalidInvitationStatusError();
        }
        catch (InvitationNotFoundException e)
        {
            _logger.LogError(e, "Invitation does not exist");

            return this.InvitationNotFoundError();
        }
        catch (UnsupportedInvitationLanguageException e)
        {
            _logger.LogError(e, "The chosen language is not supported");

            return this.UnsupportedInvitationLanguageError();
        }
        catch (NoHcpPortalMetadataForIdentityException e)
        {
            _logger.LogError(e, "No HCP portal metadata is associated with this identity");

            return this.NoHcpPortalMetadataForIdentityError();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during {callerName} request processing", callerName);

            return this.UnexpectedError();
        }
    }
}
