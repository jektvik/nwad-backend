using NwadHealth.Besthealthorg.Foundation.Extensions.Controller;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.PermissionModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.PermissionModule.Frameworks.Dtos.Response;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.PermissionModule.Domain.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.PermissionModule.Frameworks;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Controllers;

/// <summary>
/// Contains endpoints relating to patient to HCP data sharing request
/// </summary>
[ApiController]
[Route("HcpPortal/[controller]")]
public class DataSharingRequestController : ControllerBase
{
    private readonly ILogger<DataSharingRequestController> _logger;

    /// <summary>
    /// Initializes the DataSharingRequestController
    /// </summary>
    /// <param name="logger">The logger to use</param>
    public DataSharingRequestController(ILogger<DataSharingRequestController> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Requests a patient to share their data
    /// </summary>
    /// <param name="hcpRequestInteractor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="dataSharingRequestInteractor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="dto">Data for the sharing request</param>
    /// <returns>An IActionResult representing the result of the endpoint call</returns>
    /// <response code="200">Data sharing request was successfully created</response>
    [HttpPost(Name = "RequestHcpDataSharing")]
    [Produces("application/json")]
    [ProducesResponseType(typeof(DataSharingPermissionResponseDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status409Conflict)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    [Authorize(Roles = "Hcp")]
    public async Task<IActionResult> RequestDataSharing(
        [FromServices] ICreateHcpDataSharingRequestInteractor hcpRequestInteractor,
        [FromServices] ICreateDataSharingPermissionRequestInteractor dataSharingRequestInteractor,
        RequestHcpDataSharingRequestDto dto)
    {
        _logger.LogInformation("Processing request to RequestHcpDataSharing");

        try
        {
            var request = await hcpRequestInteractor.Execute(HttpContext.CurrentIdentityId(), dto.PatientEmail, dto.PatientIdentifier);

            var result = await dataSharingRequestInteractor.Execute(request);

            return Created(string.Empty, DataSharingPermissionRequestResponseDto.FromDomain(result));
        }
        catch (NoHcpPortalMetadataForIdentityException e)
        {
            _logger.LogError(e, "No HCP portal metadata is associated with this identity");

            return this.NoHcpPortalMetadataForIdentityError();
        }
        catch (IdentityNotFoundException e)
        {
            _logger.LogError(e, "Patient or HCP identity could not be found");

            return this.IdentityNotFoundError();
        }
        catch (PermissionAlreadyExistsException e)
        {
            _logger.LogError(e, "HCP and patient are already linked");

            return this.DuplicatePatientLinkError();
        }
        catch (PermissionRequestAlreadyExistsException e)
        {
            _logger.LogError(e, "HCP and patient already have a link reqest");

            return this.DuplicatePatientRequestError();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during RequestHcpDataSharing request processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Resends a data sharing permission request with the given id
    /// </summary>
    /// <param name="config">The configuration to use for getting expiry time. This is provided by DI</param>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="id">The id of the data sharing permission request to resend</param>
    /// <returns>An IActionResult representing the result of the endpoint call</returns>
    /// <response code="200">Data sharing permission request successfully resent</response>
    /// <response code="400">Data sharing permission request is in invalid state for this operation</response>
    /// <response code="404">Data sharing permission request could not be found</response>
    [HttpPost("{id}/resend", Name = "ResendDataSharingPermissionRequest")]
    [Produces("application/json")]
    [ProducesResponseType(typeof(DataSharingPermissionRequestResponseDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [Authorize(Roles = "Hcp")]
    public async Task<IActionResult> ResendDataSharingPermissionRequest(
        [FromServices] HcpPortalConfiguration config,
        [FromServices] IResendDataSharingPermissionRequestInteractor interactor,
        Guid id)
    {
        _logger.LogInformation("Processing request to ResendDataSharingPermissionRequest");

        try
        {
            var result = await interactor.Execute(HttpContext.CurrentIdentityId(), id, config.DataSharingRequestExpiryTime);

            return Ok(DataSharingPermissionRequestResponseDto.FromDomain(result));
        }
        catch (InvalidDataSharingPermissionRequestStatusException e)
        {
            _logger.LogInformation(e, "The data sharing permission request is in an invalid status for this operation");
            return this.DataSharingPermissionRequestInvalidStatusError(e.Request);
        }
        catch (DataSharingPermissionRequestNotFoundException e)
        {
            _logger.LogInformation(e, "The data sharing permission request could not be found");
            return this.DataSharingPermissionRequestNotFoundError();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during ResendDataSharingPermissionRequest request processing");
            return this.UnexpectedError();
        }
    }
}
