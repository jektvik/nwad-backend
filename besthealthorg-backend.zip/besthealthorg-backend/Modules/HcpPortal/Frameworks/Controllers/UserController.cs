﻿using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.Foundation.Extensions;
using NwadHealth.Besthealthorg.Foundation.Extensions.Controller;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.IdentityModule.Frameworks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Controllers;

/// <summary>
/// Contains endpoints relating to the HCP Portal users
/// </summary>
[ApiController]
[Route("HcpPortal/[controller]")]
public class UserController : ControllerBase
{
    private readonly ILogger<UserController> _logger;

    /// <summary>
    /// Initializes the HcpPortalController
    /// </summary>
    /// <param name="logger">The logger to use</param>
    public UserController(ILogger<UserController> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Gets all Customer Admin users
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="paginationRequest">The request object containing pagination parameters</param>
    /// <param name="sortRequest">The request object containing sorting parameters</param>
    /// <param name="searchQuery">Keyword used for searching the users</param>
    [HttpGet("CustomerAdmin", Name = "Get Customer Admin users")]
    [Authorize(Roles = "NwadAdmin")]
    [ProducesResponseType(typeof(PaginatedItems<UserResponseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetCustomerAdmins(
        [FromServices] IGetUsersInteractor interactor,
        [FromQuery] PaginationRequest paginationRequest,
        [FromQuery] SortRequest sortRequest,
        [FromQuery] string? searchQuery)
    {
        _logger.LogInformation("Processing request to Get Customer Admins");

        try
        {
            var response = await interactor.Execute(HcpPortalRole.CustomerAdmin, paginationRequest, sortRequest, searchQuery);

            return Ok(response.MapItems(UserResponseDto.FromDomain));
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during Get Customer Admins processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Gets all Hcp users
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="paginationRequest">The request object containing pagination parameters</param>
    /// <param name="sortRequest">The request object containing sorting parameters</param>
    /// <param name="searchQuery">Keyword used for searching the users</param>
    [HttpGet("Hcp", Name = "Get Hcp users")]
    [Authorize(Roles = "CustomerAdmin")]
    [ProducesResponseType(typeof(PaginatedItems<UserResponseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> GetHcps(
        [FromServices] IGetUsersInteractor interactor,
        [FromQuery] PaginationRequest paginationRequest,
        [FromQuery] SortRequest sortRequest,
        [FromQuery] string? searchQuery)
    {
        _logger.LogInformation("Processing request to Get HCPs");

        try
        {
            var response = await interactor.Execute(HcpPortalRole.Hcp, paginationRequest, sortRequest, searchQuery);

            return Ok(response.MapItems(UserResponseDto.FromDomain));
        }
        catch (ArgumentException e)
        {
            _logger.LogError(e, "The sort by parameter is not valid");

            return this.InvalidSortByValueError(sortRequest.SortBy);
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during Get HCPs processing");

            return this.UnexpectedError();
        }
    }

    /// <summary>
    /// Deletes a Customer Admin
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="identityId">The id of the Customer Admin to delete</param>
    [HttpDelete("customerAdmin/{identityId}", Name = "Delete Customer Admin")]
    [Authorize(Roles = "NwadAdmin")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> DeleteCustomerAdmin([FromServices] IDeleteCustomerAdminInteractor interactor, string identityId)
    {
        _logger.LogInformation("Processing request to Delete CustomerAdmin");

        return await HandleDeleteRequest(interactor, identityId, nameof(DeleteCustomerAdmin));
    }

    /// <summary>
    /// Deletes a HCP
    /// </summary>
    /// <param name="interactor">The business logic to execute during the request. This is provided by DI</param>
    /// <param name="identityId">The id of the HCP to delete</param>
    [HttpDelete("hcp/{identityId}", Name = "Delete HCP")]
    [Authorize(Roles = "CustomerAdmin")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ErrorResponseDto), StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> DeleteHcp([FromServices] IDeleteHcpInteractor interactor, string identityId)
    {
        _logger.LogInformation("Proccessing request to Delete Hcp");

        return await HandleDeleteRequest(interactor, identityId, nameof(DeleteHcp));
    }

    private async Task<IActionResult> HandleDeleteRequest(
        IDeleteHcpPortalUserInteractorBase interactor, string identityId, string callerName)
    {
        try
        {
            await interactor.Execute(identityId, HttpContext.CurrentIdentityId(), HttpContext.Connection.RemoteIpAddress);
            return NoContent();
        }
        catch (RoleMismatchException e)
        {
            _logger.LogError(e, "The identity does not have a valid role for this operation");

            return this.IdentityNotFoundError();
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occured during {callerName} processing", callerName);

            return this.UnexpectedError();
        }
    }
}
