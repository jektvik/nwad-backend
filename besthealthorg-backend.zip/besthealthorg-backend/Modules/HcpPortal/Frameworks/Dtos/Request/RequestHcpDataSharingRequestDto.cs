using System.ComponentModel.DataAnnotations;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Request;

/// <summary>
/// Request DTO for creating data sharing requests
/// </summary>
/// <param name="PatientEmail">The email of the patient being invited</param>
/// <param name="PatientIdentifier">Optional extra identifier chosen by the HCP</param>
public record RequestHcpDataSharingRequestDto(
    [Required] string PatientEmail,
    string? PatientIdentifier
);
