﻿using System.ComponentModel.DataAnnotations;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Request;

/// <summary>
/// Request DTO for inviting Customer Admins and HCPs
/// </summary>
/// <param name="ReceiverEmail">Email of the person being invited</param>
/// <param name="InternalReferenceName">Invitee name assigned by the inviter</param>
/// <param name="Language">Two letter code according to ISO 639-1 eg: da- Danish, en - English</param>
public record InvitationRequestDto(
    [Required] string ReceiverEmail,
    string? InternalReferenceName,
    [Required] string Language
)
{
    /// <summary>
    /// Converts the dto to a domain model
    /// </summary>
    /// <param name="identityId">The identity id to put on the domain model</param>
    /// <returns>The domain model</returns>
    public HcpPortalUserInvitation ToDomain(string identityId) => new()
    {
        SenderIdentityId = identityId,
        ReceiverEmail = ReceiverEmail,
        InternalReferenceName = InternalReferenceName,
        Language = Language
    };
}
