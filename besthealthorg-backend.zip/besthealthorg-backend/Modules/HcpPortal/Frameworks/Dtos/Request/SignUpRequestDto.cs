﻿using System.ComponentModel.DataAnnotations;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Request;

/// <summary>
/// Request DTO for signing up
/// </summary>
/// <param name="InvitationId">Unique id of the invitation</param>
/// <param name="OwnName">What user calls him/her self</param>
/// <param name="Country">User's country of residence</param>
public record SignUpRequestDto(
    [Required] Guid InvitationId,
    [Required] string OwnName,
    [Required] string Country
);
