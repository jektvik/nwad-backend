﻿using System.ComponentModel.DataAnnotations;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Request;

/// <summary>
/// Request DTO for managing invitations eg: revoke, resend
/// </summary>
/// <param name="InvitationId">Unique id of the invitation</param>
public record InvitationIdRequestDto([Required] Guid InvitationId);
