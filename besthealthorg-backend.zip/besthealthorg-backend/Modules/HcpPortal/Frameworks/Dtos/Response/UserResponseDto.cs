﻿using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Response;

/// <summary>
/// Response DTO for user requests
/// </summary>
public record UserResponseDto
{
    /// <summary>
    /// Identity id of the user
    /// </summary>
    public string Id { get; set; } = string.Empty;

    /// <summary>
    /// Internal reference name of the user
    /// </summary>
    public string? InternalReferenceName { get; set; }

    /// <summary>
    /// Email address of the user
    /// </summary>
    public string Email { get; set; } = string.Empty;

    /// <summary>
    /// DateTime of when user accepted the invitation
    /// </summary>
    public DateTimeOffset DateCreated { get; set; }

    /// <summary>
    /// Country of residence of the user
    /// </summary>
    public string? Country { get; set; }

    /// <summary>
    /// Converts the domain model to response dto
    /// </summary>
    /// <param name="user">The domain model to convert</param>
    public static UserResponseDto FromDomain(HcpPortalUser user)
    {
        return new()
        {
                Id = user.IdentityId,
                InternalReferenceName = user.InternalReferenceName,
                Email = user.Email,
                DateCreated = user.CreatedDateTime,
                Country = user.CountryCode
        };
    }
}
