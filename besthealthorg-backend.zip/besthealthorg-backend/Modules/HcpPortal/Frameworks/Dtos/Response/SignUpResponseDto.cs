﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Response;

/// <summary>
/// Response DTO for invitation requests
/// </summary>
/// <param name="RedirectTo">Url where the user should be redirected to after completing the sign up process</param>
public record SignUpResponseDto(
    string RedirectTo
);
