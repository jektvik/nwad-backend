﻿using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Response;

/// <summary>
/// Response DTO for invitation requests
/// </summary>
public record InvitationResponseDto
{
    /// <summary>
    /// Guid id of the newly created invitation
    /// </summary>
    public Guid Id { get; set; }

    /// <summary>
    /// Name the inviter wants to use for the invitee
    /// </summary>
    public string? InternalReferenceName { get; set; }

    /// <summary>
    /// Email of the invitee
    /// </summary>
    public string ReceiverEmail {  get; set; } = string.Empty;

    /// <summary>
    /// The state of the invitation, allowed values: pending, expired, rejected
    /// </summary>
    public string Status { get; set; } = string.Empty;

    /// <summary>
    /// Converts the domain model to response dto
    /// </summary>
    /// <param name="invitation">The domain model to convert</param>
    public static InvitationResponseDto FromDomain(HcpPortalUserInvitation invitation)
    {
        return new()
        {
            Id = invitation.Id,
            InternalReferenceName = invitation.InternalReferenceName,
            ReceiverEmail = invitation.ReceiverEmail,
            Status = invitation.Status.StringValue()
        };
    }
}
