using Microsoft.AspNetCore.Mvc;
using static NwadHealth.Besthealthorg.Foundation.Extensions.Controller.ErrorResponseExtensions;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Frameworks;

/// <summary>
/// ControllerBase extensions for creating error responses
/// </summary>
public static class ErrorResponseExtensions
{
    /// <summary>
    /// Creates an email already invited result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>An email already invited result</returns>
    public static IActionResult EmailAlreadyInvitedError(this ControllerBase controller) =>
        controller.Conflict(CreateErrorResponseDto("email_already_invited", "Invitation has already been sent to this email address"));

    /// <summary>
    /// Creates an invitation already accepted result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>An invitation already accepted result</returns>
    public static IActionResult IdentityAlreadyExistsError(this ControllerBase controller) =>
        controller.Conflict(CreateErrorResponseDto("identity_already_exists", "This user already exists"));

    /// <summary>
    /// Creates a no HCP portal metadata for identity result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>No HCP portal metadata for identity result</returns>
    public static IActionResult NoHcpPortalMetadataForIdentityError(this ControllerBase controller) =>
        controller.StatusCode(500, CreateErrorResponseDto("no_hcp_portal_metadata_for_identity", "No HCP portal metadata is associated with this identity"));

    /// <summary>
    /// Creates a unsupported invitation language result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>No HCP portal metadata for identity result</returns>
    public static IActionResult UnsupportedInvitationLanguageError(this ControllerBase controller) =>
        controller.BadRequest(CreateErrorResponseDto("unsupported_invitation_language", "The chosen language is not supported"));

    /// <summary>
    /// Creates a invalid country code result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>Invalid country code result</returns>
    public static IActionResult InvitationNotFoundError(this ControllerBase controller) =>
        controller.NotFound(CreateErrorResponseDto("invitation_not_found", "The invitation does not exist"));

    /// <summary>
    /// Creates a invalid invitation status result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>Invalid invitation status result</returns>
    public static IActionResult InvalidInvitationStatusError(this ControllerBase controller) =>
        controller.BadRequest(CreateErrorResponseDto("invalid_invitation_status", "The invitation is in invalid status"));

    /// <summary>
    /// Creates a expired invitation result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>Expired invitation result</returns>
    public static IActionResult ExpiredInvitationError(this ControllerBase controller) =>
        controller.BadRequest(CreateErrorResponseDto("expired_invitation", "The invitation has expired"));

    /// <summary>
    /// Creates a sign up failed result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>Sign up failed result</returns>
    public static IActionResult SignUpFailedError(this ControllerBase controller) =>
        controller.StatusCode(502, CreateErrorResponseDto("sign_up_failed", "Something went wrong during the sign up process"));

    /// <summary>
    /// Creates a duplicate patient link error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>A duplicate patient link error result</returns>
    public static IActionResult DuplicatePatientLinkError(this ControllerBase controller) =>
        controller.Conflict(CreateErrorResponseDto("duplicate_patient_link", "The HCP and patient are already linked"));

    /// <summary>
    /// Creates a duplicate patient request error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>A duplicate patient request error result</returns>
    public static IActionResult DuplicatePatientRequestError(this ControllerBase controller) =>
        controller.Conflict(CreateErrorResponseDto("duplicate_patient_request", "The HCP has already requested to be linked with the patient"));
}
