using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Controllers;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Request;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.PermissionModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.PermissionModule.Domain.Entities;
using NwadHealth.Besthealthorg.PermissionModule.Domain.Exceptions;
using NwadHealth.Besthealthorg.PermissionModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest.Frameworks.Controllers;

public class DataSharingRequestControllerTests
{
    private readonly HcpPortalConfiguration _config;

    public DataSharingRequestControllerTests()
    {
        _config = new HcpPortalConfiguration("1/", "2/", "3/", "4/");
    }
    #region RequestDataSharing

    [Fact]
    public async Task RequestDataSharing_WhenInteractorThrowsNoHcpPortalMetadataForIdentityException_Returns500()
    {
        var hcpRequestInteractorMock = new Mock<ICreateHcpDataSharingRequestInteractor>();
        hcpRequestInteractorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string?>()))
            .ThrowsAsync(new NoHcpPortalMetadataForIdentityException("id"));

        var dataSharingInteractorMock = Mock.Of<ICreateDataSharingPermissionRequestInteractor>();

        var dto = new RequestHcpDataSharingRequestDto("email", "identifier");

        var controller = new DataSharingRequestController(Mock.Of<ILogger<DataSharingRequestController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.RequestDataSharing(hcpRequestInteractorMock.Object, dataSharingInteractorMock, dto);

        Assert.IsType<ObjectResult>(resp);
        var objectResp = resp as ObjectResult;
        Assert.Equal(500, objectResp?.StatusCode);

        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("no_hcp_portal_metadata_for_identity", errorResp!.ErrorCode);
        Assert.Equal("No HCP portal metadata is associated with this identity", errorResp!.Error);
    }

    [Fact]
    public async Task RequestDataSharing_WhenInteractorThrowsIdentityNotFoundException_Returns500()
    {
        var hcpRequestInteractorMock = new Mock<ICreateHcpDataSharingRequestInteractor>();
        hcpRequestInteractorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string?>()))
            .ThrowsAsync(new IdentityNotFoundException("id"));

        var dataSharingInteractorMock = Mock.Of<ICreateDataSharingPermissionRequestInteractor>();

        var dto = new RequestHcpDataSharingRequestDto("email", "identifier");

        var controller = new DataSharingRequestController(Mock.Of<ILogger<DataSharingRequestController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.RequestDataSharing(hcpRequestInteractorMock.Object, dataSharingInteractorMock, dto);

        Assert.IsType<NotFoundObjectResult>(resp);
        var objectResp = resp as NotFoundObjectResult;

        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("identity_not_found", errorResp!.ErrorCode);
        Assert.Equal("The identity was not found", errorResp!.Error);
    }

    [Fact]
    public async Task RequestDataSharing_WhenInteractorThrowsException_Returns500()
    {
        var hcpRequestInteractorMock = new Mock<ICreateHcpDataSharingRequestInteractor>();

        hcpRequestInteractorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string?>()))
            .ThrowsAsync(new Exception());

        var dataSharingInteractorMock = Mock.Of<ICreateDataSharingPermissionRequestInteractor>();

        var dto = new RequestHcpDataSharingRequestDto("email", "identifier");

        var controller = new DataSharingRequestController(Mock.Of<ILogger<DataSharingRequestController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.RequestDataSharing(hcpRequestInteractorMock.Object, dataSharingInteractorMock, dto);

        Assert.IsType<ObjectResult>(resp);
        var objectResult = resp as ObjectResult;

        Assert.IsType<ErrorResponseDto>(objectResult!.Value);
        var error = objectResult!.Value as ErrorResponseDto;

        Assert.Equal(500, objectResult.StatusCode);
        Assert.Equal("unexpected_error", error!.ErrorCode);
        Assert.Equal("An unexpected error occured", error!.Error);
    }

    [Fact]
    public async Task RequestDataSharing_WhenInteractorThrowsPermissionAlreadyExistsException_Returns409()
    {
        var dataSharingPermissionRequest = new DataSharingPermissionRequest("subjectId", "accessorId", "ref", "hcp", DateTimeOffset.UtcNow);
        var dataSharingPermission = new DataSharingPermission("subjectId", "accessorId", "ref", "hcp", DateTimeOffset.UtcNow);

        var hcpRequestInteractorMock = new Mock<ICreateHcpDataSharingRequestInteractor>();
        hcpRequestInteractorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string?>()))
            .ReturnsAsync(dataSharingPermissionRequest);

        var dataSharingInteractorMock = new Mock<ICreateDataSharingPermissionRequestInteractor>();
        dataSharingInteractorMock
            .Setup(mock => mock.Execute(dataSharingPermissionRequest))
            .ThrowsAsync(new PermissionAlreadyExistsException(dataSharingPermission));

        var dto = new RequestHcpDataSharingRequestDto("email", "identifier");

        var controller = new DataSharingRequestController(Mock.Of<ILogger<DataSharingRequestController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.RequestDataSharing(hcpRequestInteractorMock.Object, dataSharingInteractorMock.Object, dto);

        Assert.IsType<ConflictObjectResult>(resp);
        var objectResp = resp as ConflictObjectResult;

        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("duplicate_patient_link", errorResp!.ErrorCode);
        Assert.Equal("The HCP and patient are already linked", errorResp!.Error);
    }

    [Fact]
    public async Task RequestDataSharing_WhenInteractorThrowsPermissionRequestAlreadyExistsException_Returns409()
    {
        var dataSharingPermission = new DataSharingPermissionRequest("subjectId", "accessorId", "ref", "hcp", DateTimeOffset.UtcNow);

        var hcpRequestInteractorMock = new Mock<ICreateHcpDataSharingRequestInteractor>();
        hcpRequestInteractorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string?>()))
            .ReturnsAsync(dataSharingPermission);

        var dataSharingInteractorMock = new Mock<ICreateDataSharingPermissionRequestInteractor>();
        dataSharingInteractorMock
            .Setup(mock => mock.Execute(dataSharingPermission))
            .ThrowsAsync(new PermissionRequestAlreadyExistsException(dataSharingPermission));

        var dto = new RequestHcpDataSharingRequestDto("email", "identifier");

        var controller = new DataSharingRequestController(Mock.Of<ILogger<DataSharingRequestController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.RequestDataSharing(hcpRequestInteractorMock.Object, dataSharingInteractorMock.Object, dto);

        Assert.IsType<ConflictObjectResult>(resp);
        var objectResp = resp as ConflictObjectResult;

        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("duplicate_patient_request", errorResp!.ErrorCode);
        Assert.Equal("The HCP has already requested to be linked with the patient", errorResp!.Error);
    }

    [Fact]
    public async Task RequestDataSharing_WhenInteractorsSucceed_ReturnsCreatedWithDataSharingPermissionRequest()
    {
        var dataSharingPermission = new DataSharingPermissionRequest("subjectId", "accessorId", "ref", "hcp", DateTimeOffset.UtcNow)
        {
            Id = Guid.NewGuid()
        };

        var hcpRequestInteractorMock = new Mock<ICreateHcpDataSharingRequestInteractor>();
        hcpRequestInteractorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string?>()))
            .ReturnsAsync(dataSharingPermission);

        var dataSharingInteractorMock = new Mock<ICreateDataSharingPermissionRequestInteractor>();
        dataSharingInteractorMock
            .Setup(mock => mock.Execute(dataSharingPermission))
            .ReturnsAsync(dataSharingPermission);

        var dto = new RequestHcpDataSharingRequestDto("email", "identifier");

        var controller = new DataSharingRequestController(Mock.Of<ILogger<DataSharingRequestController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.RequestDataSharing(hcpRequestInteractorMock.Object, dataSharingInteractorMock.Object, dto);

        Assert.IsType<CreatedResult>(resp);
        var objectResp = resp as CreatedResult;

        Assert.IsType<DataSharingPermissionRequestResponseDto>(objectResp!.Value);
        var result = objectResp!.Value as DataSharingPermissionRequestResponseDto;

        Assert.Equal(dataSharingPermission.Id, result!.Id);
    }

    #endregion RequestDataSharing

    #region ResendDataSharingPermissionRequest

    [Fact]
    public async Task ResendDataSharingPermissionRequest_WhenInteractorThrowsInvalidDataSharingPermissionRequestStatusException_ReturnsBadRequest()
    {
        var dataSharingRequest = new DataSharingPermissionRequest("subjId", "accId", "accRef", "type", DateTimeOffset.UtcNow.AddDays(1));

        var interactorMock = new Mock<IResendDataSharingPermissionRequestInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<TimeSpan>()))
            .ThrowsAsync(new InvalidDataSharingPermissionRequestStatusException(dataSharingRequest));

        var controller = new DataSharingRequestController(Mock.Of<ILogger<DataSharingRequestController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ResendDataSharingPermissionRequest(_config, interactorMock.Object, Guid.NewGuid());

        var objectResult = Assert.IsType<BadRequestObjectResult>(resp);
        var data = Assert.IsType<ErrorResponseDto>(objectResult.Value);

        Assert.Equal("invalid_operation_on_data_sharing_permission_request_status_pending", data.ErrorCode);
        Assert.Equal("The data sharing permission is in an invalid state for this operation", data.Error);
    }

    [Fact]
    public async Task ResendDataSharingPermissionRequest_WhenInteractorThrowsDataSharingPermissionRequestNotFoundException_ReturnsNotFound()
    {
        var interactorMock = new Mock<IResendDataSharingPermissionRequestInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<TimeSpan>()))
            .ThrowsAsync(new DataSharingPermissionRequestNotFoundException());

        var controller = new DataSharingRequestController(Mock.Of<ILogger<DataSharingRequestController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ResendDataSharingPermissionRequest(_config, interactorMock.Object, Guid.NewGuid());

        var objectResult = Assert.IsType<NotFoundObjectResult>(resp);
        var data = Assert.IsType<ErrorResponseDto>(objectResult.Value);

        Assert.Equal("data_sharing_permission_request_not_found", data.ErrorCode);
        Assert.Equal("The data sharing permission request could not be found", data.Error);
    }

    [Fact]
    public async Task ResendDataSharingPermissionRequest_WhenInteractorThrows_Returns500()
    {
        var interactorMock = new Mock<IResendDataSharingPermissionRequestInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<TimeSpan>()))
            .ThrowsAsync(new Exception());

        var controller = new DataSharingRequestController(Mock.Of<ILogger<DataSharingRequestController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ResendDataSharingPermissionRequest(_config, interactorMock.Object, Guid.NewGuid());

        var objectResult = Assert.IsType<ObjectResult>(resp);
        var data = Assert.IsType<ErrorResponseDto>(objectResult.Value);

        Assert.Equal("unexpected_error", data.ErrorCode);
        Assert.Equal("An unexpected error occured", data.Error);
    }

    [Fact]
    public async Task ResendDataSharingPermissionRequest_WhenInteractorSucceeds_ReturnsOkWithPermissons()
    {
        var permissionRequest = new DataSharingPermissionRequest("subjId", "accId", "accRef", "type", DateTimeOffset.UtcNow)
        {
            Id = Guid.NewGuid(),
            AccessorEmail = "accEmail",
            SubjectEmail = "subjEmail",
            SubjectReferenceName = "subjRef",
        };



        var interactorMock = new Mock<IResendDataSharingPermissionRequestInteractor>();
        interactorMock
            .Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<Guid>(), It.IsAny<TimeSpan>()))
            .ReturnsAsync(permissionRequest);

        var controller = new DataSharingRequestController(Mock.Of<ILogger<DataSharingRequestController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ResendDataSharingPermissionRequest(_config, interactorMock.Object, Guid.NewGuid());

        var objectResult = Assert.IsType<OkObjectResult>(resp);
        var data = Assert.IsType<DataSharingPermissionRequestResponseDto>(objectResult.Value);

        Assert.Equal(permissionRequest.Id, data.Id);
        Assert.Equal(permissionRequest.Type, data.Type);
        Assert.Equal(permissionRequest.AccessorIdentityId, data.AccessorIdentityId);
        Assert.Equal(permissionRequest.AccessorReferenceName, data.AccessorReferenceName);
        Assert.Equal(permissionRequest.AccessorEmail, data.AccessorEmail);
        Assert.Equal(permissionRequest.SubjectIdentityId, data.SubjectIdentityId);
        Assert.Equal(permissionRequest.SubjectReferenceName, data.SubjectReferenceName);
        Assert.Equal(permissionRequest.SubjectEmail, data.SubjectEmail);
        Assert.Equal(permissionRequest.ExpiresAt, data.ExpiresAt);
    }

    #endregion ResendDataSharingPermissionRequest
}
