﻿using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Controllers;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest.Frameworks.Controllers;

public class UserControllerTests
{
    static readonly PaginationRequest DefaultPaginationRequest = new() { PageSize = 20, Page = 0 };

    static readonly SortRequest DefaultSortRequest = new("internalReferenceName");

    private readonly UserController controller = new(Mock.Of<ILogger<UserController>>())
    {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
    };

    #region GetCustomerAdmins

    [Fact]
    public async Task GetCustomerAdmins_WhenInteractorSucceeds_ReturnsCustomerAdminUsers()
    {
        var usersToReturn = new PaginatedItems<HcpPortalUser>(pageIndex: 0, pageSize: 2, count:1, data:
        [
            new() {
                IdentityId = "auth0|6579a3c43f22557162975123",
                InternalReferenceName = "User1",
                CountryCode = "dk",
                Email = "test1@mail.com",
                CreatedDateTime = DateTimeOffset.UtcNow.AddDays(-1)
            },
            new(){
                IdentityId = "auth0|6579a3c43f22557162975456",
                InternalReferenceName = "User2",
                CountryCode = "en",
                Email = "test2@mail.com",
                CreatedDateTime = DateTimeOffset.UtcNow.AddDays(-2)
            }
        ]);

        var interactorMock = new Mock<IGetUsersInteractor>();

        interactorMock.Setup(mock => mock.Execute(HcpPortalRole.CustomerAdmin, DefaultPaginationRequest, DefaultSortRequest, null)).ReturnsAsync(usersToReturn);

        var resp = await controller.GetCustomerAdmins(interactorMock.Object, DefaultPaginationRequest, DefaultSortRequest, null);

        var objectResp = resp as ObjectResult;
        Assert.Equal(200, objectResp?.StatusCode);

        var data = objectResp?.Value as PaginatedItems<UserResponseDto>;

        interactorMock.Verify(mock => mock.Execute(HcpPortalRole.CustomerAdmin, DefaultPaginationRequest, DefaultSortRequest, null), Times.Once());
        Assert.Equal(usersToReturn.Data.ElementAt(0).IdentityId, data!.Data.ElementAt(0).Id);
    }

    [Fact]
    public async Task GetCustomerAdmins_WhenInteractorThrowsException_ThrowException()
    {
        var exceptionToThrow = new Exception();
        var interactorMock = new Mock<IGetUsersInteractor>();

        interactorMock.Setup(mock => mock.Execute(HcpPortalRole.CustomerAdmin,DefaultPaginationRequest, DefaultSortRequest, null)).ThrowsAsync(exceptionToThrow);

        var resp = await controller.GetCustomerAdmins(interactorMock.Object, DefaultPaginationRequest, DefaultSortRequest, null);

        var objectResp = resp as ObjectResult;
        Assert.Equal(500, objectResp?.StatusCode);
    }

    #endregion GetCustomerAdmins

    #region GetHcps

    [Fact]
    public async Task GetHcps_WhenInteractorSucceeds_ReturnsHcpUsers()
    {
        var usersToReturn = new PaginatedItems<HcpPortalUser>(pageIndex: 0, pageSize: 2, count:1, data:
        [
            new() {
                IdentityId = "auth0|6579a3c43f22557162975123",
                InternalReferenceName = "User1",
                CountryCode = "dk",
                Email = "test1@mail.com",
                CreatedDateTime = DateTimeOffset.UtcNow.AddDays(-1)
            },
            new(){
                IdentityId = "auth0|6579a3c43f22557162975456",
                InternalReferenceName = "User2",
                CountryCode = "en",
                Email = "test2@mail.com",
                CreatedDateTime = DateTimeOffset.UtcNow.AddDays(-2)
            }
        ]);

        var interactorMock = new Mock<IGetUsersInteractor>();

        interactorMock.Setup(mock => mock.Execute(HcpPortalRole.Hcp, DefaultPaginationRequest, DefaultSortRequest, null)).ReturnsAsync(usersToReturn);

        var resp = await controller.GetHcps(interactorMock.Object, DefaultPaginationRequest, DefaultSortRequest, null);

        var objectResp = resp as ObjectResult;
        Assert.Equal(200, objectResp?.StatusCode);

        var data = objectResp?.Value as PaginatedItems<UserResponseDto>;

        interactorMock.Verify(mock => mock.Execute(HcpPortalRole.Hcp, DefaultPaginationRequest, DefaultSortRequest, null), Times.Once());
        Assert.Equal(usersToReturn.Data.ElementAt(0).IdentityId, data!.Data.ElementAt(0).Id);
    }

    [Fact]
    public async Task GetHcps_WhenInteractorThrowsArgumentException_ReturnBadRequest()
    {
        var exceptionToThrow = new ArgumentException();
        var interactorMock = new Mock<IGetUsersInteractor>();

        interactorMock.Setup(mock => mock.Execute(HcpPortalRole.Hcp, DefaultPaginationRequest, It.IsAny<SortRequest>(), null)).ThrowsAsync(exceptionToThrow);

        var resp = await controller.GetHcps(interactorMock.Object, DefaultPaginationRequest, new SortRequest(SortBy:"nonExistingValue"), null);

        Assert.IsType<BadRequestObjectResult>(resp);
        var objectResp = resp as BadRequestObjectResult;

        AssertUtil.AssertErrorResponse<BadRequestObjectResult>(objectResp!, 400, "invalid_sort_value","The sort value 'nonExistingValue' is invalid");
    }

    [Fact]
    public async Task GetHcps_WhenInteractorThrowsException_ThrowException()
    {
        var exceptionToThrow = new Exception();
        var interactorMock = new Mock<IGetUsersInteractor>();

        interactorMock.Setup(mock => mock.Execute(HcpPortalRole.Hcp, DefaultPaginationRequest, DefaultSortRequest, null)).ThrowsAsync(exceptionToThrow);

        var resp = await controller.GetHcps(interactorMock.Object, DefaultPaginationRequest, DefaultSortRequest, null);

        var objectResp = resp as ObjectResult;
        Assert.Equal(500, objectResp?.StatusCode);
    }

    #endregion GetHcps

    #region DeleteCustomerAdminAsNwadAdmin

    [Fact]
    public async Task DeleteCustomerAdmin_WhenInteractorSucceeds_ReturnsNoContent()
    {
        const string identityId = "identityId";
        var interactorMock = new Mock<IDeleteCustomerAdminInteractor>();

        var resp = await controller.DeleteCustomerAdmin(interactorMock.Object, identityId);

        Assert.IsType<NoContentResult>(resp);
        interactorMock.Verify(mock => mock.Execute(identityId, identityId, It.IsAny<IPAddress>()), Times.Once());
    }

    [Fact]
    public async Task DeleteCustomerAdmin_WhenInteractorThrowsRoleMismatchException_ReturnIdentityNotFoundError()
    {
        const string identityId = "identityId";
        var exceptionToThrow = new RoleMismatchException(identityId);

        var interactorMock = new Mock<IDeleteCustomerAdminInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<IPAddress>())).ThrowsAsync(exceptionToThrow);

        var controller = new UserController(Mock.Of<ILogger<UserController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext(identityId)
        };

        var resp = await controller.DeleteCustomerAdmin(interactorMock.Object, identityId);

        var objectResp = resp as NotFoundObjectResult;
        Assert.Equal(404, objectResp?.StatusCode);
    }

    [Fact]
    public async Task DeleteCustomerAdmin_WhenInteractorThrowsException_ReturnUnexpectedError()
    {
        const string identityId = "identityId";
        var exceptionToThrow = new Exception();

        var interactorMock = new Mock<IDeleteCustomerAdminInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<IPAddress>())).ThrowsAsync(exceptionToThrow);

        var resp = await controller.DeleteCustomerAdmin(interactorMock.Object, identityId);

        var objectResp = resp as ObjectResult;
        Assert.Equal(500, objectResp?.StatusCode);
    }

    #endregion DeleteCustomerAdminAsNwadAdmin

    #region DeleteHcpAsCustomerAdmin

    [Fact]
    public async Task DeleteHcp_WhenInteractorSucceeds_ReturnsNoContent()
    {
        const string identityId = "identityId";
        var interactorMock = new Mock<IDeleteHcpInteractor>();

        var resp = await controller.DeleteHcp(interactorMock.Object, identityId);

        Assert.IsType<NoContentResult>(resp);
        interactorMock.Verify(mock => mock.Execute(identityId, identityId, It.IsAny<IPAddress>()), Times.Once());
    }

    #endregion DeleteHcpAsCustomerAdmin
}
