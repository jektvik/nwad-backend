﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Controllers;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Request;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.Foundation.Dtos;
using NwadHealth.Besthealthorg.HcpPortalModule.Frameworks.Dtos.Response;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest.Frameworks.Controllers;

public class InvitationControllerTests
{
    private readonly PaginationRequest _paginationRequest = new(1, 10);
    private readonly SortRequest _sortRequest = new("test");
    private readonly string _searchQuery = "test";

    private readonly PaginatedItems<HcpPortalUserInvitation> _invitationsToReturn = new(0, 10, 00, new List<HcpPortalUserInvitation>{
            new()
            {
                Role = HcpPortalRole.CustomerAdmin,
                ExpiresAt = DateTimeOffset.UtcNow.AddDays(1)
            },
            new()
            {
                Role = HcpPortalRole.CustomerAdmin,
                ExpiresAt = DateTimeOffset.UtcNow.AddDays(-1)
            }
        });
    #region CustomerAdminInvitationLanguages

    [Fact]
    public async Task CustomerAdminInvitationLanguages_ReturnsCustomerAdminLanguages()
    {
        var interactorMock = new Mock<IGetAvailableEmailInvitationLanguagesInteractor>();

        interactorMock.Setup(mock => mock.Execute("CustomerAdmin")).ReturnsAsync(new List<string> { "da" });

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var result = await controller.CustomerAdminInvitationLanguages(interactorMock.Object);

        Assert.IsType<OkObjectResult>(result);

        var data = (result as OkObjectResult)!.Value as List<string>;

        Assert.Equal("da", data![0]);
    }

    #endregion CustomerAdminInvitationLanguages

    #region HcpInvitationLanguages

    [Fact]
    public async Task HcpInvitationLanguages_ReturnsHcpLanguages()
    {
        var interactorMock = new Mock<IGetAvailableEmailInvitationLanguagesInteractor>();

        interactorMock.Setup(mock => mock.Execute("Hcp")).ReturnsAsync(new List<string> { "da" });

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var result = await controller.HcpInvitationLanguages(interactorMock.Object);

        Assert.IsType<OkObjectResult>(result);

        var data = (result as OkObjectResult)!.Value as List<string>;

        Assert.Equal("da", data![0]);
    }

    #endregion HcpInvitationLanguages

    #region InviteCustomerAdmin

    [Fact]
    public async Task InviteCustomerAdmin_WhenInteractorSucceeds_ReturnCreated()
    {
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();

        var inviteRequestDto = new InvitationRequestDto
        (
            "email@email.com",
            "ref1",
            "en"
        );

        var interactorMock = new Mock<IInviteCustomerAdminInteractor>();

        interactorMock.Setup(mock => mock.Execute(It.IsAny<HcpPortalUserInvitation>())).Returns(Task.FromResult(new HcpPortalUserInvitation()));

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.InviteCustomerAdmin(interactorMock.Object, inviteRequestDto);

        Assert.IsType<CreatedResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(201, objectResp?.StatusCode);
    }

    [Fact]
    public async Task InviteCustomerAdmin_WhenInteractorThrowsEmailAlreadyInvitedException_ReturnsEmailAlreadyInvitedResult()
    {
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var inviteRequestDto = new InvitationRequestDto
        (
            "email@email.com",
            "ref1",
            "en"
        );

        var ex = new EmailAlreadyInvitedException("email@email.com");

        var interactorMock = new Mock<IInviteCustomerAdminInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<HcpPortalUserInvitation>())).ThrowsAsync(ex);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.InviteCustomerAdmin(interactorMock.Object, inviteRequestDto);

        Assert.IsType<ConflictObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(409, objectResp?.StatusCode);

        Assert.IsType<ErrorResponseDto>(objectResp?.Value);
        var errorResp = objectResp?.Value as ErrorResponseDto;

        Assert.Equal("email_already_invited", errorResp?.ErrorCode);
        Assert.Equal("Invitation has already been sent to this email address", errorResp?.Error);
    }

    [Fact]
    public async Task InviteCustomerAdmin_WhenInteractorThrowsInvitationAlreadyAcceptedException_ReturnsInvitationAlreadyAcceptedResult()
    {
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var inviteRequestDto = new InvitationRequestDto
        (
            "email@email.com",
            "ref1",
            "en"
        );

        var ex = new IdentityAlreadyExistsException("email@email.com");

        var interactorMock = new Mock<IInviteCustomerAdminInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<HcpPortalUserInvitation>())).ThrowsAsync(ex);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.InviteCustomerAdmin(interactorMock.Object, inviteRequestDto);

        Assert.IsType<ConflictObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(409, objectResp?.StatusCode);

        Assert.IsType<ErrorResponseDto>(objectResp?.Value);
        var errorResp = objectResp?.Value as ErrorResponseDto;

        Assert.Equal("identity_already_exists", errorResp?.ErrorCode);
        Assert.Equal("This user already exists", errorResp?.Error);
    }

    [Fact]
    public async Task InviteCustomerAdmin_WhenInteractorThrowsNoHcpPortalMetadataForIdenityException_ReturnsNoHcpPortalMetadataForIdenityResult()
    {
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var inviteRequestDto = new InvitationRequestDto
        (
            "email@email.com",
            "ref1",
            "en"
        );

        var ex = new NoHcpPortalMetadataForIdentityException("identityId");

        var interactorMock = new Mock<IInviteCustomerAdminInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<HcpPortalUserInvitation>())).ThrowsAsync(ex);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.InviteCustomerAdmin(interactorMock.Object, inviteRequestDto);

        Assert.IsType<ObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(500, objectResp?.StatusCode);

        Assert.IsType<ErrorResponseDto>(objectResp?.Value);
        var errorResp = objectResp?.Value as ErrorResponseDto;

        Assert.Equal("no_hcp_portal_metadata_for_identity", errorResp?.ErrorCode);
        Assert.Equal("No HCP portal metadata is associated with this identity", errorResp?.Error);
    }

    [Fact]
    public async Task InviteCustomerAdmin_WhenInteractorThrowsUnsupportedInvitationLanguageException_ReturnsUnsupportedInvitationLanguageResult()
    {
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var inviteRequestDto = new InvitationRequestDto
        (
            "email@email.com",
            "ref1",
            "en"
        );

        var ex = new UnsupportedInvitationLanguageException("language");

        var interactorMock = new Mock<IInviteCustomerAdminInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<HcpPortalUserInvitation>())).ThrowsAsync(ex);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.InviteCustomerAdmin(interactorMock.Object, inviteRequestDto);

        Assert.IsType<BadRequestObjectResult>(resp);
        var objectResp = resp as BadRequestObjectResult;

        Assert.IsType<ErrorResponseDto>(objectResp?.Value);
        var errorResp = objectResp?.Value as ErrorResponseDto;

        Assert.Equal("unsupported_invitation_language", errorResp?.ErrorCode);
        Assert.Equal("The chosen language is not supported", errorResp?.Error);
    }

    [Fact]
    public async Task InviteCustomerAdmin_WhenInteractorThrowsUnexpectedError_ReturnsUnexpectedError()
    {
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var inviteRequestDto = new InvitationRequestDto
        (
            "email@email.com",
            "ref1",
            "en"
        );

        var ex = new Exception();

        var interactorMock = new Mock<IInviteCustomerAdminInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<HcpPortalUserInvitation>())).ThrowsAsync(ex);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.InviteCustomerAdmin(interactorMock.Object, inviteRequestDto);

        Assert.IsType<ObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(500, objectResp?.StatusCode);

        Assert.IsType<ErrorResponseDto>(objectResp?.Value);
        var errorResp = objectResp?.Value as ErrorResponseDto;

        Assert.Equal("unexpected_error", errorResp?.ErrorCode);
        Assert.Equal("An unexpected error occured", errorResp?.Error);
    }

    #endregion InviteCustomerAdmin

    #region InviteHcp

    [Fact]
    public async Task InviteHcp_WhenInteractorSucceeds_ReturnCreated()
    {
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();

        var inviteRequestDto = new InvitationRequestDto
        (
            "email@email.com",
            "ref1",
            "en"
        );

        var interactorMock = new Mock<IInviteHcpInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<HcpPortalUserInvitation>())).Returns(Task.FromResult(new HcpPortalUserInvitation()));

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.InviteHcp(interactorMock.Object, inviteRequestDto);

        Assert.IsType<CreatedResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(201, objectResp?.StatusCode);
    }

    #endregion InviteHcp

    #region AcceptInvitationLink

    [Fact]
    public async Task AccpetInvitationLink_WhenInteractorSucceeds_ReturnsRedirect()
    {
        var interactorMock = new Mock<IAcceptInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>())).ReturnsAsync("redirectUrl");
        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>());

        var resp = await controller.AcceptInvitation(interactorMock.Object, Guid.NewGuid());

        Assert.IsType<RedirectResult>(resp);
        var objectResp = resp as RedirectResult;

        Assert.Equal("redirectUrl", objectResp?.Url);
    }

    #endregion AcceptInvitationLink

    #region Signup

    [Fact]
    public async Task SignUp_WhenInteractorSucceeds_ReturnCreatedWithPasswordResetUrl()
    {
        var signUpRequestDto = new SignUpRequestDto
        (
            Guid.NewGuid(),
            "name",
            "DK"
        );

        var interactorMock = new Mock<ISignUpInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(),It.IsAny<string>(),It.IsAny<string>())).Returns(Task.FromResult("url"));

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.SignUp(interactorMock.Object, signUpRequestDto);

        Assert.IsType<CreatedResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(201, objectResp?.StatusCode);

        var returnDto = objectResp?.Value as SignUpResponseDto;
        Assert.Equal("url", returnDto!.RedirectTo);
    }

    [Fact]
    public async Task SignUp_WhenInteractorThrowsSignUpFailedException_ThrowSignUpFailedException()
    {
        var exception = new SignUpFailedException("error occured");

        var signUpRequestDto = new SignUpRequestDto
        (
            Guid.NewGuid(),
            "name",
            "DK"
        );

        var interactorMock = new Mock<ISignUpInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.SignUp(interactorMock.Object, signUpRequestDto);

        Assert.IsType<ObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(502, objectResp?.StatusCode);
        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("Something went wrong during the sign up process", errorResp!.Error);
    }

    [Fact]
    public async Task SignUp_WhenInteractorThrowsInvitationNotFoundException_ThrowInvitationNotFoundException()
    {
        var exception = new InvitationNotFoundException(Guid.NewGuid());

        var signUpRequestDto = new SignUpRequestDto
        (
            Guid.NewGuid(),
            "name",
            "DK"
        );

        var interactorMock = new Mock<ISignUpInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.SignUp(interactorMock.Object, signUpRequestDto);

        Assert.IsType<NotFoundObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(404, objectResp?.StatusCode);
        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("The invitation does not exist", errorResp!.Error);
    }

    [Fact]
    public async Task SignUp_WhenInteractorThrowsInvalidInvitationStatusException_ThrowInvalidInvitationStatusException()
    {
        var exception = new InvalidInvitationStatusException(InvitationStatus.Expired);

        var signUpRequestDto = new SignUpRequestDto
        (
            Guid.NewGuid(),
            "name",
            "DK"
        );

        var interactorMock = new Mock<ISignUpInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.SignUp(interactorMock.Object, signUpRequestDto);

        Assert.IsType<BadRequestObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(400, objectResp?.StatusCode);
        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("The invitation is in invalid status", errorResp!.Error);
    }

    [Fact]
    public async Task SignUp_WhenInteractorThrowsExpiredInvitationException_ThrowExpiredInvitationException()
    {
        var exception = new ExpiredInvitationException("id");

        var signUpRequestDto = new SignUpRequestDto
        (
            Guid.NewGuid(),
            "name",
            "DK"
        );

        var interactorMock = new Mock<ISignUpInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.SignUp(interactorMock.Object, signUpRequestDto);

        Assert.IsType<BadRequestObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(400, objectResp?.StatusCode);
        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("The invitation has expired", errorResp!.Error);
    }

    [Fact]
    public async Task SignUp_WhenInteractorThrowsUnsupportedCountryException_ThrowUnsupportedCountryException()
    {
        var exception = new UnsupportedCountryException("UG");

        var signUpRequestDto = new SignUpRequestDto
        (
            Guid.NewGuid(),
            "name",
            "DK"
        );

        var interactorMock = new Mock<ISignUpInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.SignUp(interactorMock.Object, signUpRequestDto);

        Assert.IsType<BadRequestObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(400, objectResp?.StatusCode);
        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("This country is not on the list of supported countries", errorResp!.Error);
    }

    [Fact]
    public async Task SignUp_WhenInteractorThrowsException_ThrowException()
    {
        var exception = new Exception();

        var signUpRequestDto = new SignUpRequestDto
        (
            Guid.NewGuid(),
            "name",
            "DK"
        );

        var interactorMock = new Mock<ISignUpInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).ThrowsAsync(exception);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.SignUp(interactorMock.Object, signUpRequestDto);

        Assert.IsType<ObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(500, objectResp?.StatusCode);
    }

    #endregion Signup

    #region GetInvitations

    [Fact]
    public async Task GetCustomerAdminInvitations_WhenInteractorSucceeds_ReturnCustomerAdminInvitations()
    {
        var invitationsToReturn = new List<HcpPortalUserInvitation>
        {
           new()
           {
               Role = HcpPortalRole.CustomerAdmin,
               ExpiresAt = DateTimeOffset.UtcNow.AddDays(1)
           },
           new()
           {
               Role = HcpPortalRole.CustomerAdmin,
               ExpiresAt = DateTimeOffset.UtcNow.AddDays(-1)
           }
        };

        var interactorMock = new Mock<IGetInvitationsInteractor>();
        interactorMock.Setup(mock => mock.Execute("CustomerAdmin", _paginationRequest, _sortRequest, _searchQuery)).ReturnsAsync(_invitationsToReturn);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.GetCustomerAdminInvitations(interactorMock.Object, _paginationRequest, _sortRequest, _searchQuery);

        Assert.IsType<OkObjectResult>(resp);
        var objectResp = resp as ObjectResult;
        Assert.Equal(200, objectResp?.StatusCode);

        var data = objectResp?.Value as PaginatedItems<InvitationResponseDto>;

        interactorMock.Verify(mock => mock.Execute("CustomerAdmin", _paginationRequest, _sortRequest, _searchQuery), Times.Once());
        Assert.Equal(invitationsToReturn[0].Status.StringValue(), data!.Data.First().Status);
    }

    [Fact]
    public async Task GetCustomerAdminInvitations_WhenInteractorThrowsException_ThrowException()
    {
        var exception = new Exception();

        var interactorMock = new Mock<IGetInvitationsInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<string>(),It.IsAny<PaginationRequest>(),It.IsAny<SortRequest>(),It.IsAny<string>())).ThrowsAsync(exception);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.GetCustomerAdminInvitations(interactorMock.Object, _paginationRequest, _sortRequest, _searchQuery);

        Assert.IsType<ObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(500, objectResp?.StatusCode);
    }

        [Fact]
    public async Task GetHcpInvitations_WhenInteractorSucceeds_ReturnHcpInvitations()
    {
        var invitationsToReturn = new List<HcpPortalUserInvitation>
        {
           new()
           {
               Role = HcpPortalRole.Hcp,
               ExpiresAt = DateTimeOffset.UtcNow.AddDays(1)
           },
           new()
           {
               Role = HcpPortalRole.Hcp,
               ExpiresAt = DateTimeOffset.UtcNow.AddDays(-1)
           }
        };

        var interactorMock = new Mock<IGetInvitationsInteractor>();
        interactorMock.Setup(mock => mock.Execute("Hcp", _paginationRequest, _sortRequest, _searchQuery)).ReturnsAsync(_invitationsToReturn);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.GetHcpInvitations(interactorMock.Object, _paginationRequest, _sortRequest, _searchQuery);

        interactorMock.Verify(mock => mock.Execute("Hcp", _paginationRequest, _sortRequest, _searchQuery), Times.Once());

        Assert.IsType<OkObjectResult>(resp);
        var objectResp = resp as ObjectResult;
        Assert.Equal(200, objectResp?.StatusCode);

        var data = objectResp?.Value as PaginatedItems<InvitationResponseDto>;

        Assert.Equal(invitationsToReturn[0].Status.StringValue(), data!.Data.First().Status);
    }

    [Fact]
    public async Task GetHcpInvitations_WhenInteractorThrowsException_ThrowException()
    {
        var exception = new Exception();

        var interactorMock = new Mock<IGetInvitationsInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<string>(),It.IsAny<PaginationRequest>(),It.IsAny<SortRequest>(),It.IsAny<string>())).ThrowsAsync(exception);

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.GetHcpInvitations(interactorMock.Object, _paginationRequest, _sortRequest, _searchQuery);

        Assert.IsType<ObjectResult>(resp);
        var objectResp = resp as ObjectResult;

        Assert.Equal(500, objectResp?.StatusCode);
    }

    #endregion GetInvitations 

    #region RevokeInvitation

    [Fact]
    public async Task RevokeCustomerAdminInvitation_WhenInteractorSucceeds_ReturnEditedInvitation()
    {
        var interactorMock = new Mock<IRevokeCustomerAdminInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>())).ReturnsAsync(new HcpPortalUserInvitation() { Role = HcpPortalRole.CustomerAdmin, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Status=InvitationStatus.Revoked });

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.RevokeCustomerAdminInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<OkObjectResult>(resp);
        var objectResp = resp as ObjectResult;
        Assert.Equal(200, objectResp?.StatusCode);

        var data = objectResp?.Value as InvitationResponseDto;

        interactorMock.Verify(mock => mock.Execute(It.IsAny<Guid>()), Times.Once());
        Assert.Equal(InvitationStatus.Revoked.StringValue(), data!.Status);
    }

    [Fact]
    public async Task RevokeHcpInvitation_WhenInteractorSucceeds_ReturnEditedInvitation()
    {
        var interactorMock = new Mock<IRevokeHcpInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>())).ReturnsAsync(new HcpPortalUserInvitation() { Role = HcpPortalRole.Hcp, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Status = InvitationStatus.Revoked });

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.RevokeHcpInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<OkObjectResult>(resp);
        var objectResp = resp as ObjectResult;
        Assert.Equal(200, objectResp?.StatusCode);

        var data = objectResp?.Value as InvitationResponseDto;

        interactorMock.Verify(mock => mock.Execute(It.IsAny<Guid>()), Times.Once());
        Assert.Equal(InvitationStatus.Revoked.StringValue(), data!.Status);
    }

    [Fact]
    public async Task RevokeHcpInvitation_WhenInteractorThrowsInvalidInvitationStatusException_ReturnsInvalidInvitationStatusError()
    {
        var interactorMock = new Mock<IRevokeHcpInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>())).ThrowsAsync(new InvalidInvitationStatusException(InvitationStatus.Revoked));

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.RevokeHcpInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<BadRequestObjectResult>(resp);
        var objectResp = resp as BadRequestObjectResult;
        Assert.Equal(400, objectResp?.StatusCode);

        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("The invitation is in invalid status", errorResp!.Error);
        Assert.Equal("invalid_invitation_status", errorResp!.ErrorCode);
    }

    [Fact]
    public async Task RevokeHcpInvitation_WhenInteractorThrowsInvitationNotFoundException_ReturnInvitationNotFoundError()
    {
        var interactorMock = new Mock<IRevokeHcpInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>())).ThrowsAsync(new InvitationNotFoundException(Guid.NewGuid()));

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.RevokeHcpInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<NotFoundObjectResult>(resp);
        var objectResp = resp as NotFoundObjectResult;
        Assert.Equal(404, objectResp?.StatusCode);

        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("The invitation does not exist", errorResp!.Error);
        Assert.Equal("invitation_not_found", errorResp!.ErrorCode);
    }

    [Fact]
    public async Task RevokeHcpInvitation_WhenInteractorThrowsException_ReturnUnexpectedError()
    {
        var interactorMock = new Mock<IRevokeHcpInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>())).ThrowsAsync(new Exception());

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.RevokeHcpInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<ObjectResult>(resp);
        var objectResp = resp as ObjectResult;
        Assert.Equal(500, objectResp?.StatusCode);
    }

    #endregion RevokeInvitation

    #region ResendInvitation

    [Fact]
    public async Task ResendCustomerAdminInvitation_WhenInteractorSucceeds_ReturnResentInvitation()
    {
        var interactorMock = new Mock<IResendCustomerAdminInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), "identityId")).ReturnsAsync(new HcpPortalUserInvitation() { Role = HcpPortalRole.CustomerAdmin, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Status = InvitationStatus.Pending });

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ResendCustomerAdminInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<OkObjectResult>(resp);
        var objectResp = resp as ObjectResult;
        Assert.Equal(200, objectResp?.StatusCode);

        var data = objectResp?.Value as InvitationResponseDto;

        interactorMock.Verify(mock => mock.Execute(It.IsAny<Guid>(), "identityId"), Times.Once());
        Assert.Equal(InvitationStatus.Pending.StringValue(), data!.Status);
    }

    [Fact]
    public async Task ResendHcpInvitation_WhenInteractorSucceeds_ReturnEditedInvitation()
    {
        var interactorMock = new Mock<IResendHcpInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), "identityId")).ReturnsAsync(new HcpPortalUserInvitation() { Role = HcpPortalRole.Hcp, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Status = InvitationStatus.Pending });

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ResendHcpInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<OkObjectResult>(resp);
        var objectResp = resp as ObjectResult;
        Assert.Equal(200, objectResp?.StatusCode);

        var data = objectResp?.Value as InvitationResponseDto;

        interactorMock.Verify(mock => mock.Execute(It.IsAny<Guid>(), "identityId"), Times.Once());
        Assert.Equal(InvitationStatus.Pending.StringValue(), data!.Status);
    }

    [Fact]
    public async Task ResendHcpInvitation_WhenInteractorThrowsInvalidInvitationStatusException_ReturnsInvalidInvitationStatusError()
    {
        var interactorMock = new Mock<IResendHcpInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), "identityId")).ThrowsAsync(new InvalidInvitationStatusException(InvitationStatus.Revoked));

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ResendHcpInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<BadRequestObjectResult>(resp);
        var objectResp = resp as BadRequestObjectResult;
        Assert.Equal(400, objectResp?.StatusCode);

        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("The invitation is in invalid status", errorResp!.Error);
        Assert.Equal("invalid_invitation_status", errorResp!.ErrorCode);
    }

    [Fact]
    public async Task ResendHcpInvitation_WhenInteractorThrowsInvitationNotFoundException_ReturnInvitationNotFoundError()
    {
        var interactorMock = new Mock<IResendHcpInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), "identityId")).ThrowsAsync(new InvitationNotFoundException(Guid.NewGuid()));

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ResendHcpInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<NotFoundObjectResult>(resp);
        var objectResp = resp as NotFoundObjectResult;
        Assert.Equal(404, objectResp?.StatusCode);

        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("The invitation does not exist", errorResp!.Error);
        Assert.Equal("invitation_not_found", errorResp!.ErrorCode);
    }

    [Fact]
    public async Task ResendHcpInvitation_WhenInteractorThrowsUnsupportedInvitationLanguageException_ReturnUnsupportedInvitationLanguageError()
    {
        var interactorMock = new Mock<IResendHcpInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), "identityId")).ThrowsAsync(new UnsupportedInvitationLanguageException("da"));

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ResendHcpInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<BadRequestObjectResult>(resp);
        var objectResp = resp as BadRequestObjectResult;
        Assert.Equal(400, objectResp?.StatusCode);

        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("The chosen language is not supported", errorResp!.Error);
        Assert.Equal("unsupported_invitation_language", errorResp!.ErrorCode);
    }

    [Fact]
    public async Task ResendHcpInvitation_WhenInteractorThrowsNoHcpPortalMetadataForIdentityException_ReturnNoHcpPortalMetadataForIdentityError()
    {
        var interactorMock = new Mock<IResendHcpInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), "identityId")).ThrowsAsync(new NoHcpPortalMetadataForIdentityException("identityId"));

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ResendHcpInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<ObjectResult>(resp);
        var objectResp = resp as ObjectResult;
        Assert.Equal(500, objectResp?.StatusCode);

        var errorResp = objectResp?.Value as ErrorResponseDto;
        Assert.Equal("No HCP portal metadata is associated with this identity", errorResp!.Error);
        Assert.Equal("no_hcp_portal_metadata_for_identity", errorResp!.ErrorCode);
    }

    [Fact]
    public async Task ResendHcpInvitation_WhenInteractorThrowsException_ReturnUnexpectedError()
    {
        var interactorMock = new Mock<IResendHcpInvitationInteractor>();
        interactorMock.Setup(mock => mock.Execute(It.IsAny<Guid>(), "identityId")).ThrowsAsync(new Exception());

        var controller = new InvitationController(Mock.Of<ILogger<InvitationController>>())
        {
            ControllerContext = ControllerTestHelper.SetupContext("identityId")
        };

        var resp = await controller.ResendHcpInvitation(interactorMock.Object, new InvitationIdRequestDto(Guid.NewGuid()));

        Assert.IsType<ObjectResult>(resp);
        var objectResp = resp as ObjectResult;
        Assert.Equal(500, objectResp?.StatusCode);
    }

    #endregion ResendInvitation
}
