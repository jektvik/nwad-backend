﻿using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class GetInvitationsInteractorTests
{
    private readonly PaginationRequest _paginationRequest = new(1, 10);
    private readonly SortRequest _sortRequest = new("test");
    private readonly string _searchQuery = "test";

    private readonly PaginatedItems<HcpPortalUserInvitation> _invitationsToReturn = new(0, 10, 00, new List<HcpPortalUserInvitation>{
            new()
            {
                Role = HcpPortalRole.CustomerAdmin,
                ExpiresAt = DateTimeOffset.UtcNow.AddDays(1)
            },
            new()
            {
                Role = HcpPortalRole.CustomerAdmin,
                ExpiresAt = DateTimeOffset.UtcNow.AddDays(-1)
            }
        });

    #region Execute

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_ReturnInvitations()
    {
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationsByRole("roleId", _paginationRequest, _sortRequest, _searchQuery)).ReturnsAsync(_invitationsToReturn);

        var interactor = new GetInvitationsInteractor(
            invitationRepoMock.Object
        );

        var invitationsFromRepo = await interactor.Execute("roleId", _paginationRequest, _sortRequest, _searchQuery);

        invitationRepoMock.Verify(repo => repo.GetInvitationsByRole("roleId", _paginationRequest, _sortRequest, _searchQuery), Times.Once);
        Assert.Equal(invitationsFromRepo, _invitationsToReturn);
    }

    #endregion Execute
}
