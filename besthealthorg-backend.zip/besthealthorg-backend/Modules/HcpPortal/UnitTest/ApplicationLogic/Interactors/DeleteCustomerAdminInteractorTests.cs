﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using Moq;
using Xunit;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using System.Net;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class DeleteCustomerAdminInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_CallsDeleteIdentityOnIdentityProviderWithProvidedId()
    {
        const string identityId = "identityId";
        var ip = new IPAddress(new byte[] { 1, 2, 3, 4 });

        var identity = Mock.Of<IIdentity>();
        var identityProviderMock = new Mock<IIdentityProvider>();

        identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(identity);

        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();
        roleAssignmentRepoMock.Setup(mock => mock.GetRoleAssignmentByIdentityId(identityId)).ReturnsAsync(new RoleAssignment { Id = "1", RoleId = "CustomerAdmin" });

        var interactor = new DeleteCustomerAdminInteractor(
            identityProviderMock.Object,
            Mock.Of<IIdentityEventPublisher>(),
            Mock.Of<IIdentityPropertiesRepository>(),
            roleAssignmentRepoMock.Object,
            Mock.Of<IAuditLogRepository>(),
            Mock.Of<ILogger<DeleteCustomerAdminInteractor>>());

        await interactor.Execute(identityId, identityId, ip);

        identityProviderMock.Verify(mock => mock.DeleteIdentity(identityId), Times.Once());
    }

    [Fact]
    public async Task Execute_WhenInteractorThrowsRoleMismatchException_ThrowRoleMismatchException()
    {
        const string identityId = "identityId";
        var ip = new IPAddress(new byte[] { 1, 2, 3, 4 });

        var identity = Mock.Of<IIdentity>();
        var identityProviderMock = new Mock<IIdentityProvider>();

        identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(identity);

        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();
        roleAssignmentRepoMock.Setup(mock => mock.GetRoleAssignmentByIdentityId(identityId)).ReturnsAsync(new RoleAssignment { Id = "1", RoleId = "Hcp" });

        var interactor = new DeleteCustomerAdminInteractor(
            identityProviderMock.Object,
            Mock.Of<IIdentityEventPublisher>(),
            Mock.Of<IIdentityPropertiesRepository>(),
            roleAssignmentRepoMock.Object,
            Mock.Of<IAuditLogRepository>(),
            Mock.Of<ILogger<DeleteCustomerAdminInteractor>>());

        await Assert.ThrowsAsync<RoleMismatchException>(async () => await interactor.Execute(identityId, identityId, ip));
    }

    #endregion Execute
}
