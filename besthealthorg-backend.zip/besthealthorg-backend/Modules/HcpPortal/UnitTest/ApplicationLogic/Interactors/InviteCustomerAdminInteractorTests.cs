﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class InviteCustomerAdminInteractorTests
{
    private readonly List<string> availableLanguages = new() { "en", "dk" };

    private readonly HcpPortalConfiguration _config;

    public InviteCustomerAdminInteractorTests()
    {
        _config = new HcpPortalConfiguration("backendApiUrl/", "frontendBaseUrl/", "webAppClientId", "apiKey");
    }

    #region Execute

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_SavesInvitation()
    {
        var mailer = new Mock<IHcpPortalMailer>();
        mailer.Setup(mock => mock.AvailableLanguages(It.IsAny<string>())).Returns(availableLanguages);

        var invitation = new HcpPortalUserInvitation
        {
            InternalReferenceName = "Patient0",
            SenderIdentityId = "sender",
            Language = "en",
            ReceiverEmail = "patient0@test.com",
        };

        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        metadataRepoMock.Setup(mock => mock.GetMetadataByIdentityId(It.IsAny<string>())).ReturnsAsync(new HcpPortalUserMetadata());
        var identityProviderMock = new Mock<IIdentityProvider>();

        var interactor = new InviteCustomerAdminInteractor(
            invitationRepoMock.Object,
            metadataRepoMock.Object,
            new Mock<ILogger<InviteCustomerAdminInteractor>>().Object,
            mailer.Object,
            _config,
            identityProviderMock.Object
        );

        await interactor.Execute(invitation);

        invitationRepoMock.Verify(repo => repo.SaveInvitation(It.IsAny<HcpPortalUserInvitation>()), Times.Once);
    }

    [Fact]
    public async Task Execute_WhenEmailIsAlreadyInvited_ThrowsEmailAlreadyInvitedException()
    {
        var mailer = new Mock<IHcpPortalMailer>();
        mailer.Setup(mock => mock.AvailableLanguages(It.IsAny<string>())).Returns(availableLanguages);

        var invitation = new HcpPortalUserInvitation
        {
            InternalReferenceName = "Patient0",
            SenderIdentityId = "sender",
            Language = "en",
            ReceiverEmail = "patient0@test.com",
        };

        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationByEmail(It.IsAny<string>())).ReturnsAsync(new HcpPortalUserInvitation());
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var identityProviderMock = new Mock<IIdentityProvider>();

        var interactor = new InviteCustomerAdminInteractor(
            invitationRepoMock.Object,
            metadataRepoMock.Object,
            new Mock<ILogger<InviteCustomerAdminInteractor>>().Object,
            mailer.Object,
            _config,
            identityProviderMock.Object
        );

        await Assert.ThrowsAsync<EmailAlreadyInvitedException>(async () => await interactor.Execute(invitation));
    }

    [Fact]
    public async Task Execute_WhenInviterHasNoMetadata_ThrowsNoHcpPortalMetadataForIdentityException()
    {
        var mailer = new Mock<IHcpPortalMailer>();
        mailer.Setup(mock => mock.AvailableLanguages(It.IsAny<string>())).Returns(availableLanguages);

        var invitation = new HcpPortalUserInvitation
        {
            InternalReferenceName = "Patient0",
            SenderIdentityId = "sender",
            Language = "en",
            ReceiverEmail = "patient0@test.com",
        };

        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var identityProviderMock = new Mock<IIdentityProvider>();
        identityProviderMock.Setup(mock => mock.FetchIdentityByEmail(It.IsAny<string>()))
            .ReturnsAsync(Mock.Of<IIdentity>());

        var interactor = new InviteCustomerAdminInteractor(
            invitationRepoMock.Object,
            metadataRepoMock.Object,
            new Mock<ILogger<InviteCustomerAdminInteractor>>().Object,
             mailer.Object,
            _config,
            identityProviderMock.Object
        );

        await Assert.ThrowsAsync<IdentityAlreadyExistsException>(async () => await interactor.Execute(invitation));
    }

    [Fact]
    public async Task Execute_WhenUserAlreadyExists_ThrowsInvitationAlreadyAcceptedException()
    {
        var mailer = new Mock<IHcpPortalMailer>();
        mailer.Setup(mock => mock.AvailableLanguages(It.IsAny<string>())).Returns(availableLanguages);

        var invitation = new HcpPortalUserInvitation
        {
            InternalReferenceName = "Patient0",
            SenderIdentityId = "sender",
            Language = "en",
            ReceiverEmail = "patient0@test.com",
        };

        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        metadataRepoMock.Setup(mock => mock.GetMetadataByIdentityId(It.IsAny<string>())).ReturnsAsync(() => null);
        var identityProviderMock = new Mock<IIdentityProvider>();

        var interactor = new InviteCustomerAdminInteractor(
            invitationRepoMock.Object,
            metadataRepoMock.Object,
            new Mock<ILogger<InviteCustomerAdminInteractor>>().Object,
             mailer.Object,
            _config,
            identityProviderMock.Object
        );

        await Assert.ThrowsAsync<NoHcpPortalMetadataForIdentityException>(async () => await interactor.Execute(invitation));
    }

    [Fact]
    public async Task Execute_WhenLanguageIsNotSupported_ThrowsUnsupportedInvitationLanguageException()
    {
        var mailer = new Mock<IHcpPortalMailer>();
        mailer.Setup(mock => mock.AvailableLanguages(It.IsAny<string>())).Returns(availableLanguages);

        var invitation = new HcpPortalUserInvitation
        {
            InternalReferenceName = "Patient0",
            SenderIdentityId = "sender",
            Language = "fr",
            ReceiverEmail = "patient0@test.com",
        };

        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var identityProviderMock = new Mock<IIdentityProvider>();

        var interactor = new InviteCustomerAdminInteractor(
            invitationRepoMock.Object,
            metadataRepoMock.Object,
            new Mock<ILogger<InviteCustomerAdminInteractor>>().Object,
            mailer.Object,
            _config,
            identityProviderMock.Object
        );

        await Assert.ThrowsAsync<UnsupportedInvitationLanguageException>(async () => await interactor.Execute(new HcpPortalUserInvitation()));
    }

    #endregion Execute
}
