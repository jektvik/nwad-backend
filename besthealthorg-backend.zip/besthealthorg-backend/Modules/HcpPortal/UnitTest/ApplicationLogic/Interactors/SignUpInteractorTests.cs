﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors.SignUp;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Moq;
using Xunit;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Exceptions;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class SignUpInteractorTests
{
    #region Execute

    private readonly HcpPortalConfiguration _config;

    public SignUpInteractorTests()
    {
        _config = new HcpPortalConfiguration("backendApiUrl/", "frontentBaseUrl/", "webAppClientId", "sendgidApiKey");
    }

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_ReturnsResetPasswordTicketUrl()
    {
        var guid = Guid.NewGuid();
        const string ownName = "John Doe";
        const string country = "DK";

        var identityProviderMock = new Mock<IIdentityProvider>();
        identityProviderMock.Setup(mock => mock.CreateIdentity(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()))
            .ReturnsAsync(Mock.Of<IIdentity>());
        identityProviderMock.Setup(mock => mock.CreateResetPasswordTicket(It.IsAny<string>(), It.IsAny<bool>(), It.IsAny<string>()))
            .ReturnsAsync("https://besthealthorg-dev.eu.auth0.com/u/reset-verify?ticket=gUjXWIzRW5bLGuLsqUNBB5Kf2OuCd7e3#");
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>()))
            .ReturnsAsync(new HcpPortalUserInvitation { ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Role = Domain.Enums.HcpPortalRole.Hcp });
        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();
        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();
        var userMetaDataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var countryRepoMock = new Mock<ICountryRepository>();
        countryRepoMock.Setup(mock => mock.GetCountryByCountryCode(It.IsAny<string>())).ReturnsAsync(new Country());

        var interactor = new SignUpInteractor(
            identityProviderMock.Object,
            invitationRepoMock.Object,
            identityPropertiesRepoMock.Object,
            roleAssignmentRepoMock.Object,
            userMetaDataRepoMock.Object,
            countryRepoMock.Object,
            _config
        );

        var passwordResetLink = await interactor.Execute(guid, ownName,country);

        Assert.NotEqual(string.Empty, passwordResetLink);
        Assert.Contains("ticket", passwordResetLink);
    }

    [Fact]
    public async Task Execute_WhenCreateIdentityThrows_ThrowsSignUpFailedExceptionWithInnerException()
    {
        var config = new HcpPortalConfiguration("backendApiUrl/", "frontentBaseUrl/", "webAppClientId", "sendgidApiKey");
        var exception = new Exception();
        var guid = Guid.NewGuid();
        const string ownName = "John Doe";
        const string country = "DK";

        var identityProviderMock = new Mock<IIdentityProvider>();
        identityProviderMock.Setup(mock => mock.CreateIdentity(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()))
            .ThrowsAsync(exception);
        identityProviderMock.Setup(mock => mock.CreateResetPasswordTicket(It.IsAny<string>(), It.IsAny<bool>(), It.IsAny<string>()))
            .ReturnsAsync("https://besthealthorg-dev.eu.auth0.com/u/reset-verify?ticket=gUjXWIzRW5bLGuLsqUNBB5Kf2OuCd7e3#");
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>()))
            .ReturnsAsync(new HcpPortalUserInvitation { ExpiresAt = DateTimeOffset.UtcNow.AddDays(1) });
        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();
        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();
        var userMetaDataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var countryRepoMock = new Mock<ICountryRepository>();
        countryRepoMock.Setup(mock => mock.GetCountryByCountryCode(It.IsAny<string>())).ReturnsAsync(new Country());

        var interactor = new SignUpInteractor(
            identityProviderMock.Object,
            invitationRepoMock.Object,
            identityPropertiesRepoMock.Object,
            roleAssignmentRepoMock.Object,
            userMetaDataRepoMock.Object,
            countryRepoMock.Object,
            config
        );

        var ex = await Assert.ThrowsAsync<SignUpFailedException>(async () => await interactor.Execute(guid, ownName, country));
        Assert.Equal(exception, ex.InnerException);
        Assert.Equal("Something went wrong during the sign up process", ex.Message);
    }

    [Fact]
    public async Task Execute_WhenIdentityPropertiesThrows_ThrowsSignUpFailedExceptionWithInnerException()
    {
        var exception = new Exception();
        var guid = Guid.NewGuid();
        const string ownName = "John Doe";
        const string country = "DK";

        var identityProviderMock = new Mock<IIdentityProvider>();
        identityProviderMock.Setup(mock => mock.CreateIdentity(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()))
            .ReturnsAsync(Mock.Of<IIdentity>());
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>()))
            .ReturnsAsync(new HcpPortalUserInvitation { ExpiresAt = DateTimeOffset.UtcNow.AddDays(1) });
        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();
        identityPropertiesRepoMock.Setup(mock => mock.Create(It.IsAny<IdentityProperties>())).ThrowsAsync(exception);
        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();
        var userMetaDataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var countryRepoMock = new Mock<ICountryRepository>();
        countryRepoMock.Setup(mock => mock.GetCountryByCountryCode(It.IsAny<string>())).ReturnsAsync(new Country());

        var interactor = new SignUpInteractor(
            identityProviderMock.Object,
            invitationRepoMock.Object,
            identityPropertiesRepoMock.Object,
            roleAssignmentRepoMock.Object,
            userMetaDataRepoMock.Object,
            countryRepoMock.Object,
            _config
        );

        var ex = await Assert.ThrowsAsync<SignUpFailedException>(async () => await interactor.Execute(guid, ownName, country));
        Assert.Equal(exception, ex.InnerException);
        Assert.Equal("Something went wrong during the sign up process", ex.Message);
    }

    [Fact]
    public async Task Execute_WhenRoleAssignmentThrows_ThrowsSignUpFailedExceptionWithInnerException()
    {
        var exception = new Exception();
        var guid = Guid.NewGuid();
        const string ownName = "John Doe";
        const string country = "DK";

        var identityProviderMock = new Mock<IIdentityProvider>();
        identityProviderMock.Setup(mock => mock.CreateIdentity(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()))
            .ReturnsAsync(Mock.Of<IIdentity>());
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>()))
            .ReturnsAsync(new HcpPortalUserInvitation { ExpiresAt = DateTimeOffset.UtcNow.AddDays(1) });
        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();
        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();
        roleAssignmentRepoMock.Setup(mock => mock.CreateRoleAssignment(It.IsAny<RoleAssignment>())).ThrowsAsync(exception);
        var userMetaDataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var countryRepoMock = new Mock<ICountryRepository>();
        countryRepoMock.Setup(mock => mock.GetCountryByCountryCode(It.IsAny<string>())).ReturnsAsync(new Country());

        var interactor = new SignUpInteractor(
            identityProviderMock.Object,
            invitationRepoMock.Object,
            identityPropertiesRepoMock.Object,
            roleAssignmentRepoMock.Object,
            userMetaDataRepoMock.Object,
            countryRepoMock.Object,
            _config
        );

        var ex = await Assert.ThrowsAsync<SignUpFailedException>(async () => await interactor.Execute(guid, ownName, country));
        Assert.Equal(exception, ex.InnerException);
        Assert.Equal("Something went wrong during the sign up process", ex.Message);
    }

    [Fact]
    public async Task Execute_WhenCreateMetadataThrows_ThrowsSignUpFailedExceptionWithInnerException()
    {
        var exception = new Exception();
        var guid = Guid.NewGuid();
        const string ownName = "John Doe";
        const string country = "DK";

        var identityProviderMock = new Mock<IIdentityProvider>();
        identityProviderMock.Setup(mock => mock.CreateIdentity(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()))
            .ReturnsAsync(Mock.Of<IIdentity>());
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>()))
            .ReturnsAsync(new HcpPortalUserInvitation { ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Role = Domain.Enums.HcpPortalRole.Hcp });
        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();
        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();
        var userMetaDataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
            userMetaDataRepoMock.Setup(mock => mock.CreateMetadata(It.IsAny<HcpPortalUserMetadata>())).ThrowsAsync(exception);
        var countryRepoMock = new Mock<ICountryRepository>();
        countryRepoMock.Setup(mock => mock.GetCountryByCountryCode(It.IsAny<string>())).ReturnsAsync(new Country());

        var interactor = new SignUpInteractor(
            identityProviderMock.Object,
            invitationRepoMock.Object,
            identityPropertiesRepoMock.Object,
            roleAssignmentRepoMock.Object,
            userMetaDataRepoMock.Object,
            countryRepoMock.Object,
            _config
        );

        var ex = await Assert.ThrowsAsync<SignUpFailedException>(async () => await interactor.Execute(guid, ownName, country));
        Assert.Equal(exception, ex.InnerException);
        Assert.Equal("Something went wrong during the sign up process", ex.Message);
    }

    [Fact]
    public async Task Execute_WhenInvitationIsNull_ThrowsInvitationNotFoundException()
    {
        var guid = Guid.NewGuid();
        const string ownName = "John Doe";
        const string country = "DK";

        var interactor = new SignUpInteractor(
            Mock.Of<IIdentityProvider>(),
            Mock.Of<IHcpPortalUserInvitationRepository>(),
            Mock.Of<IIdentityPropertiesRepository>(),
            Mock.Of<IRoleAssignmentRepository>(),
            Mock.Of<IHcpPortalUserMetadataRepository>(),
            Mock.Of<ICountryRepository>(),
            _config
        );

        var ex = await Assert.ThrowsAsync<InvitationNotFoundException>(async () => await interactor.Execute(guid, ownName, country));
        Assert.Contains("The invitation does not exist", ex.Message);
    }

    [Fact]
    public async Task Execute_WhenInvitationIsNotInPendingState_ThrowsInvalidInvitationStatusException()
    {
        var guid = Guid.NewGuid();
        const string ownName = "John Doe";
        const string country = "DK";

        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(new HcpPortalUserInvitation());

        var interactor = new SignUpInteractor(
            Mock.Of<IIdentityProvider>(),
            invitationRepoMock.Object,
            Mock.Of<IIdentityPropertiesRepository>(),
            Mock.Of<IRoleAssignmentRepository>(),
            Mock.Of<IHcpPortalUserMetadataRepository>(),
            Mock.Of<ICountryRepository>(),
            _config
        );

        var ex = await Assert.ThrowsAsync<InvalidInvitationStatusException>(async () => await interactor.Execute(guid, ownName, country));
        Assert.Contains("The invitation is in invalid status", ex.Message);
    }

    [Fact]
    public async Task Execute_WhenDbCountryIsNull_ThrowsUnsupportedCountryException()
    {
        var exceptionToThrow = new UnsupportedCountryException("SE");
        var guid = Guid.NewGuid();
        const string ownName = "John Doe";
        const string country = "DK";

        var identityProviderMock = new Mock<IIdentityProvider>();
        identityProviderMock.Setup(mock => mock.CreateResetPasswordTicket(It.IsAny<string>(), It.IsAny<bool>(),It.IsAny<string>()))
            .ReturnsAsync("https://besthealthorg-dev.eu.auth0.com/u/reset-verify?ticket=gUjXWIzRW5bLGuLsqUNBB5Kf2OuCd7e3#");
        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>()))
            .ReturnsAsync(new HcpPortalUserInvitation { ExpiresAt = DateTimeOffset.UtcNow.AddDays(1) });
        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();
        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();
        var userMetaDataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var countryRepoMock = new Mock<ICountryRepository>();
        countryRepoMock.Setup(mock => mock.GetCountryByCountryCode(It.IsAny<string>())).ReturnsAsync((Country?)null);

        var interactor = new SignUpInteractor(
            identityProviderMock.Object,
            invitationRepoMock.Object,
            identityPropertiesRepoMock.Object,
            roleAssignmentRepoMock.Object,
            userMetaDataRepoMock.Object,
            countryRepoMock.Object,
            _config
        );

        var ex = await Assert.ThrowsAsync<UnsupportedCountryException>(async () => await interactor.Execute(guid, ownName, country));

        Assert.Equal("The selected country is not supported", ex.Message);
    }

    #endregion Execute
}
