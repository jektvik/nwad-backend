﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class AcceptInvitationInteractorTests
{
    #region Execute

    private readonly HcpPortalConfiguration _config;

    public AcceptInvitationInteractorTests()
    {
        _config = new HcpPortalConfiguration("backendApiUrl/", "frontendBaseUrl/", "webAppClientId", "apiKey");
    }

    [Fact]
    public async Task Execute_WhenInvitationIsValid_ReturnsRedirectLinkToSingupPage()
    {
        var guid = Guid.NewGuid();
        var validInvitation = new HcpPortalUserInvitation { ExpiresAt = DateTimeOffset.UtcNow.AddDays(1) };

        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(validInvitation);

        var interactor = new AcceptInvitationInteractor(
            invitationRepoMock.Object,
            new Mock<ILogger<AcceptInvitationInteractor>>().Object,
            _config
        );

        var redirectLink = await interactor.Execute(guid);

        Assert.NotEqual(string.Empty,redirectLink );
        Assert.Contains("invitationId", redirectLink);
    }

    [Fact]
    public async Task Execute_WhenInvitationIsExpired_ReturnsRedirectLinkToExpiredInvitationPage()
    {
        var guid = Guid.NewGuid();
        var expiredInvitation = new HcpPortalUserInvitation { ExpiresAt = DateTimeOffset.UtcNow.AddDays(-1) };

        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(expiredInvitation);

        var interactor = new AcceptInvitationInteractor(
            invitationRepoMock.Object,
            new Mock<ILogger<AcceptInvitationInteractor>>().Object,
            _config
        );

        var redirectLink = await interactor.Execute(guid);

        Assert.NotEqual(string.Empty, redirectLink);
        Assert.Contains("expired", redirectLink);
    }

    [Fact]
    public async Task Execute_WhenInvitationIsRevoked_ReturnsRedirectLinkToRevokedInvitationPage()
    {
        var guid = Guid.NewGuid();
        var revokedInvitation = new HcpPortalUserInvitation { ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Status = InvitationStatus.Revoked };

        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(revokedInvitation);

        var interactor = new AcceptInvitationInteractor(
            invitationRepoMock.Object,
            new Mock<ILogger<AcceptInvitationInteractor>>().Object,
            _config
        );

        var redirectLink = await interactor.Execute(guid);

        Assert.NotEqual(string.Empty, redirectLink);
        Assert.Contains("revoked", redirectLink);
    }

    [Fact]
    public async Task Execute_WhenInvitationIsNull_ReturnsRedirectLinkToErrorPage()
    {
        var guid = Guid.NewGuid();
        HcpPortalUserInvitation? nullInvitation = null;

        var invitationRepoMock = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepoMock.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(nullInvitation);

        var interactor = new AcceptInvitationInteractor(
            invitationRepoMock.Object,
            new Mock<ILogger<AcceptInvitationInteractor>>().Object,
            _config
        );

        var redirectLink = await interactor.Execute(guid);

        Assert.NotEqual(string.Empty, redirectLink);
        Assert.Contains("error", redirectLink);
    }

    #endregion Execute
}
