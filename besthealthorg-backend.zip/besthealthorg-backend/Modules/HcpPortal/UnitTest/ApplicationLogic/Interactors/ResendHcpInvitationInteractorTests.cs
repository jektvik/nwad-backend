﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class ResendHcpInvitationInteractorTests
{
    private static readonly string[] invitationLanguage = ["en"];

    #region Execute

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_ReturnInvitation()
    {
        var invitationRepo = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepo.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(new HcpPortalUserInvitation() { Role = HcpPortalRole.Hcp, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Language="en" });

        var metadataRepo = new Mock<IHcpPortalUserMetadataRepository>();
        metadataRepo.Setup(mock => mock.GetMetadataByIdentityId(It.IsAny<string>())).ReturnsAsync(new HcpPortalUserMetadata { IdentityId = "identityId", InternalReferenceName = "Doc", OwnName = "Doctor" });

        var mailer = new Mock<IHcpPortalMailer>();
        mailer.Setup(mock => mock.AvailableLanguages(It.IsAny<string>())).Returns(invitationLanguage);
        mailer.Setup(mock => mock.SendHcpInvitation(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));

        var config = new HcpPortalConfiguration("backendApiUrl/", "frontendUrl/", "webAppClientId", "sendgridApiKey");
        var interactor = new ResendHcpInvitationInteractor(invitationRepo.Object, metadataRepo.Object, config, mailer.Object);

        var resentInvitation = await interactor.Execute(Guid.NewGuid(),"resenderIdentityId");

        Assert.NotNull(resentInvitation);
        Assert.Equal(InvitationStatus.Pending, resentInvitation.Status);
        Assert.Equal(HcpPortalRole.Hcp, resentInvitation.Role);
        invitationRepo.Verify(mock => mock.GetInvitationById(It.IsAny<Guid>()), Times.Once);
        mailer.Verify(mock => mock.AvailableLanguages(It.IsAny<string>()), Times.Once);
        mailer.Verify(mock => mock.SendHcpInvitation(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
    }

    #endregion Execute
}
