using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class CreateHcpDataSharingRequestInteractorTests
{
    private Mock<IHcpPortalUserMetadataRepository> _metadataRepoMock = new();
    private Mock<IIdentityProvider> _identityProviderMock = new();
    
    private readonly CreateHcpDataSharingRequestInteractor _interactor;
    public CreateHcpDataSharingRequestInteractorTests()
    {
        _interactor = new CreateHcpDataSharingRequestInteractor(_identityProviderMock.Object, _metadataRepoMock.Object, new("1/", "2/", "3", "4"));
    }
    #region Execute

    [Fact]
    public async Task Execute_WhenPatientIdentityCouldNotBeFound_ThrowsIdentityNotFoundException()
    {
        var exception = await Assert.ThrowsAsync<IdentityNotFoundException>(async () => await _interactor.Execute("hcpId", "patientEmail", "patientName"));

        Assert.Equal("patientEmail", exception.Identifier);
    }

    [Fact]
    public async Task Execute_WhenHcpIdentityCouldNotBeFound_ThrowsIdentityNotFoundException()
    {
        _identityProviderMock.Setup(mock => mock.FetchIdentityByEmail("patientEmail")).ReturnsAsync(Mock.Of<IIdentity>());

        await Assert.ThrowsAsync<NoHcpPortalMetadataForIdentityException>(async () => await _interactor.Execute("hcpId", "patientEmail", "patientName"));
    }

    [Fact]
    public async Task Execute_WhenHcpMetadataCouldNotBeFound_ThrowsNoHcpPortalMetadataForIdentityException()
    {
        _identityProviderMock.Setup(mock => mock.FetchIdentityByEmail("patientEmail")).ReturnsAsync(Mock.Of<IIdentity>());

        _metadataRepoMock.Setup(mock => mock.GetMetadataByIdentityId("hcpId")).ReturnsAsync(new HcpPortalUserMetadata());

        var exception = await Assert.ThrowsAsync<IdentityNotFoundException>(async () => await _interactor.Execute("hcpId", "patientEmail", "patientName"));

        Assert.Equal("hcpId", exception.Identifier);
    }

    [Fact]
    public async Task Execute_WhenAllGoesWell_ReturnsDataSharingPermissionRequest()
    {
        var patientIdentityMock = new Mock<IIdentity>();
        patientIdentityMock.SetupGet(mock => mock.Id).Returns("patientId");

        var hcpIdentityMock = new Mock<IIdentity>();
        hcpIdentityMock.SetupGet(mock => mock.Id).Returns("hcpId");
        hcpIdentityMock.SetupGet(mock => mock.Email).Returns("hcpEmail");

        var hcpMetadata = new HcpPortalUserMetadata
        {
            OwnName = "hcpOwnName"
        };

        _identityProviderMock.Setup(mock => mock.FetchIdentityByEmail("patientEmail")).ReturnsAsync(patientIdentityMock.Object);
        _identityProviderMock.Setup(mock => mock.FetchIdentity("hcpId")).ReturnsAsync(hcpIdentityMock.Object);

        _metadataRepoMock.Setup(mock => mock.GetMetadataByIdentityId("hcpId")).ReturnsAsync(hcpMetadata);

        var dataSharingPermission = await _interactor.Execute("hcpId", "patientEmail", "patientName");

        Assert.Equal("patientId", dataSharingPermission.SubjectIdentityId);
        Assert.Equal("hcpId", dataSharingPermission.AccessorIdentityId);
        Assert.Equal("hcpOwnName", dataSharingPermission.AccessorReferenceName);
        Assert.Equal("hcpEmail", dataSharingPermission.AccessorEmail);
        Assert.Equal("Hcp", dataSharingPermission.Type);
        Assert.Equal("patientName", dataSharingPermission.SubjectReferenceName);
    }

    #endregion Execute
}
