﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class RevokeHcpInvitationInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_ReturnInvitation()
    {
        var invitationRepo = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepo.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(new HcpPortalUserInvitation() { Role = HcpPortalRole.Hcp, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1) });

        var interactor = new RevokeHcpInvitationInteractor(invitationRepo.Object);

        var updatedInvitation = await interactor.Execute(Guid.NewGuid());

        Assert.NotNull(updatedInvitation);
        Assert.Equal(InvitationStatus.Revoked, updatedInvitation.Status);
        Assert.Equal(HcpPortalRole.Hcp, updatedInvitation.Role);
        invitationRepo.Verify(mock => mock.GetInvitationById(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task Execute_WhenInvitationIsNull_ThrowInvitationNotFoundException()
    {
        var invitationRepo = new Mock<IHcpPortalUserInvitationRepository>();
        var interactor = new RevokeHcpInvitationInteractor(invitationRepo.Object);

        var ex = await Assert.ThrowsAsync<InvitationNotFoundException>(async () => await interactor.Execute(Guid.NewGuid()));

        Assert.Equal("The invitation does not exist", ex.Message);
        invitationRepo.Verify(mock => mock.GetInvitationById(It.IsAny<Guid>()), Times.Once);
    }

    [Fact]
    public async Task Execute_WhenTheRolesDontMatch_ThrowInvitationNotFoundException()
    {
        var invitationRepo = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepo.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(new HcpPortalUserInvitation() { Role = HcpPortalRole.CustomerAdmin, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1) });

        var interactor = new RevokeHcpInvitationInteractor(invitationRepo.Object);

        var ex = await Assert.ThrowsAsync<InvitationNotFoundException>(async () => await interactor.Execute(Guid.NewGuid()));

        Assert.Equal("The invitation does not exist", ex.Message);
        invitationRepo.Verify(mock => mock.GetInvitationById(It.IsAny<Guid>()), Times.Once);
    }

    #endregion Execute
}
