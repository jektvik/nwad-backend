﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using Moq;
using Xunit;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using System.Net;
using NwadHealth.Besthealthorg.Foundation.Interfaces;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class DeleteHcpInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_CallsDeleteIdentityOnIdentityProviderWithProvidedId()
    {
        const string identityId = "identityId";
        var ip = new IPAddress(new byte[] { 1, 2, 3, 4 });

        var identity = Mock.Of<IIdentity>();
        var identityProviderMock = new Mock<IIdentityProvider>();

        identityProviderMock
            .Setup(mock => mock.FetchIdentity(identityId))
            .ReturnsAsync(identity);

        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();
        roleAssignmentRepoMock.Setup(mock => mock.GetRoleAssignmentByIdentityId(identityId)).ReturnsAsync(new RoleAssignment { Id = "1", RoleId = "Hcp" });

        var interactor = new DeleteHcpInteractor(
            identityProviderMock.Object,
            Mock.Of<IIdentityEventPublisher>(),
            Mock.Of<IIdentityPropertiesRepository>(),
            roleAssignmentRepoMock.Object,
            Mock.Of<IAuditLogRepository>(),
            Mock.Of<ILogger<DeleteHcpInteractor>>());

        await interactor.Execute(identityId, identityId, ip);

        identityProviderMock.Verify(mock => mock.DeleteIdentity(identityId), Times.Once());
    }

    #endregion Execute
}
