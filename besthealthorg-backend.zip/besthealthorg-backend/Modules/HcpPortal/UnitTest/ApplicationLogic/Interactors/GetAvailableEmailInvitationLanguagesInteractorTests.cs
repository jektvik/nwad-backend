using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class GetAvailableEmailInvitationLanguagesInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_ReturnsLanguagesFromMailer()
    {
        var mailerMock = new Mock<IHcpPortalMailer>();
        mailerMock.Setup(mock => mock.AvailableLanguages("CustomerAdmin")).Returns(new List<string> { "en", "da" });
        mailerMock.Setup(mock => mock.AvailableLanguages("Hcp")).Returns(new List<string> { "da" });

        var interactor = new GetAvailableEmailInvitationLanguagesInteractor(
            mailerMock.Object,
            Mock.Of<ILogger<GetAvailableEmailInvitationLanguagesInteractor>>());

        var result = await interactor.Execute("CustomerAdmin");

        Assert.Equal("en", result.ElementAt(0));
        Assert.Equal("da", result.ElementAt(1));
    }

    [Fact]
    public async Task Execute_WhenInteractorThrowDirectoryNotFoundException_ThrowsArgumentOutOfRangeException()
    {
        var mailerMock = new Mock<IHcpPortalMailer>();
        mailerMock.Setup(mock => mock.AvailableLanguages("CustomerAdmin")).Throws(new DirectoryNotFoundException());

        var interactor = new GetAvailableEmailInvitationLanguagesInteractor(
            mailerMock.Object,
            Mock.Of<ILogger<GetAvailableEmailInvitationLanguagesInteractor>>());

        await Assert.ThrowsAsync<ArgumentOutOfRangeException>(async () => await interactor.Execute("CustomerAdmin"));
    }

    #endregion Execute
}
