﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;
public class RevokeCustomerAdminInvitationInteractorTests
{
    #region Execute

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_ReturnInvitation()
    {
        var invitationRepo = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepo.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(new HcpPortalUserInvitation() { Role = HcpPortalRole.CustomerAdmin, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1) });

        var interactor = new RevokeCustomerAdminInvitationInteractor(invitationRepo.Object);

        var updatedInvitation = await interactor.Execute(Guid.NewGuid());

        Assert.NotNull(updatedInvitation);
        Assert.Equal(InvitationStatus.Revoked, updatedInvitation.Status);
        Assert.Equal(HcpPortalRole.CustomerAdmin, updatedInvitation.Role);
        invitationRepo.Verify(mock => mock.GetInvitationById(It.IsAny<Guid>()), Times.Once);
    }

    #endregion Execute
}
