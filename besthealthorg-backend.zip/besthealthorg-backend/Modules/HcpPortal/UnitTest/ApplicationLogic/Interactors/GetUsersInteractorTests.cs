﻿using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class GetUsersInteractorTests
{
    static readonly PaginationRequest DefaultPaginationRequest = new() { PageSize = 20, Page = 0 };

    static readonly SortRequest DefaultSortRequest = new("Email");

    #region Execute

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_ReturnUsers()
    {
        var identityId = Guid.NewGuid();
        var metadataToReturn = new HcpPortalUserMetadata()
        {
            IdentityId= identityId.ToString(),
            InternalReferenceName="testReference",
            OwnName="testName",
            Email="mail@test.com",
            CreatedAt = DateTimeOffset.UtcNow.AddDays(-1),
        };

        var roleAssignmentsToReturn = new List<RoleAssignment>()
        {
            new() { Id = identityId.ToString(), RoleId = HcpPortalRole.CustomerAdmin.StringValue() }
        };

        var identityPropertiesToReturn = new IdentityProperties { IdentityId = identityId.ToString() ,CountryCode = "dk" };

        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        metadataRepoMock.Setup(mock => mock.GetMetadataByIdentityId(It.IsAny<string>())).ReturnsAsync(metadataToReturn);

        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();
        identityPropertiesRepoMock.Setup(mock => mock.GetIdentityPropertiesByIdentityId(It.IsAny<string>())).ReturnsAsync(identityPropertiesToReturn);

        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();
        roleAssignmentRepoMock.Setup(mock => mock.GetRoleAssignmentsByRoleId(It.IsAny<string>())).ReturnsAsync(roleAssignmentsToReturn);

        var interactor = new GetUsersInteractor(
            metadataRepoMock.Object,
            identityPropertiesRepoMock.Object,
            roleAssignmentRepoMock.Object
        );

        var responseUsers = await interactor.Execute(HcpPortalRole.CustomerAdmin, DefaultPaginationRequest, DefaultSortRequest, null);

        metadataRepoMock.Verify(mock => mock.GetMetadataByIdentityId(metadataToReturn.IdentityId), Times.Once());
        identityPropertiesRepoMock.Verify(mock => mock.GetIdentityPropertiesByIdentityId(identityId.ToString()), Times.Once());
        Assert.NotEmpty(responseUsers.Data);
        Assert.Equal(identityId.ToString(), responseUsers.Data.First().IdentityId);
    }

    [Fact]
    public async Task Execute_WhenIdentityPropertiesIsNull_DoNotReturnUser()
    {
        var identityId = Guid.NewGuid();
        var metadataToReturn = new HcpPortalUserMetadata()
        {
            IdentityId= identityId.ToString(),
            InternalReferenceName="testReference",
            OwnName="testName",
            Email="mail@test.com",
            CreatedAt = DateTimeOffset.UtcNow.AddDays(-1)
        };

        var roleAssignmentsToReturn = new List<RoleAssignment>()
        {
            new() { Id = identityId.ToString(), RoleId = HcpPortalRole.CustomerAdmin.StringValue() }
        };

        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        metadataRepoMock.Setup(mock => mock.GetMetadataByIdentityId(It.IsAny<string>())).ReturnsAsync(metadataToReturn);

        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();
        identityPropertiesRepoMock.Setup(mock => mock.GetIdentityPropertiesByIdentityId(It.IsAny<string>())).ReturnsAsync((IdentityProperties?)null);

        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();
        roleAssignmentRepoMock.Setup(mock => mock.GetRoleAssignmentsByRoleId(It.IsAny<string>())).ReturnsAsync(roleAssignmentsToReturn);

        var interactor = new GetUsersInteractor(
            metadataRepoMock.Object,
            identityPropertiesRepoMock.Object,
            roleAssignmentRepoMock.Object
        );

        var responseUsers = await interactor.Execute(HcpPortalRole.CustomerAdmin, DefaultPaginationRequest, DefaultSortRequest, null);

        metadataRepoMock.Verify(mock => mock.GetMetadataByIdentityId(metadataToReturn.IdentityId), Times.Once());
        identityPropertiesRepoMock.Verify(mock => mock.GetIdentityPropertiesByIdentityId(identityId.ToString()), Times.Once);
        Assert.Empty(responseUsers.Data);
    }

    [Fact]
    public async Task Execute_WhenRoleIsNotValid_ThrowArgumentException()
    {
        var metadataRepoMock = new Mock<IHcpPortalUserMetadataRepository>();
        var identityPropertiesRepoMock = new Mock<IIdentityPropertiesRepository>();
        var roleAssignmentRepoMock = new Mock<IRoleAssignmentRepository>();

        var interactor = new GetUsersInteractor(
            metadataRepoMock.Object,
            identityPropertiesRepoMock.Object,
            roleAssignmentRepoMock.Object
        );

        var ex = await Assert.ThrowsAsync<ArgumentException>(async () => await interactor.Execute(HcpPortalRole.NwadAdmin, DefaultPaginationRequest, DefaultSortRequest, null));
        Assert.Contains("The provided role is not valid (Parameter 'role')", ex.Message);
    }

    #endregion Execute
}
