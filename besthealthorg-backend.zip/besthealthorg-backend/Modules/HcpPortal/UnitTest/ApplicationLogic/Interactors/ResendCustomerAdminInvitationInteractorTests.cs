﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using Moq;
using Xunit;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class ResendCustomerAdminInvitationInteractorTests
{
    private static readonly string[] invitationLanguage = ["en"];

    private readonly HcpPortalConfiguration _config;
    public ResendCustomerAdminInvitationInteractorTests()
    {
        _config = new HcpPortalConfiguration("backendApiUrl/", "frontendUrl/", "webAppClientId", "sendgridApiKey");
    }

    #region Execute

    [Fact]
    public async Task Execute_WhenInteractorSucceeds_ReturnInvitation()
    {
        var invitationRepo = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepo.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(new HcpPortalUserInvitation() { ReceiverEmail="receiver@email.com", Role = HcpPortalRole.CustomerAdmin, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Language="en" });

        var metadataRepo = new Mock<IHcpPortalUserMetadataRepository>();
        metadataRepo.Setup(mock => mock.GetMetadataByIdentityId(It.IsAny<string>())).ReturnsAsync(new HcpPortalUserMetadata { IdentityId = "identityId", InternalReferenceName = "Doc", OwnName = "Doctor" });

        var mailer = new Mock<IHcpPortalMailer>();
        mailer.Setup(mock => mock.AvailableLanguages(It.IsAny<string>())).Returns(invitationLanguage);
        mailer.Setup(mock => mock.SendCustomerAdminInvitation(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));

        var interactor = new ResendCustomerAdminInvitationInteractor(invitationRepo.Object, metadataRepo.Object, _config, mailer.Object);

        var resentInvitation = await interactor.Execute(Guid.NewGuid(), "resenderIdentityId");

        Assert.NotNull(resentInvitation);
        Assert.Equal(InvitationStatus.Pending, resentInvitation.Status);
        Assert.Equal(HcpPortalRole.CustomerAdmin, resentInvitation.Role);
        invitationRepo.Verify(mock => mock.GetInvitationById(It.IsAny<Guid>()), Times.Once);
        mailer.Verify(mock => mock.AvailableLanguages(It.IsAny<string>()), Times.Once);
        mailer.Verify(mock => mock.SendCustomerAdminInvitation(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task Execute_WhenInvitationDoesntExist_ThrowInvitationNotFoundException()
    {
        var invitationRepo = new Mock<IHcpPortalUserInvitationRepository>();
        var metadataRepo = new Mock<IHcpPortalUserMetadataRepository>();
        var mailer = new Mock<IHcpPortalMailer>();
        var interactor = new ResendCustomerAdminInvitationInteractor(invitationRepo.Object, metadataRepo.Object, _config, mailer.Object);

        await Assert.ThrowsAsync<InvitationNotFoundException>(async () => await interactor.Execute(Guid.NewGuid(), "resenderIdentityId"));

        invitationRepo.Verify(mock => mock.GetInvitationById(It.IsAny<Guid>()), Times.Once);
        mailer.Verify(mock => mock.AvailableLanguages(It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task Execute_WhenRolesDontMatch_ThrowInvitationNotFoundException()
    {
        var invitationRepo = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepo.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(new HcpPortalUserInvitation() { Role = HcpPortalRole.Hcp, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Language = "en" });

        var metadataRepo = new Mock<IHcpPortalUserMetadataRepository>();
        var mailer = new Mock<IHcpPortalMailer>();
        var interactor = new ResendCustomerAdminInvitationInteractor(invitationRepo.Object, metadataRepo.Object, _config, mailer.Object);

        await Assert.ThrowsAsync<InvitationNotFoundException>(async () => await interactor.Execute(Guid.NewGuid(), "resenderIdentityId"));

        invitationRepo.Verify(mock => mock.GetInvitationById(It.IsAny<Guid>()), Times.Once);
        mailer.Verify(mock => mock.AvailableLanguages(It.IsAny<string>()), Times.Never);
    }

    [Fact]
    public async Task Execute_WhenTemplateDoesntExistInRequestedLanguage_ThrowUnsupportedInvitationLanguageException()
    {
        var invitationRepo = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepo.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(new HcpPortalUserInvitation() { Role = HcpPortalRole.CustomerAdmin, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Language = "da" });

        var metadataRepo = new Mock<IHcpPortalUserMetadataRepository>();

        var mailer = new Mock<IHcpPortalMailer>();
        mailer.Setup(mock => mock.AvailableLanguages(It.IsAny<string>())).Returns(invitationLanguage);

        var interactor = new ResendCustomerAdminInvitationInteractor(invitationRepo.Object, metadataRepo.Object, _config, mailer.Object);

        await Assert.ThrowsAsync<UnsupportedInvitationLanguageException>(async () => await interactor.Execute(Guid.NewGuid(), "resenderIdentityId"));

        invitationRepo.Verify(mock => mock.GetInvitationById(It.IsAny<Guid>()), Times.Once);
        mailer.Verify(mock => mock.AvailableLanguages(It.IsAny<string>()), Times.Once);
    }

    [Fact]
    public async Task Execute_WhenSenderHasNoMetadata_ThrowNoHcpPortalMetadataForIdentityException()
    {
        var invitationRepo = new Mock<IHcpPortalUserInvitationRepository>();
        invitationRepo.Setup(mock => mock.GetInvitationById(It.IsAny<Guid>())).ReturnsAsync(new HcpPortalUserInvitation() { Role = HcpPortalRole.CustomerAdmin, ExpiresAt = DateTimeOffset.UtcNow.AddDays(1), Language = "en" });

        var metadataRepo = new Mock<IHcpPortalUserMetadataRepository>();

        var mailer = new Mock<IHcpPortalMailer>();
        mailer.Setup(mock => mock.AvailableLanguages(It.IsAny<string>())).Returns(invitationLanguage);
        
        var interactor = new ResendCustomerAdminInvitationInteractor(invitationRepo.Object, metadataRepo.Object, _config, mailer.Object);

        await Assert.ThrowsAsync<NoHcpPortalMetadataForIdentityException>(async () => await interactor.Execute(Guid.NewGuid(), "resenderIdentityId"));

        invitationRepo.Verify(mock => mock.GetInvitationById(It.IsAny<Guid>()), Times.Once);
        mailer.Verify(mock => mock.AvailableLanguages(It.IsAny<string>()), Times.Once);
    }

    #endregion Execute
}
