﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class NoHcpPortalMetadataForIdentityExceptionTests
{
    #region InstantitateNoHcpPortalMetadataForIdentityException

    [Fact]
    public void InstantiateNoHcpPortalMetadataForIdentityException_HasCorrectMessage()
    {
        var ex = new NoHcpPortalMetadataForIdentityException("id");

        Assert.Equal("No HCP portal metadata is associated with this identity", ex.Message);
    }

    [Fact]
    public void InstantiateNoHcpPortalMetadataForIdentityException_SetsIdentityId()
    {
        const string expectedIdentityId = "some id";

        var ex = new NoHcpPortalMetadataForIdentityException(expectedIdentityId);

        Assert.Equal(expectedIdentityId, ex.IdentityId);
    }

    #endregion InstantitateNoHcpPortalMetadataForIdentityException
}
