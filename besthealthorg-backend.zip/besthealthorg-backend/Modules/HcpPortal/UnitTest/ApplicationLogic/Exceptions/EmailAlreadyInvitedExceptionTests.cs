﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using Xunit;

namespace NwadHealth.Besthealthorg.HcpPortalModule.UnitTest;

public class EmailAlreadyInvitedExceptionTests
{
    #region InstantitateEmailAlreadyInvitedException

    [Fact]
    public void InstantiateEmailAlreadyInvitedException_HasCorrectMessage()
    {
        var ex = new EmailAlreadyInvitedException("ReceiverEmail");

        Assert.Equal("Invitation has already been sent to this email address", ex.Message);
    }

    [Fact]
    public void InstantiateEmailAlreadyInvitedException_ReceiverId()
    {
        const string expectedReceiverEmail = "email@email.com";

        var ex = new EmailAlreadyInvitedException(expectedReceiverEmail);

        Assert.Equal(expectedReceiverEmail, ex.ReceiverEmail);
    }

    #endregion InstantitateEmailAlreadyInvitedException
}
