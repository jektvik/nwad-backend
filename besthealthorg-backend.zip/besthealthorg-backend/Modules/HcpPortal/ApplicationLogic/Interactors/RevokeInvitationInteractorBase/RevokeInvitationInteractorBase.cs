﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The base class containing the common logic for revoking Hcp portal user invitations
/// </summary>
public abstract class RevokeInvitationInteractorBase : IRevokeInvitationInteractorBase
{
    /// <summary>
    /// Specifies which role this interactor allows revoking
    /// </summary>
    protected abstract HcpPortalRole AllowedInvitationRole { get; }

    private readonly IHcpPortalUserInvitationRepository _invitationRepository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="invitationRepo">The data store for storage/retrieval of invitations</param>
    protected RevokeInvitationInteractorBase(IHcpPortalUserInvitationRepository invitationRepo)
    {
        _invitationRepository = invitationRepo;
    }

    /// <summary>
    /// Attempts to revoke the invitation
    /// </summary>
    /// <param name="invitationId">Guid of the invitation</param>
    /// <exception cref="InvitationNotFoundException">Thrown when invitation doesn't exist or the roles dont match</exception>
    /// <returns>Revoked invitation</returns>
    public virtual async Task<HcpPortalUserInvitation> Execute(Guid invitationId)
    {
        var existingInvitation = await _invitationRepository.GetInvitationById(invitationId);

        if (existingInvitation is null || existingInvitation.Role != AllowedInvitationRole)
        {
            throw new InvitationNotFoundException(invitationId);
        }

        existingInvitation.Status = InvitationStatus.Revoked;
        await _invitationRepository.UpdateInvitation(existingInvitation);

        return existingInvitation;
    }
}
