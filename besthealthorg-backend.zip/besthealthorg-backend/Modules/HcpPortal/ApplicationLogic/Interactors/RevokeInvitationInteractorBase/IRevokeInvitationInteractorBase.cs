﻿using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing business logic for revoking an invitation
/// </summary>
public interface IRevokeInvitationInteractorBase
{
    /// <summary>
    /// Revokes HCP Portal user invitation
    /// </summary>
    /// <param name="invitationId">Guid of the invitation to revoke</param>
    /// <returns>Revoked invitation</returns>
    Task<HcpPortalUserInvitation> Execute(Guid invitationId);
}
