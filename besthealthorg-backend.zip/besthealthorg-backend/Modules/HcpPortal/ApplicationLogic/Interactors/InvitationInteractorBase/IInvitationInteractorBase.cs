using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
///  The interface representing common logic for sending an invitation
/// </summary>
public interface IInvitationInteractorBase
{
    /// <summary>
    /// Attempts to send the invitation
    /// </summary>
    /// <param name="invitation">The invitation to send</param>
    /// <returns>Created invitation</returns>
    Task<HcpPortalUserInvitation> Execute(HcpPortalUserInvitation invitation);
}
