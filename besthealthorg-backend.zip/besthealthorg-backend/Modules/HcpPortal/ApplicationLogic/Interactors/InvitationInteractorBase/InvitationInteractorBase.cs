﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// Base class containing the common logic of invitation interactors
/// </summary>
public abstract class InvitationInteractorBase : IInvitationInteractorBase
{
    private readonly IHcpPortalUserInvitationRepository _invitationRepository;
    private readonly IHcpPortalUserMetadataRepository _metadataRepository;
    private readonly HcpPortalConfiguration _configuration;
    private readonly IIdentityProvider _identityProvider;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="invitationRepository">The data store for retrieving the invitations</param>
    /// <param name="metadataRepository">The data store for retrieving the HCP portal user metadata</param>
    /// <param name="configuration">The configuration to use</param>
    /// <param name="identityProvider">The identity provider to use</param>
    protected InvitationInteractorBase(
        IHcpPortalUserInvitationRepository invitationRepository,
        IHcpPortalUserMetadataRepository metadataRepository,
        HcpPortalConfiguration configuration,
        IIdentityProvider identityProvider)
    {
        _invitationRepository = invitationRepository;
        _metadataRepository = metadataRepository;
        _configuration = configuration;
        _identityProvider = identityProvider;
    }

    /// <summary>
    /// Attempts to send the invitation
    /// </summary>
    /// <param name="invitation">The invitation to send</param>
    /// <exception cref="EmailAlreadyInvitedException">Throws when trying to send an invitation to an email address that has already received one</exception>
    /// <exception cref="NoHcpPortalMetadataForIdentityException">Throws when trying to retrieve HCP portal user metadata for an identity that does not have any</exception>
    /// <exception cref="IdentityAlreadyExistsException">Throws when trying to send an invitation to an identity which already accepted one</exception>
    /// <returns>Created invitation</returns>
    public virtual async Task<HcpPortalUserInvitation> Execute(HcpPortalUserInvitation invitation)
    {
        var identity = await _identityProvider.FetchIdentityByEmail(invitation.ReceiverEmail);
        if (identity is not null)
        {
            throw new IdentityAlreadyExistsException(invitation.ReceiverEmail);
        }

        var existingInvitation = await _invitationRepository.GetInvitationByEmail(invitation.ReceiverEmail);

        if (existingInvitation is not null)
        {
            throw new EmailAlreadyInvitedException(invitation.ReceiverEmail);
        }

        var senderMetaData = await _metadataRepository.GetMetadataByIdentityId(invitation.SenderIdentityId);

        if (senderMetaData is null)
        {
            throw new NoHcpPortalMetadataForIdentityException(invitation.SenderIdentityId);
        }

        invitation.Id = Guid.NewGuid();
        invitation.ExpiresAt = DateTimeOffset.UtcNow.Add(_configuration.InvitationExpiryTime);
        invitation.Status = InvitationStatus.Pending;
        invitation.AcceptLink = $"{_configuration.BackendApiUrl}HcpPortal/Invitation/accept/{invitation.Id}";
        invitation.InviterOwnName = senderMetaData.OwnName;

        var savedInvitation = await _invitationRepository.SaveInvitation(invitation);
        await SendInvitation(invitation);

        return savedInvitation;
    }

    /// <summary>
    /// Implemented by subclass to customize how invitations are sent
    /// </summary>
    /// <param name="invitation">The invitation to send</param>
    protected abstract Task SendInvitation(HcpPortalUserInvitation invitation);
}
