﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
///  The interface representing business logic for sending an invitation to Customer Admin
/// </summary>
public interface IInviteCustomerAdminInteractor : IInvitationInteractorBase;
