﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for sending an invitation to Customer Admin
/// </summary>
public class InviteCustomerAdminInteractor : InvitationInteractorBase, IInviteCustomerAdminInteractor
{
    private readonly ILogger<InviteCustomerAdminInteractor> _logger;
    private readonly IHcpPortalMailer _mailer;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="invitationRepository">The data store for storage/retrieval of invitations</param>
    /// <param name="metadataRepository">The data store to use for retrieval of user metadata</param>
    /// <param name="logger">The logger to use</param>
    /// <param name="mailer">The mailer to use</param>
    /// <param name="configuration">The configuration to use</param>
    /// <param name="identityProvider">the identity provider to use</param>
    public InviteCustomerAdminInteractor(
        IHcpPortalUserInvitationRepository invitationRepository,
        IHcpPortalUserMetadataRepository metadataRepository,
        ILogger<InviteCustomerAdminInteractor> logger,
        IHcpPortalMailer mailer,
        HcpPortalConfiguration configuration,
        IIdentityProvider identityProvider) : base(invitationRepository, metadataRepository, configuration, identityProvider)
    {
        _logger = logger;
        _mailer = mailer;
    }

    /// <summary>
    /// Attempts to send the invitation
    /// </summary>
    /// <param name="invitation">The invitation to send and store</param>
    /// <exception cref="EmailAlreadyInvitedException">Thrown when trying to send an invitation to an email address that has already received one</exception>
    /// <exception cref="NoHcpPortalMetadataForIdentityException">Thrown when trying to retrieve HCP portal user metadata for an identity that does not have any</exception>
    /// <exception cref="UnsupportedInvitationLanguageException">Thrown when trying to send an invitation in a language that is not supported</exception>
    /// <returns>Created invitation</returns>
    public override async Task<HcpPortalUserInvitation> Execute(HcpPortalUserInvitation invitation)
    {
        _logger.LogInformation("Executing InviteCustomerAdminInteractor...");

        invitation.Role = HcpPortalRole.CustomerAdmin;
        if (!_mailer.AvailableLanguages("CustomerAdmin").Contains(invitation.Language))
        {
            throw new UnsupportedInvitationLanguageException(invitation.Language);
        }

        return await base.Execute(invitation);
    }

    /// <summary>
    /// Sends an invitation using the customer admin template
    /// </summary>
    /// <param name="invitation">The invitation parameters to use</param>
    protected override async Task SendInvitation(HcpPortalUserInvitation invitation)
    {
        await _mailer.SendCustomerAdminInvitation(invitation.ReceiverEmail, invitation.Language, invitation.InviterOwnName, invitation.AcceptLink);
    }
}
