﻿using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
///  The interface representing common logic for resending an invitation
/// </summary>
public interface IResendInvitationInteractorBase
{
    /// <summary>
    /// Resends HCP Portal user invitation
    /// </summary>
    /// <param name="invitationId">The invitation to resend</param>
    /// <param name="resenderIdentityId">The Id of the identity resending the invitation</param>
    /// <returns>Resent invitation</returns>
    Task<HcpPortalUserInvitation> Execute(Guid invitationId, string resenderIdentityId);
}
