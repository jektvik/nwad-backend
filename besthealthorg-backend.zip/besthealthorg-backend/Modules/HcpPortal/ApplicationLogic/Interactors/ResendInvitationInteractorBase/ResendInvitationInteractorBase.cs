﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Exceptions;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// Base class containing the common logic of resend invitation interactors
/// </summary>
public abstract class ResendInvitationInteractorBase : IResendInvitationInteractorBase
{
    /// <summary>
    /// Specifies which role this interactor allows resending
    /// </summary>
    protected abstract HcpPortalRole AllowedInvitationRole { get; }

    private readonly IHcpPortalUserInvitationRepository _invitationRepository;
    private readonly IHcpPortalUserMetadataRepository _metadataRepository;
    private readonly HcpPortalConfiguration _configuration;
    private readonly IHcpPortalMailer _mailer;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="invitationRepo">The data store for storage/retrieval of invitations</param>
    /// <param name="metadataRepo">The data store for retrieving the HCP portal user metadata</param>
    /// <param name="configuration">The configuration to use</param>
    /// <param name="mailer">The mailer to use</param>
    protected ResendInvitationInteractorBase(
        IHcpPortalUserInvitationRepository invitationRepo,
        IHcpPortalUserMetadataRepository metadataRepo,
        HcpPortalConfiguration configuration,
        IHcpPortalMailer mailer)
    {
        _invitationRepository = invitationRepo;
        _metadataRepository = metadataRepo;
        _configuration = configuration;
        _mailer = mailer;
    }

    /// <summary>
    /// Attempts to resend the invitation
    /// </summary>
    /// <param name="invitationId">Guid of the invitation</param>
    /// <param name="resenderIdentityId">The Id of the identity resending the invitation</param>
    /// <exception cref="InvitationNotFoundException">Thrown when invitation doesn't exist or the roles dont match</exception>
    /// <exception cref="InvalidInvitationStatusException">Thrown when trying to resend accepted invitation</exception>
    /// <exception cref="NoHcpPortalMetadataForIdentityException">Thrown when trying to retrieve HCP portal user metadata for an identity that does not have any</exception>
    /// <exception cref="UnsupportedInvitationLanguageException">Thrown when trying to resend an invitation in a language that is not supported</exception>
    /// <returns>Resent invitation</returns>
    public virtual async Task<HcpPortalUserInvitation> Execute(Guid invitationId, string resenderIdentityId)
    {
        var existingInvitation = await _invitationRepository.GetInvitationById(invitationId);

        if (existingInvitation is null || existingInvitation.Role != AllowedInvitationRole)
        {
            throw new InvitationNotFoundException(invitationId);
        }

        if (!_mailer.AvailableLanguages(existingInvitation.Role.StringValue()).Contains(existingInvitation.Language))
        {
            throw new UnsupportedInvitationLanguageException(existingInvitation.Language);
        }

        var senderMetaData = await _metadataRepository.GetMetadataByIdentityId(resenderIdentityId);

        if (senderMetaData is null)
        {
            throw new NoHcpPortalMetadataForIdentityException(resenderIdentityId);
        }

        existingInvitation.Status = InvitationStatus.Pending;
        existingInvitation.ExpiresAt = DateTimeOffset.UtcNow.AddDays(_configuration.InvitationExpiryTime.Days);
        existingInvitation.InviterOwnName = senderMetaData.OwnName;
        existingInvitation.AcceptLink = $"{_configuration.BackendApiUrl}HcpPortal/Invitation/accept/{existingInvitation.Id}";

        await _invitationRepository.UpdateInvitation(existingInvitation);
        await SendInvitation(existingInvitation);

        return existingInvitation;
    }

    /// <summary>
    /// Implemented by subclass to customize how invitations are resend
    /// </summary>
    /// <param name="invitation">The invitation to send</param>
    protected abstract Task SendInvitation(HcpPortalUserInvitation invitation);
}
