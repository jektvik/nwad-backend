﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
///  The interface representing business logic for verifying the validity of an invite
/// </summary>
public interface IAcceptInvitationInteractor
{
    /// <summary>
    /// Attempts to verify the invitation
    /// </summary>
    /// <param name="invitationId">Guid of the invitation</param>
    /// <returns>redirect link</returns>
    public Task<string> Execute(Guid invitationId);
}
