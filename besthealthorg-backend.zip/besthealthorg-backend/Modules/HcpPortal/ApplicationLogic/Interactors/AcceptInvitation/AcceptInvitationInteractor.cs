﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
///  The interface representing business logic for verifying the validity of an invite
/// </summary>
public class AcceptInvitationInteractor : IAcceptInvitationInteractor
{
    private readonly IHcpPortalUserInvitationRepository _invitationRepository;
    private readonly ILogger<AcceptInvitationInteractor> _logger;
    private readonly HcpPortalConfiguration _configuration;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="invitationRepository">The data store for storage/retrieval of invitations</param>
    /// <param name="logger">The logger to use</param>
    /// <param name="configuration">The configuration to use</param>
    public AcceptInvitationInteractor(
        IHcpPortalUserInvitationRepository invitationRepository,
        ILogger<AcceptInvitationInteractor> logger,
        HcpPortalConfiguration configuration)
    {
        _invitationRepository = invitationRepository;
        _logger = logger;
        _configuration = configuration;
    }

    /// <summary>
    /// Attempts to verify the invitation
    /// </summary>
    /// <param name="invitationId">Guid of the invitation</param>
    /// <returns>redirect link</returns>
    public async Task<string> Execute(Guid invitationId)
    {
        _logger.LogInformation("Executing AcceptInvitationInteractor...");

        var invitation = await _invitationRepository.GetInvitationById(invitationId);

        if (invitation is null)
        {
            return $"{_configuration.FrontendBaseUrl}signup/error";
        }

        return invitation.Status switch
        {
            InvitationStatus.Pending => $"{_configuration.FrontendBaseUrl}signup?invitationId={invitationId}",
            InvitationStatus.Revoked => $"{_configuration.FrontendBaseUrl}signup/revoked",
            _ => $"{_configuration.FrontendBaseUrl}signup/expired"
        };
    }
}
