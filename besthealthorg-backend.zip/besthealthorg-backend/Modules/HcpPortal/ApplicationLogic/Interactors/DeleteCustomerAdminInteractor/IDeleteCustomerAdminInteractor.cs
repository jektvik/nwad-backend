﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// Interface representing business logic for deleting Customer Admin
/// </summary>
public interface IDeleteCustomerAdminInteractor: IDeleteHcpPortalUserInteractorBase;
