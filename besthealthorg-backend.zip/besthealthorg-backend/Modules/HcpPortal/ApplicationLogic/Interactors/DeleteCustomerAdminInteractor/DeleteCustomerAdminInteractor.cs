﻿using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for deleting Customer Admin
/// </summary>
public class DeleteCustomerAdminInteractor : DeleteHcpPortalUserInteractorBase, IDeleteCustomerAdminInteractor
{
    /// <summary>
    /// Specifies which role this interactor allows deleting
    /// </summary>
    protected override HcpPortalRole AllowedIdentityRole => HcpPortalRole.CustomerAdmin;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="identityProvider">The identity provider to use</param>
    /// <param name="eventPublisher">The event publisher to use</param>
    /// <param name="identityPropertiesRepository">The data store to use for deleting the users identity properties</param>
    /// <param name="roleAssignmentRepository">The data store to use for deleting the users identity properties</param>
    /// <param name="auditLogRepository">The data store to use for writing audit logs</param>
    /// <param name="logger">The logger to use</param>
    public DeleteCustomerAdminInteractor(IIdentityProvider identityProvider,
        IIdentityEventPublisher eventPublisher,
        IIdentityPropertiesRepository identityPropertiesRepository,
        IRoleAssignmentRepository roleAssignmentRepository,
        IAuditLogRepository auditLogRepository,
        ILogger<DeleteCustomerAdminInteractor> logger) : base(
            identityProvider,
            eventPublisher,
            identityPropertiesRepository,
            roleAssignmentRepository,
            auditLogRepository,
            logger)
    {
    }
}
