﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing business logic for revoking an CustomerAdmin invitation
/// </summary>
public interface IRevokeCustomerAdminInvitationInteractor : IRevokeInvitationInteractorBase;
