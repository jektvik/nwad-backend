﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interactor representing business logic for revoking Hcp portal user invitations
/// </summary>
public class RevokeCustomerAdminInvitationInteractor : RevokeInvitationInteractorBase, IRevokeCustomerAdminInvitationInteractor
{
    /// <summary>
    /// Specifies which role this interactor allows revoking
    /// </summary>
    protected override HcpPortalRole AllowedInvitationRole => HcpPortalRole.CustomerAdmin;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="invitationRepo">The data store for storage/retrieval of invitations</param>
    public RevokeCustomerAdminInvitationInteractor(IHcpPortalUserInvitationRepository invitationRepo) : base(invitationRepo)
    {
    }
}
