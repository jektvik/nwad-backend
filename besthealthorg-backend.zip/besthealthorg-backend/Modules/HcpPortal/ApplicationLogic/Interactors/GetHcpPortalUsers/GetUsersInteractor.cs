﻿using NwadHealth.Besthealthorg.Foundation.Extensions;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interactor representing business logic for getting HCP portal users by role
/// </summary>
public class GetUsersInteractor : IGetUsersInteractor
{
    private readonly IHcpPortalUserMetadataRepository _metadataRepository;
    private readonly IIdentityPropertiesRepository _identityPropertiesRepository;
    private readonly IRoleAssignmentRepository _roleAssignmentRepository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="metadataRepository">The repository to fetch the user metadata from</param>
    /// <param name="identityPropertiesRepository">The repository to fetch the identity properties from</param>
    /// <param name="roleAssignmentRepository">The repository to fetch the role assignments from</param>
    public GetUsersInteractor(
        IHcpPortalUserMetadataRepository metadataRepository,
        IIdentityPropertiesRepository identityPropertiesRepository,
        IRoleAssignmentRepository roleAssignmentRepository
        )
    {
        _metadataRepository = metadataRepository;
        _identityPropertiesRepository = identityPropertiesRepository;
        _roleAssignmentRepository = roleAssignmentRepository;
    }

    /// <summary>
    /// Gets HCP portal users by role
    /// </summary>
    /// <param name="role">The role to filter the users by</param>
    /// <param name="paginationRequest">The request object containing pagination parameters</param>
    /// <param name="sortRequest">The request object containing sorting parameters</param>
    /// <param name="searchQuery">Keyword used for searching the users</param>
    /// <returns>HCP portal users for the specified role</returns>
    /// <exception cref="ArgumentException">Thrown when provided role is not valid</exception>
    public async Task<PaginatedItems<HcpPortalUser>> Execute(
        HcpPortalRole role,
        PaginationRequest paginationRequest,
        SortRequest sortRequest,
        string? searchQuery)
    {
        if (role is not HcpPortalRole.CustomerAdmin and not HcpPortalRole.Hcp)
        {
            throw new ArgumentException("The provided role is not valid", nameof(role));
        }

        var roleAssignmentsInRole = await _roleAssignmentRepository.GetRoleAssignmentsByRoleId(role.StringValue());

        var users = (await GetUsersFromRoleAssignments(roleAssignmentsInRole))
            .Where(UsersForKeyword(searchQuery))
            .ToList();

        var totalUsers = users.Count;

        var (pageSize, pageIndex) = paginationRequest.Limit(totalUsers, 100);

        var sortvalue = sortRequest.SortBy?.ToLower() switch
        {
            "datecreated" => "CreatedDateTime",
            "country" => "CountryCode",
            _ => sortRequest.SortBy ?? "InternalReferenceName",
        };

        users = users
            .AsQueryable()
            .SortBy(sortvalue, sortRequest.SortOrder)
            .ThenBy(u => u.IdentityId)
            .Skip(pageSize * pageIndex)
            .Take(pageSize)
            .ToList();

        return new PaginatedItems<HcpPortalUser>(pageIndex, pageSize, totalUsers, users);
    }

    private static Func<HcpPortalUser, bool> UsersForKeyword(string? keyword)
    {
        return hcpPortalUser => string.IsNullOrEmpty(keyword) || (hcpPortalUser.InternalReferenceName ?? string.Empty)
            .Contains(keyword, StringComparison.CurrentCultureIgnoreCase) || hcpPortalUser.Email.Contains(keyword, StringComparison.CurrentCultureIgnoreCase);
    }

    private async Task<List<HcpPortalUser>> GetUsersFromRoleAssignments(IEnumerable<RoleAssignment> roleAssignments)
    {
        var metadataInRole = new List<HcpPortalUserMetadata>();

        foreach (var assignment in roleAssignments)
        {
            var metadata = await _metadataRepository.GetMetadataByIdentityId(assignment.Id);
            if (metadata is not null)
            {
                metadataInRole.Add(metadata);
            }
        }

        var tasks = metadataInRole.Select(async metadata =>
        {
            var properties = await _identityPropertiesRepository.GetIdentityPropertiesByIdentityId(metadata.IdentityId);

            if (properties is null)
            {
                return null;
            }

            return new HcpPortalUser
            {
                IdentityId = metadata.IdentityId,
                Email = metadata.Email,
                CreatedDateTime = metadata.CreatedAt,
                InternalReferenceName = metadata.InternalReferenceName,
                CountryCode = properties.CountryCode
            };
        });

        var users = await Task.WhenAll(tasks);

        return users.Where(user => user is not null).Select(user => user!).ToList();
    }
}
