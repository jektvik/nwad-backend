﻿using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing business logic for getting Hcp portal users
/// </summary>
public interface IGetUsersInteractor
{
    /// <summary>
    /// Gets HCP portal users by role
    /// </summary>
    /// <param name="role">The role to filter the users by</param>
    /// <param name="paginationRequest">The request object containing pagination parameters</param>
    /// <param name="sortRequest">The request object containing sorting parameters</param>
    /// <param name="searchQuery">Keyword used for searching the users</param>
    /// <returns>HCP portal users for the specified role</returns>
    public Task<PaginatedItems<HcpPortalUser>> Execute(HcpPortalRole role, PaginationRequest paginationRequest, SortRequest sortRequest, string? searchQuery);
}
