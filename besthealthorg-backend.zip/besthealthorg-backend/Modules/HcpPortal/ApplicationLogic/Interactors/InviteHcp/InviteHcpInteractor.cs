﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for sending an invitation to Health Care Provider
/// </summary>
public class InviteHcpInteractor : InvitationInteractorBase, IInviteHcpInteractor
{
    private readonly ILogger<InviteHcpInteractor> _logger;
    private readonly IHcpPortalMailer _mailer;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="invitationRepository">The data store for storage/retrieval of invitations</param>
    /// <param name="metadataRepository">The data store to use for retrieval of user metadata</param>
    /// <param name="logger">The logger to use</param>
    /// <param name="configuration">The configuration to use</param>
    /// <param name="mailer">The mailer to use</param>
    /// <param name="identityProvider">The identity provider to use</param>
    public InviteHcpInteractor(
        IHcpPortalUserInvitationRepository invitationRepository,
        IHcpPortalUserMetadataRepository metadataRepository,
        ILogger<InviteHcpInteractor> logger,
        HcpPortalConfiguration configuration,
        IHcpPortalMailer mailer,
        IIdentityProvider identityProvider) : base(invitationRepository, metadataRepository, configuration, identityProvider)
    {
        _logger = logger;
        _mailer = mailer;
    }

    /// <summary>
    /// Attempts to send the invitation
    /// </summary>
    /// <param name="invitation">The invitation to send and store</param>
    /// <exception cref="EmailAlreadyInvitedException">Thrown when trying to send an invitation to an email address that has already received one</exception>
    /// <exception cref="NoHcpPortalMetadataForIdentityException">Thrown when trying to retrieve HCP portal user metadata for an identity that does not have any</exception>
    /// <exception cref="UnsupportedInvitationLanguageException">Thrown when trying to send an invitation in a language that is not supported</exception>
    /// <returns>Created invitation</returns>
    public override async Task<HcpPortalUserInvitation> Execute(HcpPortalUserInvitation invitation)
    {
        _logger.LogInformation("Executing InviteHcpInteractor...");

        invitation.Role = HcpPortalRole.Hcp;
        if (!_mailer.AvailableLanguages("Hcp").Contains(invitation.Language))
        {
            throw new UnsupportedInvitationLanguageException(invitation.Language);
        }

        return await base.Execute(invitation);
    }

    /// <summary>
    /// Sends an invitation using the HCP template
    /// </summary>
    /// <param name="invitation">The invitation parameters to use</param>
    protected override async Task<Guid> SendInvitation(HcpPortalUserInvitation invitation)
    {
        await _mailer.SendHcpInvitation(invitation.ReceiverEmail, invitation.Language, invitation.InviterOwnName, invitation.AcceptLink);
        return invitation.Id;
    }
}
