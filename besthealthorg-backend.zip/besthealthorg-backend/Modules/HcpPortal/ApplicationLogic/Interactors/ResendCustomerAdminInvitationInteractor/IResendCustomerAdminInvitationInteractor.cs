﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing business logic for resending a Customer Admin invitation
/// </summary>
public interface IResendCustomerAdminInvitationInteractor : IResendInvitationInteractorBase;
