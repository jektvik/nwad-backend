using NwadHealth.Besthealthorg.PermissionModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of an HCP requesting data sharing from a patient
/// </summary>
public interface ICreateHcpDataSharingRequestInteractor
{
    /// <summary>
    /// Creates the data sharing request
    /// </summary>
    /// <param name="hcpIdentityId">The unique identifier of the HCP account requesting data sharing</param>
    /// <param name="patientEmail">The email of the patient to receive the request</param>
    /// <param name="patientName">The name to use for displaying the patient to the HCP</param>
    /// <returns>The created request</returns>
    Task<DataSharingPermissionRequest> Execute(string hcpIdentityId, string patientEmail, string? patientName);
}
