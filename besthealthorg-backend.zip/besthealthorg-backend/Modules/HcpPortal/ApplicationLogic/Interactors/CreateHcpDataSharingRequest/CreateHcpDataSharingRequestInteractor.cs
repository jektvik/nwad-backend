using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.PermissionModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents the business logic of an HCP requesting data sharing from a patient
/// </summary>
public class CreateHcpDataSharingRequestInteractor : ICreateHcpDataSharingRequestInteractor
{
    private readonly IIdentityProvider _identityProvider;
    private readonly IHcpPortalUserMetadataRepository _metadataRepo;
    private readonly HcpPortalConfiguration _config;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="identityProvider">The identity provider to use</param>
    /// <param name="metadataRepo">The metadata repository to use</param>
    /// <param name="config">The configuration to use</param>
    public CreateHcpDataSharingRequestInteractor(
        IIdentityProvider identityProvider,
        IHcpPortalUserMetadataRepository metadataRepo,
        HcpPortalConfiguration config
    )
    {
        _identityProvider = identityProvider;
        _metadataRepo = metadataRepo;
        _config = config;
    }

    /// <summary>
    /// Creates the data sharing request
    /// </summary>
    /// <param name="hcpIdentityId">The unique identifier of the HCP account requesting data sharing</param>
    /// <param name="patientEmail">The email of the patient to receive the request</param>
    /// <param name="patientName">The name to use for displaying the patient to the HCP</param>
    /// <returns>The created request</returns>
    /// <exception cref="IdentityNotFoundException">Thrown if the patient or HCP identity could not be found</exception>
    /// <exception cref="NoHcpPortalMetadataForIdentityException">Thrown if no metadata could be found for the HCP</exception>
    public async Task<DataSharingPermissionRequest> Execute(string hcpIdentityId, string patientEmail, string? patientName)
    {
        var patientIdentity = await _identityProvider.FetchIdentityByEmail(patientEmail);

        if (patientIdentity is null)
        {
            throw new IdentityNotFoundException(patientEmail);
        }

        var hcpMetadata = await _metadataRepo.GetMetadataByIdentityId(hcpIdentityId);

        if (hcpMetadata is null)
        {
            throw new NoHcpPortalMetadataForIdentityException(hcpIdentityId);
        }

        var hcpIdentity = await _identityProvider.FetchIdentity(hcpIdentityId);

        if (hcpIdentity is null)
        {
            throw new IdentityNotFoundException(hcpIdentityId);
        }

        return new(
            patientIdentity.Id,
            hcpIdentity.Id,
            hcpMetadata.OwnName,
            HcpPortalConfiguration.HcpPermissionType,
            DateTimeOffset.UtcNow.Add(_config.DataSharingRequestExpiryTime))
        {
            SubjectReferenceName = patientName,
            SubjectEmail = patientEmail,
            AccessorEmail = hcpIdentity.Email,
        };
    }
}
