﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
///  The interface representing business logic for user signing up on HCP portal
/// </summary>
public interface ISignUpInteractor
{
    /// <summary>
    /// Attempts to sign up the user
    /// </summary>
    /// <param name="invitationId">Unique id of the invitation</param>
    /// <param name="ownName">What user calls him/her self</param>
    /// <param name="country">User's country of residence</param>
    /// <returns>Redirect url to set password page</returns>
    public Task<string> Execute(Guid invitationId, string ownName, string country);
}
