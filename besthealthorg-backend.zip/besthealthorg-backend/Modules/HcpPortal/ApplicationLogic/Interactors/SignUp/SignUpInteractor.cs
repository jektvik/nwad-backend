﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors.SignUp;

/// <summary>
/// Attempts to sign up the user
/// </summary>
public class SignUpInteractor : ISignUpInteractor
{
    private readonly IIdentityProvider _identityProvider;
    private readonly IHcpPortalUserInvitationRepository _invitationRepository;
    private readonly IIdentityPropertiesRepository _identityPropertiesRepository;
    private readonly IRoleAssignmentRepository _roleAssignmentRepository;
    private readonly IHcpPortalUserMetadataRepository _userMetadataRepository;
    private readonly ICountryRepository _countryRepository;
    private readonly HcpPortalConfiguration _configuration;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="identityProvider">The identity provider to use</param>
    /// <param name="invitationRepo">The repository to fetch the invitation from</param>
    /// <param name="identityPropertiesRepo">The repository where the identity properties will be created</param>
    /// <param name="roleAssignmentRepo">The repository where the role assignment will be created</param>
    /// <param name="userMetadataRepo">The repository where the HCP portal user metadata will be created</param>
    /// <param name="countryRepository">The repository to fetch the available countries from</param>
    /// <param name="configuration">The configuration to use</param>
    public SignUpInteractor(
        IIdentityProvider identityProvider,
        IHcpPortalUserInvitationRepository invitationRepo,
        IIdentityPropertiesRepository identityPropertiesRepo,
        IRoleAssignmentRepository roleAssignmentRepo,
        IHcpPortalUserMetadataRepository userMetadataRepo,
        ICountryRepository countryRepository,
        HcpPortalConfiguration configuration
        )
    {
        _identityProvider = identityProvider;
        _invitationRepository = invitationRepo;
        _identityPropertiesRepository = identityPropertiesRepo;
        _roleAssignmentRepository = roleAssignmentRepo;
        _userMetadataRepository = userMetadataRepo;
        _countryRepository = countryRepository;
        _configuration = configuration;
    }

    /// <summary>
    /// Attempts to sign up the user
    /// </summary>
    /// <param name="invitationId">Unique id of the invitation</param>
    /// <param name="ownName">What user calls him/her self</param>
    /// <param name="country">User's country of residence</param>
    /// <returns>Redirect url to set password page</returns>
    /// <exception cref="SignUpFailedException">Thrown when one of the sign up steps fails</exception>
    /// <exception cref="UnsupportedCountryException">Thrown when entered country is not supported</exception>
    /// <exception cref="InvitationNotFoundException">Thorwn when entered invitation does not exist</exception>
    /// <exception cref="InvalidInvitationStatusException">Thrown when invitation is in invalid status for this operation</exception>
    /// <exception cref="ExpiredInvitationException">Thrown when trying to sign up using an invitation that has expired</exception>
    public async Task<string> Execute(Guid invitationId, string ownName, string country)
    {
        var invitation = await _invitationRepository.GetInvitationById(invitationId) ?? throw new InvitationNotFoundException(invitationId);

        if (invitation.Status != InvitationStatus.Pending)
        {
            throw new InvalidInvitationStatusException(invitation.Status);
        }

        var dbcountry = (country is null) ? null : await _countryRepository.GetCountryByCountryCode(country);

        if (dbcountry is null)
        {
            throw new UnsupportedCountryException(country!);
        }

        try
        {
            var identity = await _identityProvider.CreateIdentity(invitation.ReceiverEmail, $"Aa0 + {Guid.NewGuid()}", true);

            await _identityPropertiesRepository.Create(new()
            {
                IdentityId = identity!.Id,
                CountryCode = country
            });

            await _roleAssignmentRepository.CreateRoleAssignment(new() { Id = identity.Id, RoleId = invitation.Role.StringValue() });

            await _userMetadataRepository.CreateMetadata(
                new HcpPortalUserMetadata {
                    IdentityId = identity.Id,
                    InternalReferenceName = invitation.InternalReferenceName,
                    OwnName = ownName,
                    Email = invitation.ReceiverEmail,
                    CreatedAt = DateTimeOffset.UtcNow,
                    Language = invitation.Language});

            var resetPasswordUrl = await _identityProvider.CreateResetPasswordTicket(identity.Id, true, _configuration.WebApplicationClientId);

            await _invitationRepository.DeleteInvitationByEmail(invitation.ReceiverEmail);
            return resetPasswordUrl!;
        }
        catch (Exception e)
        {
            throw new SignUpFailedException(e);
        }
    }
}
