﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing business logic for revoking an HCP invitation
/// </summary>
public interface IRevokeHcpInvitationInteractor : IRevokeInvitationInteractorBase;
