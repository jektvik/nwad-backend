﻿using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing business logic for getting non accepted HCP portal invitations
/// </summary>
public interface IGetInvitationsInteractor
{
    /// <summary>
    /// Gets non accepted Hcp portal invitations by role
    /// </summary>
    /// <param name="role">The role to filter the invitations by</param>
    /// <param name="paginationRequest">The request object containing pagination parameters</param>
    /// <param name="sortRequest">The request object containing sorting parameters</param>
    /// <param name="searchQuery">Keyword used for searching the permission requests</param>
    /// <returns>Paginated items of HCP portal user invitations for the specified role</returns>
    public Task<PaginatedItems<HcpPortalUserInvitation>> Execute(
        string role,
        PaginationRequest paginationRequest,
        SortRequest sortRequest,
        string? searchQuery);
}
