﻿using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interactor representing business logic for getting HCP portal invitations by role
/// </summary>
public class GetInvitationsInteractor : IGetInvitationsInteractor
{
    private readonly IHcpPortalUserInvitationRepository _invitationRepository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="invitationRepository">The repository to fetch the invitations from</param>
    public GetInvitationsInteractor(IHcpPortalUserInvitationRepository invitationRepository)
    {
        _invitationRepository = invitationRepository;
    }

    /// <summary>
    /// Gets HCP portal invitations with for specified role
    /// </summary>
    /// <param name="role">The role to filter the invitations by</param>
    /// <param name="paginationRequest">The request object containing pagination parameters</param>
    /// <param name="sortRequest">The request object containing sorting parameters</param>
    /// <param name="searchQuery">Keyword used for searching the permission requests</param>
    /// <returns>Paginated items of HCP portal user invitations for the specified role</returns>
    public async Task<PaginatedItems<HcpPortalUserInvitation>> Execute(
        string role,
        PaginationRequest paginationRequest,
        SortRequest sortRequest,
        string? searchQuery)
    {
        return await _invitationRepository.GetInvitationsByRole(role, paginationRequest, sortRequest, searchQuery);
    }
}
