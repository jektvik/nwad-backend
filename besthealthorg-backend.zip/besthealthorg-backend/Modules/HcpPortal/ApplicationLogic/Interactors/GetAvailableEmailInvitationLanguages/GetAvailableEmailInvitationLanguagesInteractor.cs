using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// Business logic for getting available languages for an invitation template
/// </summary>
public class GetAvailableEmailInvitationLanguagesInteractor : IGetAvailableEmailInvitationLanguagesInteractor
{
    private readonly IHcpPortalMailer _mailer;
    private readonly ILogger<GetAvailableEmailInvitationLanguagesInteractor> _logger;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="mailer">The mailer to use</param>
    /// <param name="logger">The logger to use</param>
    public GetAvailableEmailInvitationLanguagesInteractor(IHcpPortalMailer mailer, ILogger<GetAvailableEmailInvitationLanguagesInteractor> logger)
    {
        _mailer = mailer;
        _logger = logger;
    }

    /// <summary>
    /// Gets the available languages for the given template
    /// </summary>
    /// <param name="templateName">The name of the template to get available languages for</param>
    /// <exception cref="ArgumentOutOfRangeException">Thrown when trying to get template that does not exist</exception>
    public Task<IEnumerable<string>> Execute(string templateName)
    {
        _logger.LogInformation("Executing GetAvailableInvitationLanguagesInteractor...");

        try
        {
            return Task.FromResult(_mailer.AvailableLanguages(templateName));
        }
        catch (DirectoryNotFoundException)
        {
            throw new ArgumentOutOfRangeException(nameof(templateName), $"The template '{templateName}' does not exist");
        }
    }
}
