namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing business logic for getting available languages for an invitation template
/// </summary>
public interface IGetAvailableEmailInvitationLanguagesInteractor
{
    /// <summary>
    /// Gets the available languages for the given template
    /// </summary>
    /// <param name="templateName">The name of the template to get available languages for</param>
    Task<IEnumerable<string>> Execute(string templateName);
}
