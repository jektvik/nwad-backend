﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interactor representing business logic for resending Hcp portal user invitations
/// </summary>
public class ResendHcpInvitationInteractor : ResendInvitationInteractorBase, IResendHcpInvitationInteractor
{
    /// <summary>
    /// Specifies which role this interactor allows resending
    /// </summary>
    protected override HcpPortalRole AllowedInvitationRole => HcpPortalRole.Hcp;

    private readonly IHcpPortalMailer _mailer;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="invitationRepository">The data store for storage/retrieval of invitations</param>
    /// <param name="metadataRepository">The data store to use for retrieval of user metadata</param>
    /// <param name="configuration">The configuration to use</param>
    /// <param name="mailer">The mailer to use</param>
    public ResendHcpInvitationInteractor(
        IHcpPortalUserInvitationRepository invitationRepository,
        IHcpPortalUserMetadataRepository metadataRepository,
        HcpPortalConfiguration configuration,
        IHcpPortalMailer mailer) : base(invitationRepository, metadataRepository, configuration, mailer)
    {
        _mailer = mailer;
    }

    /// <summary>
    /// Resends an invitation using the HCP template
    /// </summary>
    /// <param name="invitation">The invitation parameters to use</param>
    protected override async Task SendInvitation(HcpPortalUserInvitation invitation)
    {
        await _mailer.SendHcpInvitation(invitation.ReceiverEmail, invitation.Language, invitation.InviterOwnName, invitation.AcceptLink);
    }
}
