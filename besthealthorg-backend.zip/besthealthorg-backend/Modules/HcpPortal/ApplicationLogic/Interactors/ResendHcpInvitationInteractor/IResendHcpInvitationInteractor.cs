﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing business logic for resending an HCP invitation
/// </summary>
public interface IResendHcpInvitationInteractor : IResendInvitationInteractorBase;
