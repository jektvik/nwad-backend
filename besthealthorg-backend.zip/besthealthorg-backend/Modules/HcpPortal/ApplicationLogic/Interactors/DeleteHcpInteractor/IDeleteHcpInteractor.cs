﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// Interface representing business logic for deleting HCP
/// </summary>
public interface IDeleteHcpInteractor : IDeleteHcpPortalUserInteractorBase;
