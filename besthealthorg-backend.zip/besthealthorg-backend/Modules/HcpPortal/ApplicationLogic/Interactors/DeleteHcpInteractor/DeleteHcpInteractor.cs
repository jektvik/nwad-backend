﻿using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents business logic for deleting HCP
/// </summary>
public class DeleteHcpInteractor : DeleteHcpPortalUserInteractorBase, IDeleteHcpInteractor
{
    /// <summary>
    /// Specifies which role this interactor allows deleting
    /// </summary>
    protected override HcpPortalRole AllowedIdentityRole => HcpPortalRole.Hcp;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="identityProvider">The identity provider to use</param>
    /// <param name="eventPublisher">The event publisher to use</param>
    /// <param name="identityPropertiesRepository">The data store to use for deleting the users identity properties</param>
    /// <param name="roleAssignmentRepository">The data store to use for deleting the users identity properties</param>
    /// <param name="auditLogRepository">The data store to use for writing audit logs</param>
    /// <param name="logger">The logger to use</param>
    public DeleteHcpInteractor(IIdentityProvider identityProvider,
        IIdentityEventPublisher eventPublisher,
        IIdentityPropertiesRepository identityPropertiesRepository,
        IRoleAssignmentRepository roleAssignmentRepository,
        IAuditLogRepository auditLogRepository,
        ILogger<DeleteHcpInteractor> logger) : base(
            identityProvider,
            eventPublisher,
            identityPropertiesRepository,
            roleAssignmentRepository,
            auditLogRepository,
            logger)
    {
    }
}
