﻿using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// interface representing the business logic for deleting HCP Portal user
/// </summary>
public interface IDeleteHcpPortalUserInteractorBase : IDeleteIdentityInteractor;
