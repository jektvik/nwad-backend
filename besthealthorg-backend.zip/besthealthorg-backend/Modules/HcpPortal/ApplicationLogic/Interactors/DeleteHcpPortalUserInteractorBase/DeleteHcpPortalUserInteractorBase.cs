﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Exceptions;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using Microsoft.Extensions.Logging;
using System.Net;
using NwadHealth.Besthealthorg.Foundation.Interfaces;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents businnes logic for deleting HCP Portal user
/// </summary>
public abstract class DeleteHcpPortalUserInteractorBase : DeleteIdentityInteractor, IDeleteHcpPortalUserInteractorBase
{
    /// <summary>
    /// Specifies which role this interactor allows deleting
    /// </summary>
    protected abstract HcpPortalRole AllowedIdentityRole { get; }

    private readonly IRoleAssignmentRepository _roleAssignmentRepository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="identityProvider">The identity provider to use</param>
    /// <param name="eventPublisher">The event publisher to use</param>
    /// <param name="identityPropertiesRepository">The data store to use for deleting the users identity properties</param>
    /// <param name="roleAssignmentRepository">The data store to use for deleting the users role assignment</param>
    /// <param name="auditLogRepository">The data store to use for writing audit logs</param>
    /// <param name="logger">The logger to use</param>
    protected DeleteHcpPortalUserInteractorBase(
        IIdentityProvider identityProvider,
        IIdentityEventPublisher eventPublisher,
        IIdentityPropertiesRepository identityPropertiesRepository,
        IRoleAssignmentRepository roleAssignmentRepository,
        IAuditLogRepository auditLogRepository,
        ILogger<DeleteHcpPortalUserInteractorBase> logger) : base(
            identityProvider,
            eventPublisher,
            identityPropertiesRepository,
            roleAssignmentRepository,
            auditLogRepository,
            logger)
    {
        _roleAssignmentRepository = roleAssignmentRepository;
    }

    /// <summary>
    /// Deletes the User
    /// </summary>
    /// <param name="identityId">The id of the identity to delete</param>
    /// <param name="deletedByIdentityId">The id of the identity which requested the deletion</param>
    /// <param name="ipAddress">The IP address that initiated the deletion</param>
    /// <exception cref="NoRoleAssigndedException">Thrown when the identity being deleted has no role assigned</exception>
    /// <exception cref="RoleMismatchException">Thrown when the identity being deleted has incorrect role assigned</exception>
    new public async Task Execute(string identityId, string deletedByIdentityId, IPAddress? ipAddress)
    {
        var roleAssignment = await _roleAssignmentRepository.GetRoleAssignmentByIdentityId(identityId);

        if (AllowedIdentityRole.StringValue() != roleAssignment?.RoleId)
        {
            throw new RoleMismatchException(identityId);
        }

        await base.Execute(identityId, deletedByIdentityId, ipAddress);
    }
}
