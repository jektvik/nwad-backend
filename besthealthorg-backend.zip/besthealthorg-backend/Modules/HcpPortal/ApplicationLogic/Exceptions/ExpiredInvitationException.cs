﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when trying to sign up using an invitation that has expired
/// </summary>
public class ExpiredInvitationException : Exception
{
    private const string MESSAGE = "The invitation has expired";

    /// <summary>
    /// The invitationId for which the exception occured
    /// </summary>
    public string InvitationId { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="invitationId">The invitationId for which the exception occured</param>
    public ExpiredInvitationException(string invitationId) : base(MESSAGE)
    {
        InvitationId = invitationId;
    }
}
