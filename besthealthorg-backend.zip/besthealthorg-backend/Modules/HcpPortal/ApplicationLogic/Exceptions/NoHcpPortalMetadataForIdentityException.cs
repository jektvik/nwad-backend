﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when trying to retrieve HCP portal user metadata for an identity that does not have any
/// </summary>
public class NoHcpPortalMetadataForIdentityException : Exception
{
    private const string MESSAGE = "No HCP portal metadata is associated with this identity";

    /// <summary>
    /// The identity id for which the exception occured
    /// </summary>
    public string IdentityId { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="identityId">The identity id for which the exception occured</param>
    public NoHcpPortalMetadataForIdentityException(string identityId) : base(MESSAGE)
    {
        IdentityId = identityId;
    }
}
