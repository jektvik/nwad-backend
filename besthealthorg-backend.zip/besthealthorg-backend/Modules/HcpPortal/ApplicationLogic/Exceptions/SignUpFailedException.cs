﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when one of the sign up steps fails
/// </summary>
public class SignUpFailedException : Exception
{
    private const string MESSAGE = "Something went wrong during the sign up process";

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="reason">The reason for the exception to occur</param>
    public SignUpFailedException(string reason) : base($"{MESSAGE}. Reason: {reason}")
    {
    }

    /// <summary>
    /// Initializes the exception with inner exception
    /// </summary>
    /// <param name="innerException">The inner exception that cause the exception to occur</param>
    public SignUpFailedException(Exception innerException) : base(MESSAGE, innerException)
    {
    }
}
