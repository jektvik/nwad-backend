﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when trying to send an invitation to an identity which already accepted one
/// </summary>
public class IdentityAlreadyExistsException : Exception
{
    private const string MESSAGE = "This user already exists";

    /// <summary>
    /// The email for which the exception occured
    /// </summary>
    public string ReceiverEmail { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="receiverEmail">The email for which the exception occured</param>
    public IdentityAlreadyExistsException(string receiverEmail) : base(MESSAGE)
    {
        ReceiverEmail = receiverEmail;
    }
}
