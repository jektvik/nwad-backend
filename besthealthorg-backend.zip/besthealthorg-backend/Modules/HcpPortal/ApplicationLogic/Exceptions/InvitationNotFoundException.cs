﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when trying to signup using an ivnitation that does not exist
/// </summary>
public class InvitationNotFoundException : Exception
{
    private const string MESSAGE = "The invitation does not exist";

    /// <summary>
    /// The invitationId for which the exception occured
    /// </summary>
    public Guid InvitationId { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="invitationId">The invitationId for which the exception occured</param>
    public InvitationNotFoundException(Guid invitationId) : base(MESSAGE)
    {
        InvitationId = invitationId;
    }
}
