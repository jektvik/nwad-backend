﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when identity does not have a valid role for specified operation
/// </summary>
public class RoleMismatchException : Exception
{
    private const string MESSAGE = "The requested identity does not have a valid role for this operation";

    /// <summary>
    /// The identity Id for which the exception occured
    /// </summary>
    public string IdentityId { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="identityId">The identityId for which the exception occured</param>
    public RoleMismatchException(string identityId) : base(MESSAGE)
    {
        IdentityId = identityId;
    }
}
