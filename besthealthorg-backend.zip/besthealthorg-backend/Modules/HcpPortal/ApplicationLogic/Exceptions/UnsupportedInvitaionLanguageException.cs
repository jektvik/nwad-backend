﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when trying to send an invitation in a language that is not supported
/// </summary>
public class UnsupportedInvitationLanguageException : Exception
{
    private const string MESSAGE = "The chosen language is not supported";

    /// <summary>
    /// The language for which the exception occured
    /// </summary>
    public string InvitationLanguage { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="invitationLanguage">The invitation language for which the exception occured</param>
    public UnsupportedInvitationLanguageException(string invitationLanguage) : base(MESSAGE)
    {
        InvitationLanguage = invitationLanguage;
    }
}
