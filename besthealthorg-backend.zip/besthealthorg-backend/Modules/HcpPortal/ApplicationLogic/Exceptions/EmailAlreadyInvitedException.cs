﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Exceptions;

/// <summary>
/// Represents an error that occurs when trying to send an invitation to an email address that has already received one
/// </summary>
public class EmailAlreadyInvitedException : Exception
{
    private const string MESSAGE = "Invitation has already been sent to this email address";

    /// <summary>
    /// The email for which the exception occured
    /// </summary>
    public string ReceiverEmail { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="receiverEmail">The email for which the exception occured</param>
    public EmailAlreadyInvitedException(string receiverEmail) : base(MESSAGE)
    {
        ReceiverEmail = receiverEmail;
    }
}
