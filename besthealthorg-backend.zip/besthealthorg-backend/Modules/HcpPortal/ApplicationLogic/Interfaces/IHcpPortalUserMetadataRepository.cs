﻿using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing the required interactions with a data store
/// </summary>
public interface IHcpPortalUserMetadataRepository
{
    /// <summary>
    /// Attempts to find the HCP portal user metadata by identity id
    /// </summary>
    /// <param name="identityId">Unique id of the user</param>
    /// <returns>The HCP portal metadata or null if not present in db</returns>
    Task<HcpPortalUserMetadata?> GetMetadataByIdentityId(string identityId);

    /// <summary>
    /// Attempts to create HCP portal metadata
    /// </summary>
    /// <param name="userMetadata">The data to create the metadata with</param>
    /// <returns>The HCP portal metadata or null if something goes wrong</returns>
    Task<HcpPortalUserMetadata> CreateMetadata(HcpPortalUserMetadata userMetadata);

    /// <summary>
    /// Attempts to delete HCP portal metadata
    /// </summary>
    /// <param name="identityId">The id of the identity whose metadata should be deleted</param>
    Task DeleteMetadataByIdentityId(string identityId);

    /// <summary>
    /// Attempts to replace HCP portal metadata
    /// </summary>
    /// <param name="metadata">The new metadata</param>
    Task Replace(HcpPortalUserMetadata metadata);
}
