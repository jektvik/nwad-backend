namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing sending of invitation emails
/// </summary>
public interface IHcpPortalMailer
{
    /// <summary>
    /// Send an email invitation using the "Hcp" template
    /// </summary>
    /// <param name="toEmail">The email to send to</param>
    /// <param name="language">The language to send the email in</param>
    /// <param name="customerAdminName">The name of the customer admin that invited the HCP</param>
    /// <param name="acceptLink">The link to click to accept the invite</param>
    Task SendHcpInvitation(string toEmail, string language, string customerAdminName, string acceptLink);

    /// <summary>
    /// Send an email invitation using the "CustomerAdmin" template
    /// </summary>
    /// <param name="toEmail">The email to send to</param>
    /// <param name="language">The language to send the email in</param>
    /// <param name="nwadAdminName">The name of the Nwad admin that invited the customer admin</param>
    /// <param name="acceptLink">The link to click to accept the invite</param>
    Task SendCustomerAdminInvitation(string toEmail, string language, string nwadAdminName, string acceptLink);

    /// <summary>
    /// Send an email to HCP to notify him that a patient has withdraw permission to share his data
    /// </summary>
    /// <param name="toEmail">The email to send to</param>
    /// <param name="language">The language to send the email in</param>
    Task NotifyUnlinkedHcp(string toEmail, string language);

    /// <summary>
    /// Returns a list of available languages for a given template.
    /// </summary>
    /// <param name="templateName">The name of the template to get available languages for</param>
    /// <returns>An enumerable of the available languages for the provided template name</returns>
    IEnumerable<string> AvailableLanguages(string templateName);
}
