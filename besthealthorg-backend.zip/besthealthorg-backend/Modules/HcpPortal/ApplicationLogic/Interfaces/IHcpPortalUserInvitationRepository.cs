﻿using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;

/// <summary>
/// The interface representing the required interactions with a data store
/// </summary>
public interface IHcpPortalUserInvitationRepository
{
    /// <summary>
    /// Stores invitation in the database
    /// </summary>
    /// <param name="invitation">The invitation to store</param>
    /// <returns>Created invitation</returns>
    Task<HcpPortalUserInvitation> SaveInvitation(HcpPortalUserInvitation invitation);

    /// <summary>
    /// Attempts to find the invitation by receiver email
    /// </summary>
    /// <param name="receiverEmail">The email to find the invitation for</param>
    /// <returns>The invitation or null if not present in db</returns>
    Task<HcpPortalUserInvitation?> GetInvitationByEmail(string receiverEmail);

    /// <summary>
    /// Attempts to retrieve HCP portal invitation by invitation id
    /// </summary>
    /// <param name="invitationId">The id to get the invitation for</param>
    /// <returns>The invitation or null if not present in db</returns>
    Task<HcpPortalUserInvitation?> GetInvitationById(Guid invitationId);

    /// <summary>
    /// Attempts to update the status of the invitation
    /// </summary>
    /// <param name="invitation">The invitation containing the updated status information</param>
    Task UpdateInvitation(HcpPortalUserInvitation invitation);

    /// <summary>
    /// Gets all HCP portal invitations with the specified role
    /// </summary>
    /// <param name="roleId">Id of the role to filter by</param>
    /// <param name="paginationRequest">The request object containing pagination parameters</param>
    /// <param name="sortRequest">The request object containing sorting parameters</param>
    /// <param name="searchQuery">Keyword used for searching the permission requests</param>
    /// <returns>Paginated items of HCP portal user invitations</returns>
    Task<PaginatedItems<HcpPortalUserInvitation>> GetInvitationsByRole(
        string roleId,
        PaginationRequest paginationRequest,
        SortRequest sortRequest,
        string? searchQuery);

    /// <summary>
    /// Deletes invitation by email
    /// </summary>
    /// <param name="email">The receiver email of the invitation to delete</param>
    Task DeleteInvitationByEmail(string email);
}
