﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

/// <summary>
/// Represents the HCP portal user invitation domain model
/// </summary>
public class HcpPortalUserMetadata
{
    /// <summary>
    /// Unique id representing the user
    /// </summary>
    public string IdentityId { get; set; } = string.Empty;

    /// <summary>
    /// What identifier others use for this user
    /// </summary>
    public string? InternalReferenceName { get; set; }

    /// <summary>
    /// What name did this user choose for himself
    /// </summary>
    public string OwnName { get; set; } = string.Empty;

    /// <summary>
    /// Email address of the user
    /// </summary>
    public string Email { get; set; } = string.Empty;

    /// <summary>
    /// Date and time of when the user accepted the invitation
    /// </summary>
    public DateTimeOffset CreatedAt { get; set; }

    /// <summary>
    /// The signup language of the user
    /// </summary>
    public string Language { get; set; } = string.Empty;
}
