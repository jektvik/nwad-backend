﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

/// <summary>
/// Represents the configuration of the HCP portal module
/// </summary>
public class HcpPortalConfiguration
{
    /// <summary>
    /// The type of permissions and permission requests created by the HCP Portal module
    /// </summary>
    public const string HcpPermissionType = "Hcp";

    /// <summary>
    /// How long should the Invitation stay valid
    /// </summary>
    public TimeSpan InvitationExpiryTime { get; set; } = TimeSpan.FromDays(5);

    /// <summary>
    /// The time period the patient has to accept the data sharing request within
    /// </summary>
    public TimeSpan DataSharingRequestExpiryTime { get; set; } = TimeSpan.FromDays(5);

    /// <summary>
    /// Base url of the HCP portal backend
    /// </summary>
    public string BackendApiUrl { get; }

    /// <summary>
    /// Base url of the HCP portal frontend
    /// </summary>
    public string FrontendBaseUrl { get; }

    /// <summary>
    /// Client id of the auth0 application for which to use the login url
    /// </summary>
    public string WebApplicationClientId { get; }

    /// <summary>
    /// Sendgrid api key used for sending the invitations
    /// </summary>
    public string SendGridApiKey { get; }

    /// <summary>
    /// Initializes the configuration
    /// </summary>
    /// <param name="backendApiUrl">Base url of the HCP portal backend</param>
    /// <param name="frontendBaseUrl">Base url of the HCP portal frontend</param>
    /// <param name="webApplicationClientId">Client id of the auth0 frontend application</param>
    /// <param name="sendgridApiKey">Sendgrid api key used for sending the invitations</param>
    public HcpPortalConfiguration(
        string backendApiUrl,
        string frontendBaseUrl,
        string webApplicationClientId,
        string sendgridApiKey)
    {
        if (string.IsNullOrEmpty(backendApiUrl))
        {
            throw new ArgumentException("backendApiUrl cannot be null or empty", nameof(backendApiUrl));
        }

        if (backendApiUrl.Last() != '/')
        {
            throw new ArgumentException("backendApiUrl must end with '/'", nameof(backendApiUrl));
        }

        BackendApiUrl = backendApiUrl;

        if (string.IsNullOrEmpty(frontendBaseUrl))
        {
            throw new ArgumentException("frontendBaseUrl cannot be null or empty", nameof(frontendBaseUrl));
        }

        if (frontendBaseUrl.Last() != '/')
        {
            throw new ArgumentException("frontendBaseUrl must end with '/'", nameof(frontendBaseUrl));
        }

        FrontendBaseUrl = frontendBaseUrl;

        if (string.IsNullOrEmpty(webApplicationClientId))
        {
            throw new ArgumentException("webApplicationClientId cannot be null or empty", nameof(webApplicationClientId));
        }

        WebApplicationClientId = webApplicationClientId;

        if (string.IsNullOrEmpty(sendgridApiKey))
        {
            throw new ArgumentException("SendGridApiKey cannot be null or empty", nameof(sendgridApiKey));
        }

        SendGridApiKey = sendgridApiKey;
    }
}
