﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

/// <summary>
/// Represents the HCP portal user domain model
/// </summary>
public class HcpPortalUser
{
    /// <summary>
    /// The unique id of the Identity
    /// </summary>
    public string IdentityId { get; set; } = string.Empty;

    /// <summary>
    /// Internal reference name of the user
    /// </summary>
    public string? InternalReferenceName { get; set; }

    /// <summary>
    /// Email address that the user was invited with
    /// </summary>
    public string Email { get; set; } = string.Empty;

    /// <summary>
    /// Datetime of when the user was created
    /// </summary>
    public DateTimeOffset CreatedDateTime { get; set; }

    /// <summary>
    /// User's country of residence
    /// </summary>
    public string? CountryCode {  get; set; }
}
