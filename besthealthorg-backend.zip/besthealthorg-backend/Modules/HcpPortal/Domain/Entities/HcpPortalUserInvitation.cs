﻿using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Exceptions;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

/// <summary>
/// Represents the HCP portal user invitation domain model
/// </summary>
public class HcpPortalUserInvitation
{
    /// <summary>
    /// Unique identifier of the Invitation
    /// </summary>
    public Guid Id { get; set; }

    /// <summary>
    /// Indicates whether the invitation is revoked
    /// </summary>
    public bool IsRevoked { get; set; }

    /// <summary>
    /// The expiration date/time of the invitation
    /// </summary>
    public DateTimeOffset ExpiresAt { get; set; }

    /// <summary>
    /// The state of the invitation, allowed values: pending, expired, rejected
    /// </summary>
    /// <exception cref="InvalidInvitationStatusException">Thrown when trying to change the status of an invitation that is not pending</exception>
    /// <exception cref="ArgumentOutOfRangeException">Thrown when trying to set the invitation to an invalid status</exception>
    public InvitationStatus Status {
        get
        {
            if (IsRevoked)
            {
                return InvitationStatus.Revoked;
            }

            if (ExpiresAt < DateTimeOffset.UtcNow)
            {
                return InvitationStatus.Expired;
            }

            return InvitationStatus.Pending;
        }

        set
        {
            var previousStatus = Status;

            if (value != InvitationStatus.Pending && previousStatus is not InvitationStatus.Pending)
            {
                throw new InvalidInvitationStatusException(previousStatus);
            }

            IsRevoked = value switch
            {
                InvitationStatus.Pending => false,
                InvitationStatus.Revoked => true,
                _ => throw new ArgumentOutOfRangeException(nameof(value))
            };
        }
    }

    /// <summary>
    /// Unique IdentityId of the Inviter
    /// </summary>
    public string SenderIdentityId { get; set; } = string.Empty;

    /// <summary>
    /// Email of the Invitee
    /// </summary>
    public string ReceiverEmail { get; set; } = string.Empty;

    /// <summary>
    /// Id of the role they are being invited to
    /// </summary>
    public HcpPortalRole Role { get; set; }

    /// <summary>
    /// Name the inviter wants to use for the invitee
    /// </summary>
    public string? InternalReferenceName { get; set; }

    /// <summary>
    /// The language in which the ivitation was sent
    /// </summary>
    public string Language { get; set; } = string.Empty;

    /// <summary>
    /// Link that the invitee will receive by email to continue the invitation flow
    /// </summary>
    public string AcceptLink { get; set; } = string.Empty;

    /// <summary>
    /// Name that the inviter has chosen for himself
    /// </summary>
    public string InviterOwnName { get; set; } = string.Empty;
}
