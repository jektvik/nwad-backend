﻿using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Domain.Exceptions;

/// <summary>
/// Represents an error that occurs when trying to signup using an invitation that is in invalid status
/// </summary>
public class InvalidInvitationStatusException : Exception
{
    private const string MESSAGE = "The invitation is in invalid status for this operation";

    /// <summary>
    /// Previous status for which the exception occured
    /// </summary>
    public InvitationStatus PreviousStatus { get; }

    /// <summary>
    /// Initializes the exception
    /// </summary>
    /// <param name="previousStatus">The previous status for which the exception occured</param>
    public InvalidInvitationStatusException(InvitationStatus previousStatus) : base(MESSAGE)
    {
        PreviousStatus = previousStatus;
    }
}
