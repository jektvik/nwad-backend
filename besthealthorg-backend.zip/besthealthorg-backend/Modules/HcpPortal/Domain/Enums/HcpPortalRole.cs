﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;

/// <summary>
/// Enum representing required HCP portal roles
/// </summary>
public enum HcpPortalRole
{
    /// <summary>
    /// Administrator from Nwad Health
    /// </summary>
    NwadAdmin = 0,

    /// <summary>
    /// Administrator from customer organization
    /// </summary>
    CustomerAdmin = 1,

    /// <summary>
    /// Health care provider
    /// </summary>
    Hcp = 2,
}

/// <summary>
/// Extention class providing mapping methods
/// </summary>
public static class HcpPortalRoleExtensions
{
    /// <summary>
    /// Converts enum value to string
    /// </summary>
    /// <param name="role">The role value to convert</param>
    /// <returns>HCP portal role in string type</returns>
    /// <exception cref="ArgumentException">Thrown when trying to convert invalid role</exception>
    public static string StringValue(this HcpPortalRole role)
    {
        return role switch
        {
            HcpPortalRole.NwadAdmin => "NwadAdmin",
            HcpPortalRole.CustomerAdmin => "CustomerAdmin",
            HcpPortalRole.Hcp => "Hcp",
            _ => throw new ArgumentException("Provided role is not valid" , nameof(role))
        };
    }

    /// <summary>
    /// Converts string to enum
    /// </summary>
    /// <param name="roleId">The id of the role to convert</param>
    /// <returns>HCP portal role</returns>
    /// <exception cref="ArgumentException">Thrown when trying to convert invalid role</exception>
    public static HcpPortalRole ToEnum(string roleId)
    {
        return roleId switch
        {
            "NwadAdmin" => HcpPortalRole.NwadAdmin,
            "CustomerAdmin" => HcpPortalRole.CustomerAdmin,
            "Hcp" => HcpPortalRole.Hcp,
            _ => throw new ArgumentException("Provided role Id is not valid" , nameof(roleId))
        };
    }
}
