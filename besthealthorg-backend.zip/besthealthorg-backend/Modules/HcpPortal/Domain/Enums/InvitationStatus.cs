﻿namespace NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;

/// <summary>
/// Enum representing valid statuses that the invitation can be in
/// </summary>
public enum InvitationStatus
{
    /// <summary>
    /// Invitation is waiting to be accepted/revoked
    /// </summary>
    Pending = 0,

    /// <summary>
    /// Invitation has been revoked by sender
    /// </summary>
    Revoked = 1,

    /// <summary>
    /// The invitation has expired
    /// </summary>
    Expired = 2,
}

/// <summary>
/// Extention class providing mapping methods
/// </summary>
public static class InvitationStatusExtensions
{
    /// <summary>
    /// Converts enum value to string
    /// </summary>
    /// <param name="status">The enum value to convert</param>
    /// <returns>invitation status in string type</returns>
    /// <exception cref="ArgumentException">Thrown when trying to convert invalid status</exception>
    public static string StringValue(this InvitationStatus status)
    {
        return status switch
        {
            InvitationStatus.Pending => "pending",
            InvitationStatus.Revoked => "revoked",
            InvitationStatus.Expired => "expired",
            _ => throw new ArgumentException("Provided status is not valid" , nameof(status))
        };
    }
}
