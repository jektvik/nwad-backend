using Microsoft.EntityFrameworkCore;
using NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure.Models;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure;

/// <summary>
/// Represents required actions of a provided database context
/// </summary>
public interface IHcpPortalDbContext
{
    /// <summary>
    /// The collection of HCP portal user invitations
    /// </summary>
    DbSet<HcpPortalUserInvitationDbModel> HcpPortalUserInvitations { get; set; }
    /// <summary>
    /// The collection of HCP portal user metadata
    /// </summary>
    DbSet<HcpPortalUserMetadataDbModel> HcpPortalUserMetadata { get; set; }

    /// <summary>
    /// Executes queued add/update tasks
    /// </summary>
    /// <param name="cancellationToken">Used for notifying whether the action should be cancelled</param>
    /// <returns>The number of affected items</returns>
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Configures DbSets as required by the HCP portal module
    /// </summary>
    /// <param name="modelBuilder">The model builder to use for configuring</param>
    void ConfigureDbSets(ModelBuilder modelBuilder)
    {
        var hcpPortalInvitations = modelBuilder.Entity<HcpPortalUserInvitationDbModel>();
        hcpPortalInvitations.HasKey(hpi => hpi.Id);

        var hcpPortalUserMetadatas = modelBuilder.Entity<HcpPortalUserMetadataDbModel>();
        hcpPortalUserMetadatas.HasKey(hpum => hpum.Id);
    }
}
