using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.PermissionModule.Domain.Events.V1;
using Microsoft.Extensions.DependencyInjection;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure;

internal static class PermissionEventHandlers
{
    internal static async Task OnDataSharingPermissionDeleted(
        IServiceProvider serviceProvider,
        DataSharingPermissionDeletedEvent dataSharingPermissionDeletedEvent)
    {
        if (IsPatientInitiatedUnlink(dataSharingPermissionDeletedEvent.Permission.Type, dataSharingPermissionDeletedEvent.DeleterId,
                dataSharingPermissionDeletedEvent.Permission.SubjectIdentityId))
        {
            return;
        }

        var scope = serviceProvider.CreateScope();
        var mailer = scope.ServiceProvider.GetRequiredService<IHcpPortalMailer>();
        var metadataRepo = scope.ServiceProvider.GetRequiredService<IHcpPortalUserMetadataRepository>();
        var metadata = await metadataRepo.GetMetadataByIdentityId(dataSharingPermissionDeletedEvent.Permission.AccessorIdentityId);

        await mailer.NotifyUnlinkedHcp(dataSharingPermissionDeletedEvent.Permission.AccessorEmail!, metadata?.Language ?? "en");
    }

    private static bool IsPatientInitiatedUnlink(string permissionType, string deleterId, string subjectIdentityId)
    {
        return permissionType != HcpPortalConfiguration.HcpPermissionType && deleterId != subjectIdentityId;
    }
}
