using NwadHealth.Besthealthorg.Foundation.Extensions.ServiceCollection;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interactors.SignUp;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure.Repositories;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure.Repositories;
using NwadHealth.Besthealthorg.PermissionModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.PermissionModule.Domain.Entities;
using NwadHealth.Besthealthorg.PermissionModule.Infrastructure;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure;

/// <summary>
/// Provides extension methods for configuring the dependency injection of the HcpPortalModule
/// </summary>
public static class HcpPortalExtensions
{
    /// <summary>
    /// Configures dependency injection to use the provided configuration
    /// </summary>
    /// <typeparam name="TDbContext">The type of the database context</typeparam>
    /// <param name="services">The IServiceCollection to be configured</param>
    /// <param name="config">The custom configuration instance</param>
    /// <returns>The same IServiceCollection the method was called on, with configuration set</returns>
    public static IServiceCollection AddPaceHcpPortal<TDbContext>(
        this IServiceCollection services,
        HcpPortalConfiguration config) where TDbContext : DbContext, IHcpPortalDbContext, IPermissionDbContext
    {
        services.AddPacePermission<TDbContext>();

        services.AddScoped<IHcpPortalMailer, TemplateMailer>();
        services.AddSendGridMailer(config.SendGridApiKey);

        //Singletons
        services.AddSingleton(config);

        //Context
        services.AddScoped<IHcpPortalDbContext>(provider => provider.GetRequiredService<TDbContext>());

        //Interactors
        services.AddScoped<IInviteCustomerAdminInteractor, InviteCustomerAdminInteractor>();
        services.AddScoped<IInviteHcpInteractor, InviteHcpInteractor>();
        services.AddScoped<IGetAvailableEmailInvitationLanguagesInteractor, GetAvailableEmailInvitationLanguagesInteractor>();
        services.AddScoped<IAcceptInvitationInteractor, AcceptInvitationInteractor>();
        services.AddScoped<ISignUpInteractor, SignUpInteractor>();
        services.AddScoped<IGetInvitationsInteractor, GetInvitationsInteractor>();
        services.AddScoped<IGetUsersInteractor, GetUsersInteractor>();

        services.AddScoped<IRevokeCustomerAdminInvitationInteractor, RevokeCustomerAdminInvitationInteractor>();
        services.AddScoped<IRevokeHcpInvitationInteractor, RevokeHcpInvitationInteractor>();

        services.AddScoped<IResendCustomerAdminInvitationInteractor, ResendCustomerAdminInvitationInteractor>();
        services.AddScoped<IResendHcpInvitationInteractor, ResendHcpInvitationInteractor>();

        services.AddScoped<IDeleteCustomerAdminInteractor, DeleteCustomerAdminInteractor>();
        services.AddScoped<IDeleteHcpInteractor, DeleteHcpInteractor>();

        services.AddScoped<ICreateHcpDataSharingRequestInteractor, CreateHcpDataSharingRequestInteractor>();

        //Repositories
        services.AddScoped<IHcpPortalUserInvitationRepository, HcpPortalUserInvitationRepository>();
        services.AddScoped<IHcpPortalUserMetadataRepository, HcpPortalUserMetadataRepository>();
        services.AddScoped<ICountryRepository, CountryRepository>();

        return services;
    }

    /// <summary>
    /// Prepares the application to use the HCP Module
    /// </summary>
    /// <param name="app">The IApplicationBuilder to be prepared</param>
    /// <returns>The same IApplicationBuilder the method was called on, prepared for the HCP Module</returns>
    public static void UsePaceHcpPortal(this IApplicationBuilder app)
    {
        var identityEventSubscriber = app.ApplicationServices.GetRequiredService<IIdentityEventSubscriber>();

        identityEventSubscriber.IdentityDeleted += async (_, @event) => await IdentityEventHandlers.OnIdentityDeleted(app.ApplicationServices, @event);
        identityEventSubscriber.EmailChanged += async (_, @event) => await IdentityEventHandlers.OnEmailChanged(app.ApplicationServices, @event);

        var permissionEventSubscriber = app.ApplicationServices.GetRequiredService<IDataSharingPermissionEventSubscriber>();

        permissionEventSubscriber.PermissionDeleted += async (_, @event) => await PermissionEventHandlers.OnDataSharingPermissionDeleted(
            app.ApplicationServices,
            @event);
    }
}
