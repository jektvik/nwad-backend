using System.Text;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure;

/// <summary>
/// Provides functionality for sending emails using templates
/// </summary>
public class TemplateMailer : IHcpPortalMailer
{
    private const string TemplateFolder = "InvitationTemplates";
    private const string FromEmail = "no-reply@besthealthorg.nwadhealthdev.com";
    private readonly IMailer _mailer;

    /// <summary>
    /// Initializes the template mailer
    /// </summary>
    /// <param name="mailer">The mailer to use</param>
    public TemplateMailer(IMailer mailer)
    {
        _mailer = mailer;
    }

    /// <summary>
    /// Send an email invitation using the "Hcp" template
    /// </summary>
    /// <param name="toEmail">The email to send to</param>
    /// <param name="language">The language to send the email in</param>
    /// <param name="customerAdminName">The name of the customer admin that invited the HCP</param>
    /// <param name="acceptLink">The link to click to accept the invite</param>
    /// <exception cref="FileNotFoundException">Thrown if the "Hcp" template does not exist in the provided language</exception>
    public async Task SendHcpInvitation(string toEmail, string language, string customerAdminName, string acceptLink)
    {
        var content = await PrepareContentFromTemplate("Hcp", language, new (string, string)[] { ("{acceptLink}", acceptLink), ("{name}", customerAdminName) });

        await _mailer.SendHtml(FromEmail, customerAdminName, toEmail, "HCP Portal Invitation", content);
    }

    /// <summary>
    /// Send an email invitation using the "CustomerAdmin" template
    /// </summary>
    /// <param name="toEmail">The email to send to</param>
    /// <param name="language">The language to send the email in</param>
    /// <param name="nwadAdminName">The name of the Nwad admin that invited the customer admin</param>
    /// <param name="acceptLink">The link to click to accept the invite</param>
    /// <exception cref="FileNotFoundException">Thrown if the "CustomerAdmin" template does not exist in the provided language</exception>
    public async Task SendCustomerAdminInvitation(string toEmail, string language, string nwadAdminName, string acceptLink)
    {
        var content = await PrepareContentFromTemplate(
            "CustomerAdmin",
            language,
            new (string, string)[] { ("{acceptLink}", acceptLink), ("{name}", nwadAdminName) });

        await _mailer.SendHtml(FromEmail, nwadAdminName, toEmail, "HCP Portal Invitation", content);
    }

    /// <summary>
    /// Send an email to HCP to notify them that a patient has withdraw permission to share their data
    /// </summary>
    /// <param name="toEmail">The email to send to</param>
    /// <param name="language">The language to send the email in</param>
    public async Task NotifyUnlinkedHcp(string toEmail, string language)
    {
        var content = await PrepareContentFromTemplate(
           "NotifyHcp",
           language,
           Array.Empty<(string, string)>());

        await _mailer.SendHtml(FromEmail, "HCP Portal System", toEmail, "Patient Update", content);
    }

    /// <summary>
    /// Returns a list of available languages for a given template.
    /// </summary>
    /// <param name="templateName">The name of the template to get available languages for</param>
    /// <returns>An enumerable of the available languages for the provided template name</returns>
    /// <exception cref="DirectoryNotFoundException">Thrown if the directory with the given template name does not exist</exception>
    public IEnumerable<string> AvailableLanguages(string templateName) =>
        Directory.GetFiles(Path.Combine(TemplateFolder, templateName))
            .Select(path => path.Split(Path.DirectorySeparatorChar)[^1])
            .Select(file => file.Replace(".html", string.Empty));

    private static async Task<string> ReadTemplate(string templateName, string language) =>
        await File.ReadAllTextAsync(Path.Combine(TemplateFolder, templateName, $"{language}.html"), Encoding.UTF8);

    private static string ReplacePlaceholders(string original, IEnumerable<(string placeholder, string replacement)> replacements) =>
        replacements.Aggregate(new StringBuilder(original), (builder, tuple) => builder.Replace(tuple.placeholder, tuple.replacement)).ToString();

    private static async Task<string> PrepareContentFromTemplate(string templateName, string language, IEnumerable<(string, string)> replacements) =>
        ReplacePlaceholders(await ReadTemplate(templateName, language), replacements);
}
