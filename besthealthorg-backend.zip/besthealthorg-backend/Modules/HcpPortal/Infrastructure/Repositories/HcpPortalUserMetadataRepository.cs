﻿using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure.Repositories;

/// <summary>
/// Represents operations available for storage/retrieval of HcpPortalModules
/// </summary>
public class HcpPortalUserMetadataRepository : IHcpPortalUserMetadataRepository
{
    private readonly IHcpPortalDbContext _context;

    /// <summary>
    /// Initializes the HcpPortalModule repository
    /// </summary>
    /// <param name="context">The database context the repo should use for data access</param>
    public HcpPortalUserMetadataRepository(IHcpPortalDbContext context)
    {
        _context = context;
    }

    /// <summary>
    /// Attempts to create HCP portal metadata
    /// </summary>
    /// <param name="userMetadata">The data to create the metadata with</param>
    /// <returns>The HCP portal metadata or null if something goes wrong</returns>
    public async Task<HcpPortalUserMetadata> CreateMetadata(HcpPortalUserMetadata userMetadata)
    {
        var entity = _context.HcpPortalUserMetadata.Add(HcpPortalUserMetadataDbModel.FromDomain(userMetadata));
        await _context.SaveChangesAsync();
        return entity.Entity.ToDomain();
    }

    /// <summary>
    /// Attempts to find the user meta data by identity id
    /// </summary>
    /// <param name="identityId">Unique id of the user</param>
    /// <returns>The meta data or null if not present in db</returns>
    public async Task<HcpPortalUserMetadata?> GetMetadataByIdentityId(string identityId)
    {
        var dbMetadata = await _context.HcpPortalUserMetadata.FirstOrDefaultAsync(x => x.IdentityId == identityId);
        return dbMetadata?.ToDomain();
    }

    /// <summary>
    /// Attempts to delete HCP portal metadata
    /// </summary>
    /// <param name="identityId">The id of the identity whose metadata should be deleted</param>
    public async Task DeleteMetadataByIdentityId(string identityId)
    {
        await _context.HcpPortalUserMetadata.Where(x => x.IdentityId == identityId).ExecuteDeleteAsync();
    }

    /// <summary>
    /// Attempts to replace HCP portal metadata
    /// </summary>
    /// <param name="metadata">The new metadata</param>
    public async Task Replace(HcpPortalUserMetadata metadata)
    {
        var dbModel = HcpPortalUserMetadataDbModel.FromDomain(metadata);
        _context.HcpPortalUserMetadata.Update(dbModel);
        await _context.SaveChangesAsync();
    }
}
