using System.Linq.Expressions;
using NwadHealth.Besthealthorg.Foundation.Extensions;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;
using NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure.Repositories;

/// <summary>
/// Represents operations available for storage/retrieval of HCP portal user invitations
/// </summary>
public class HcpPortalUserInvitationRepository : IHcpPortalUserInvitationRepository
{
    private readonly IHcpPortalDbContext _context;

    /// <summary>
    /// Initializes the HcpPortalModule repository
    /// </summary>
    /// <param name="context">The database context the repo should use for data access</param>
    public HcpPortalUserInvitationRepository(IHcpPortalDbContext context)
    {
        _context = context;
    }

    /// <summary>
    /// Attempts to retrieve HCP portal invitation by receiver email
    /// </summary>
    /// <param name="receiverEmail">The email to get the invitation for</param>
    /// <returns>The invitation or null if not present in db</returns>
    public async Task<HcpPortalUserInvitation?> GetInvitationByEmail(string receiverEmail)
    {
        var dbInvitation = await _context.HcpPortalUserInvitations.FirstOrDefaultAsync(x => x.ReceiverEmail == receiverEmail);
        return dbInvitation?.ToDomain();
    }

    /// <summary>
    /// Attempts to retrieve HCP portal invitation by invitation id
    /// </summary>
    /// <param name="invitationId">The id to get the invitation for</param>
    /// <returns>The invitation or null if not present in db</returns>
    public async Task<HcpPortalUserInvitation?> GetInvitationById(Guid invitationId)
    {
        var dbInvitation = await _context.HcpPortalUserInvitations.FindAsync(invitationId);
        return dbInvitation?.ToDomain();
    }

    /// <summary>
    /// Stores invitation in the database
    /// </summary>
    /// <param name="invitation">The invitaion to store</param>
    /// <returns>Created invitation</returns>
    public async Task<HcpPortalUserInvitation> SaveInvitation(HcpPortalUserInvitation invitation)
    {
       var savedInvitation = await _context.HcpPortalUserInvitations.AddAsync(HcpPortalUserInvitationDbModel.FromDomain(invitation));
       await _context.SaveChangesAsync();
       return savedInvitation.Entity.ToDomain();
    }

    /// <summary>
    /// Updates invitation in the database
    /// </summary>
    /// <param name="invitation">The invitation containing the updated status information</param>
    public async Task UpdateInvitation(HcpPortalUserInvitation invitation)
    {
        await _context.HcpPortalUserInvitations.Where(x => x.Id == invitation.Id).ExecuteUpdateAsync(setters =>
                setters.SetProperty(i => i.IsRevoked, invitation.IsRevoked)
                    .SetProperty(i => i.ReceiverEmail, invitation.ReceiverEmail)
                    .SetProperty(i => i.ExpiresAt, invitation.ExpiresAt));
    }

    /// <summary>
    /// Gets invitations with specified role
    /// </summary>
    /// <param name="roleId">The role to filter the invitations by</param>
    /// <param name="paginationRequest">The request object containing pagination parameters</param>
    /// <param name="sortRequest">The request object containing sorting parameters</param>
    /// <param name="searchQuery">Keyword used for searching the permission requests</param>
    /// <returns>Paginated items of HCP portal user invitations</returns>
    public async Task<PaginatedItems<HcpPortalUserInvitation>> GetInvitationsByRole(
        string roleId,
        PaginationRequest paginationRequest,
        SortRequest sortRequest,
        string? searchQuery)
    {
        var invitations = _context.HcpPortalUserInvitations.Where(i => i.RoleId == roleId)
            .Where(InvitationsForKeyword(searchQuery))
            .AsNoTracking();

        var totalInvitations = await invitations.CountAsync();

        var (pageSize, pageIndex) = paginationRequest.Limit(totalInvitations, 100);

        var sortvalue = sortRequest.SortBy ?? "InternalReferenceName";

        var orderedInvitations = sortRequest.SortBy?.ToLower() switch
        {
            "status" => (IOrderedQueryable<HcpPortalUserInvitationDbModel>)invitations.OrderBy(GetStatusSorter(sortRequest.SortOrder)).AsQueryable(),
            _ => invitations.SortBy(sortvalue, sortRequest.SortOrder)
        };

        invitations = orderedInvitations
            .ThenBy(u => u.Id)
            .Skip(pageSize * pageIndex)
            .Take(pageSize);

        return new PaginatedItems<HcpPortalUserInvitation>(pageIndex, pageSize, totalInvitations, invitations.Select(i => i.ToDomain()));
    }

    /// <summary>
    /// Deletes invitation by email
    /// </summary>
    /// <param name="email">The receiver email of the invitation to delete</param>
    public async Task DeleteInvitationByEmail(string email)
    {
        await _context.HcpPortalUserInvitations.Where(x => x.ReceiverEmail == email).ExecuteDeleteAsync();
    }

    private static Expression<Func<HcpPortalUserInvitationDbModel, bool>> InvitationsForKeyword(string? keyword)
    {
        return invitations => string.IsNullOrEmpty(keyword) || (invitations.InternalReferenceName ?? string.Empty)
            .Contains(keyword) || (invitations.ReceiverEmail ?? string.Empty).Contains(keyword);
    }

    private static Func<HcpPortalUserInvitationDbModel, int>GetStatusSorter(SortOrder sortOrder)
    {
        return new(invitation =>
        {
            var domain = invitation.ToDomain();

            var order = domain.Status switch
            {
                InvitationStatus.Expired => 1,
                InvitationStatus.Pending => 2,
                InvitationStatus.Revoked => 3,
                _ => 4
            };

            return (sortOrder == SortOrder.Asc) ? order : -order;
        });
    }
}
