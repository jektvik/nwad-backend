﻿using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure.Models;

/// <summary>
///  The HCP PortalUserMetadata domain model
/// </summary>
public class HcpPortalUserMetadataDbModel
{
    /// <summary>
    /// Primary key
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Unique identifier of the portal user
    /// </summary>
    public string IdentityId { get; set; } = null!;

    /// <summary>
    /// Name the inviter wants to use for the invitee
    /// </summary>
    public string? InternalReferenceName { get; set; }

    /// <summary>
    /// Name that the invitee uses for him/her self
    /// </summary>
    public string OwnName { get; set; } = null!;

    /// <summary>
    /// Email address of the invitee
    /// </summary>
    public string Email { get; set; } = null!;

    /// <summary>
    /// Date and time when the user was created
    /// </summary>
    public DateTimeOffset CreatedAt { get; set; }

    /// <summary>
    /// The signup language of the user
    /// </summary>
    public string Language { get; set; } = null!;

    /// <summary>
    /// Converts portal user metadata from database model to domain model
    /// </summary>
    public HcpPortalUserMetadata ToDomain()
    {
        return new()
        {
            IdentityId = IdentityId,
            InternalReferenceName = InternalReferenceName,
            OwnName = OwnName,
            Email = Email,
            CreatedAt = CreatedAt,
            Language = Language
        };
    }

    /// <summary>
    /// Converts portal user metadata from domain model to database model
    /// </summary>
    /// <param name="model">The database model to convert</param>
    public static HcpPortalUserMetadataDbModel FromDomain(HcpPortalUserMetadata model)
    {
        return new()
        {
            IdentityId = model.IdentityId,
            InternalReferenceName = model.InternalReferenceName,
            OwnName = model.OwnName,
            Email = model.Email,
            CreatedAt = model.CreatedAt,
            Language = model.Language
        };
    }
}
