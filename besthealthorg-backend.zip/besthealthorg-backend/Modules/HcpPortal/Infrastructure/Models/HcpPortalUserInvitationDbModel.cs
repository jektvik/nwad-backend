using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Entities;
using NwadHealth.Besthealthorg.HcpPortalModule.Domain.Enums;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure.Models;

/// <summary>
/// The HcpPortal invitation database model
/// </summary>
public class HcpPortalUserInvitationDbModel
{
    /// <summary>
    /// Unique identifier of the Invitation
    /// </summary>
    public Guid Id { get; set; }

    /// <summary>
    /// The the expiration time of the invitation
    /// </summary>
    public DateTimeOffset ExpiresAt { get; set; }

    /// <summary>
    /// Indicates whether the invitation is revoked
    /// </summary>
    public bool IsRevoked { get; set; }

    /// <summary>
    /// Identity id of the inviter
    /// </summary>
    public string InvitationSenderId { get; set; } = null!;

    /// <summary>
    /// Email of the invitee
    /// </summary>
    public string ReceiverEmail { get; set;} = null!;

    /// <summary>
    /// Id of the role they are being invited to
    /// </summary>
    public string RoleId { get; set; } = null!;

    /// <summary>
    /// Name the inviter wants to use for the invitee
    /// </summary>
    public string? InternalReferenceName { get; set; }

    /// <summary>
    /// The language in which the ivitation was sent
    /// </summary>
    public string Language { get; set; } = null!;

    /// <summary>
    /// Allows mapping from database model to domain model
    /// </summary>
    public HcpPortalUserInvitation ToDomain()
    {
        return new()
        {
            Id = Id,
            ExpiresAt = ExpiresAt,
            IsRevoked = IsRevoked,
            SenderIdentityId = InvitationSenderId,
            ReceiverEmail = ReceiverEmail,
            Role = HcpPortalRoleExtensions.ToEnum(RoleId),
            InternalReferenceName = InternalReferenceName,
            Language = Language,
        };
    }

    /// <summary>
    /// Allows mapping from domain model to database model
    /// </summary>
    /// <param name="model">The domain model to convert</param>
    public static HcpPortalUserInvitationDbModel FromDomain(HcpPortalUserInvitation model)
    {
        return new()
        {
            Id = model.Id,
            ExpiresAt = model.ExpiresAt,
            IsRevoked = model.IsRevoked,
            InvitationSenderId = model.SenderIdentityId,
            ReceiverEmail = model.ReceiverEmail,
            RoleId = model.Role.StringValue(),
            InternalReferenceName = model.InternalReferenceName,
            Language = model.Language,
        };
    }
}
