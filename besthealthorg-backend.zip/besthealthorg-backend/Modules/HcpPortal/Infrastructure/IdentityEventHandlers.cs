using NwadHealth.Besthealthorg.HcpPortalModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Events;
using Microsoft.Extensions.DependencyInjection;

namespace NwadHealth.Besthealthorg.HcpPortalModule.Infrastructure;

internal static class IdentityEventHandlers
{
    internal static async Task OnIdentityDeleted(IServiceProvider serviceProvider, IdentityDeletedEvent identityDeletedEvent)
    {
        using var scope = serviceProvider.CreateScope();

        var invitationRepository = scope.ServiceProvider.GetRequiredService<IHcpPortalUserInvitationRepository>();
        var metadataRepository = scope.ServiceProvider.GetRequiredService<IHcpPortalUserMetadataRepository>();

        await invitationRepository.DeleteInvitationByEmail(identityDeletedEvent.Identity.Email);
        await metadataRepository.DeleteMetadataByIdentityId(identityDeletedEvent.Identity.Id);
    }

    internal static async Task OnEmailChanged(IServiceProvider serviceProvider, EmailChangedEvent emailChangedEvent)
    {
        using var scope = serviceProvider.CreateScope();

        var invitationRepository = scope.ServiceProvider.GetRequiredService<IHcpPortalUserInvitationRepository>();

        var invitation = await invitationRepository.GetInvitationByEmail(emailChangedEvent.OldEmail);
        if (invitation is not null)
        {
            invitation.ReceiverEmail = emailChangedEvent.NewEmail;
            await invitationRepository.UpdateInvitation(invitation);
        }

        var metadataRepository = scope.ServiceProvider.GetRequiredService<IHcpPortalUserMetadataRepository>();
        var metadata = await metadataRepository.GetMetadataByIdentityId(emailChangedEvent.IdentityId);
        if (metadata is not null)
        {
            metadata.Email = emailChangedEvent.NewEmail;
            await metadataRepository.Replace(metadata);
        }
    }
}
