# HCP Portal Module

The PACE HCP Portal module is used for managing Nwad Admin, Customer Admins, Health Care Providers (HCPs), Patients and the relationship between them

## Module setup

### General requirements

The HCP Portal module requires the application to have authorization enabled (ideally through the [Identity module](/Identity/README.md)).

The HCP Portal module is dependent on the [Permission module](/Permission/README.md).

### Required infrastructure

- Azure CosmosDB instance
  - CosmosDB database
    - CosmosDB container named `role`
    - CosmosDB container named `roleAssignments`

- SQL Server
  - SQL database

### Installation

Copy the files by following the [instructions](/README.md#template-modules) in the main README.

### Application Configuration

To configure the HCP Portal module in your application, when registering services call the `AddPaceHcpPortal()` extension method on your service provider as well as `UsePaceHcpPortal()` on your web application instance.
`AddPaceHcpPortal` requires an instance of [HcpPortalConfiguration](https://effective-robot-19m1v3p.pages.github.io/classNwadHealth_1_1Pace_1_1HcpPortalModule_1_1Domain_1_1Entities_1_1HcpPortalConfiguration.html)

The configuration requires at a minimum (as constructor params):

- The domain name of your backend
- The domain name of your frontend
- The client id of your frontend application in Auth0
- The SendGrid API key 

Optional but recommended configuration:

| Property                       | Purpose                                                              | Default |
|--------------------------------|----------------------------------------------------------------------|---------|
| `InvitationExpiryTime`         | How many days should the invitation to the HCP Portal stay valid for | `5`     |
| `DataSharingRequestExpiryTime` | How many days should the data sharing request stay valid for         | `5`     |


Furthermore three required roles need to be seeded to the CosmosDB `roles` container:

  - `NwadAdmin`
  - `CustomerAdmin`
  - `Hcp`

In addition to this, users with role `NwadAdmin` cannot be created through application functionality in any way, so at least one user needs to manually have this role assigned, in order to invite users with the two other roles.

See [Identity module role based authorization](/Identity/README.md#role-based-authorization) for how to create the roles and manually assign the `rolesNwadAdmin` role.

```
#### Example

```CSharp
using NwadHealth.Pace.HcpPortalModule.Domain.Entities;
using NwadHealth.Pace.HcpPortalModule.Infrastructure;
using NwadHealth.Pace.PermissionModule.Domain.Entities;

... // other setup

var hcpPortalConfig = new HcpPortalConfiguration(
    "https://your-be-base-url.net/",
    "https://your-fe-base-url.net/",
    "Auth0-WebApplicationClientId",
    "SendGridApiKey"
)
{
    InvitationExpiryTime = TimeSpan.FromDays(3),
    DataSharingRequestExpiryTime = TimeSpan.FromDays(2)
};

services.AddPaceHcpPortal<YourDbContext>(hcpPortalConfig);

... // other setup

var app = builder.Build();

... // other setup

app.UsePaceHcpPortal();

... // other setup

app.Run(); 
```

`AddPaceHcpPortal` method expects a type parameter that implements both `DbContext` and `IHcpPortalDbContext`

If your project already uses SQL database this class should already be present in your project and you should just extend it, otherwise you need to create a new one 

The example below illustrates how to implement the `IHcpPortalDbContext` 

```CSharp
using NwadHealth.Pace.HcpPortalModule.Infrastructure;
using NwadHealth.Pace.HcpPortalModule.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace YourProjectNamespace;

public class YourDbContext : DbContext, IHcpPortalDbContext
{
    public YourDbContext(DbContextOptions<YourDbContext> options) : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        (this as IHcpPortalDbContext).ConfigureDbSets(modelBuilder);
    }

    public DbSet<HcpPortalUserInvitationDbModel> HcpPortalUserInvitations { get; set; }

    public DbSet<HcpPortalUserMetadataDbModel> HcpPortalUserMetadata { get; set; }
}

```

## Events Published

This module does not publish any events

## Application Lifecycle 

When an identity is deleted the module will delete invitations and metadata belonging to the deleleted identity

When data sharing permission is deleted by the patient an email will be sent to notify the HCP about this. (This does not happen when the HCP deletes the permission)
