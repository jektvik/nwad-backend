namespace NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of deleting a note
/// </summary>
public interface IDeleteNoteInteractor
{
    /// <summary>
    /// Attempts to delete the note from the data store
    /// </summary>
    /// <param name="identityId">The id of the identity trying to delete the note</param>
    /// <param name="noteId">The id of the note to delete</param>
    /// <returns>Returns true if the note was deleted otherwise false</returns>
    Task<bool> Execute(string identityId, Guid noteId);
}
