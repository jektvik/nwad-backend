using NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interfaces;

namespace NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents the business logic for deleting a note from a data store
/// </summary>
public class DeleteNoteInteractor : IDeleteNoteInteractor
{
    private readonly INoteRepository _repository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="repository">The data store to delete data from</param>
    public DeleteNoteInteractor(INoteRepository repository)
    {
        _repository = repository;
    }

    /// <summary>
    /// Attempts to delete the note from the data store
    /// </summary>
    /// <param name="identityId">The id of the identity trying to delete the note</param>
    /// <param name="noteId">The id of the note to delete</param>
    /// <returns>Returns true if the note was deleted, false if not found</returns>
    public async Task<bool> Execute(string identityId, Guid noteId)
    {
        var note = await _repository.Get(noteId);

        if (note is null || note.IdentityId != identityId)
        {
            return false;
        }

        await _repository.Delete(noteId);
        return true;
    }
}
