using NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.NoteModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents the business logic for fetching a note from a data store
/// </summary>
public class GetNoteInteractor : IGetNoteInteractor
{
    private readonly INoteRepository _repository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="repository">The data store to use for fetching data</param>
    public GetNoteInteractor(INoteRepository repository)
    {
        _repository = repository;
    }

    /// <summary>
    /// Attempts to fetch a note from the data store
    /// </summary>
    /// <param name="identityId">The id of the identity trying to fetch the note</param>
    /// <param name="noteId">The id of the note to fetch</param>
    /// <returns>The note or null if it was not found</returns>
    public async Task<Note?> Execute(string identityId, Guid noteId)
    {
        var note = await _repository.Get(noteId);

        if (note is null || note.IdentityId != identityId)
        {
            return null;
        }

        return note;
    }
}
