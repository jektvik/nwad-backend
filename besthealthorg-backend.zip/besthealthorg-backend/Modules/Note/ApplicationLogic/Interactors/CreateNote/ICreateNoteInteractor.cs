using NwadHealth.Besthealthorg.NoteModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of creating a note
/// </summary>
public interface ICreateNoteInteractor
{
    /// <summary>
    /// Attempts to save the note to the data store
    /// </summary>
    /// <param name="note">The note to save</param>
    /// <returns>The saved note</returns>
    Task<Note> Execute(Note note);
}
