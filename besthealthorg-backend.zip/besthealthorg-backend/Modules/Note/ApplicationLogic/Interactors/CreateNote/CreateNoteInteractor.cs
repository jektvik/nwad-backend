using NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.NoteModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.NoteModule.ApplicationLogic.Interactors;

/// <summary>
/// Represents the business logic for adding a note to a data store
/// </summary>
public class CreateNoteInteractor : ICreateNoteInteractor
{
    private readonly INoteRepository _repository;

    /// <summary>
    /// Initializes the interactor
    /// </summary>
    /// <param name="repository">The data store to use for saving data</param>
    public CreateNoteInteractor(INoteRepository repository)
    {
        _repository = repository;
    }

    /// <summary>
    /// Attempts to save the note to the data store
    /// </summary>
    /// <param name="note">The note to save</param>
    /// <returns>The saved note</returns>
    public async Task<Note> Execute(Note note)
    {
        return await _repository.Create(note);
    }
}
