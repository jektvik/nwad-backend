using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Controllers;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.IdentityModule.Infrastructure;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using NwadHealth.Besthealthorg.TestUtilities.IntegrationTestHelpers;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.E2eIntegrationTest;

public class ContentLibraryWebApplicationFactory : PaceWebApplicationFactory
{
    private static Configuration Configuration { get; } = new(CosmosDbConnectionString) { IsEmailVerificationRequired = true };

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        base.ConfigureWebHost(builder);
        //ConfigureTestAuth(builder);

        builder.ConfigureServices(services =>
        {
            services
                .AddControllers()
                .AddApplicationPart(typeof(ArticleController).Assembly);

            services.AddDbContext<ContentLibraryTestDbContext>(o =>
            {
                o.UseSqlServer(SqlDbConnectionString);
                o.EnableSensitiveDataLogging();
            });
            var plugin = new TestIdentityPlugin(JwtHelper.TokenSigningKey);

            services.AddPaceIdentity(Configuration, plugin);
            services.AddPaceContentLibrary<ContentLibraryTestDbContext>(new ContentLibraryConfiguration());
        });

        builder.Configure(app =>
        {
            using var scope = app.ApplicationServices.CreateScope();
            var services = scope.ServiceProvider;

            var context = services.GetRequiredService<ContentLibraryTestDbContext>();
            context.Database.EnsureCreated();
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UsePaceIdentity();
            app.UseEndpoints(endpoints => endpoints.MapControllers());
        });
    }
}
