using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

// ReSharper disable MemberCanBePrivate.Global

namespace NwadHealth.Besthealthorg.ContentLibraryModule.E2eIntegrationTest;

public static class FakeData
{
    public const string PortugueseLanguageCode = "PT";
    public const string SpanishLanguageCode = "ES";
    public const string GermanLanguageCode = "DE";
    public const string FrenchLanguageCode = "FR";
    public const string ItalianLanguageCode = "IT";

    private static readonly Dictionary<string, Language> LanguagesDictionary = new()
    {
        { PortugueseLanguageCode, new Language { Name = "Portuguese", Code = PortugueseLanguageCode } },
        { SpanishLanguageCode, new Language { Name = "Spanish", Code = SpanishLanguageCode } },
        { GermanLanguageCode, new Language { Name = "German", Code = GermanLanguageCode } },
        { FrenchLanguageCode, new Language { Name = "French", Code = FrenchLanguageCode } },
        { ItalianLanguageCode, new Language { Name = "Italian", Code = ItalianLanguageCode } },
    };
    public static Language GetLanguageByCode(string code) => new()
    {
        Name = LanguagesDictionary[code].Name,
        Code = LanguagesDictionary[code].Code,
    };
    public static List<Language> Languages => LanguagesDictionary.Select(l => GetLanguageByCode(l.Key)).ToList();

    public const string UnitedStatesCode = "US";
    public const string CanadaCode = "CA";
    public const string BrazilCode = "BR";
    public const string ArgentinaCode = "AR";
    public const string SwitzerlandCode = "CH";
    public const string DenmarkCode = "DK";

    private static readonly Dictionary<string, Country> CountryDictionary = new()
    {
        { UnitedStatesCode, new Country { Name = "United States", Code = UnitedStatesCode } },
        { CanadaCode, new Country { Name = "Canada", Code = CanadaCode } },
        { BrazilCode, new Country { Name = "Brazil", Code = BrazilCode } },
        { ArgentinaCode, new Country { Name = "Argentina", Code = ArgentinaCode } },
        { SwitzerlandCode, new Country { Name = "Switzerland", Code = SwitzerlandCode } },
        { DenmarkCode, new Country { Name = "Denmark", Code = DenmarkCode } },
    };

    public static List<Country> Countries => CountryDictionary.Select(l => GetCountryByCode(l.Key)).ToList();
    public static Country GetCountryByCode(string code) => new()
    {
        Name = CountryDictionary[code].Name,
        Code = CountryDictionary[code].Code,
    };

    public static List<Tag> GetTags() => new()
    {
        new() { Id = 1, Name = "Tag 1", LanguageCode = "ES" },
        new() { Id = 2, Name = "Tag 2", LanguageCode = "ES" },
        new() { Id = 3, Name = "Tag 3", LanguageCode = "ES" },
        new() { Id = 4, Name = "Tag 4", LanguageCode = "ES" },
    };

    public static List<Category> GetCategories() => new()
    {
        new() { Id = 1, Name = "Cat 1", ImageUrl = "https://test.com/cat1.jpg", LanguageCode = "ES" },
        new() { Id = 2, Name = "Cat 2", ImageUrl = "https://test.com/cat2.jpg", LanguageCode = "ES" },
        new() { Id = 3, Name = "Cat 3 FR", ImageUrl = "https://test.com/cat3.jpg", LanguageCode = "FR" },
        new() { Id = 3, Name = "Cat 3 ES", ImageUrl = "https://test.com/cat3.jpg", LanguageCode = "ES" },
        new() { Id = 3, Name = "Cat 3 IT", ImageUrl = "https://test.com/cat3.jpg", LanguageCode = "IT" },
        new() { Id = 4, Name = "Cat 4", ImageUrl = "https://test.com/cat4.jpg", LanguageCode = "ES" },
    };

    public static List<Article> SeedArticles(int count = 90, string? forCountry = null, string? forLanguage = null, bool randomCountry = false)
    {
        var random = new Random();
        var articles = new List<Article>();
        const int loopOffset = 1;
        for (var i = loopOffset; i <= count; i++)
        {
            var randomLanguageCode = forLanguage ?? Languages[random.Next(0, Languages.Count)].Code;
            Console.WriteLine("Fake article key: " + i + "\nLanguageCode" + randomLanguageCode);
            var randomCountryCode = randomCountry ? (random.Next(0, 2) == 0 ? null : Countries[random.Next(Countries.Count)].Code) : forCountry;

            var tags = Enumerable.Range(10, random.Next(5)).ToList().ConvertAll(tagCount => new Tag
            {
                Id = Convert.ToInt32($"{i}{tagCount}"),
                Name = $"Article {tagCount}, Tag {tagCount}, lang {randomLanguageCode}",
                LanguageCode = randomLanguageCode,
            });
            var categories = Enumerable.Range(1, random.Next(5)).ToList().ConvertAll(catCount => new Category
            {
                Id = Convert.ToInt32($"{i}{catCount}"),
                Name = $"Article {catCount}, Category {catCount}, lang {randomLanguageCode}",
                LanguageCode = randomLanguageCode,
                ImageUrl = $"https://example.com/article{i}/category{catCount}.jpg",
            });
            var title = $"Article {i}: {randomLanguageCode} Language and {randomCountryCode ?? "No"} Country";

            var article = new Article
            {
                Id = i,
                Title = title,
                AuthorName = $"Author {i}",
                OriginalArticleUrl = $"https://example.com/article{i}",
                ThumbnailUrl = $"https://example.com/article{i}/thumbnail.jpg",
                LanguageCode = randomLanguageCode,
                CountryCode = randomCountryCode,
                Tags = tags,
                Categories = categories,
           //     Components = GenerateRandomComponents(i),
            };

            articles.Add(article);
        }

       return articles;
    }

    private static List<ArticleComponent> GenerateRandomComponents(int articleId)
    {
        var random = new Random();
        var components = new List<ArticleComponent>();

        // Add 1-4 HTML components
        for (var i = 0; i < random.Next(1, 4); i++)
        {
            components.Add(new HtmlComponent
            {
                Position = i + 1,
                Html = $"<p>This is HTML content for article {articleId}, component {i + 1}</p>",
            });
        }

        // Optionally add an image or video component
        if (random.Next(0, 2) == 0) // 50% chance for image
        {
            components.Add(new ImageComponent
            {
                Position = components.Count + 1,
                Url = $"https://example.com/article{articleId}/image.jpg",
            });
        }
        else // 50% chance for video
        {
            components.Add(new VideoComponent
            {
                Position = components.Count + 1,
                Url = $"https://example.com/article{articleId}/video.mp4",
            });
        }

        return components;
    }

    public static readonly List<Category> Categories =
    [
        new()
        {
            Id = 1,
            Name = "Cat 1",
            ImageUrl = "https://test.com/cat1.jpg",
            LanguageCode = SpanishLanguageCode,
        },
        new()
        {
            Id = 2,
            Name = "Cat 2",
            ImageUrl = "https://test.com/cat2.jpg",
            LanguageCode = SpanishLanguageCode,
        },
        new()
        {
            Id = 3,
            Name = "Cat 3 FR",
            ImageUrl = "https://test.com/cat3.jpg",
            LanguageCode = FrenchLanguageCode,
        },
        new()
        {
            Id = 3,
            Name = "Cat 3 ES",
            ImageUrl = "https://test.com/cat3.jpg",
            LanguageCode = SpanishLanguageCode,
        },
        new()
        {
            Id = 3,
            Name = "Cat 3 IT",
            ImageUrl = "https://test.com/cat3.jpg",
            LanguageCode = ItalianLanguageCode,
        },
        new()
        {
            Id = 4,
            Name = "Cat 4",
            ImageUrl = "https://test.com/cat4.jpg",
            LanguageCode = SpanishLanguageCode,
        },
    ];
}
