﻿using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.TestUtilities.IntegrationTestHelpers;
using Microsoft.EntityFrameworkCore;
using TechTalk.SpecFlow;
using Xunit;
using Xunit.Sdk;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.E2eIntegrationTest.Steps;

[Binding]
public sealed class SharedSteps(
    ScenarioContext scenarioContext,
    ContentLibraryWebApplicationFactory factory,
    TestOutputHelper outputHelper
) : IClassFixture<ContentLibraryWebApplicationFactory> {

    [Given("a running backend")]
    public void GivenARunningBackend()
    {
        var client = factory.CreateDefaultClient(new LoggingHandler(new HttpClientHandler(), outputHelper));
        scenarioContext.Set(client);
    }

    [Given("No identity properties")]
    public async Task GivenNoIdentityProperties()
    {
        using var scope = factory.Services.CreateScope();

        var deleteIdentityInteractor = scope.ServiceProvider.GetRequiredService<IDeleteIdentityInteractor>();
        var identityPropertiesInteractor = scope.ServiceProvider.GetRequiredService<IGetIdentityPropertiesInteractor>();

        await deleteIdentityInteractor.Execute("authorized", "authorized", null);

        var identityProperties = await identityPropertiesInteractor.Execute("authorized");

        Assert.Null(identityProperties);
    }

    [BeforeScenario]
    public async Task ResetDatabases()
    {
        outputHelper.WriteLine("Resetting databases");
        using var scope = factory.Services.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<ContentLibraryTestDbContext>();
        await context.ContentArticles.ExecuteDeleteAsync();
        await context.ContentLanguages.ExecuteDeleteAsync();
        await context.ContentCountries.ExecuteDeleteAsync();
        await context.ContentCategories.ExecuteDeleteAsync();
        await context.ContentTags.ExecuteDeleteAsync();
        context.ChangeTracker.Clear();

        context.ContentLanguages.AddRange(FakeData.Languages);
        context.ContentCountries.AddRange(FakeData.Countries);
        await context.SaveChangesAsync();
    }
}
