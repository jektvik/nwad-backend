using NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Dtos;
using Microsoft.EntityFrameworkCore;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.E2eIntegrationTest.Steps;

[Binding]
public class CategoryStep(
    ScenarioContext scenarioContext,
    ContentLibraryWebApplicationFactory factory)
{
    [Given("{int} categories exist")]
    public async Task GivenCategoriesExist(int count)
    {
        using var scope = factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ContentLibraryTestDbContext>();

        var articlesWithCategoriesToAdd = FakeData.SeedArticles(count, forLanguage: FakeData.ItalianLanguageCode);
        var categoriesToAdd = articlesWithCategoriesToAdd.SelectMany(a => a.Categories).ToList();

        dbContext.ContentArticles.AddRange(articlesWithCategoriesToAdd);
        await dbContext.SaveChangesAsync();

        var categoriesAdded = await dbContext.ContentCategories.ToListAsync();
        Assert.Equal(categoriesToAdd.Count, categoriesAdded.Count);
    }

    [When("I request to get all categories")]
    public async Task WhenIRequestToGetAllCategories()
    {
        var client = scenarioContext.Get<HttpClient>();

        using var requestMessage = new HttpRequestMessage(HttpMethod.Get, "/contentLibrary/category");

        requestMessage.Headers.Add("Accept-Language", FakeData.ItalianLanguageCode);

        var resp = await client.SendAsync(requestMessage);

        scenarioContext.Set(resp);
    }

    [Then("I receive all categories")]
    public async Task ThenIReceiveAllCategories()
    {
        var resp = scenarioContext.Get<HttpResponseMessage>();
        var categories = await resp.Content.ReadFromJsonAsync<List<CategoryDto>>();

        Assert.NotNull(categories);
        Assert.NotEmpty(categories);

        using var scope = factory.Services.CreateScope();

        var dbContext = scope.ServiceProvider.GetRequiredService<ContentLibraryTestDbContext>();

        var categoriesInDb = dbContext.ContentCategories.Where(t => t.LanguageCode == FakeData.ItalianLanguageCode).ToList();

        Assert.Equal(categoriesInDb.Count, categories.Count);
    }
}
