using NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Dtos;
using Microsoft.EntityFrameworkCore;
using TechTalk.SpecFlow;
using Xunit;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.E2eIntegrationTest.Steps;

[Binding]
public class TagsStep(
    ScenarioContext scenarioContext,
    ContentLibraryWebApplicationFactory factory)
{
    [Given("{int} tags exist")]
    public async Task GivenTagsExist(int count)
    {
        using var scope = factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ContentLibraryTestDbContext>();

        var articlesWithTagsToAdd = FakeData.SeedArticles(count, forLanguage: FakeData.ItalianLanguageCode);
        var tagsToAdd = articlesWithTagsToAdd.SelectMany(a => a.Tags).ToList();

        dbContext.ContentArticles.AddRange(articlesWithTagsToAdd);
        await dbContext.SaveChangesAsync();

        var tagsAdded = await dbContext.ContentTags.ToListAsync();
        Assert.Equal(tagsToAdd.Count, tagsAdded.Count);
    }

    [When("I request to get all tags")]
    public async Task WhenIRequestToGetAllTags()
    {
        var client = scenarioContext.Get<HttpClient>();

        using var requestMessage = new HttpRequestMessage(HttpMethod.Get, "/contentLibrary/tag");

        requestMessage.Headers.Add("Accept-Language", FakeData.ItalianLanguageCode);

        var resp = await client.SendAsync(requestMessage);

        scenarioContext.Set(resp);
    }

    [Then("I receive all tags")]
    public async Task ThenIReceiveAllTags()
    {
        var resp = scenarioContext.Get<HttpResponseMessage>();
        var tags = await resp.Content.ReadFromJsonAsync<List<TagDto>>();

        Assert.NotNull(tags);
        Assert.NotEmpty(tags);

        using var scope = factory.Services.CreateScope();

        var dbContext = scope.ServiceProvider.GetRequiredService<ContentLibraryTestDbContext>();

        var tagsInDb = dbContext.ContentTags.Where(t => t.LanguageCode == FakeData.ItalianLanguageCode).ToList();

        Assert.Equal(tagsInDb.Count, tags.Count);
    }
}
