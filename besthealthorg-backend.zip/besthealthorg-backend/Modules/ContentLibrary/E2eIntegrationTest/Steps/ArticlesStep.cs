using NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Dtos;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using Microsoft.EntityFrameworkCore;
using TechTalk.SpecFlow;
using Xunit;
using Xunit.Sdk;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.E2eIntegrationTest.Steps;

[Binding]
public sealed class ArticlesStep(ScenarioContext context, ContentLibraryWebApplicationFactory factory, TestOutputHelper outputHelper) : IClassFixture<ContentLibraryWebApplicationFactory>
{
    private (int, string) _articleKey;
    private (int, int) _paginationParams = (0, 100);

    private const string SearchTerm = "article";
    private const string IdentityPropertiesCountryCode = "dk";

    [Given("{int} articles exist")]
    public async Task GivenArticlesExist(int count)
    {
        using var scope = factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ContentLibraryTestDbContext>();
        var random = new Random();
        var forCountry = (random.Next(0, 2) == 0
            ? IdentityPropertiesCountryCode
            : null);

        var articlesToAdd = FakeData.SeedArticles(count, forCountry, FakeData.ItalianLanguageCode);

        dbContext.ContentArticles.AddRange(articlesToAdd);
        await dbContext.SaveChangesAsync();

        var articlesAdded = await dbContext.ContentArticles.ToListAsync();
        Assert.Equal(count, articlesAdded.Count);

        if (count == 1)
            _articleKey = (articlesAdded[0].Id, articlesAdded[0].LanguageCode);
    }

    [When("I request to get all recommended articles")]
    public async Task WhenIRequestToGetAllRecommendedArticles()
    {
        var client = context.Get<HttpClient>();

        using var requestMessage = new HttpRequestMessage(HttpMethod.Get, "/contentLibrary/article/recommended");

        requestMessage.Headers.Add("Accept-Language", FakeData.ItalianLanguageCode);

        var resp = await client.SendAsync(requestMessage);

        context.Set(resp);
    }

    [When("I request to get all articles")]
    public async Task WhenIRequestToGetAllArticles()
    {
        var client = context.Get<HttpClient>();

        using var requestMessage = new HttpRequestMessage(HttpMethod.Get, "/contentLibrary/article");

        requestMessage.Headers.Add("Accept-Language", FakeData.ItalianLanguageCode);

        var resp = await client.SendAsync(requestMessage);

        context.Set(resp);
    }

    [When("I request to get a non-existent article")]
    public async Task WhenIRequestToGetANonExistentArticle()
    {
        var client = context.Get<HttpClient>();
        var resp = await client.GetAsync("/contentLibrary/article/-1");
        context.Set(resp);
    }

    [When("I request to get an article")]
    public async Task WhenIRequestToGetAnArticle()
    {
        var client = context.Get<HttpClient>();

        var (articleId, languageCode) = _articleKey;

        using var requestMessage = new HttpRequestMessage(HttpMethod.Get,
            $"/contentLibrary/article/{articleId}");

        requestMessage.Headers.Add("Accept-Language", languageCode);

        var resp = await client.SendAsync(requestMessage);
        context.Set(resp);
    }

    [When("I request to get articles sorted by {string} in {string}")]
    public async Task WhenIRequestToGetArticlesSortedByAnd(string sortField, string sortOrder)
    {
        var client = context.Get<HttpClient>();

        var (page, pageSize) = _paginationParams;

        using var requestMessage = new HttpRequestMessage(HttpMethod.Get,
            $"/contentLibrary/article?page={page}&pageSize={pageSize}&sortBy={sortField}&sortOrder={sortOrder}");
        outputHelper.WriteLine($"Sort request: {requestMessage.RequestUri}");
        requestMessage.Headers.Add("Accept-Language", FakeData.ItalianLanguageCode);

        var resp = await client.SendAsync(requestMessage);

        context.Set(resp);
    }

    [When("I request to get articles with page {string} and page size {string}")]
    public async Task WhenIRequestToGetArticlesWithPageAndPageSize(string page, string pageSize)
    {
        var client = context.Get<HttpClient>();

        using var requestMessage = new HttpRequestMessage(HttpMethod.Get,
            $"/contentLibrary/article?page={page}&pageSize={pageSize}");

        requestMessage.Headers.Add("Accept-Language", FakeData.ItalianLanguageCode);

        var resp = await client.SendAsync(requestMessage);

        context.Set(resp);
    }

    [When("I request to get articles with search term")]
    public async Task WhenIRequestToGetArticlesWithSearchTerm()
    {
        var client = context.Get<HttpClient>();

        var (page, pageSize) = _paginationParams;

        using var requestMessage = new HttpRequestMessage(HttpMethod.Get,
            $"/contentLibrary/article?page={page}&pageSize={pageSize}&search={SearchTerm}");

        requestMessage.Headers.Add("Accept-Language", FakeData.ItalianLanguageCode);

        var resp = await client.SendAsync(requestMessage);

        context.Set(resp);
    }

    [When("I request to get articles filtered by tags and categories")]
    public async Task WhenIRequestToGetArticlesFilteredByTagsAndCategories()
    {
        var client = context.Get<HttpClient>();

        var (page, pageSize) = _paginationParams;

        List<int> l = [110, 210];
        var result = string.Join("&", l.Select(tagId => $"tagIds={tagId}"));

        using var requestMessage = new HttpRequestMessage(HttpMethod.Get,
            $"/contentLibrary/article?page={page}&pageSize={pageSize}&{result}");

        requestMessage.Headers.Add("Accept-Language", FakeData.ItalianLanguageCode);

        var resp = await client.SendAsync(requestMessage);

        context.Set(resp);
    }

    [Then("I receive all recommended articles")]
    public async Task ThenIReceiveAllRecommendedArticles()
    {
        var resp = context.Get<HttpResponseMessage>();
        var articles = await resp.Content.ReadFromJsonAsync<List<ArticleDto>>();

        Assert.NotNull(articles);
        Assert.Equal(5, articles.Count);
    }

    [Then("I receive paginated articles filtered by tags and categories")]
    public async Task ThenIReceivePaginatedArticlesFilteredByTagsAndCategories()
    {
        var resp = context.Get<HttpResponseMessage>();
        var pagination = await resp.Content.ReadFromJsonAsync<PaginatedItems<ArticleDto>>();
        Assert.NotNull(pagination?.Data);

        var articles = pagination.Data.ToList();
        Assert.True(articles.All(a => a.Tags!.Any(t => t.Id is 110 or 210)));
    }

    [Then("I receive paginated articles filtered by search term")]
    public async Task ThenIReceivePaginatedArticlesFilteredBy()
    {
        var resp = context.Get<HttpResponseMessage>();
        var pagination = await resp.Content.ReadFromJsonAsync<PaginatedItems<ArticleDto>>();
        Assert.NotNull(pagination?.Data);

        var articles = pagination.Data.ToList();
        Assert.True(articles.All(a => a.Title.Contains(SearchTerm, StringComparison.OrdinalIgnoreCase)));
    }

    [Then("I receive paginated articles with page {string} and size {string}")]
    public async Task ThenIReceivePaginatedArticlesWithPageAndPageSize(string page, string size)
    {
        var resp = context.Get<HttpResponseMessage>();
        var pagination = await resp.Content.ReadFromJsonAsync<PaginatedItems<ArticleDto>>();
        Assert.NotNull(pagination?.Data);

        var articles = pagination.Data.ToList();
        Assert.Equal(size, articles.Count.ToString());

        Assert.Equal(page, pagination.PageIndex.ToString());
        Assert.Equal(size, pagination.PageSize.ToString());
    }

    [Then("I receive paginated articles sorted by {string} in {string}")]
    public async Task ThenIReceivePaginatedArticlesSortedByAnd(string sortField, string sortOrder)
    {
        var resp = context.Get<HttpResponseMessage>();
        var pagination = await resp.Content.ReadFromJsonAsync<PaginatedItems<ArticleDto>>();
        Assert.NotNull(pagination?.Data);

        var articles = pagination.Data.ToList();

        var isAscending = sortOrder.Equals("asc", StringComparison.OrdinalIgnoreCase);

        IEnumerable<ArticleDto> sortedArticles = sortField switch
        {
            "title" => isAscending ? articles.OrderBy(a => a.Title) : articles.OrderByDescending(a => a.Title),
            "authorName" => isAscending ? articles.OrderBy(a => a.AuthorName) : articles.OrderByDescending(a => a.AuthorName),
            _ => throw new ArgumentException($"Unsupported sort field: {sortField}")
        };

        var sortedArticlesList = sortedArticles.ToList();

        Assert.NotEmpty(articles);
        Assert.NotEmpty(sortedArticlesList);
        // Assert that the received articles are sorted as expected
        Assert.Equal(sortedArticlesList, articles);

    }

    [Then("I receive the article")]
    public async Task ThenIReceiveTheArticle()
    {
        var resp = context.Get<HttpResponseMessage>();

        var article = await resp.Content.ReadFromJsonAsync<ArticleDto>();

        Assert.NotNull(article);

        var (articleId, _) = _articleKey;
        Assert.Equal(articleId, article.Id);
    }

    [Then("I receive paginated articles for language and country")]
    public async Task ThenIReceivePaginatedArticlesForLanguageAndCountry()
    {
        var resp = context.Get<HttpResponseMessage>();
        var pagination = await resp.Content.ReadFromJsonAsync<PaginatedItems<ArticleDto>>();
        Assert.NotNull(pagination?.Data);

        var articles = pagination.Data.ToList();

        List<(int, string)> articleKeys = articles.ConvertAll(a => (a.Id, FakeData.ItalianLanguageCode));

        using var scope = factory.Services.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<ContentLibraryTestDbContext>();

        var articlesFromDb = dbContext.ContentArticles
            .ToList()
            .Where(a => articleKeys.Any(key => key.Item1 == a.Id && key.Item2 == a.LanguageCode))
            .ToList();

        Assert.NotEmpty(articlesFromDb);
        Assert.All(articlesFromDb, a =>
        {
            Assert.True(a.LanguageCode == FakeData.ItalianLanguageCode);
            Assert.True(a.CountryCode is IdentityPropertiesCountryCode or null);
        });
    }
}
