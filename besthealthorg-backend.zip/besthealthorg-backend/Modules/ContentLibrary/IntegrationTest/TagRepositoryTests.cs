using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

// ReSharper disable InconsistentNaming
// ReSharper disable UseAwaitUsing

namespace NwadHealth.Besthealthorg.ContentLibraryModule.IntegrationTest;

[Collection("SequentialTestCollection")]
public class TagRepositoryTests : IClassFixture<TestDatabaseFixture>
{
    private readonly ContentLibraryTestDbContext _context;
    private readonly TagRepository _repository;

    public TagRepositoryTests(TestDatabaseFixture fixture)
    {
        _context = TestDatabaseFixture.CreateContext();
        _repository = new TagRepository(_context, Mock.Of<ILogger<TagRepository>>());
    }

    [Fact]
    public async Task CreateTag_WithTranslations_ShouldCreateTagAndTranslations()
    {
        var languageCodeIT = FakeData.Italian.Code;
        var languageCodeDE = FakeData.German.Code;

        var tagIT = new Tag
        {
            Id = 1,
            Name = "IT TAG 1",
            LanguageCode = languageCodeIT,
        };

        var tagDE = new Tag
        {
            Id = 1,
            Name = "DE TAG 1",
            LanguageCode = languageCodeDE,
        };
        List<Tag> tags = [tagIT, tagDE];

        await using var transaction = await _context.Database.BeginTransactionAsync();

        foreach (var tag in tags)
        {
            await _repository.Create(tag);
        }

        _context.ChangeTracker.Clear();

        var createdTagDE = await _repository.Get(tags.First().Id, languageCodeDE);
        AssertTagEquals(tagDE, createdTagDE);

        var createdTagIT = await _repository.Get(tags.First().Id, languageCodeIT);
        AssertTagEquals(tagIT, createdTagIT);
    }

    // [Fact]
    // public async Task UpdateTag_UpdateTranslation_ShouldUpdateTagTranslation()
    // {
    //     await using var transaction = await _context.Database.BeginTransactionAsync();

    //     var tag = _context.ContentTags
    //         .AsNoTracking()
    //         .First();

    //     Assert.NotNull(tag);

    //     const string newName = "Updated Tag Name";
    //     tag.Name = newName;

    //     await _repository.Update(tag);

    //     _context.ChangeTracker.Clear();

    //     var updatedTag = await _repository.Get(tag.Id, tag.LanguageCode);

    //     AssertTagEquals(tag, updatedTag);
    // }

    [Fact]
    public async Task DeleteTag_ShouldDeleteTag()
    {
        var newTag = new Tag
        {
            Id = 9999,
            Name = "New tag to test delete",
            LanguageCode = FakeData.Spanish.Code,
        };

        _context.ContentTags.Add(newTag);
        _context.SaveChanges();

        await using var transaction = await _context.Database.BeginTransactionAsync();

        await _repository.Delete(newTag.Id);

        _context.ChangeTracker.Clear();

        var deletedTag = await _repository.Get(newTag.Id, newTag.LanguageCode);

        Assert.Null(deletedTag);
    }

    [Fact]
    public async Task CreateTag_WithExistingArticle_ShouldCreateTagWithArticles()
    {
        await using var transaction = await _context.Database.BeginTransactionAsync();

        var article = await _context.ContentArticles.FirstAsync();

        var languageCode = FakeData.Spanish.Code;

        var tag = new Tag
        {
            Id = 999,
            Name = "New tag",
            LanguageCode = languageCode,
            Articles = [article],
        };

        await _repository.Create(tag);

        _context.ChangeTracker.Clear();

        var createdTag = await _repository.Get(tag.Id, tag.LanguageCode);

        Assert.NotNull(createdTag);
        Assert.Single(createdTag.Articles);
        AssertTagEquals(tag, createdTag);
    }

    [Fact]
    public async Task CreateTag_WithNewArticle_ShouldCreateTagWithArticles()
    {
        var article = new Article
        {
            Language = _context.ContentLanguages.First(),
            LanguageCode = _context.ContentLanguages.First().Code,
            Id = 890,
            Title = "New article for tag",
            AuthorName = "An author",
            ThumbnailUrl = "www.thumbnail.com/image.jpg",
        };

        var languageCode = FakeData.Spanish.Code;

        await using var transaction = await _context.Database.BeginTransactionAsync();

        var tag = new Tag
        {
            Id = 999,
            Name = "New tag",
            LanguageCode = languageCode,
            Articles = [article],
        };

        await _repository.Create(tag);

        _context.ChangeTracker.Clear();

        var createdTag = await _repository.Get(tag.Id, tag.LanguageCode);

        Assert.NotNull(createdTag);
        Assert.Single(createdTag.Articles);
        AssertTagEquals(tag, createdTag);
    }

    private static void AssertTagEquals(Tag expected, Tag? actual)
    {
        Assert.NotNull(actual);
        Assert.Equal(expected.Id, actual.Id);
        Assert.Equal(expected.Name, actual.Name);
        Assert.Equal(expected.LanguageCode, actual.LanguageCode);
    }
}
