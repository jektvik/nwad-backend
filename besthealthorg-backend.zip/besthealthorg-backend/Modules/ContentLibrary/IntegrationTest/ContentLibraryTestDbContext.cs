using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.IntegrationTest;

/// <summary>
/// DbContext for Consultation integration tests
/// </summary>
public class ContentLibraryTestDbContext(DbContextOptions<ContentLibraryTestDbContext> options)
    : DbContext(options), IContentLibraryDbContext
{
    public DbSet<Article> ContentArticles { get; set; }

    public DbSet<Tag> ContentTags { get; set; }

    public DbSet<Category> ContentCategories { get; set; }

    public DbSet<Language> ContentLanguages { get; set; }

    public DbSet<Country> ContentCountries { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        (this as IContentLibraryDbContext).ConfigureDbSets(modelBuilder);
    }
}
