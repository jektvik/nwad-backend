using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Xunit;
using Xunit.Abstractions;
// ReSharper disable UseAwaitUsing
// ReSharper disable MethodHasAsyncOverload

namespace NwadHealth.Besthealthorg.ContentLibraryModule.IntegrationTest;

public class LanguageRepositoryTests : IClassFixture<TestDatabaseFixture>
{
    private readonly ITestOutputHelper _testOutputHelper;
    private readonly ContentLibraryTestDbContext _context;
    private readonly LanguageRepository _repository;

    public LanguageRepositoryTests(ITestOutputHelper testOutputHelper)
    {
        _testOutputHelper = testOutputHelper;
        _context = TestDatabaseFixture.CreateContext();
        _repository = new LanguageRepository(_context);
    }

    [Fact]
    public async Task CreateLanguage_ShouldPersistLanguage()
    {
        // Start transaction
        await using var transaction = await _context.Database.BeginTransactionAsync();

        // Arrange
        var language = new Language { Name = "Test Language", Code = "TL" };

        // Act
        await _repository.Create(language);
        _context.ChangeTracker.Clear();

        // Assert
        var addedLanguage = await _repository.Get(language.Code);
        Assert.NotNull(addedLanguage);
        Assert.Equal(language.Code, addedLanguage.Code);
        Assert.Equal(language.Name, addedLanguage.Name);
    }

    [Fact]
    public async Task CreateLanguage_WithExistingCountry_ShouldPersistLanguageWithCountry()
    {
        // Start transaction
        await using var transaction = await _context.Database.BeginTransactionAsync();

        // Arrange
        var existingCountry = _context.ContentCountries
            .AsNoTracking()
            .First(c => c.Code == FakeData.RandomCountryCode);

        var language = new Language() { Name = "Test Language", Code = "TL", Countries = [existingCountry] };

        // Act
        await _repository.Create(language);
        _context.ChangeTracker.Clear();

        // Assert
        var createdLanguage = await _repository.Get(language.Code);

        Assert.NotNull(createdLanguage);
        Assert.Equal(language.Code, createdLanguage.Code);
        Assert.Equal(language.Name, createdLanguage.Name);
        Assert.Single(createdLanguage.Countries, c => c.Code == existingCountry.Code);
    }

    [Fact]
    public async Task CreateLanguage_WithNewCountry_ShouldPersistLanguageWithNewCountry()
    {
        // Start transaction
        await using var transaction = await _context.Database.BeginTransactionAsync();

        // Arrange
        var newCountry = new Country() { Name = "New Country", Code = "NC" };
        var language = new Language() { Name = "Test Language", Code = "TL", Countries = [newCountry] };

        // Act
        await _repository.Create(language);
        _context.ChangeTracker.Clear();

        // Assert
        var createdLanguage = await _repository.Get(language.Code);
        AssertLanguagesEqual(language, createdLanguage);
    }

    [Fact]
    public async Task UpdateLanguage_WithExistingCountry_ShouldPersistLanguageWithUpdatedCountry()
    {
        var languageCode = FakeData.Portuguese.Code;
        // Arrange
        var language = await _repository.Get(languageCode);
        _testOutputHelper.WriteLine("Language used: " + languageCode);
        Assert.NotNull(language);

        var countryToAdd = _context.ContentCountries
            .AsNoTracking()
            .First(c => c.Code == FakeData.RandomCountryCode);

        language.Countries.Add(countryToAdd);

        const string updatedName = "Updated Language Name";
        language.Name = updatedName;

        // Start transaction
        using var transaction = _context.Database.BeginTransaction();

        // Act
        await _repository.Update(language.Code, language);
        _context.ChangeTracker.Clear();

        // Assert
        var updatedLanguage = await _repository.Get(language.Code);
        Assert.NotNull(updatedLanguage);

        AssertLanguagesEqual(language, updatedLanguage);
    }

    [Fact]
    public async Task DeleteLanguage_ShouldRemoveLanguageFromDatabase()
    {
        // Start transaction
        using var transaction = _context.Database.BeginTransaction();
        var newLanguage = new Language { Name = "New Language", Code = "XX" };
        _context.ContentLanguages.Add(newLanguage);
        _context.SaveChanges();

        // Act
        await _repository.Delete(newLanguage.Code);
        _context.ChangeTracker.Clear();

        // Assert
        var deletedLanguage = await _repository.Get(newLanguage.Code);
        Assert.Null(deletedLanguage);
    }

    private static void AssertLanguagesEqual(Language expected, Language? actual)
    {
        // Ensure the actual language is not null
        Assert.NotNull(actual);

        // Check that the basic properties match
        Assert.Equal(expected.Name, actual.Name);
        Assert.Equal(expected.Code, actual.Code);

        // Check that the number of associated countries matches
        Assert.Equal(expected.Countries.Count, actual.Countries.Count);

        // Check that each country in the expected list matches the actual list
        foreach (var expectedCountry in expected.Countries)
        {
            var actualCountry = actual.Countries.FirstOrDefault(c => c.Code == expectedCountry.Code);
            Assert.NotNull(actualCountry);
            Assert.Equal(expectedCountry.Name, actualCountry.Name);
            Assert.Equal(expectedCountry.Code, actualCountry.Code);
        }
    }
}
