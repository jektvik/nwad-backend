using System.Diagnostics.CodeAnalysis;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

// ReSharper disable MethodHasAsyncOverload
// ReSharper disable InconsistentNaming

namespace NwadHealth.Besthealthorg.ContentLibraryModule.IntegrationTest;

[SuppressMessage("Roslynator", "RCS1261:Resource can be disposed asynchronously")]
[SuppressMessage("ReSharper", "UseAwaitUsing")]
public class CategoryRepositoryTests : IClassFixture<TestDatabaseFixture>
{
    private readonly CategoryRepository _repository;
    private readonly ContentLibraryTestDbContext _context;

    public CategoryRepositoryTests()
    {
        _context = TestDatabaseFixture.CreateContext();
        _repository = new CategoryRepository(_context, Mock.Of<ILogger<CategoryRepository>>());
    }

    [Fact]
    public async Task CreateCategory_WithTranslations_ShouldCreateCategoryAndTranslations()
    {
        List<Category> translatedCategory =
        [
            new()
            {
                Id = 666,
                LanguageCode = FakeData.Spanish.Code,
                Name = "ES Category",
                ImageUrl = "https://example.com/image",
            },
            new()
            {
                Id = 666,
                LanguageCode = FakeData.German.Code,
                Name = "DE Category",
                ImageUrl = "https://example.com/image",
            },
        ];
        using var transaction = _context.Database.BeginTransaction();

        foreach (var category in translatedCategory)
        {
            await _repository.Create(category);
        }

        _context.ChangeTracker.Clear();
        var createdES = await _repository.Get(666, FakeData.Spanish.Code);
        AssertCategoryEquals(translatedCategory[0], createdES);

        var createdDE = await _repository.Get(666, FakeData.German.Code);
        AssertCategoryEquals(translatedCategory[1], createdDE);
    }

    [Fact]
    public async Task UpdateCategory_ShouldUpdateCategoryTranslationAndImageUrl()
    {
        var category = await _context.ContentCategories
            .AsNoTracking()
            .FirstAsync();

        await using var transaction = await _context.Database.BeginTransactionAsync();

        const string newImageUrl = "https://example.com/new-image";
        category.ImageUrl = newImageUrl;

        const string newName = "New category name";
        category.Name = newName;

        await _repository.Update(category);

        _context.ChangeTracker.Clear();

        var updatedCategory = await _repository.Get(category.Id, category.LanguageCode);

        AssertCategoryEquals(category, updatedCategory);
    }

    [Fact]
    public async Task DeleteCategory_ShouldDeleteCategory()
    {
        var categoryToDelete = new Category
        {
            Id = 787899,
            Name = "Category to delete",
            ImageUrl = "https://example.com/image",
            LanguageCode = "ES",
        };
        await _repository.Create(categoryToDelete);

        var deleteCount = await _repository.Delete(categoryToDelete.Id);
        Assert.Equal(1, deleteCount);

        var deletedCategory = await _repository.Get(categoryToDelete.Id, categoryToDelete.LanguageCode);
        Assert.Null(deletedCategory);
    }

    private static void AssertCategoryEquals(Category expected, Category? actual)
    {
        Assert.NotNull(actual);
        Assert.Equal(expected.ImageUrl, actual.ImageUrl);
        Assert.Equal(expected.Name, actual.Name);
        Assert.Equal(expected.LanguageCode, actual.LanguageCode);
    }
}
