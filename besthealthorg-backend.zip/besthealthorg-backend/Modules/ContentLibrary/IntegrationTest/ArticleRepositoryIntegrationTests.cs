using System.Diagnostics.CodeAnalysis;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;
using NwadHealth.Besthealthorg.Foundation.Extensions;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;
using Xunit.Abstractions;

// ReSharper disable InconsistentNaming
// ReSharper disable UseAwaitUsing
// ReSharper disable MethodHasAsyncOverload

namespace NwadHealth.Besthealthorg.ContentLibraryModule.IntegrationTest;

[SuppressMessage("Roslynator", "RCS1261:Resource can be disposed asynchronously")]
public class ArticleRepositoryTests : IClassFixture<TestDatabaseFixture>
{
    private readonly ContentLibraryTestDbContext _context;
    private readonly ArticleRepository _repository;
    private readonly ITestOutputHelper _testOutputHelper;

    public ArticleRepositoryTests(ITestOutputHelper testOutputHelper)
    {
        _testOutputHelper = testOutputHelper;
        _context = TestDatabaseFixture.CreateContext();
        _context.ChangeTracker.Clear();
        _repository = new ArticleRepository(_context, Mock.Of<ILogger<ArticleRepository>>());
    }

    [Fact]
    [Trait("Category", "Get")]
    public async void Get_ForLanguage_ReturnsArticle()
    {
        string languageCode = FakeData.Italian.Code;
        var articleId2 = await _repository.Get(2, languageCode);

        Assert.NotNull(articleId2);
        Assert.True(articleId2.Tags.All(t => t.LanguageCode == languageCode));

        PrintArticleUsed(articleId2);
    }

    [Fact]
    [Trait("Category", "GetAll")]
    public async Task GetAll_ForLanguage_ReturnsAllArticlesLanguage()
    {
        var languageCode = FakeData.Spanish.Code;

        var filters = new ArticleFilters
        {
            LanguageCode = languageCode,
        };

        var paginatedArticles = await _repository.GetAll(
            new PaginationRequest(), new SortRequest("title"), filters);

        Assert.NotEmpty(paginatedArticles.Data);
        Assert.True(paginatedArticles.Data.All(a => a.LanguageCode == languageCode));

        foreach (var article in paginatedArticles.Data)
        {
            PrintArticleUsed(article);
        }
    }

    [Fact]
    [Trait("Category", "GetAll")]
    public async Task GetAll_WithKeyword_ReturnsAllArticlesForKeyword()
    {
        var languageCode = FakeData.Spanish.Code;

        var filters = new ArticleFilters
        {
            LanguageCode = languageCode,
            TagIds = [],
            CategoryIds = [],
            Keyword = "seEDed",
        };

        var paginatedArticles = await _repository.GetAll(
            new PaginationRequest(100), new SortRequest("title"), filters);

        Assert.All(paginatedArticles.Data, a => Assert.Contains("seeded", a.Title.ToString().ToLower()));
        Assert.All(paginatedArticles.Data, a => Assert.Equal(languageCode, a.LanguageCode));
        Assert.Equal(paginatedArticles.Data.Count(), paginatedArticles.Count);

        foreach (var article in paginatedArticles.Data)
        {
            PrintArticleUsed(article);
        }
    }

    [Fact]
    [Trait("Category", "GetAll")]
    public async Task GetAll_WithTagsCategoriesKeywordFilter_ReturnsAllArticlesForFilters()
    {
        var languageCode = FakeData.Spanish.Code;

        var filters = new ArticleFilters
        {
            LanguageCode = languageCode,
            TagIds = [1],
            CategoryIds = [1],
            Keyword = "Article",
        };

        var paginatedArticles = await _repository.GetAll(
            new PaginationRequest(100), new SortRequest("title"), filters);

        Assert.Equal(paginatedArticles.Data.Count(), paginatedArticles.Count);
        Assert.All(paginatedArticles.Data, a => Assert.Contains("article", a.Title.ToString().ToLower()));
        Assert.All(paginatedArticles.Data, a => Assert.Equal(languageCode, a.LanguageCode));
        Assert.All(paginatedArticles.Data, a => Assert.Contains(1, a.Tags.Select(t => t.Id)));
        Assert.All(paginatedArticles.Data, a => Assert.Contains(1, a.Categories.Select(c => c.Id)));
    }

    [Fact]
    [Trait("Category", "Pagination")]
    public async Task GetAll_WithOutOfRangePage_ShouldReturnLastPage()
    {
        // Arrange
        var languageCode = FakeData.Spanish.Code;

        // Get the total count of articles with the specified language code
        var totalCount = await _context.ContentArticles.CountAsync(a => a.LanguageCode == languageCode);

        // Calculate the last valid page index based on the total count and page size
        const int pageSize = 10;
        var lastPage = ((totalCount + pageSize - 1) / pageSize) - 1; // last valid page index

        // Use an out-of-range page number (one page beyond the last valid one)
        var outOfRangePage = lastPage + 1;

        var paginationRequest = new PaginationRequest(PageSize: pageSize, Page: outOfRangePage);

        var filters = new ArticleFilters
        {
            LanguageCode = languageCode,
        };

        // Act
        var paginatedArticles = await _repository.GetAll(paginationRequest, new SortRequest("title"), filters);

        // Assert

        // Ensure that the total count matches what we expect from the database
        Assert.Equal(totalCount, paginatedArticles.Count);

        // Verify that we received the last page's data (not an empty page)
        var expectedPageSize = totalCount % pageSize == 0 ? pageSize : totalCount % pageSize;
        Assert.Equal(expectedPageSize, paginatedArticles.Data.Count());

        // Ensure that all returned articles are in the correct language
        Assert.True(paginatedArticles.Data.All(a => a.LanguageCode == languageCode));

        // Optionally, check that the IDs are from the last page
        var expectedLastPageIds = await _context.ContentArticles
            .Where(a => a.LanguageCode == languageCode)
            .OrderBy(a => a.Title)  // Assuming you're sorting by title
            .Skip(lastPage * pageSize)  // Skip to the last page
            .Take(pageSize)
            .Select(a => a.Id)
            .ToListAsync();

        var actualIds = paginatedArticles.Data.Select(a => a.Id).ToList();

        Assert.Equal(expectedLastPageIds, actualIds);
    }

    [Fact]
    [Trait("Category", "Sorting")]
    public async Task GetAll_WithSorting_ShouldReturnCorrectOrder()
    {
        var filters = new ArticleFilters
        {
            LanguageCode = FakeData.Spanish.Code,
        };

        var paginatedArticles = await _repository.GetAll(
            new PaginationRequest(), new SortRequest("title", SortOrder.Desc), filters);

        var sortedTitles = paginatedArticles.Data.Select(a => a.Title.ToString()).ToList();
        Assert.True(sortedTitles.SequenceEqual(sortedTitles.OrderByDescending(title => title)));
    }

    [Fact]
    [Trait("Category", "Update")]
    public async void UpdateArticle_WithNewContentType_ShouldUpdateArticleContentTypes()
    {
        _context.ChangeTracker.Clear();
        const int updateArticleId = 2;
        const string updateArticleLanguageCode = "IT";

        var articleId2 = await _repository.Get(updateArticleId, updateArticleLanguageCode);
        Assert.NotNull(articleId2);

        List<ArticleComponent> newContentTypes =
        [
            new ImageComponent
            {
                Position = 2,
                Url = "https://test.com/image_it.jpg",
            },
            new VideoComponent
            {
                Position = 3,
                Url = "https://test.com/video_it.mp4",
            },
        ];

        articleId2.UpdateComponents(newContentTypes);

        using var t = _context.Database.BeginTransaction();

        await _repository.Update(articleId2);

        _context.ChangeTracker.Clear();

        var updatedArticle = await _repository.Get(updateArticleId, updateArticleLanguageCode);

        AssertArticlesEqual(articleId2, updatedArticle);
    }

    [Fact]
    [Trait("Category", "Pagination")]
    public async Task Test_Pagination()
    {
        // Arrange
        const string languageCode = "ES";
        const string sortByProperty = "title";

        const int pageSize = 5;
        const int pageIndex = 1;
        var paginationRequest = new PaginationRequest(PageSize: pageSize, Page: pageIndex);

        var filters = new ArticleFilters
        {
            LanguageCode = languageCode,
        };

        // Act
        var paginatedArticles = await _repository.GetAll(
            paginationRequest: paginationRequest, sortRequest: new SortRequest(sortByProperty),
            articleFilters: filters);

        Assert.NotNull(paginatedArticles.Data);

        // Ensure that the number of articles returned matches the PageSize
        Assert.Equal(pageSize, paginatedArticles.Data.Count());

        // Ensure the total count of articles matches what's in the database
        var totalCount = await _context.ContentArticles.LongCountAsync(a => a.LanguageCode == languageCode);
        Assert.Equal(totalCount, paginatedArticles.Count);

        // Check that the articles returned belong to the correct page based on the order (Id)
        var expectedTitles = await _context.ContentArticles
            .Where(a => a.LanguageCode == languageCode)
            .SortBy(sortByProperty, SortOrder.Asc)
            .ThenBy(a => a.Id)
            .Skip(pageSize * pageIndex)
            .Take(pageSize)
            .Select(a => a.Title)
            .ToListAsync();

        var actualTitles = paginatedArticles.Data.Select(a => a.Title).ToList();

        // Ensure the actual IDs match the expected IDs
        Assert.Equal(expectedTitles, actualTitles);
    }

    [Fact]
    [Trait("Category", "Create")]
    public async Task CreateArticle_WithContentTypes_ShouldCreateArticleAndContentTypes()
    {
        const int newArticleId = 999;
        var newArticleFR = new Article
        {
            Id = newArticleId,
            Title = "Test Article FR",
            AuthorName = "Test Author",
            OriginalArticleUrl = "https://test.com/article.jpg",
            ThumbnailUrl = "https://test.com/thumbnail.jpg",
            LanguageCode = _context.ContentLanguages.First(l => l.Code == "FR").Code,
        };

        var contentTypes = new List<ArticleComponent>
        {
            new HtmlComponent
            {
                Position = 1,
                Html = "Test content",
            },
            new ImageComponent
            {
                Position = 2,
                Url = "https://test.com/image.jpg",
            },
            new VideoComponent
            {
                Position = 3,
                Url = "https://test.com/video.mp4",
            },
        };
        newArticleFR.UpdateComponents(contentTypes);

        var newArticleDE = new Article
        {
            Id = newArticleId,
            Title = "Test Article DE",
            AuthorName = "Test Author",
            OriginalArticleUrl = "https://test.com/article.jpg",
            ThumbnailUrl = "https://test.com/thumbnail.jpg",
            LanguageCode = FakeData.German.Code,
        };

        var contentTypesDE = new List<ArticleComponent>
        {
            new HtmlComponent
            {
                Position = 1,
                Html = "Test content",
            },
            new ImageComponent
            {
                Position = 2,
                Url = "https://test.com/image.jpg",
            },
            new VideoComponent
            {
                Position = 3,
                Url = "https://test.com/video.mp4",
            },
        };
        newArticleDE.UpdateComponents(contentTypesDE);

        using var transaction = _context.Database.BeginTransaction();

        await _repository.Create(newArticleFR);
        await _repository.Create(newArticleDE);

        _context.ChangeTracker.Clear();

        var fetchedCreatedArticleFR = await _repository.Get(newArticleFR.Id, FakeData.French.Code);
        AssertArticlesEqual(newArticleFR, fetchedCreatedArticleFR);

        var fetchedCreatedArticleDE = await _repository.Get(newArticleDE.Id, FakeData.German.Code);
        AssertArticlesEqual(newArticleDE, fetchedCreatedArticleDE);
    }

    [Fact]
    [Trait("Category", "Create")]
    public async Task CreateArticle_WithNewCountry_ShouldCreateArticle()
    {
        using var transaction = _context.Database.BeginTransaction();

        var newCountry = new Country { Name = "XXX", Code = "XX" };

        _context.ContentCountries.Add(newCountry);
        _context.SaveChanges();

        string countryCode = newCountry.Code;
        string languageCode = FakeData.German.Code;

        List<Tag> tags =
        [
            new()
            {
                Id = 789,
                LanguageCode = languageCode,
                Name = "New tag 1: german",
            },
            new()
            {
                Id = 790,
                LanguageCode = languageCode,
                Name = "New tag 2: french",
            },
        ];

        List<Category> categories =
        [
            new()
            {
                Id = 1,
                Name = "Cat 1",
                ImageUrl = "https://test.com/cat1.jpg",
                LanguageCode = languageCode,
            },
            new()
            {
                Id = 2,
                Name = "Cat 2",
                ImageUrl = "https://test.com/cat2.jpg",
                LanguageCode = languageCode,
            },
        ];

        var components = new List<ArticleComponent>
        {
            new HtmlComponent
            {
                Position = 1,
                Html = "Test content",
            },
            new ImageComponent
            {
                Position = 2,
                Url = "https://test.com/image.jpg",
            },
            new VideoComponent
            {
                Position = 3,
                Url = "https://test.com/video.mp4",
            },
        };

        var article = new Article
        {
            Id = 5555,
            Title = "Title prlp",
            AuthorName = "Author name prlp",
            OriginalArticleUrl = "https://example.com",
            ThumbnailUrl = "https://example.com/thumbnail",
            Tags = tags,
            Categories = categories,
            LanguageCode = languageCode,
            Components = components,
            CountryCode = countryCode,
        };
        await _repository.Create(article);

        _context.ChangeTracker.Clear();
        var createdArticle = await _repository.Get(article.Id, article.LanguageCode);

        PrintArticleUsed(article: article);
        AssertArticlesEqual(article, createdArticle);
    }

    [Fact]
    [Trait("Category", "Create")]
    public async Task CreateArticle_WithTagsCategoriesContentTypes_ShouldCreateArticle()
    {
        string languageCode = FakeData.German.Code;
        List<Tag> tags =
        [
            new()
            {
                Id = 789,
                LanguageCode = languageCode,
                Name = "New tag 1: german",
            },
            new()
            {
                Id = 790,
                LanguageCode = languageCode,
                Name = "New tag 2: french",
            },
        ];

        List<Category> categories =
        [
            new()
            {
                Id = 1,
                Name = "Cat 1",
                ImageUrl = "https://test.com/cat1.jpg",
                LanguageCode = languageCode,
            },
            new()
            {
                Id = 2,
                Name = "Cat 2",
                ImageUrl = "https://test.com/cat2.jpg",
                LanguageCode = languageCode,
            },
        ];

        var components = new List<ArticleComponent>
        {
            new HtmlComponent
            {
                Position = 1,
                Html = "Test content",
            },
            new ImageComponent
            {
                Position = 2,
                Url = "https://test.com/image.jpg",
            },
            new VideoComponent
            {
                Position = 3,
                Url = "https://test.com/video.mp4",
            },
        };

        var article = new Article
        {
            Id = 5555,
            Title = "Title prlp",
            AuthorName = "Author name prlp",
            OriginalArticleUrl = "https://example.com",
            ThumbnailUrl = "https://example.com/thumbnail",
            Tags = tags,
            Categories = categories,
            LanguageCode = languageCode,
            Components = components,
        };

        using var transaction = _context.Database.BeginTransaction();

        await _repository.Create(article);

        _context.ChangeTracker.Clear();
        var createdArticle = await _repository.Get(article.Id, article.LanguageCode);

        PrintArticleUsed(article: article);
        AssertArticlesEqual(article, createdArticle);
    }

    [Fact]
    [Trait("Category", "Update")]
    public async Task UpdateArticle_WithNewTagsAndFilters_ShouldPersistUpdatedTagsAndFilters()
    {
        var article = _context.ContentArticles.AsNoTracking().First();
        Assert.NotNull(article);

        var newTag = new Tag
        {
            Id = 789,
            LanguageCode = article.LanguageCode,
            Name = "New tag 2: french",
        };

        var newCategory = new Category
        {
            Id = 777,
            Name = "default",
            ImageUrl = "https://example.com",
            LanguageCode = article.LanguageCode,
        };

        using var transaction = _context.Database.BeginTransaction();

        article.Tags.Add(newTag);
        article.Categories.Add(newCategory);

        await _repository.Update(article);

        _context.ChangeTracker.Clear();

        var updatedArticle = await _repository.Get(article.Id, article.LanguageCode);

        Assert.NotNull(updatedArticle);
        AssertArticlesEqual(article, updatedArticle);
    }

    [Fact]
    [Trait("Category", "Delete")]
    public async Task DeleteNonExistingArticle_ShouldReturnZeroAndNotThrowException()
    {
        const int nonExistingArticleId = -1;

        using var transaction = _context.Database.BeginTransaction();
        var deleteResult = await _repository.Delete(nonExistingArticleId);

        Assert.Equal(0, deleteResult);
    }

    [Fact]
    [Trait("Category", "Update")]
    public async Task UpdateArticle_WithNewScalarProperties_ShouldUpdateArticleProperties()
    {
        var article = _context.ContentArticles.AsNoTracking().First();
        Assert.NotNull(article);

        const string newAuthor = "kappa title";
        article.AuthorName = newAuthor;

        const string newImageUrl = "https://newimage.com";
        article.ThumbnailUrl = newImageUrl;

        using var transaction = _context.Database.BeginTransaction();

        await _repository.Update(article);
        _context.ChangeTracker.Clear();

        var updatedArticle = await _repository.Get(article.Id, article.LanguageCode);

        AssertArticlesEqual(article, updatedArticle);

        PrintArticleUsed(article);
    }

    [Fact]
    [Trait("Category", "Update")]
    public async Task UpdateArticle_WhenAddingAndRemovingTags_ShouldPersistUpdatedTagsCorrectly()
    {
        var article = _context.ContentArticles.AsNoTracking().First(t => t.Tags.Count > 0);
        Assert.NotNull(article);

        using var transaction = _context.Database.BeginTransaction();

        var newTag = new Tag
        {
            Id = 5555,
            LanguageCode = article.LanguageCode,
            Name = "New tag 2: french",
        };

        var existingTag = _context.ContentTags.First();

        article.Tags.Clear();
        article.Tags.Add(newTag);
        article.Tags.Add(existingTag);

        await _repository.Update(article);

        _context.ChangeTracker.Clear();

        var updatedArticle = await _repository.Get(article.Id, article.LanguageCode);
        AssertArticlesEqual(article, updatedArticle);

        PrintArticleUsed(article);
    }

    [Fact]
    [Trait("Category", "Update")]
    public async Task UpdateArticle_WithExistingCountry_ShouldPersistNewCountryDetails()
    {
        using var transaction = _context.Database.BeginTransaction();
        _context.ChangeTracker.Clear();

        var updateToCountry = new Country() { Name = "Switzerland", Code = "CH" };
        var article = _context.ContentArticles
            .First(a => a.CountryCode != updateToCountry.Code);

        Assert.NotNull(article);

        article.Country = updateToCountry;

        await _repository.Update(article);

        _context.ChangeTracker.Clear();

        var updatedArticle = await _repository.Get(article.Id, article.LanguageCode);
        PrintArticleUsed(article);
        AssertArticlesEqual(article, updatedArticle);
    }

    [Fact]
    [Trait("Category", "Delete")]
    public async Task DeleteArticle_WithValidId_DeletesArticleFromDB()
    {
        var article = _context.ContentArticles.First();

        using var transaction = _context.Database.BeginTransaction();

        var deleteCount = await _repository.Delete(article.Id);
        Assert.True(deleteCount >= 1);

        _context.ChangeTracker.Clear();
        var deletedArticle = await _repository.Get(article.Id, article.LanguageCode);

        Assert.Null(deletedArticle);
    }

    [Fact]
    [Trait("Category", "Delete")]
    public async Task DeleteArticle_WithValidIdAndLanguageCode_ShouldPersistDeletionInDatabase()
    {
        const int articleToDeleteId = 2;
        var articles = _context.ContentArticles.Where(a => a.Id == articleToDeleteId).ToList();

        using var transaction = _context.Database.BeginTransaction();

        var deleteCount = await _repository.Delete(articleToDeleteId, articles.First().LanguageCode);
        Assert.Equal(1, deleteCount);
    }

    private void PrintArticleUsed(Article article)
    {
        var toPrint = "Article used:\n-" + article.Id + "\n-" + article.Title + "\n-" + article.LanguageCode +
                      "\n-" + article.Country?.Code + "\n\n";

        // Append tag details to the string
        toPrint = article.Tags.Select(articleTag =>
            "Tag used:\n-" + articleTag.Id + "\n-" + articleTag.Name + "\n-" + articleTag.LanguageCode + "\n\n").Aggregate(toPrint, (current, tagDetails) => current + tagDetails);

        _testOutputHelper.WriteLine(toPrint);
    }

    private static void AssertArticlesEqual(Article expected, Article? actual)
    {
        Assert.NotNull(actual);
        Assert.Equal(expected.Title, actual.Title);
        Assert.Equal(expected.AuthorName, actual.AuthorName);
        Assert.Equal(expected.OriginalArticleUrl, actual.OriginalArticleUrl);
        Assert.Equal(expected.ThumbnailUrl, actual.ThumbnailUrl);
        Assert.Equal(expected.LanguageCode, actual.LanguageCode);
        Assert.Equal(expected.Tags.Count, actual.Tags.Count);
        Assert.Equal(expected.Categories.Count, actual.Categories.Count);
        Assert.Equal(expected.CountryCode, actual.CountryCode);

        // Compare components
        Assert.Equal(expected.Components.Count, actual.Components.Count);
        for (var i = 0; i < expected.Components.Count; i++)
        {
            var expectedContentType = expected.Components.OrderBy(ct => ct.Position).ToList()[i];
            var actualContentType = actual.Components.OrderBy(ct => ct.Position).ToList()[i];

            Assert.Equal(expectedContentType.GetType(), actualContentType.GetType());

            switch (expectedContentType)
            {
                case HtmlComponent expectedHtmlType:
                {
                    var actualHtmlType = (HtmlComponent)actualContentType;
                    Assert.Equal(expectedHtmlType.Html, actualHtmlType.Html);
                    break;
                }
                case ImageComponent expectedImageType:
                {
                    var actualImageType = (ImageComponent)actualContentType;
                    Assert.Equal(expectedImageType.Url, actualImageType.Url);
                    break;
                }
                case VideoComponent expectedVideoType:
                {
                    var actualVideoType = (VideoComponent)actualContentType;
                    Assert.Equal(expectedVideoType.Url, actualVideoType.Url);
                    break;
                }
            }
        }
    }
}
