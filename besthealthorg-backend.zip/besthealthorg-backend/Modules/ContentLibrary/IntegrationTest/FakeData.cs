using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
// ReSharper disable MemberCanBePrivate.Global

namespace NwadHealth.Besthealthorg.ContentLibraryModule.IntegrationTest;

public static class FakeData
{
    public static readonly Language Portuguese = new() { Name = "Portuguese", Code = "PT" };
    public static readonly Language Spanish = new() { Name = "Spanish", Code = "ES" };
    public static readonly Language German = new() { Name = "German", Code = "DE" };
    public static readonly Language French = new() { Name = "French", Code = "FR" };
    public static readonly Language Italian = new() { Name = "Italian", Code = "IT" };

    public static readonly List<Language> Languages = [Portuguese, Spanish, German, French, Italian];

    // ReSharper disable once InconsistentNaming
    public static readonly Country US = new() { Name = "United States", Code = "US" };
    public static readonly Country Canada = new() { Name = "Canada", Code = "CA" };
    public static readonly Country Brazil = new() { Name = "Brazil", Code = "BR" };
    public static readonly Country Argentina = new() { Name = "Argentina", Code = "AR" };
    public static readonly Country Switzerland = new() { Name = "Switzerland", Code = "CH" };

    public static readonly List<Country> Countries = [US, Canada, Brazil, Argentina, Switzerland];

    public static readonly List<Tag> Tags =
    [
        new() {
            Id = 1,
            Name = "Tag 1",
            LanguageCode = Spanish.Code,
        },
        new() {
            Id = 2,
            Name = "Tag 2",
            LanguageCode = Spanish.Code,
        },
        new() {
            Id = 3,
            Name = "Tag 3",
            LanguageCode = Spanish.Code,
        },
        new() {
            Id = 4,
            Name = "Tag 4",
            LanguageCode = Spanish.Code,
        },
    ];

    public static List<Article> SeedArticles(int count = 90)
    {
        var random = new Random();
        var articles = new List<Article>();
        var loopOffset = articles.Count + 5;
        for (var i = loopOffset; i <= count + loopOffset; i++)
        {
            var randomLanguage = Languages[random.Next(Languages.Count)];
            var randomCountry = random.Next(0, 2) == 0 ? null : Countries[random.Next(Countries.Count)];
            var tags = Enumerable.Range(10, random.Next(5)).ToList().ConvertAll(tagCount => new Tag
            {
                Id = Convert.ToInt32($"{i}{tagCount}"),
                Name = $"Article {tagCount}, Tag {tagCount}, lang {randomLanguage.Code}",
                LanguageCode = randomLanguage.Code,
            });
            var categories = Enumerable.Range(1, random.Next(5)).ToList().ConvertAll(catCount => new Category
            {
                Id = Convert.ToInt32($"{i}{catCount}"),
                Name = $"Article {catCount}, Category {catCount}, lang {randomLanguage.Code}",
                LanguageCode = randomLanguage.Code,
                ImageUrl = $"https://example.com/article{i}/category{catCount}.jpg",
            });
            var title = $"Article {i}: {randomLanguage.Name} Language and {randomCountry?.Name ?? "No"} Country";

            var article = new Article
            {
                Id = i,
                Title = title,
                AuthorName = $"Author {i}",
                OriginalArticleUrl = $"https://example.com/article{i}",
                ThumbnailUrl = $"https://example.com/article{i}/thumbnail.jpg",
                Language = randomLanguage,
                LanguageCode = randomLanguage.Code,
                Country = randomCountry,
                Tags = tags,
                Categories = categories,
                Components = GenerateRandomComponents(i),
            };

            articles.Add(article);
        }

        return articles;
    }

    private static List<ArticleComponent> GenerateRandomComponents(int articleId)
    {
        var random = new Random();
        var components = new List<ArticleComponent>();

        // Add 1-4 HTML components
        for (var i = 0; i < random.Next(1, 4); i++)
        {
            components.Add(new HtmlComponent
            {
                Position = i + 1,
                Html = $"<p>This is HTML content for article {articleId}, component {i + 1}</p>"
            });
        }

        // Optionally add an image or video component
        if (random.Next(0, 2) == 0) // 50% chance for image
        {
            components.Add(new ImageComponent
            {
                Position = components.Count + 1,
                Url = $"https://example.com/article{articleId}/image.jpg"
            });
        }
        else // 50% chance for video
        {
            components.Add(new VideoComponent
            {
                Position = components.Count + 1,
                Url = $"https://example.com/article{articleId}/video.mp4"
            });
        }

        return components;
    }

    public static readonly List<Category> Categories =
    [
        new()
        {
            Id = 1,
            Name = "Cat 1",
            ImageUrl = "https://test.com/cat1.jpg",
            LanguageCode = Spanish.Code,
        },
        new()
        {
            Id = 2,
            Name = "Cat 2",
            ImageUrl = "https://test.com/cat2.jpg",
            LanguageCode = Spanish.Code,
        },
        new()
        {
            Id = 3,
            Name = "Cat 3 FR",
            ImageUrl = "https://test.com/cat3.jpg",
            LanguageCode = French.Code,
        },
        new()
        {
            Id = 3,
            Name = "Cat 3 ES",
            ImageUrl = "https://test.com/cat3.jpg",
            LanguageCode = Spanish.Code,
        },
        new()
        {
            Id = 3,
            Name = "Cat 3 IT",
            ImageUrl = "https://test.com/cat3.jpg",
            LanguageCode = Italian.Code,
        },
        new()
        {
            Id = 4,
            Name = "Cat 4",
            ImageUrl = "https://test.com/cat4.jpg",
            LanguageCode = Spanish.Code,
        },
    ];

    public static readonly List<Article> Articles =
    [
        new() {
            Id = 1,
            Title = "Seeded 1: Language: Spanish, Country: Argentina",
            AuthorName = "Author",
            OriginalArticleUrl = "https://test.com",
            ThumbnailUrl = "https://test.com",
            Tags = [..Tags.GetRange(0, 2)],
            Categories = [..Categories.TakeLast(1).ToList()],
            Country = Argentina,
            Language = Spanish,
            LanguageCode = Spanish.Code,
        },
        new() {
            Id = 2,
            Title = "Seeded 2: CH Country, IT Lang",
            AuthorName = "Test Content",
            ThumbnailUrl = "https://test.com",
            OriginalArticleUrl = "https://test.com",
            Tags = [
                new Tag
                {
                    Id = 55,
                    Name = "Article ID: 1, Tag 1, lang IT",
                    LanguageCode = "IT",
                },
                new Tag
                {
                    Id = 55,
                    Name = "Article ID: 1, Tag 1, lang DE",
                    LanguageCode = "DE",
                },
                new Tag
                {
                    Id = 55,
                    Name = "Article ID: 1, Tag 1, lang FR",
                    LanguageCode = "FR",
                },
            ],
            Country = Switzerland,
            Components =  [
                new HtmlComponent
                {
                    Position = 1,
                    Html = "HTML Content",
                },
                new HtmlComponent
                {
                    Position = 2,
                    Html = "HTML Content",
                },
                new ImageComponent
                {
                    Position = 4,
                    Url = "https://test.com/image_it.jpg",
                },
                new VideoComponent {
                    Position = 5,
                    Url = "https://test.com/video_it.mp4",
                },
            ],
            Language = Italian,
            LanguageCode = Italian.Code,
        },
        new() {
            Id = 2,
            Title = "Seeded 2: CH Country, FR Lang",
            AuthorName = "Test Content",
            ThumbnailUrl = "https://test.com",
            OriginalArticleUrl = "https://test.com",
            Country = Switzerland,
            Language = French,
            LanguageCode = French.Code,
        },
        new() {
            Id = 2,
            Title = "Seeded 2: CH Country, DE Lang",
            AuthorName = "Test Content",
            OriginalArticleUrl = "https://test.com",
            ThumbnailUrl = "https://test.com",
            Country = Switzerland,
            Language = German,
            LanguageCode = German.Code,
        },
        new() {
            Id = 3,
            Title = "Seeded 3: Spanish country, Spanish language",
            AuthorName = "Test Content",
            OriginalArticleUrl = "https://test.com",
            ThumbnailUrl = "https://test.com",
            Country = US,
            Language = Spanish,
            LanguageCode = Spanish.Code,
        },
        new() {
            Id = 4,
            Title = "Seeded 4: NO country, Spanish language",
            AuthorName = "Test Content",
            OriginalArticleUrl = "https://test.com",
            ThumbnailUrl = "https://test.com",
            Language = Spanish,
            LanguageCode = Spanish.Code,
        },
    ];

    public static Article RandomArticle => Articles[new Random().Next(Articles.Count)];
    public static string RandomCountryCode => Countries[new Random().Next(Countries.Count)].Code;

    public static string RandomLanguageCode =>Languages[new Random().Next(Languages.Count)].Code;
}
