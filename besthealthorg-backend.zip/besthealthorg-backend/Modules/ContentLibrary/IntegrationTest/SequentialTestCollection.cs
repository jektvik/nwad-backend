using Xunit;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.IntegrationTest;

[CollectionDefinition("SequentialTestCollection")]
public class SequentialTestCollection : ICollectionFixture<TestDatabaseFixture>
{
    // This class has no code and is used only to define the collection.
}
