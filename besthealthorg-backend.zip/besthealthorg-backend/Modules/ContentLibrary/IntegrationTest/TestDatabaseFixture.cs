using Microsoft.EntityFrameworkCore;
using Testcontainers.SqlEdge;
using Xunit;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.IntegrationTest;

public class TestDatabaseFixture: IAsyncLifetime
{
    private static readonly object Lock = new();
    private static bool _databaseInitialized;

    private static readonly SqlEdgeContainer TestSqlDatabase = CreateTestSqlDatabase();
    private static async Task StartTestSqlDatabase() => await TestSqlDatabase.StartAsync();

    private static string SqlDbConnectionString => TestSqlDatabase.GetConnectionString();

    public TestDatabaseFixture()
    {
    }

    private static async Task StartTestContainers()
    {
        await StartTestSqlDatabase();
    }

    private static SqlEdgeContainer CreateTestSqlDatabase()
    {
        return new SqlEdgeBuilder()
            .WithImage("mcr.microsoft.com/azure-sql-edge:latest")
            .Build();
    }

    public static ContentLibraryTestDbContext CreateContext(bool beginTransaction = false)
    {
        var context = new ContentLibraryTestDbContext(new DbContextOptionsBuilder<ContentLibraryTestDbContext>()
            .UseSqlServer(SqlDbConnectionString)
            .EnableSensitiveDataLogging()
            .Options);

        if (beginTransaction)
        {
            context.Database.BeginTransaction();
        }

        return context;
    }

    /// <summary>
    /// Clears the database and seeds initial data.
    /// </summary>
    private void SeedDatabase()
    {
        using var context = CreateContext();

        // Clear the database by deleting all existing records
        ClearDatabase(context);

        // Seed initial data
        context.ContentCountries.AddRange(FakeData.Countries);
        context.ContentLanguages.AddRange(FakeData.Languages);
        context.ContentTags.AddRange(FakeData.Tags);
        context.ContentCategories.AddRange(FakeData.Categories);
        context.ContentArticles.AddRange(FakeData.Articles);
        context.ContentArticles.AddRange(FakeData.SeedArticles());
        context.SaveChanges();
        context.ChangeTracker.Clear();
    }

    /// <summary>
    /// Clears all the tables in the database.
    /// </summary>
    private void ClearDatabase(ContentLibraryTestDbContext context)
    {
        context.ContentArticles.ExecuteDelete();  // Deletes all records in the ContentArticles table
        context.ContentLanguages.ExecuteDelete();        // Deletes all records in the Languages table
        context.ContentTags.ExecuteDelete();             // Deletes all records in the Tags table
        context.ContentCountries.ExecuteDelete();        // Deletes all records in the Countries table
        context.ContentCategories.ExecuteDelete();          // Deletes all records in the Filters table
    }

    public async Task InitializeAsync()
    {
        await StartTestContainers();

        lock (Lock)
        {
            if (_databaseInitialized) return;
            using var context = CreateContext();
            context.Database.EnsureCreated();

            // Initialize and seed the database on the first run
            SeedDatabase();

            _databaseInitialized = true;
        }
    }

    public Task DisposeAsync()
    {
        return Task.CompletedTask;
    }
}
