using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Xunit;
// ReSharper disable MethodHasAsyncOverload

namespace NwadHealth.Besthealthorg.ContentLibraryModule.IntegrationTest;

public class CountryRepositoryTests : IClassFixture<TestDatabaseFixture>
{
    private readonly ContentLibraryTestDbContext _context;
    private readonly CountryRepository _repository;

    public CountryRepositoryTests()
    {
        _context = TestDatabaseFixture.CreateContext();
        _repository = new CountryRepository(_context);
    }

    [Fact]
    public async Task CreateCountry_WithLanguages_ShouldPersistLanguagesWithCountry()
    {
        // Start transaction
        await using var transaction = await _context.Database.BeginTransactionAsync();

        var existingLanguage = _context.ContentLanguages
            .AsNoTracking()
            .First();

        // Arrange
        var country = new Country() { Name = "Spain", Code = "ES", Languages = [existingLanguage] };

        // Act
        var createdCountry = await _repository.Create(country);
        _context.ChangeTracker.Clear();

        // Assert
        var fetchedCountry = await _repository.Get(createdCountry.Code);
        AssertCountriesEqual(country, fetchedCountry);

        Assert.Single(fetchedCountry!.Languages);
        Assert.Contains(fetchedCountry.Languages, l => l.Code == existingLanguage.Code);
    }

    [Fact]
    public async Task UpdateCountry_UpdateNameAndAddNewLanguage_ShouldPersistNewLanguageAndUpdateCountry()
    {
        // Start transaction
        await using var transaction = await _context.Database.BeginTransactionAsync();

        // Arrange
        var country = await _repository.Get(FakeData.RandomCountryCode);
        Assert.NotNull(country);

        var newLanguage = new Language { Name = "Catalan", Code = "CA" };
        country.Languages.Add(newLanguage);

        const string newCountryName = "monkaS";
        country.Name = newCountryName;

        // Act
        await _repository.Update(country.Code, country);
        _context.ChangeTracker.Clear();

        // Assert
        var updatedCountry = await _repository.Get(country.Code);
        Assert.NotNull(updatedCountry);
        Assert.Equal(newCountryName, updatedCountry.Name);
        Assert.Contains(updatedCountry.Languages, l => l.Code == newLanguage.Code);

        var createdLanguage = _context.ContentLanguages
            .AsNoTracking()
            .First(l => l.Code == newLanguage.Code);

        Assert.NotNull(createdLanguage);
        Assert.Equal(newLanguage.Code, createdLanguage.Code);
    }

    [Fact]
    public async Task DeleteCountry_WithLanguage_ShouldOnlyDeleteCountry()
    {
        var newLanguage = new Language { Name = "New Language", Code = "NL" };
        var newCountry = new Country { Name = "New Country", Code = "NC", Languages = [newLanguage] };

        await _repository.Create(newCountry);

        var createdCountry = await _repository.Get(newCountry.Code);
        Assert.NotNull(createdCountry);

        var deleteCount = await _repository.Delete(createdCountry.Code);
        Assert.Equal(1, deleteCount);

        var deletedCountry = await _repository.Get(newCountry.Code);
        Assert.Null(deletedCountry);

        var language = _context.ContentLanguages.Find(newLanguage.Code);
        Assert.NotNull(language);
    }

    private static void AssertCountriesEqual(Country expected, Country? actual)
    {
        Assert.NotNull(actual);
        Assert.Equal(expected.Name, actual.Name);
        Assert.Equal(expected.Code, actual.Code);
        Assert.Equal(expected.Languages.Count, actual.Languages.Count);
    }
}
