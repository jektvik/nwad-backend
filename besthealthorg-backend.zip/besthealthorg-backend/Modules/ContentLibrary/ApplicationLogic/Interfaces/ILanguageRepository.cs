using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;

/// <summary>
/// Interface for Language repository operations.
/// </summary>
public interface ILanguageRepository
{
    /// <summary>
    /// Creates a new Language.
    /// </summary>
    /// <param name="language">The Language to create.</param>
    /// <returns>The created Language</returns>
    Task<Language> Create(Language language);

    /// <summary>
    /// Retrieves a Language by its language code.
    /// </summary>
    /// <param name="languageCode">The language code of the Language to retrieve.</param>
    /// <returns>The Language with the specified code, or null if not found.</returns>
    Task<Language?> Get(string languageCode);

    /// <summary>
    /// Updates an existing Language.
    /// </summary>
    /// <param name="languageCode">The language code of the Language to update.</param>
    /// <param name="language">The updated Language data.</param>
    /// <returns>The updated Language.</returns>
    Task<Language> Update(string languageCode, Language language);

    /// <summary>
    /// Deletes a Language by its language code.
    /// </summary>
    /// <param name="languageCode">The language code of the Language to delete.</param>
    Task<int> Delete(string languageCode);
}
