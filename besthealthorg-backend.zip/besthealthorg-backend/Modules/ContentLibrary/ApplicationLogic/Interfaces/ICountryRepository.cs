using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;

/// <summary>
/// Interface for Country repository operations.
/// </summary>
public interface ICountryRepository
{
    /// <summary>
    /// Creates a new Country.
    /// </summary>
    /// <param name="country">The Country to create.</param>
    /// <returns>The created Country</returns>
    Task<Country> Create(Country country);

    /// <summary>
    /// Retrieves a Country by its code.
    /// </summary>
    /// <param name="countryCode">The country code of the Country to retrieve.</param>
    /// <returns>The Country with the specified ID, or null if not found.</returns>
    Task<Country?> Get(string countryCode);

    /// <summary>
    /// Updates an existing Country.
    /// </summary>
    /// <param name="countryCode">The country code of the Country to update.</param>
    /// <param name="country">The updated Country data.</param>
    /// <returns>The updated country</returns>
    Task<Country> Update(string countryCode, Country country);

    /// <summary>
    /// Deletes a Country by its ID.
    /// </summary>
    /// <param name="countryCode">The country code of the Country to delete.</param>
    Task<int> Delete(string countryCode);
}
