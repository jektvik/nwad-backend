using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;

/// <summary>
/// Interface for Category repository operations.
/// </summary>
public interface ICategoryRepository
{
    /// <summary>
    /// Creates a new Category.
    /// </summary>
    /// <param name="category">The category to be created.</param>
    /// <remarks>
    /// Combines the existing translations from <paramref name="category"/> with the optional <paramref name="translations"/> parameter.
    /// Translations are added uniquely based on the <c>LanguageCode</c> to ensure no duplicates.
    /// </remarks>
    /// <returns>The created <see cref="Category"/>.</returns>
    Task<Category> Create(Category category);

    /// <summary>
    /// Retrieves a Category by its ID.
    /// </summary>
    /// <param name="id">The ID of the Category to retrieve.</param>
    /// <param name="languageCode">The language code of the Category to retrieve.</param>
    /// <returns>The Category with the specified ID, or null if not found.</returns>
    Task<Category?> Get(int id, string languageCode);

    /// <summary>
    /// Retrieves all Categories for a given language code.
    /// </summary>
    Task<List<Category>> GetAll(string languageCode);

    /// <summary>
    /// Updates an existing Category.
    /// </summary>
    /// <param name="category">The Category to update.</param>
    /// <returns>The updated Category</returns>
    Task<Category> Update(Category category);

    /// <summary>
    /// Deletes a Category by its ID.
    /// </summary>
    /// <param name="id">The ID of the Category to delete.</param>
    /// <param name="languageCode">Optional. The language code of the category to delete.</param>
    Task<int> Delete(int id, string? languageCode = null);
}
