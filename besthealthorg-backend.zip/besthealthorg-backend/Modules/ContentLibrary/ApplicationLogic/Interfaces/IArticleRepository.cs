using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;

/// <summary>
/// Interface for Article repository operations.
/// </summary>
public interface IArticleRepository
{
    /// <summary>
    /// Creates a new Article.
    /// </summary>
    /// <param name="article">The article to be created.</param>
    /// <returns>The created <see cref="Article"/>.</returns>
    Task<Article> Create(Article article);

    /// <summary>
    /// Updates an existing article with new values and saves the changes to the database.
    /// </summary>
    /// <param name="article">The article entity with updated values.</param>
    /// <exception cref="InvalidOperationException">If the article does not exist</exception>
    /// <returns>The updated article</returns>
    Task<Article> Update(Article article);

    /// <summary>
    /// Retrieves an article from the database by its ID.
    /// </summary>
    /// <param name="id">The ID of the article to retrieve.</param>
    /// <param name="languageCode">The language code of the article to retrieve</param>
    /// <returns>The article entity if found, or null if not found.</returns>
    Task<Article?> Get(int id, string languageCode);

    /// <summary>
    /// Retrieves all articles from the database that match the specified country and language filters.
    /// Returns global articles (those with no associated country) that match the provided language,
    /// and country-specific articles that match both the provided country and language.
    /// </summary>
    /// <param name="paginationRequest">The pagination parameters</param>
    /// <param name="sortRequest">The sorting parameters</param>
    /// <param name="articleFilters">The filters to apply</param>
    /// <returns>A list of articles that are either global (with no associated country) or match the specified country and language combination.</returns>
    Task<PaginatedItems<Article>> GetAll(
        PaginationRequest paginationRequest,
        SortRequest sortRequest,
        ArticleFilters articleFilters);

    /// <summary>
    /// Retrieves all articles from the database that match the specified language and country codes.
    /// </summary>
    Task<List<Article>> GetAll(string languageCode, string countryCode);

    /// <summary>
    /// Deletes an article from the database by its ID.
    /// </summary>
    /// <param name="id">The ID of the article to delete.</param>
    /// <param name="languageCode">Optional. The language code of the article to delete.</param>
    Task<int> Delete(int id, string? languageCode);
}
