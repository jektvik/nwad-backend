using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;

/// <summary>
/// Interface for Tag repository operations.
/// </summary>
public interface ITagRepository
{
    /// <summary>
    /// Creates a new Tag.
    /// </summary>
    /// <param name="tag">The Tag to create.</param>
    /// <returns>The created tag</returns>
    Task<Tag> Create(Tag tag);

    /// <summary>
    /// Retrieves a Tag by its ID.
    /// </summary>
    /// <param name="id">The ID of the Tag to retrieve.</param>
    /// <param name="languageCode">The language code of the Tag to retrieve.</param>
    /// <returns>The Tag with the specified ID, or null if not found.</returns>
    Task<Tag?> Get(int id, string languageCode);

    /// <summary>
    /// Retrieves all tags for a given language code.
    /// </summary>
    Task<List<Tag>> GetAll(string languageCode);

    /// <summary>
    /// Updates an existing Tag.
    /// </summary>
    /// <param name="tag">The updated Tag data.</param>
    /// <returns>The updated tag</returns>
    Task<Tag> Update(Tag tag);

    /// <summary>
    /// Deletes a Tag by its ID.
    /// </summary>
    /// <param name="id">The ID of the Tag to delete.</param>
    /// <param name="languageCode">Optional. The language code of the tag to delete.</param>
    Task<int> Delete(int id, string? languageCode = null);
}
