namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic;

/// <summary>
/// Represents filters for articles.
/// </summary>
public class ArticleFilters
{
    /// <summary>
    /// The keyword to search in the article title.
    /// </summary>
    public string? Keyword { get; set; }

    /// <summary>
    /// List of category IDs to filter the articles by.
    /// </summary>
    public ICollection<int> CategoryIds { get; set; } = [];

    /// <summary>
    /// List of tag IDs to filter the articles by.
    /// </summary>
    public ICollection<int> TagIds { get; set; } = [];

    /// <summary>
    /// The language code to filter the articles by.
    /// </summary>
    public required string LanguageCode { get; init; }

    /// <summary>
    /// The country code to filter the articles by.
    /// </summary>
    public string? CountryCode { get; set; }

    public override string ToString()
    {
        return "ArticleFilter{" +
               $"Keyword='{Keyword}', " +
               $"CategoryIds={CategoryIds}, " +
               $"TagIds={TagIds}, " +
               $"LanguageCode='{LanguageCode}', " +
               $"CountryCode='{CountryCode}'" +
               "}";
    }
}
