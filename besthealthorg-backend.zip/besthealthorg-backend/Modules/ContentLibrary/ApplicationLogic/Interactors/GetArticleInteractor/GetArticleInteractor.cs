using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors;

/// <inheritdoc />
public class GetArticleInteractor(IArticleRepository repository): IGetArticleInteractor
{
    public async Task<Article?> Execute(int articleId, string languageCode)
    {
        return await repository.Get(articleId, languageCode);
    }
}
