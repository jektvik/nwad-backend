using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors;

/// <summary>
/// The interface representing the business logic of fetching an article
/// </summary>
public interface IGetArticleInteractor
{
    /// <summary>
    /// Attempts to fetch an article from the data store
    /// </summary>
    /// <returns>The article or null if it was not found</returns>
    Task<Article?> Execute(int articleId, string languageCode);
}
