using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetCategoriesInteractor;

/// <summary>
/// Interface for fetching all categories based on a language code.
/// </summary>
public interface IGetCategoriesInteractor
{
    /// <summary>
    /// Fetches a list of categories for the specified language code.
    /// </summary>
    /// <param name="languageCode">The language code used to filter the categories.</param>
    /// <returns>A task containing a list of categories.</returns>
    Task<List<Category>> Execute(string languageCode);
}
