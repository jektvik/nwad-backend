using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetCategoriesInteractor;

/// <inheritdoc />
public class GetCategoriesInteractor(ICategoryRepository categoryRepository): IGetCategoriesInteractor
{
    /// <inheritdoc />
    public async Task<List<Category>> Execute(string languageCode)
    {
        return await categoryRepository.GetAll(languageCode);
    }
}
