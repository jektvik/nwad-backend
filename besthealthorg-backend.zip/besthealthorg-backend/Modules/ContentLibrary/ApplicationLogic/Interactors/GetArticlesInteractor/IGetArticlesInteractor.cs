using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetArticlesInteractor;

/// <summary>
/// Interactor for fetching paginated articles with filters and sorting options.
/// </summary>
public interface IGetArticlesInteractor
{
    /// <summary>
    /// Retrieves paginated articles with optional sorting and filtering.
    /// </summary>
    /// <param name="paginationRequest">The pagination request to control page size and index.</param>
    /// <param name="userId">The ID of the user whose country code will be used as a filter for the articles.</param>
    /// <param name="sortRequest">An optional sorting request. Defaults to sorting by "title" <see cref="SortOrder.Asc"/> if not provided.</param>
    /// <param name="articleFilters">The article filter to apply. The country filter will be overridden with the user's country code.</param>
    /// <returns>A paginated list of articles that match the applied filters and sorting criteria.</returns>
    Task<PaginatedItems<Article>> GetArticlesAsync(
        PaginationRequest paginationRequest,
        string userId,
        SortRequest? sortRequest,
        ArticleFilters articleFilters);
}
