using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.Foundation.Exceptions;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetArticlesInteractor;

/// <inheritdoc />
public class GetArticlesInteractor(
    IArticleRepository articleRepository,
    IGetIdentityPropertiesInteractor getIdentityPropertiesInteractor): IGetArticlesInteractor
{
    private static readonly SortRequest DefaultSortRequest = new("title");

    /// <inheritdoc />
    public async Task<PaginatedItems<Article>> GetArticlesAsync(
        PaginationRequest paginationRequest,
        string userId,
        SortRequest? sortRequest,
        ArticleFilters articleFilters)
    {
        var identityProperties = await getIdentityPropertiesInteractor.Execute(userId);

        var userCountryCode = identityProperties?.CountryCode;

        if (userCountryCode is null)
        {
            throw new CountryCodeNotSetException();
        }

        articleFilters.CountryCode = userCountryCode;

        return await articleRepository.GetAll(
            paginationRequest: paginationRequest,
            sortRequest: sortRequest ?? DefaultSortRequest,
            articleFilters: articleFilters
        );
    }
}
