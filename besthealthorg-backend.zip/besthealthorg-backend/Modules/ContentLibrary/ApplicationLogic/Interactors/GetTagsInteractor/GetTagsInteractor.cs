using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetTagsInteractor;

/// <inheritdoc />
public class GetTagsInteractor(ITagRepository tagRepository): IGetTagsInteractor
{
    /// <inheritdoc />
    public Task<List<Tag>> Execute(string languageCode)
    {
        return tagRepository.GetAll(languageCode);
    }
}
