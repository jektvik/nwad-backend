using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetTagsInteractor;

/// <summary>
/// Interface for fetching all tags based on a language code.
/// </summary>
public interface IGetTagsInteractor
{
    /// <summary>
    /// Fetches a list of tags for the specified language code.
    /// </summary>
    /// <param name="languageCode">The language code used to filter the tags.</param>
    /// <returns>A task containing a list of tags.</returns>
    Task<List<Tag>> Execute(string languageCode);
}
