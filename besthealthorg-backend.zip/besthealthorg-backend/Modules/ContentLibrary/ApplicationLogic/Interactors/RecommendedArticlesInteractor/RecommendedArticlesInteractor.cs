using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.Foundation.Exceptions;
using NwadHealth.Besthealthorg.Foundation.Extensions.Controller;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using static NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ContentLibraryConfiguration;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.RecommendedArticlesInteractor;

/// <summary>
/// Responsible for fetching recommended articles.
/// </summary>
/// <param name="articleRepository">Repository used for fetching articles from the database.</param>
/// <param name="identityPropertiesInteractor">Interactor used to retrieve user identity properties.</param>
/// <param name="selector">Delegate function responsible for selecting recommended articles from a list.</param>
/// <param name="scopeFactory">Service scope factory for managing the scope of dependencies.</param>
public class RecommendedArticlesInteractor(
    IArticleRepository articleRepository,
    IGetIdentityPropertiesInteractor identityPropertiesInteractor,
    RecommendedArticleSelector selector,
    IServiceScopeFactory scopeFactory): IRecommendedArticlesInteractor
{
    /// <summary>
    /// Executes the logic for fetching recommended articles based on the user's identity and country code.
    /// </summary>
    /// <param name="httpContext">The current HTTP context, used to retrieve the user's identity information.</param>
    /// <param name="languageCode">The language code to filter the articles.</param>
    /// <returns>A list of recommended articles for the user.</returns>
    /// <exception cref="CountryCodeNotSetException">Thrown when the user's country code is not set.</exception>
    public async Task<IEnumerable<Article>> Execute(HttpContext httpContext, string languageCode)
    {
        var identityProperties = await identityPropertiesInteractor.Execute(httpContext.CurrentIdentityId());

        var userCountryCode = identityProperties?.CountryCode;

        if (userCountryCode is null)
        {
            throw new CountryCodeNotSetException();
        }

        var articles = await articleRepository.GetAll(languageCode, userCountryCode);

        return selector(articles, scopeFactory, httpContext);
    }
}
