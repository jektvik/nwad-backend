using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Microsoft.AspNetCore.Http;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.RecommendedArticlesInteractor;

/// <summary>
/// Interactor responsible for fetching recommended articles.
/// </summary>
public interface IRecommendedArticlesInteractor
{
    Task<IEnumerable<Article>> Execute(HttpContext httpContext, string languageCode);
}
