using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;
using NwadHealth.Besthealthorg.ContentLibraryModule.Cms.NotificationHandlers;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Umbraco.Cms.Core.Notifications;
using Umbraco.Cms.Core.Services;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms;

/// <summary>
/// Contains extensions for configuring the Umbraco part of the ContentLibraryModule
/// </summary>
public static class ContentLibraryCmsExtensions
{
    /// <summary>
    /// Configures BESTHEALTHORG component mapping for Umbraco.
    /// </summary>
    /// <typeparam name="TDbContext">The type of the DBContext</typeparam>
    /// <param name="builder">The Umbraco builder being extended</param>
    /// <param name="configure">Function used for registering mapping of article components</param>
    public static IUmbracoBuilder AddPaceContentMapping<TDbContext>(this IUmbracoBuilder builder, Action<IArticleComponentMapperConfiguration>? configure = null)
        where TDbContext : DbContext, IContentLibraryDbContext
    {
        var componentManager = new ArticleComponentManager();

        componentManager.RegisterComponent(ContentTypeAlias.ArticleHtmlComponent, ArticleComponentMappers.MapArticleHtmlComponent);
        componentManager.RegisterComponent(ContentTypeAlias.ArticleImageComponent, ArticleComponentMappers.MapArticleImageComponent);
        componentManager.RegisterComponent(ContentTypeAlias.ArticleVideoComponent, ArticleComponentMappers.MapArticleVideoComponent);

        if (configure is not null)
        {
            configure(componentManager);
        }

        builder.Services.AddSingleton<ArticleComponentManager>(componentManager);
        builder.Services.AddSingleton<IArticleComponentMapper>(p => p.GetRequiredService<ArticleComponentManager>());
        builder.Services.AddSingleton<IArticleComponentMapperConfiguration>(x => x.GetRequiredService<ArticleComponentManager>());
        builder.Services.AddSingleton<IContentMapperHelper, ContentMapperHelper>();
        builder.Services.AddScoped<IContentMapper, ContentMapper>();

        builder.Services.AddScoped<IContentLibraryDbContext>(provider => provider.GetRequiredService<TDbContext>());
        builder.Services.AddScoped<ICountryRepository, CountryRepository>();
        builder.Services.AddScoped<ILanguageRepository, LanguageRepository>();
        builder.Services.AddScoped<ITagRepository, TagRepository>();
        builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();
        builder.Services.AddScoped<IArticleRepository, ArticleRepository>();

        builder
            .AddNotificationAsyncHandler<LanguageSavedNotification, LanguageSavedNotificationHandler>()
            .AddNotificationAsyncHandler<LanguageDeletingNotification, LanguageDeletingNotificationHandler>()
            .AddNotificationAsyncHandler<ContentPublishingNotification, ContentPublishingNotificationHandler>()
            .AddNotificationAsyncHandler<ContentUnpublishingNotification, ContentUnpublishingNotificationHandler>();

        return builder;
    }

    /// <summary>
    /// Adds the Umbraco languages that are currently not in the content database to the content database
    /// </summary>
    /// <param name="app">The web application being extended</param>
    public static async Task AddMissingLanguages(this WebApplication app)
    {
        using var scope = app.Services.CreateScope();

        var services = scope.ServiceProvider;
        var languageService = services.GetRequiredService<ILanguageService>();
        var languageRepository = services.GetRequiredService<ILanguageRepository>();

        var languages = await languageService.GetAllAsync();

        foreach (var language in languages)
        {
            var code = language.IsoCode.Substring(0, 2);
            var existingLanguage = await languageRepository.Get(code);

            if (existingLanguage is not null)
            {
                continue;
            }

            await languageRepository.Create(new() { Name = language.CultureName, Code = code });
        }
    }
}
