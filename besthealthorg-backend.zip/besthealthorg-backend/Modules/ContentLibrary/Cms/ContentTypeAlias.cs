namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms;

/// <summary>
/// Contains aliases for different content types defined in Umbraco
/// </summary>
public static class ContentTypeAlias
{
    public const string Country = "country";

    public const string Article = "article";
    public const string ArticleTag = "articleTag";
    public const string ArticleCategory = "articleCategory";

    public const string ArticleHtmlComponent = "articleHtmlComponent";
    public const string ArticleImageComponent = "articleImageComponent";
    public const string ArticleVideoComponent = "articleVideoComponent";
}
