using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;
using Umbraco.Cms.Core.Events;
using Umbraco.Cms.Core.Models;
using Umbraco.Cms.Core.Notifications;
using Umbraco.Cms.Core.Services;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.NotificationHandlers;

/// <summary>
/// Notification handler responsible for deleting content that is being unpublished from the content database
/// </summary>
/// <remarks>
/// Despite this being a "ContentUnpublished" notification handler, Umbraco instead invokes the "ContentPublished" handler when variant content is being unpublished.
/// This means that this notification handler only handles unpublishing of invariant content.
/// </remarks>
public class ContentUnpublishingNotificationHandler : INotificationAsyncHandler<ContentUnpublishingNotification>
{
    private readonly IContentService _contentService;
    private readonly IContentTypeService _contentTypeService;
    private readonly IContentMapper _contentMapper;
    private readonly ICountryRepository _countryRepository;

    public ContentUnpublishingNotificationHandler(
        IContentService contentService,
        IContentTypeService contentTypeService,
        IContentMapper contentMapper,
        ICountryRepository countryRepository)
    {
        _contentService = contentService;
        _contentTypeService = contentTypeService;
        _contentMapper = contentMapper;
        _countryRepository = countryRepository;
    }

    /// <inheritdoc />
    public async Task HandleAsync(ContentUnpublishingNotification notification, CancellationToken cancellationToken)
    {
        foreach (var entity in notification.UnpublishedEntities)
        {
            // if there are available cultures, the content is variant and unpublished is handled in the publishing handler
            if (!ContentShouldBeSynced(entity) || entity.AvailableCultures.Any())
            {
                continue;
            }

            if (entity.ContentType.Alias == ContentTypeAlias.Country)
            {
                var country = _contentMapper.MapCountry(entity, false);
                await _countryRepository.Delete(country.Code);
            }
        }
    }

    private static readonly string[] TYPES_TO_SYNC = [
        ContentTypeAlias.Country,
        ContentTypeAlias.Article,
        ContentTypeAlias.ArticleTag,
        ContentTypeAlias.ArticleCategory
    ];

    private bool ContentShouldBeSynced(IContent content)
    {
        return TYPES_TO_SYNC.Contains(content.ContentType.Alias);
    }
}
