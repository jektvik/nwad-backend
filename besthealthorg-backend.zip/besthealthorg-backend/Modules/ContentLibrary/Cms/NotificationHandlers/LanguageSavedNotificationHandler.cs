using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Umbraco.Cms.Core.Events;
using Umbraco.Cms.Core.Notifications;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.NotificationHandlers;

/// <summary>
/// Notification handler responsible for adding languages to the content database, when they are added in Umbraco.
/// </summary>
public class LanguageSavedNotificationHandler : INotificationAsyncHandler<LanguageSavedNotification>
{
    private readonly ILanguageRepository _languageRepository;

    public LanguageSavedNotificationHandler(ILanguageRepository languageRepository)
    {
        _languageRepository = languageRepository;
    }

    public async Task HandleAsync(LanguageSavedNotification notification, CancellationToken cancellationToken)
    {
        foreach (var language in notification.SavedEntities)
        {
            await _languageRepository.Create(new Language { Name = language.CultureName, Code = language.IsoCode.Substring(0, 2) });
        }
    }
}
