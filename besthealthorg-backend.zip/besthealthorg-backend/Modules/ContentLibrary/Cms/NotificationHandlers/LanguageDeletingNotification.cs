using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using Umbraco.Cms.Core.Events;
using Umbraco.Cms.Core.Notifications;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.NotificationHandlers;

/// <summary>
/// Notification handler responsible for deleting languages from the content database, when they are removed from Umbraco.
/// </summary>
public class LanguageDeletingNotificationHandler : INotificationAsyncHandler<LanguageDeletingNotification>
{
    private readonly ILanguageRepository _languageRepository;

    public LanguageDeletingNotificationHandler(ILanguageRepository languageRepository)
    {
        _languageRepository = languageRepository;
    }

    /// <inheritdoc />
    public async Task HandleAsync(LanguageDeletingNotification notification, CancellationToken cancellationToken)
    {
        foreach (var language in notification.DeletedEntities)
        {
            await _languageRepository.Delete(language.IsoCode.Substring(0, 2));
        }
    }
}
