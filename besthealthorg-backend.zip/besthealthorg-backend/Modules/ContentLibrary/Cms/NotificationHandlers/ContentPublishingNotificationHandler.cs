using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;
using Umbraco.Cms.Core.Events;
using Umbraco.Cms.Core.Models;
using Umbraco.Cms.Core.Notifications;
using Umbraco.Cms.Core.Services;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.NotificationHandlers;

/// <summary>
/// Notification handler responsible for syncing content that is being published to the content database
/// </summary>
/// <remarks>
/// Despite this being a "ContentPublished" notification handler, Umbraco also invokes this handler when variant content is being UNpublished.
/// This means that this notification handler handles publishing of invariant content as well as publishing and unpublishing of variant content.
/// </remarks>
public class ContentPublishingNotificationHandler : INotificationAsyncHandler<ContentPublishingNotification>
{
    private readonly IContentService _contentService;
    private readonly IContentTypeService _contentTypeService;
    private readonly IContentMapper _contentMapper;
    private readonly ICountryRepository _countryRepository;
    private readonly IArticleRepository _articleRepository;
    private readonly ITagRepository _tagRepository;
    private readonly ICategoryRepository _categoryRepository;

    public ContentPublishingNotificationHandler(
        IContentService contentService,
        IContentTypeService contentTypeService,
        IContentMapper contentMapper,
        ICountryRepository countryRepository,
        IArticleRepository articleRepository,
        ITagRepository tagRepository,
        ICategoryRepository categoryRepository)
    {
        _contentService = contentService;
        _contentTypeService = contentTypeService;
        _contentMapper = contentMapper;
        _countryRepository = countryRepository;
        _articleRepository = articleRepository;
        _tagRepository = tagRepository;
        _categoryRepository = categoryRepository;
    }

    /// <inheritdoc/>
    public async Task HandleAsync(ContentPublishingNotification notification, CancellationToken cancellationToken)
    {
        foreach (var entity in notification.PublishedEntities)
        {
            if (!ContentShouldBeSynced(entity))
            {
                continue;
            }

            if (!entity.AvailableCultures.Any())
            {
                if (entity.ContentType.Alias == ContentTypeAlias.Country)
                {
                    var country = _contentMapper.MapCountry(entity, true);
                    var existing = await _countryRepository.Get(country.Code);

                    if (existing is null)
                    {
                        await _countryRepository.Create(country);
                    }
                    else
                    {
                        await _countryRepository.Update(country.Code, country);
                    }
                }
            }
            else
            {
                var unpublishedCultures = entity.AvailableCultures.Where(culture => notification.IsUnpublishingCulture(entity, culture));
                var publishedCultures = entity.AvailableCultures.Where(culture => notification.IsPublishingCulture(entity, culture));

                foreach (var culture in unpublishedCultures)
                {
                    await DeleteVariantContent(entity, culture);
                }

                foreach (var culture in publishedCultures)
                {
                    await SyncVariantContent(entity, culture);
                }
            }
        }
    }

    /// <summary>
    /// Creates or updates variant content being published
    /// </summary>
    /// <param name="entity">The Umbraco content being published</param>
    /// <param name="culture">The culture being published</param>
    private async Task SyncVariantContent(IContent entity, string culture)
    {
        switch (entity.ContentType.Alias)
        {
            case ContentTypeAlias.Article:
                var article = _contentMapper.MapArticle(entity, culture, true);
                var existingArticle = await _articleRepository.Get(article.Id, article.LanguageCode);

                if (existingArticle is null)
                {
                    await _articleRepository.Create(article);
                }
                else
                {
                    await _articleRepository.Update(article);
                }

                break;

            case ContentTypeAlias.ArticleTag:
                var tag = _contentMapper.MapArticleTag(entity, culture, true);
                var existingTag = await _tagRepository.Get(tag.Id, tag.LanguageCode);

                if (existingTag is null)
                {
                    await _tagRepository.Create(tag);
                }
                else
                {
                    await _tagRepository.Update(tag);
                }

                break;

            case ContentTypeAlias.ArticleCategory:
                var category = _contentMapper.MapArticleCategory(entity, culture, true);
                var existingCategory = await _categoryRepository.Get(category.Id, category.LanguageCode);

                if (existingCategory is null)
                {
                    await _categoryRepository.Create(category);
                }
                else
                {
                    await _categoryRepository.Update(category);
                }

                break;
        }
    }

    /// <summary>
    /// Deletes variant content being unpublished
    /// </summary>
    /// <param name="entity">The Umbraco content being unpublished</param>
    /// <param name="culture">The culture being unpublished</param>
    private async Task DeleteVariantContent(IContent entity, string culture)
    {
        switch (entity.ContentType.Alias)
        {
            case ContentTypeAlias.Article:
                var article = _contentMapper.MapArticle(entity, culture, false);
                await _articleRepository.Delete(article.Id, article.LanguageCode);
                break;

            case ContentTypeAlias.ArticleTag:
                var tag = _contentMapper.MapArticleTag(entity, culture, false);
                await _tagRepository.Delete(tag.Id, tag.LanguageCode);
                break;

            case ContentTypeAlias.ArticleCategory:
                var category = _contentMapper.MapArticleCategory(entity, culture, false);
                await _categoryRepository.Delete(category.Id, category.LanguageCode);
                break;
        }
    }

    private static readonly string[] TYPES_TO_SYNC = [
        ContentTypeAlias.Country,
        ContentTypeAlias.Article,
        ContentTypeAlias.ArticleTag,
        ContentTypeAlias.ArticleCategory
    ];

    private bool ContentShouldBeSynced(IContent content)
    {
        return TYPES_TO_SYNC.Contains(content.ContentType.Alias);
    }
}
