using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.MicrosoftAccount;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Umbraco.Cms.Api.Management.Security;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Authentication;

/// <summary>
/// Contains extensions for configuring authentication
/// </summary>
public static class AuthenticationExtensions
{
    /// <summary>
    /// Configures AzureAD authentication for the Umbraco instance
    /// </summary>
    /// <param name="builder">The Umbraco builder being extended</param>
    public static IUmbracoBuilder AddMicrosoftBackOfficeAuthentication(this IUmbracoBuilder builder)
    {
        builder.AddBackOfficeExternalLogins(loginBuilder =>
        {
            loginBuilder.AddBackOfficeLogin(authenticationBuilder =>
            {
                var scheme = BackOfficeAuthenticationBuilder.SchemeForBackOffice(MicrosoftAccountDefaults.AuthenticationScheme) ?? string.Empty;

                authenticationBuilder.AddOpenIdConnect(scheme, MicrosoftAccountDefaults.DisplayName, options =>
                {
                    var tenantId = builder.Config.GetValue<string>("AzureADConnection:TenantId");
                    options.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                    options.AuthenticationMethod = OpenIdConnectRedirectBehavior.RedirectGet;
                    options.CallbackPath = "/umbraco/";
                    options.ClientId = builder.Config.GetValue<string>("AzureADConnection:ClientId");
                    options.ClientSecret = builder.Config.GetValue<string>("AzureADConnection:ClientSecret");

                    options.Authority = $"https://login.microsoftonline.com/{tenantId}/v2.0";
                    options.ResponseType = OpenIdConnectResponseType.Code;
                    options.RequireHttpsMetadata = true;
                    options.GetClaimsFromUserInfoEndpoint = true;
                    options.SaveTokens = false;
                    options.UsePkce = true;

                    options.Scope.Add("openid");
                    options.Scope.Add("profile");
                    options.Scope.Add("offline_access");
                    options.Scope.Add("email");
                    options.ClaimActions.MapJsonKey(claimType: ClaimTypes.Email, jsonKey: "email");
                    options.ClaimActions.MapJsonKey(claimType: ClaimTypes.Role, jsonKey: "role");
                    options.ClaimActions.MapJsonKey(claimType: ClaimTypes.Name, jsonKey: "name");
                });
            });
        });

        builder.Services.ConfigureOptions<OpenIdConnectBackOfficeExternLoginProviderOptions>();

        return builder;
    }
}
