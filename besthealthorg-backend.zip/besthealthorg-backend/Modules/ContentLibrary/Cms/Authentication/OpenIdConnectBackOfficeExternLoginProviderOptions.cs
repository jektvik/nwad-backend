using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using Umbraco.Cms.Core.Security;
using Umbraco.Cms.Api.Management.Security;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Authentication;

public class OpenIdConnectBackOfficeExternLoginProviderOptions : IConfigureNamedOptions<BackOfficeExternalLoginProviderOptions>
{
    public void Configure(BackOfficeExternalLoginProviderOptions options)
    {
        options.AutoLinkOptions = new(true, allowManualLinking: false);
        options.AutoLinkOptions.OnAutoLinking += OnAutoLinking;
        options.AutoLinkOptions.OnExternalLogin += OnLogin;

        options.DenyLocalLogin = true;
    }

    public void Configure(string? name, BackOfficeExternalLoginProviderOptions options)
    {
        Configure(options);
    }

    private static void OnAutoLinking(BackOfficeIdentityUser user, ExternalLoginInfo loginInfo)
    {
        var claims = loginInfo.Principal.Claims.ToList();

        user.Name = claims.Find(p => p.Type == ClaimTypes.Name)?.Value ?? throw new("Could not find name claim");
        user.Email = claims.Find(p => p.Type == ClaimTypes.Email)?.Value ?? throw new("Could not find email claim");
        user.UserName = claims.Find(p => p.Type == ClaimTypes.Email)?.Value ?? throw new("Could not find email claim");

        user.IsApproved = true;
    }

    private static bool OnLogin(BackOfficeIdentityUser user, ExternalLoginInfo loginInfo)
    {
        var roleClaims = loginInfo.Principal.Claims.Where(claim => claim.Type == ClaimTypes.Role);

        user.Roles = new List<IdentityUserRole<string>>();

        foreach (var role in roleClaims)
        {
            user.AddRole(role.Value);

            user.Claims.Add(new IdentityUserClaim<string>
            {
                ClaimType = role.Type,
                ClaimValue = role.Value,
            });
        }

        return true;
    }
}
