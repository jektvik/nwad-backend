using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms;

#nullable disable

/// <summary>
/// Database context representing the content database, to which content is synced
/// </summary>
public class ContentDbContext : DbContext, IContentLibraryDbContext
{
    public ContentDbContext(DbContextOptions<ContentDbContext> options) : base(options)
    {
    }

    public DbSet<Article> ContentArticles { get; set; }

    public DbSet<Tag> ContentTags { get; set; }

    public DbSet<Category> ContentCategories { get; set; }

    public DbSet<Language> ContentLanguages { get; set; }

    public DbSet<Country> ContentCountries { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        (this as IContentLibraryDbContext).ConfigureDbSets(modelBuilder);
    }
}

#nullable enable
