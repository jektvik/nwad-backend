using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;

public class ArticleComponentManager : IArticleComponentMapper, IArticleComponentMapperConfiguration
{
    private readonly IDictionary<string, ComponentMapper> _mappers = new Dictionary<string, ComponentMapper>();

    /// <inheritdoc />
    public ArticleComponent MapComponent(IntermediateArticleComponent component, IServiceScope scope)
    {
        var mapper = _mappers[component.Alias] ?? throw new($"No mapper registered for alias: {component.Alias}");

        return mapper(component, scope);
    }

    /// <inheritdoc />
    public IArticleComponentMapperConfiguration RegisterComponent(string alias, ComponentMapper mapper)
    {
        _mappers[alias] = mapper;
        return this;
    }
}
