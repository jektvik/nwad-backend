using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Umbraco.Cms.Core.Models;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;

/// <summary>
/// Interface representing mapping from Umbraco content types to the ContentLibrary domain types
/// </summary>
public interface IContentMapper
{
    /// <summary>
    /// Maps IContent representing a country to a ContentLibrary Country
    /// </summary>
    /// <param name="content">The Umbraco content representing a country</param>
    /// <param name="published">Whether the content being mapped is being published or not</param>
    /// <returns>The mapped Country</param>
    Country MapCountry(IContent content, bool published);

    /// <summary>
    /// Maps IContent representing an article to a ContentLibrary Article
    /// </summary>
    /// <param name="content">The Umbraco content representing an article</param>
    /// <param name="published">Whether the content being mapped is being published or not</param>
    /// <returns>The mapped Article</param>
    Article MapArticle(IContent content, string culture, bool published);

    /// <summary>
    /// Maps IContent representing a tag to a ContentLibrary Tag
    /// </summary>
    /// <param name="content">The Umbraco content representing a tag</param>
    /// <param name="published">Whether the content being mapped is being published or not</param>
    /// <returns>The mapped Tag</param>
    Domain.Entities.Tag MapArticleTag(IContent content, string culture, bool published);

    /// <summary>
    /// Maps IContent representing a category to a ContentLibrary Category
    /// </summary>
    /// <param name="content">The Umbraco content representing a category</param>
    /// <param name="published">Whether the content being mapped is being published or not</param>
    /// <returns>The mapped Category</param>
    Category MapArticleCategory(IContent content, string culture, bool published);
}
