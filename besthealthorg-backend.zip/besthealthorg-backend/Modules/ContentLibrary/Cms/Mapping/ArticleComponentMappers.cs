using System.Text.Json.Nodes;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;

public static class ArticleComponentMappers
{
    /// <summary>
    /// Mapper for the ArticleHTMLComponent
    /// </summary>
    public static ArticleComponent MapArticleHtmlComponent(IntermediateArticleComponent comp, IServiceScope _)
    {
        var textField = comp.Content["text"]?.GetValue<string>() ?? throw new("Could not find richtext for component");
        var textContent = JsonNode.Parse(textField)?["markup"]?.GetValue<string>() ?? throw new("Could not extract markup from richtext");

        return new HtmlComponent
        {
            ArticleId = comp.ArticleId,
            ArticleLanguageCode = comp.LanguageCode,
            Position = comp.Position,
            Html = textContent
        };
    }

    /// <summary>
    /// Mapper for the ArticleImageComponent
    /// </summary>
    public static ArticleComponent MapArticleImageComponent(IntermediateArticleComponent comp, IServiceScope scope)
    {
        var mapperHelper = scope.ServiceProvider.GetRequiredService<IContentMapperHelper>();
        var image = comp.Content["image"]?.GetValue<string>() ?? throw new("Could not find url for image component");
        var imageUrl = mapperHelper.ExtractMediaUrl(image);

        return new ImageComponent
        {
            ArticleId = comp.ArticleId,
            ArticleLanguageCode = comp.LanguageCode,
            Position = comp.Position,
            Url = GetMediaBaseUrl(scope) + imageUrl
        };
    }

    /// <summary>
    /// Mapper for the ArticleVideoComponent
    /// </summary>
    public static ArticleComponent MapArticleVideoComponent(IntermediateArticleComponent comp, IServiceScope scope)
    {
        var mapperHelper = scope.ServiceProvider.GetRequiredService<IContentMapperHelper>();
        var video = comp.Content["video"]?.GetValue<string>() ?? throw new("Could not find url for video component");
        var videoUrl = mapperHelper.ExtractMediaUrl(video);

        return new VideoComponent
        {
            ArticleId = comp.ArticleId,
            ArticleLanguageCode = comp.LanguageCode,
            Position = comp.Position,
            Url = GetMediaBaseUrl(scope) + videoUrl
        };
    }

    private static string GetMediaBaseUrl(IServiceScope scope)
    {
        var config = scope.ServiceProvider.GetRequiredService<IConfiguration>();
        return config.GetValue<string>("MediaBaseUrl")?.TrimEnd("/") ?? throw new("MediaBaseUrl environment variable not set");
    }
}
