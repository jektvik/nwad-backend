using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;

/// <summary>
/// Interface representing capabilities for mapping intermediate components
/// </summary>
public interface IArticleComponentMapper
{
    /// <summary>
    /// Maps an intermediate component to an ArticleComponent
    /// </summary>
    /// <param name="component">The intemediate component to be mapped</param>
    /// <param name="scope">Service scope the mapper can use to acquire external services for the mapping</param>
    ArticleComponent MapComponent(IntermediateArticleComponent component, IServiceScope scope);
}
