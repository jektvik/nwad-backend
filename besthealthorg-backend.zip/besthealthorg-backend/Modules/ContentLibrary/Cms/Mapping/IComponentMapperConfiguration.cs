using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;

/// <summary>
/// Represents a function used for mapping an intermediate article component to an article component
/// </summary>
public delegate ArticleComponent ComponentMapper(IntermediateArticleComponent component, IServiceScope scope);

/// <summary>
/// Interface representing capabilities for registering component mapping
/// </summary>
public interface IArticleComponentMapperConfiguration
{
    /// <summary>
    /// Registers a mapper for an article component
    /// </summary>
    /// <param name="alias">The alias of the Umbraco ElementType this mapper should be registered for</param>
    /// <param name="mapper">The mapping function to register</param>
    public IArticleComponentMapperConfiguration RegisterComponent(string alias, ComponentMapper mapper);
}
