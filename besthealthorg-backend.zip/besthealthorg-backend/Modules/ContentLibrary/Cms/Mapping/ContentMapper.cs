using System.Text.Json.Nodes;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Umbraco.Cms.Core.Models;
using Umbraco.Cms.Core.Services;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;

/// <summary>
/// Implementation of mapping for Umbraco content types to ContentLibrary domain models
/// </summary>
public class ContentMapper : IContentMapper
{
    private readonly IContentService _contentService;
    private readonly IContentTypeService _contentTypeService;
    private readonly IArticleComponentMapper _articleComponentMapper;
    private readonly IContentMapperHelper _contentMapperHelper;
    private readonly IServiceProvider _serviceProvider;
    private readonly string _mediaBaseUrl;

    /// <summary>
    /// Initializes the ContentMapper
    /// </summary>
    public ContentMapper(
        IContentService contentService,
        IContentTypeService contentTypeService,
        IArticleComponentMapper articleComponentMapper,
        IServiceProvider serviceProvider,
        IConfiguration config,
        IContentMapperHelper contentMapperHelper)
    {
        _contentService = contentService;
        _contentTypeService = contentTypeService;
        _articleComponentMapper = articleComponentMapper;
        _serviceProvider = serviceProvider;
        _mediaBaseUrl = config.GetValue<string>("MediaBaseUrl")?.TrimEnd("/") ?? throw new("MediaBaseUrl environment variable not set");
        _contentMapperHelper = contentMapperHelper;
    }

    /// <inheritdoc />
    public Country MapCountry(IContent content, bool published)
    {
        var code = content.GetValue<string>("countryCode", published: published) ?? throw new("Could not find country code");
        var name = content.GetValue<string>("countryName", published: published) ?? throw new("Could not find country name");

        return new()
        {
            Code = code,
            Name = name,
        };
    }

    /// <inheritdoc />
    public Article MapArticle(IContent content, string culture, bool published)
    {
        var countryContent = _contentService.GetAncestors(content).First(ancestor => ancestor.ContentType.Alias == ContentTypeAlias.Country);
        var countryCode = countryContent.GetValue<string>("countryCode", published: published) ?? throw new("Could not find country code on ancestor");
        var title = content.GetValue<string>("title", culture, published: published) ?? throw new("Required property (title) for article not provided");
        var author = content.GetValue<string>("author", published: published) ?? throw new("Required property (author) for article not provided");
        var originalArticleUrl = content.GetValue<string>("originalArticleUrl", culture, published: published);
        var thumbnail = content.GetValue<string>("thumbnail", culture, published: published)
            ?? throw new("Required property (thumbnail) for article not provided");

        var thumbnailSrc = _contentMapperHelper.ExtractMediaUrl(thumbnail);

        var categoryUdis = content.GetValue<string>("categories", published: published)?.Split(",").Select(_contentMapperHelper.StringToGuidUdi) ?? [];
        var tagUdis = content.GetValue<string>("tags", published: published)?.Split(",").Select(_contentMapperHelper.StringToGuidUdi) ?? [];

        var componentJson = content.GetValue<string>("components", culture, published: published) ?? throw new("Could not find component data");

        var intermediateComponents = MapArticleComponents(componentJson, culture, content.Id);

        var categories = _contentService.GetByIds(categoryUdis)
            .Where(c => c.IsCulturePublished(culture))
            .Select((c) => MapArticleCategory(c, culture, published))
            .ToList();

        var tags = _contentService.GetByIds(tagUdis)
            .Where(c => c.IsCulturePublished(culture))
            .Select((t) => MapArticleTag(t, culture, published))
            .ToList();

        using var scope = _serviceProvider.CreateScope();

        return new()
        {
            Id = content.Id,
            LanguageCode = culture.Substring(0, 2),
            CountryCode = countryCode,
            Title = title,
            AuthorName = author,
            ThumbnailUrl = _mediaBaseUrl + thumbnailSrc,
            OriginalArticleUrl = originalArticleUrl,
            Categories = categories,
            Tags = tags,
            Components = intermediateComponents.Select((c) => _articleComponentMapper.MapComponent(c, scope)).ToList()
        };
    }

    /// <inheritdoc />
    public Category MapArticleCategory(IContent content, string culture, bool published)
    {
        var displayName = content.GetValue<string>("displayName", culture, published: published)
            ?? throw new("Required property (displayName) for article category not provided");

        var image = content.GetValue<string>("image", culture, published: published)
            ?? throw new("Required property (image) for article category not provided");

        return new()
        {
            Id = content.Id,
            Name = displayName,
            LanguageCode = culture.Substring(0, 2),
            ImageUrl = _mediaBaseUrl + _contentMapperHelper.ExtractMediaUrl(image)
        };
    }

    /// <inheritdoc />
    public Domain.Entities.Tag MapArticleTag(IContent content, string culture, bool published)
    {
        var displayName = content.GetValue<string>("displayName", culture, published: published)
            ?? throw new("Required property (displayName) for articleTag not provided");

        return new()
        {
            Id = content.Id,
            Name = displayName,
            LanguageCode = culture.Substring(0, 2)
        };
    }

    /// <summary>
    /// Maps the article components to their intermediate format and orders them according to order in Umbraco
    /// </summary>
    private IEnumerable<IntermediateArticleComponent> MapArticleComponents(string componentsJson, string culture, int articleId)
    {
        var parsed = JsonNode.Parse(componentsJson);

        var orderInfoLookup = parsed?["Layout"]?["Umbraco.BlockList"]
            ?.AsArray()
            ?.Select((c, i) =>
            {
                var udi = c?["contentUdi"]?.GetValue<string>() ?? throw new("Could not find matching contentUdi in blocklist");
                return (udi, i);
            })
            .ToDictionary(t => t.udi, t => t.i) ?? throw new("Could not find article components order information");

        return parsed?["contentData"]
            ?.AsArray()
            .Where((c) => c is not null)
            .Select(c => MapArticleComponent(c!, culture, articleId, orderInfoLookup[c!["udi"]!.GetValue<string>()])) ?? [];
    }

    /// <summary>
    /// Maps a single component to its intermediate format
    /// </summary>
    private IntermediateArticleComponent MapArticleComponent(JsonNode component, string culture, int articleId, int position)
    {
        var key = component["contentTypeKey"]?.GetValue<string>() ?? throw new("Could not find article component key");
        var udi = component["udi"]?.GetValue<string>() ?? throw new("Could not find article component udi");

        var contentType = _contentTypeService.Get(new Guid(key)) ?? throw new("Could not find component content type");

        return new()
        {
            Id = _contentMapperHelper.StringToGuidUdi(udi).Guid,
            Alias = contentType.Alias,
            LanguageCode = culture.Substring(0, 2),
            Content = component,
            ArticleId = articleId,
            Position = position
        };
    }
}
