using Umbraco.Cms.Core;

/// <summary>
/// Interface representing helpers used for content mapping.
/// </summary>
public interface IContentMapperHelper
{
    /// <summary>
    /// Converts a string to an Umbraco GuidUdi
    /// </summary>
    /// <param name="udiString">The string to convert</param>
    /// <returns>A GuidUdi built from the provided string</returns>
    GuidUdi StringToGuidUdi(string udiString);

    /// <summary>
    /// Extracts the relative media URL from Umbraco MediaPicker data.
    /// </summary>
    /// <param name="mediaPickerData">The media picker data to extract the media URL from</param>
    string ExtractMediaUrl(string mediaPickerData);
}
