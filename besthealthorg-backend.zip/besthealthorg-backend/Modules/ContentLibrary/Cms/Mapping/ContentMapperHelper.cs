using System.Text.Json.Nodes;
using Umbraco.Cms.Core;
using Umbraco.Cms.Core.Services;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;

/// <summary>
/// Implements helper methods for content mapping
/// </summary>
public class ContentMapperHelper : IContentMapperHelper
{
    private readonly IMediaService _mediaService;

    /// <summary>
    /// Initializes the ContentMapperHelper
    /// </summary>
    public ContentMapperHelper(IMediaService mediaService)
    {
        _mediaService = mediaService;
    }

    /// <inheritdoc />
    public GuidUdi StringToGuidUdi(string udiString)
    {
        return new(new Uri(udiString));
    }

    /// <inheritdoc />
    public string ExtractMediaUrl(string mediaPickerData)
    {
        var mediaKey = JsonNode.Parse(mediaPickerData)?.AsArray().FirstOrDefault()?["mediaKey"]?.GetValue<Guid>()
            ?? throw new("Could not extract media key");
        var media = _mediaService.GetById(mediaKey);

        var fileData = media?.GetValue<string>(Constants.Conventions.Media.File) ?? throw new("Could not find media file");

        if (media.ContentType.Alias == "Image")
        {
            return JsonNode.Parse(fileData)?["src"]?.GetValue<string>() ?? throw new("Could not find media src");
        }

        return fileData;
    }
}
