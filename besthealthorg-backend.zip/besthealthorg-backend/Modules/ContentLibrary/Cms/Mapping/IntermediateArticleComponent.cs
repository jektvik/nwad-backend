using System.Text.Json.Nodes;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;

/// <summary>
/// Represents an article component that has gone through first pass of mapping.
/// This datastructure is passed to the "ComponentMapper" to finish up mapping,
/// allowing consumers to create custom components.
/// </summary>
public class IntermediateArticleComponent
{
    public required Guid Id { get; set; }

    public required string Alias { get; set; }

    public required int Position { get; set; }

    public required int ArticleId { get; set; }

    public required string LanguageCode { get; set; }

    public required JsonNode Content { get; set; }
}
