using System.Configuration;
using NwadHealth.Besthealthorg.ContentLibraryModule.Cms;
using NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Authentication;
using NwadHealth.Besthealthorg.ContentLibraryModule.Cms.Mapping;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure;
using Microsoft.EntityFrameworkCore;

WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

var sqlConnectionString = builder.Configuration["ConnectionStrings:ContentDb"]
    ?? throw new ConfigurationErrorsException("Could not read ContentDB SQL connection string");

builder.Services.AddDbContext<ContentDbContext>(options => options.UseSqlServer(sqlConnectionString));

builder
    .CreateUmbracoBuilder()
    .AddBackOffice()
    .AddWebsite()
    .AddDeliveryApi()
    .AddComposers()
    .AddAzureBlobMediaFileSystem()
    .AddMicrosoftBackOfficeAuthentication()
    .AddPaceContentMapping<ContentDbContext>()
    .Build();

WebApplication app = builder.Build();

await app.BootUmbracoAsync();

await app.AddMissingLanguages();

app.UseUmbraco()
    .WithMiddleware(u =>
    {
        u.UseBackOffice();
        u.UseWebsite();
    })
    .WithEndpoints(u =>
    {
        u.UseBackOfficeEndpoints();
        u.UseWebsiteEndpoints();
    });

app.MapGet("/", context =>
{
    context.Response.Redirect("/umbraco");
    return Task.CompletedTask;
});

await app.RunAsync();
