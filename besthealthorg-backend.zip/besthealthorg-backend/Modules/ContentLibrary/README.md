# ContentLibraryModule

The PACE Content Library module is used for managing and serving content.
The module consists of two parts: the CMS for managing content and the backend module for serving content.

## Module setup

### General requirements

The module requires the application to have authorization enabled (ideally through the [Identity module](/Identity/README.md)).

### Required infrastructure

- Storage Account
  - One container for storing media
- SQL server 
  - One database used by the Umbraco CMS
  - One database used for storing the mapped content (can be the application db or a separate one)
- Azure App Registration for using MS sign in with Umbraco.
  - (Authentication tab) Set a web redirect URI, e.g. `https://pace-tst-cms-stable.azurewebsites.net/umbraco/`
  - (Certificates & secrets tab) Generate a client secret.
  - Add users through the enterprise application tied to the app registration.

### Module installation

Install the `NwadHealth.Pace.ContentLibraryModule` NuGet package in your application by following the [instructions](/README.md#sdk-modules) in the main README.

### CMS installation

Copy the `/ContentLibrary/Cms` folder containing the Umbraco application.

Follow step 3 of the [instructions](/README.md#template-modules) in the main README, for changing project references to package references.

### Application configuration

To configure the Content Library module in your application, when registering services call the `AddPaceContentLibrary` extension method on your service provider.
`AddPaceContentLibrary` requires an instance of [ContentLibraryConfiguration](https://effective-robot-19m1v3p.pages.github.io/classNwadHealth_1_1Pace_1_1ContentLibraryModule_1_1Domain_1_1Entities_1_1ContentLibraryConfiguration.html).

Optional configuration

| Property                      | Purpose                                                                                 | Default                 |
|-------------------------------|-----------------------------------------------------------------------------------------|-------------------------|
| `RecommendedArticlesSelector` | Function for selecting the articles to be returned by the recommended articles endpoint | return 5 first articles |

#### Example

```CSharp
using NwadHealth.Pace.ContentLibraryModule.Domain.Entities;
using NwadHealth.Pace.ContentLibraryModule.Infrastructure;

... // other setup

var config = new ContentLibraryConfiguration();

services.AddPaceContentLibrary<YourContentDbContext>(config);

... // other setup

var app = builder.Build();

... // other setup

app.Run(); 
```

### CMS configuration

To configure the CMS set the following properties through `appsettings.json` (example below) or environment variables / IaC:

| Property                                           | Purpose                                                            |
|----------------------------------------------------|--------------------------------------------------------------------|
| `Umbraco:CMS:Unattended:UnattendedUserName`        | Name to set for the unattended install user                        |
| `Umbraco:CMS:Unattended:UnattendedUserEmail`       | Email to set for the unattended install user                       |
| `Umbraco:CMS:Unattended:UnattendedUserPassword`    | Password to set for the unattended install user                    |
| `Umbraco:Storage:AzureBlob:Media:ConnectionString` | Connection string for the storage account for storing media        |
| `AzureADConnection:TenantId`                       | Tenant ID of the Azure Tenant the app registration is contained in |
| `AzureADConnection:ClientId`                       | Client ID of the app registration                                  |
| `AzureADConnection:ClientSecret`                   | Client secret of the app registration                              |
| `ConnectionStrings:umbracoDbDSN`                   | Connection string for the CMS database                             |
| `ConnectionStrings:contentDb`                      | Connection strieng for the "mapped content" database               |
| `MediaBaseUrl`                                     | Url for the media container in the storage account                 |

Once the required configuration is set and Umbraco is running, required content types etc. must be imported.
This can be done by logging into the Umbraco, navigating to `Settings -> uSync (left menu) -> Import everything`.

#### Example Appsettings
> **Note: this example ONLY contains the configuration items you should set, do not copy the entire example configuration**

``` json
{
  "Umbraco": {
    "CMS": {
      "Unattended": {
        "UnattendedUserName": "gab",
        "UnattendedUserEmail": "gab@nwadhealth.com",
        "UnattendedUserPassword": "StronkPassword123!"
      },
    },
    "Storage": {
      "AzureBlob": {
        "Media": {
          "ConnectionString": "DefaultEndpointsProtocol=https;AccountName=gabsandboxcmsstorage;AccountKey=lXp7PEGtO6QuFgXqw0ZWSuI4ZBy/wiBSrqJJFItBy0q21Gfoi91juXSJChr5ZPzL1Nu/LVYqDXeV+AStgL8LoQ==;EndpointSuffix=core.windows.net"
        }
      }
    }
  },
  "AzureADConnection": {
    "TenantId": "76c04424-88b8-4c32-bf5f-403166dfe4cd",
    "ClientId": "b92cb756-3e2f-4abe-aaf1-353f9facc9f2",
    "ClientSecret": "_rW8Q~9tqSuz1lhPkL9aNrgj4c45CejYz8PN6bjY"
  },
  "ConnectionStrings": {
    "umbracoDbDSN": "Server=tcp:gab-sandbox-server.database.windows.net,1433;Initial Catalog=cms-db;Persist Security Info=False;User ID=admin-login;Password=StronkPassword123!;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;",
    "contentDb": "Server=tcp:gab-sandbox-server.database.windows.net,1433;Initial Catalog=gab-sandbox-db;Persist Security Info=False;User ID=admin-login;Password=StronkPassword123!;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
  },
  "MediaBaseUrl": "https://gabsandboxcmsstorage.blob.core.windows.net/media"
}
```

### Adding custom article components

Articles are built using a collection of article components.
You are able to create your own components for use in your own articles, this requires work on both the client and server side.
The server is responsible for mapping the custom component to the content database and the client is resoponsible for rendering the component (this must be configured by the client developers).

1. Create new content type
    1. Log into Umbraco and navigate to `Settings`.
    1. Add a new `Element Type` in the `Document Types -> Components` folder.
    1. Configure the name, description, alias as well as property structure required for the component.
1. Allow the content type to be attached to articles
    1. Log into Umbraco and navigate to `Settings`.
    1. In the `Data Types` folder, locate and edit the data type called `ArticleComponentList`
    1. Add the content type you just created in the `Available Blocks` section
1. Create the model representing the article component in your application.
    1. Create a subclass of [ArticleComponent](https://effective-robot-19m1v3p.pages.github.io/classNwadHealth_1_1Pace_1_1ContentLibraryModule_1_1Domain_1_1Entities_1_1ArticleComponents_1_1ArticleComponent.html)
    1. Create a Db mapping configuration for your newly added model, using ModelBuilder. It is only required for you to map the component specific properties. Example of HTML component:

       ```CSharp
        builder
            .Entity<HtmlComponent>()
            .Property(ht => ht.Html)
            .HasConversion(ValueConverters.NonEmptyStringConverter);
       ```
       
1. Add the Umbraco type to component mapping in the CMS
    1. Locate the call to `AddPaceComponentMapping` in the CMS program file.
    1. If not passed already, pass a function as parameter. The function should receive an `IArticleComponentMapperConfiguration` which is used for registering component mappers.
    1. Register a mapper using `RegisterComponent`. Example of registering mapper for HTML component:
       ```CSharp
        componentManager.RegisterComponent("ElementTypeAlias", (IntermediateArticleComponent comp, IServiceScope _) =>
        {
            var textField = comp.Content["text"]?.GetValue<string>() ?? throw new("Could not find richtext for component");
            var textContent = JsonNode.Parse(textField)?["markup"]?.GetValue<string>() ?? throw new("Could not extract markup from richtext");

            return new HtmlComponent
            {
                ArticleId = comp.ArticleId,
                ArticleLanguageCode = comp.LanguageCode,
                Position = comp.Position,
                Html = textContent
            };
        });
       ```

## Events published

This module does not publish any events.

## Application lifecycle

This module does not have lifecycle management.
