namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Controllers;

/// <summary>
/// DTO used for article filtering query parameters
/// </summary>
/// <param name="Search">The search keyword to lookup for</param>
/// <param name="CategoryIds">Category IDs to filter by</param>
/// <param name="TagIds">Tag IDs to filter by</param>
public record ArticleFiltersDto(
    string? Search,
    int[]? CategoryIds,
    int[]? TagIds
);
