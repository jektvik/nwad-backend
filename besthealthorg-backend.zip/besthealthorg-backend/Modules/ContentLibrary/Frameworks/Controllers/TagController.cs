using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetTagsInteractor;
using NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Controllers;

/// <summary>
/// Controller responsible for tag operations.
/// </summary>
[ApiController]
[Route("contentLibrary/[controller]")]
[Authorize]
public class TagController : ControllerBase
{
    /// <summary>
    /// Fetches all tags from the data store.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Tags(
        [FromServices] IGetTagsInteractor interactor,
        [FromHeader(Name = "Accept-Language")] string acceptLanguage = "en")
    {
        var tags = await interactor.Execute(acceptLanguage);

        return Ok(tags.Select(TagDto.FromDomain));
    }
}
