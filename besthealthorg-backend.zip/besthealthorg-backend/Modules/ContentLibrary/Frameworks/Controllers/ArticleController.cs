using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetArticlesInteractor;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.RecommendedArticlesInteractor;
using NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Dtos;
using NwadHealth.Besthealthorg.Foundation.Exceptions;
using NwadHealth.Besthealthorg.Foundation.Extensions;
using NwadHealth.Besthealthorg.Foundation.Extensions.Controller;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Controllers;

/// <summary>
/// Controller for managing articles.
/// </summary>
[ApiController]
[Route("contentLibrary/[controller]")]
[Authorize]
public class ArticleController: ControllerBase
{
    private const string DefaultAcceptLanguage = "en";

    /// <summary>
    /// Fetches a list of recommended articles for the user.
    /// </summary>
    /// <param name="interactor">The interactor responsible for fetching the recommended articles.</param>
    /// <param name="acceptLanguage">The language code for the articles (from the Accept-Language header).</param>
    [HttpGet("recommended")]
    public async Task<IActionResult> GetRecommendedArticles(
        [FromServices] IRecommendedArticlesInteractor interactor,
        [FromHeader(Name = "Accept-Language")] string acceptLanguage = DefaultAcceptLanguage)
    {
        try
        {
            var articles = await interactor.Execute(HttpContext, acceptLanguage);

            var response = articles.Select(ArticleDto.FromDomain);

            return Ok(response);
        }
        catch (CountryCodeNotSetException)
        {
            return this.CountryCodeNotSetError();
        }
    }

    /// <summary>
    /// Fetches an article from the data store.
    /// </summary>
    /// <param name="interactor">The interactor responsible for fetching a single article</param>
    /// <param name="articleId">The ID of the article to fetch</param>
    /// <param name="acceptLanguage">The language code for the articles (from the Accept-Language header).</param>
    [HttpGet("{articleId:int}")]
    public async Task<IActionResult> GetArticle([FromServices] IGetArticleInteractor interactor,
        [FromRoute] int articleId,
        [FromHeader(Name = "Accept-Language")] string acceptLanguage = DefaultAcceptLanguage)
    {
        var article = await interactor.Execute(articleId, acceptLanguage);

        return (article is not null) ? Ok(ArticleDto.FromDomain(article)) : this.ArticleNotFoundError();
    }

    /// <summary>
    /// Fetches a paginated list of articles, with optional filtering, sorting, and pagination.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>Sorting:</b>
    /// The paginated articles are sorted first by the provided sorting criteria and then by ID.
    /// The default sorting is by title.
    /// The default sort order is ascending.
    /// </para>
    /// <para>
    /// <b>Pagination:</b>
    /// Pagination query parameters are optional. Defaults to page 0 and page size 10 if not provided.
    /// if the page size is greater than the maximum allowed value, it will be capped at the maximum value.
    /// </para>
    /// <para>
    /// <b>Accept-Language:</b>
    /// The Accept-Language header is optional. Defaults to "en" if not provided.
    /// </para>
    /// </remarks>
    /// <param name="interactor">The interactor responsible for fetching the articles.</param>
    /// <param name="filtersDto">Filters to apply, such as tags, categories, and keywords.</param>
    /// <param name="sortRequest">Optional sorting criteria. Defaults to sorting by title if not provided.</param>
    /// <param name="paginationRequest">Pagination settings (page number and page size).</param>
    /// <param name="acceptLanguage">The language code for the articles (from the Accept-Language header).</param>
    /// <returns>A paginated list of articles matching the given filters.</returns>
    /// <response code="200">Returns a paginated list of articles.</response>
    [HttpGet]
    public async Task<IActionResult> Article([FromServices] IGetArticlesInteractor interactor,
        [FromQuery] ArticleFiltersDto filtersDto,
        [FromQuery] SortRequest sortRequest,
        [FromQuery] PaginationRequest paginationRequest,
        [FromHeader(Name = "Accept-Language")] string acceptLanguage = DefaultAcceptLanguage)
    {
        var filters = new ArticleFilters
        {
            LanguageCode = acceptLanguage,
            TagIds = filtersDto.TagIds?.ToList() ?? [],
            CategoryIds = filtersDto.CategoryIds?.ToList() ?? [],
            Keyword = filtersDto.Search,
        };

        try
        {
            var articles = await interactor.GetArticlesAsync(
                paginationRequest,
                userId: HttpContext.CurrentIdentityId(),
                sortRequest: sortRequest,
                filters
            );

            var response = articles.MapItems(ArticleDto.FromDomain);

            return Ok(response);
        }
        catch (CountryCodeNotSetException)
        {
            return this.CountryCodeNotSetError();
        }
    }
}
