using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetCategoriesInteractor;
using NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Controllers;

/// <summary>
/// Controller responsible for categories operations.
/// </summary>
[ApiController]
[Route("contentLibrary/[controller]")]
[Authorize]
public class CategoryController : ControllerBase
{
    /// <summary>
    /// Fetches all categories from the data store.
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Categories(
        [FromServices] IGetCategoriesInteractor interactor,
        [FromHeader(Name = "Accept-Language")] string acceptLanguage = "en")
    {
        var categories = await interactor.Execute(acceptLanguage);

        return Ok(categories.Select(c => CategoryDto.FromDomain(c, true)));
    }
}
