using System.Text.Json.Serialization;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Dtos;

/// <summary>
/// Represents a category DTO.
/// </summary>
public record CategoryDto(
    int Id,
    string Name,
    string ImageUrl,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    int? ArticleCount = null
)
{
    /// <summary>
    /// Converts a category domain object to a DTO.
    /// </summary>
    /// <param name="category">The category domain object to convert</param>
    /// <param name="includeArticleCount">If the article count should be included in the DTO</param>
    /// <returns>The category DTO</returns>
    public static CategoryDto FromDomain(Category category, bool includeArticleCount = false)
    {
        return new(
            Id: category.Id,
            Name: category.Name,
            ImageUrl: category.ImageUrl,
            ArticleCount: includeArticleCount ? category.Articles.Count : null
        );
    }
}
