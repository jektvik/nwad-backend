using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.ArticleComponents.Dtos;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Dtos;

/// <summary>
/// Represents an article DTO
/// </summary>
public record ArticleDto(
    int Id,
    string Title,
    string ThumbnailUrl,
    string AuthorName,
    DateTimeOffset PublishedDate,
    string? OriginalArticleUrl,
    IReadOnlyCollection<IArticleComponentDto>? ArticleComponents,
    IReadOnlyCollection<TagDto>? Tags,
    IReadOnlyCollection<CategoryDto>? Categories
)
{
    /// <summary>
    /// Converts an article domain object to a DTO
    /// </summary>
    /// <param name="article">The article domain object to convert</param>
    /// <returns>The article DTO</returns>
    public static ArticleDto FromDomain(Article article)
    {
        return new(
            Id: article.Id,
            Title: article.Title,
            ThumbnailUrl: article.ThumbnailUrl,
            AuthorName: article.AuthorName,
            PublishedDate: article.UpdatedAt,
            OriginalArticleUrl: article.OriginalArticleUrl,
            ArticleComponents: article.Components.Select(IArticleComponentDto.FromDomain).ToList(),
            Tags: article.Tags.Select(TagDto.FromDomain).ToList(),
            Categories: article.Categories.Select(a => CategoryDto.FromDomain(a)).ToList()
        );
    }
}
