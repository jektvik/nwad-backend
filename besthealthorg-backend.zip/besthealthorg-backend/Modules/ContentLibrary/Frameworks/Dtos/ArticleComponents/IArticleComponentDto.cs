using System.Text.Json.Serialization;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.ArticleComponents.Dtos;

/// <summary>
/// Represents a component of an article.
/// </summary>
[JsonDerivedType(typeof(HtmlComponentDto))]
[JsonDerivedType(typeof(VideoComponentDto))]
[JsonDerivedType(typeof(ImageComponentDto))]
public interface IArticleComponentDto
{
    public string Type { get; init; }

    /// <summary>
    /// Converts an article component domain object to a DTO.
    /// </summary>
    /// <param name="articleComponent">The article component domain object to convert</param>
    /// <returns>The Article Component DTO</returns>
    /// <exception cref="NotSupportedException">Throws if the article component is of an unkown type</exception>
    public static IArticleComponentDto FromDomain(ArticleComponent articleComponent)
    {
        return articleComponent switch
        {
            VideoComponent videoComponent => new VideoComponentDto(
                Type: "video",
                VideoUrl: videoComponent.Url
            ),
            ImageComponent imageComponent => new ImageComponentDto(
                Type: "image",
                ImageUrl: imageComponent.Url
            ),
            HtmlComponent htmlComponent => new HtmlComponentDto(
                Type: "html",
                Html: htmlComponent.Html
            ),
            _ => throw new NotSupportedException($"Article component type {articleComponent.GetType().Name} is not supported.")
        };
    }
}
