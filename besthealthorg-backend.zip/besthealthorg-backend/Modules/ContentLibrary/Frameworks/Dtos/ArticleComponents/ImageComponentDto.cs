namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.ArticleComponents.Dtos;

/// <summary>
/// Represents an image component DTO.
/// </summary>
public record ImageComponentDto(
    string Type,
    string ImageUrl
) : IArticleComponentDto;
