namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.ArticleComponents.Dtos;

/// <summary>
/// Represents a video component DTO.
/// </summary>
public record VideoComponentDto(
    string Type,
    string VideoUrl
) : IArticleComponentDto;
