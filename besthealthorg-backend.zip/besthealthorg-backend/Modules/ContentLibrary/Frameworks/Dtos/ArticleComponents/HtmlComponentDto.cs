namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.ArticleComponents.Dtos;

/// <summary>
/// Represents an HTML component DTO.
/// </summary>
public record HtmlComponentDto(
    string Type,
    string Html
) : IArticleComponentDto;
