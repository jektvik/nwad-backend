using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Dtos;

/// <summary>
/// Represents a tag DTO.
/// </summary>
public record TagDto(
    int Id,
    string Name
)
{
    /// <summary>
    /// Converts a tag domain object to a DTO.
    /// </summary>
    /// <param name="tag">The tag domain to convert</param>
    /// <returns>The tag DTO</returns>
    public static TagDto FromDomain(Tag tag)
    {
        return new(
            Id: tag.Id,
            Name: tag.Name
        );
    }
}
