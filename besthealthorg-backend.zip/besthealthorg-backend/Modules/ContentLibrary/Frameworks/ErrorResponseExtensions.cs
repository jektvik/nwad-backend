﻿using Microsoft.AspNetCore.Mvc;
using static NwadHealth.Besthealthorg.Foundation.Extensions.Controller.ErrorResponseExtensions;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks;

/// <summary>
/// ControllerBase extensions for creating error responses
/// </summary>
internal static class ErrorResponseExtensions
{
    /// <summary>
    /// Creates an article not found error result
    /// </summary>
    /// <param name="controller">The instance being extended</param>
    /// <returns>An article not found result</returns>
    internal static IActionResult ArticleNotFoundError(this ControllerBase controller) =>
        controller.NotFound(CreateErrorResponseDto("article_not_found", "The article could not be found"));
}
