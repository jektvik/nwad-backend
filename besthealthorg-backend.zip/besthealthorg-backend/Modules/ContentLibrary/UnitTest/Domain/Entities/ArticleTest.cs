using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.Foundation.Exceptions;
using NwadHealth.Besthealthorg.Foundation.CustomTypes;
using Xunit;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.UnitTest;

public class ArticleTest
{
    [Fact]
    public void CreateArticle_WhenTitleEmpty_ThrowsException()
    {
        // Arrange & Act & Assert
        Assert.Throws<ArgumentException>(() =>
            new Article
            {
                Id = 1,
                LanguageCode = new NonEmptyString("EN"),
                Title = new NonEmptyString(""), // Empty title
                AuthorName = new NonEmptyString("Author"),
                ThumbnailUrl = new UrlString("https://example.com")
            });
    }

    [Fact]
    public void CreateArticle_WhenInvalidArticleUrl_ThrowsException()
    {
        // Arrange & Act & Assert
        Assert.Throws<ArgumentNotUrlException>(() =>
            new Article
            {
                Id = 1,
                LanguageCode = new NonEmptyString("EN"),
                Title = new NonEmptyString("Valid Title"),
                AuthorName = new NonEmptyString("Author"),
                ThumbnailUrl = new UrlString("https://example.com"),
                OriginalArticleUrl = new UrlString("invalid-url"),
            });
    }

    [Fact]
    public void CreateArticle_WhenInvalidThumbnailUrl_ThrowsException()
    {
        // Arrange & Act & Assert
        Assert.Throws<ArgumentNotUrlException>(() =>
            new Article
            {
                Id = 1,
                LanguageCode = new NonEmptyString("EN"),
                Title = new NonEmptyString("Valid Title"),
                AuthorName = new NonEmptyString("Author"),
                ThumbnailUrl = new UrlString("invalid-url") // Invalid URL
            });
    }

    [Fact]
    public void ArticleUpdateThumbnailUrl_WhenInvalidUrl_ThrowsException()
    {
        // Arrange
        var article = FakesGenerator.CreateFakeArticle();

        // Act & Assert
        Assert.Throws<ArgumentNotUrlException>(() => article.ThumbnailUrl = new UrlString(":5head:")); // Invalid URL
    }

    [Fact]
    public void CreateArticle_WithCountry_Succeeds()
    {
        // Arrange
        var country = FakesGenerator.CreateFakeCountry();
        var article = new Article
        {
            Id = 1,
            LanguageCode = new NonEmptyString("EN"),
            Title = new NonEmptyString("Valid Title"),
            AuthorName = new NonEmptyString("Author"),
            ThumbnailUrl = new UrlString("https://example.com"),
            // Act
            Country = country,
        };

        // Assert
        Assert.Equal(country, article.Country);
    }
}
