using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Xunit;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.UnitTest;

public class CountryTest
{
    [Fact]
    public void CreateCountry_WhenNameEmpty_ThrowsException()
    {
        // Arrange
        const string invalidName = "";

        // Act & Assert
        Assert.Throws<ArgumentException>(() => new Country() { Name = invalidName, Code = "US"});
    }

    [Fact]
    public void CreateCountry_WhenInvalidCountryCode_ThrowsException()
    {
        // Arrange
        const string validName = "Zimbabwe";
        const string invalidCode = "monkaS";

        // Act & Assert
        Assert.Throws<ArgumentException>(() => new Country { Name = validName, Code = invalidCode });
    }

    [Fact]
    public void CreateCountry_WhenValidNameAndCode_Succeeds()
    {
        // Arrange
        const string validName = "Denmark";
        const string validCode = "Dk";

        // Act
        var country = new Country() { Name = validName, Code = validCode };

        // Assert
        Assert.NotNull(country);
        Assert.Equal(validName, country.Name);
        Assert.Equal(validCode.ToUpper(), country.Code);
    }

    [Fact]
    public void CreateCountry_WhenCodeHasExtraSpaces_StillValid()
    {
        // Arrange
        const string validName = "Valid Country";
        const string codeWithSpaces = " us ";

        // Act
        var country = new Country() { Name = validName, Code = codeWithSpaces };

        // Assert
        Assert.Equal("US", country.Code);
    }
}
