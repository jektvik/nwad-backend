using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Xunit;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.UnitTest;

public class LanguageTest
{
    [Fact]
    public void CreateLanguage_WhenNameEmpty_ThrowsException()
    {
        // Arrange
        const string invalidName = "";

        // Act & Assert
        Assert.Throws<ArgumentException>(() => new Language { Name = invalidName, Code = "EN" });
    }

    [Fact]
    public void CreateLanguage_WhenCodeEmpty_ThrowsException()
    {
        // Arrange
        const string validName = "English";
        const string invalidCode = "";

        // Act & Assert
        Assert.Throws<ArgumentException>(() => new Language { Name = validName, Code = invalidCode });
    }

    [Fact]
    public void CreateLanguage_WhenInvalidCode_ThrowsException()
    {
        // Arrange
        const string validName = "Spanish";
        const string invalidCode = "Pog";

        // Act & Assert
        Assert.Throws<ArgumentException>(() => new Language { Name = validName, Code = invalidCode });
    }

    [Fact]
    public void CreateLanguage_WhenValidNameAndCode_Succeeds()
    {
        // Arrange
        const string validName = "French";
        const string validCode = "FR";

        // Act
        var language = new Language { Name = validName, Code = validCode };

        // Assert
        Assert.Equal(validName, language.Name);
        Assert.Equal(validCode, language.Code);
    }

    [Fact]
    public void CreateLanguage_WithValidCode_Succeeds()
    {
        // Arrange
        const string newValidCode = "ES";
        var language = new Language { Name = "Spanish", Code = newValidCode};

        // Assert
        Assert.Equal(newValidCode, language.Code);
    }

    [Fact]
    public void CreateLanguage_WhenCodeHasExtraSpaces_Succeeds()
    {
        // Arrange
        const string validName = "Portuguese";
        const string codeWithWhiteSpaces = " pt ";

        // Act
        var language = new Language { Name = validName, Code = codeWithWhiteSpaces };

        // Assert
        Assert.Equal("PT", language.Code);
    }

    [Fact]
    public void CreateLanguage_WithArticlesAndCountries_Succeeds()
    {
        // Arrange
        const string validName = "Italian";
        const string validCode = "IT";

        List<Article> articles = [FakesGenerator.CreateFakeArticle()];
        List<Country> countries = [FakesGenerator.CreateFakeCountry()];

        // Act
        var language = new Language { Name = validName, Code = validCode, Articles = articles, Countries = countries };

        // Assert
        Assert.NotNull(language);
        Assert.Equal(validName, language.Name);
        Assert.Equal(validCode, language.Code);
        Assert.Single(language.Articles);
        Assert.Single(language.Countries);
        Assert.Equal(articles, language.Articles);
        Assert.Equal(countries, language.Countries);
    }
}
