using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Xunit;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.UnitTest;

public class TagTest
{
    [Fact]
    public void CreateTag_WithArticles_Succeeds()
    {
        // Arrange
        List<Article> articles = [FakesGenerator.CreateFakeArticle()];

        // Act
        var tag = new Tag
        {
            Id = 2,
            Name = "Tag",
            LanguageCode = "ES",
            Articles = articles,
        };

        // Assert
        Assert.Equal(articles, tag.Articles);
    }

    [Fact]
    public void CreateTag_WhenNameEmpty_ThrowsArgumentException()
    {
        // Arrange, Act & Assert
        Assert.Throws<ArgumentException>(() =>
            new Tag
            {
                Id = 1,
                Name = "",
                LanguageCode = "EN",
            });
    }

    [Fact]
    public void CreateTag_WhenValidNameAndLanguage_Succeeds()
    {
        // Act
        var tag = new Tag
        {
            Id = 1,
            Name = "Technology",
            LanguageCode = "EN",
        };

        // Assert
        Assert.Equal("Technology", tag.Name);
        Assert.Equal("EN", tag.LanguageCode);
    }

    [Fact]
    public void SetArticles_WithNewArticles_Succeeds()
    {
        // Arrange
        List<Article> oldArticles = [FakesGenerator.CreateFakeArticle()];
        List<Article> newArticles = [FakesGenerator.CreateFakeArticle()];

        var tag = new Tag
        {
            Id = 1,
            Name = "Technology",
            LanguageCode = "EN",
            Articles = oldArticles,
        };

        // Act
        tag.Articles = newArticles;

        // Assert
        Assert.Equal(newArticles, tag.Articles);
    }

    [Fact]
    public void CreateTag_WithMultipleArticles_Succeeds()
    {
        // Arrange
        List<Article> articles =
        [
            FakesGenerator.CreateFakeArticle(),
            FakesGenerator.CreateFakeArticle(),
        ];

        // Act
        var tag = new Tag
        {
            Id = 1,
            Name = "Technology",
            LanguageCode = "EN",
            Articles = articles,
        };

        // Assert
        Assert.Equal(articles, tag.Articles);
    }
}
