using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.Foundation.Exceptions;
using Xunit;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.UnitTest;

public class CategoryTest
{
    [Fact]
    public void CreateCategory_WhenInvalidImageUrl_ThrowsException()
    {
        // Arrange
        const string invalidUrl = "invalid-url";

        // Act & Assert
        Assert.Throws<ArgumentNotUrlException>(() =>
            new Category
            {
                Id = 1,
                ImageUrl = invalidUrl,
                Name = "Name",
                LanguageCode = default,
            });
    }

    [Fact]
    public void CreateCategory_WhenValidImageUrl_Succeeds()
    {
        // Arrange
        const string validUrl = "https://validurl.com";

        // Act
        var category = new Category
        {
            Id = 0,
            Name = "Name",
            ImageUrl = validUrl,
            LanguageCode = "en",
        };

        // Assert
        Assert.NotNull(category);
        Assert.Equal(validUrl, category.ImageUrl);
    }

    [Fact]
    public void CreateCategory_WhenImageUrlUpdatedToInvalid_ThrowsException()
    {
        // Arrange
        var category = new Category
        {
            Id = 0,
            Name = "Name",
            ImageUrl = "www.validurl.com",
            LanguageCode = "ES"
        };

        // Act & Assert
        Assert.Throws<ArgumentNotUrlException>(() => category.ImageUrl = "invalid-url");
    }

    [Fact]
    public void CreateCategory_WhenImageUrlUpdatedToValid_Succeeds()
    {
        // Arrange
        var category = new Category
        {
            Id = 0,
            Name = "Name",
            ImageUrl = "www.validurl.com",
            LanguageCode = "EL",
        };

        const string newValidUrl = "https://newvalidurl.com";

        // Act
        category.ImageUrl = newValidUrl;

        // Assert
        Assert.Equal(newValidUrl, category.ImageUrl);
    }

    [Fact]
    public void CreateCategory_WithArticles_Succeeds()
    {
        List<Article> articles = [FakesGenerator.CreateFakeArticle()];

        // Arrange
        var category = new Category
        {
            Id = 0,
            Name = "Name",
            ImageUrl = "www.validurl.com",
            LanguageCode = "TT",
            Articles = articles,
        };

        // Assert
        Assert.Equal(articles, category.Articles);
    }
}
