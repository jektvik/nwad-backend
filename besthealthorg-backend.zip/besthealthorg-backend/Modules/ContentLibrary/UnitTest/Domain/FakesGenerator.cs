using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.UnitTest;

public static class FakesGenerator
{
    public static readonly Language Language = new() { Name = "English", Code = "EN" };
    public static readonly Language Portuguese = new() { Name = "Portuguese", Code = "PT" };
    public static readonly Language Spanish = new() { Name = "Spanish", Code = "ES" };
    public static readonly Language German = new() { Name = "German", Code = "DE" };
    public static readonly Language French = new() { Name = "French", Code = "FR" };
    public static readonly Language Italian = new() { Name = "Italian", Code = "IT" };

    public static readonly List<Language> Languages = [Portuguese, Spanish, German, French, Italian];

    // ReSharper disable once InconsistentNaming
    public static readonly Country US = new() { Name = "United States", Code = "US" };
    public static readonly Country Canada = new() { Name = "Canada", Code = "CA" };
    public static readonly Country Brazil = new() { Name = "Brazil", Code = "BR" };
    public static readonly Country Argentina = new() { Name = "Argentina", Code = "AR" };
    public static readonly Country Switzerland = new() { Name = "Switzerland", Code = "CH" };

    public static readonly List<Country> Countries = [US, Canada, Brazil, Argentina, Switzerland];

    public static List<Article> SeedArticles(int count = 90)
    {
        var random = new Random();
        var articles = new List<Article>();
        var loopOffset = articles.Count + 5;
        for (var i = loopOffset; i <= count + loopOffset; i++)
        {
            var randomLanguage = Languages[random.Next(Languages.Count)];
            var randomCountry = random.Next(0, 2) == 0 ? null : Countries[random.Next(Countries.Count)];
            var tags = Enumerable.Range(10, random.Next(5)).ToList().ConvertAll(tagCount => new Tag
            {
                Id = Convert.ToInt32($"{i}{tagCount}"),
                Name = $"Article {tagCount}, Tag {tagCount}, lang {randomLanguage.Code}",
                LanguageCode = randomLanguage.Code,
            });
            var categories = Enumerable.Range(1, random.Next(5)).ToList().ConvertAll(catCount => new Category
            {
                Id = Convert.ToInt32($"{i}{catCount}"),
                Name = $"Article {catCount}, Category {catCount}, lang {randomLanguage.Code}",
                LanguageCode = randomLanguage.Code,
                ImageUrl = $"https://example.com/article{i}/category{catCount}.jpg",
            });
            var title = $"Article {i}: {randomLanguage.Name} Language and {randomCountry?.Name ?? "No"} Country";

            var article = new Article
            {
                Id = i,
                Title = title,
                AuthorName = $"Author {i}",
                OriginalArticleUrl = $"https://example.com/article{i}",
                ThumbnailUrl = $"https://example.com/article{i}/thumbnail.jpg",
                Language = randomLanguage,
                LanguageCode = randomLanguage.Code,
                Country = randomCountry,
                Tags = tags,
                Categories = categories,
                Components = GenerateRandomComponents(i),
            };

            articles.Add(article);
        }

        return articles;
    }

    private static List<ArticleComponent> GenerateRandomComponents(int articleId)
    {
        var random = new Random();
        var components = new List<ArticleComponent>();

        // Add 1-4 HTML components
        for (var i = 0; i < random.Next(1, 4); i++)
        {
            components.Add(new HtmlComponent
            {
                Position = i + 1,
                Html = $"<p>This is HTML content for article {articleId}, component {i + 1}</p>"
            });
        }

        // Optionally add an image or video component
        if (random.Next(0, 2) == 0) // 50% chance for image
        {
            components.Add(new ImageComponent
            {
                Position = components.Count + 1,
                Url = $"https://example.com/article{articleId}/image.jpg"
            });
        }
        else // 50% chance for video
        {
            components.Add(new VideoComponent
            {
                Position = components.Count + 1,
                Url = $"https://example.com/article{articleId}/video.mp4"
            });
        }

        return components;
    }

    public static Article CreateFakeArticle()
    {
        return new Article
        {
            Id = 578,
            AuthorName = "Juan Joya Borja",
            OriginalArticleUrl = "https://kekw.kekw",
            ThumbnailUrl = "https://kekw.kekw",
            Title = "Title",
            LanguageCode = Language.Code,
        };
    }

    public static Country CreateFakeCountry()
    {
        return new Country
        {
            Name = "KEKW country",
            Code = "BR",
        };
    }
}
