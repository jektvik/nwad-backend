using System.Diagnostics.CodeAnalysis;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetArticlesInteractor;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.RecommendedArticlesInteractor;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Controllers;
using NwadHealth.Besthealthorg.ContentLibraryModule.Frameworks.Dtos;
using NwadHealth.Besthealthorg.Foundation.Exceptions;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using NwadHealth.Besthealthorg.IdentityModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.IdentityModule.Domain.Entities;
using NwadHealth.Besthealthorg.TestUtilities.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Xunit;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.UnitTest.Frameworks.Controllers;

[SuppressMessage("ReSharper", "RedundantArgumentDefaultValue")]
public class ArticleControllerTests
{
    private readonly Mock<IGetArticleInteractor> _mockGetArticleInteractor = new();
    private readonly Mock<IGetArticlesInteractor> _mockGetArticlesInteractor = new();

    private readonly ArticleController _controller = new()
    {
        ControllerContext = ControllerTestHelper.SetupContext("identityId"),
    };

    [Fact]
    public async Task RecommendedArticles_ReturnsOk_WhenArticlesExist()
    {
        // Arrange
        var mockArticleRepository = new Mock<IArticleRepository>();
        var mockIdentityPropertiesInteractor = new Mock<IGetIdentityPropertiesInteractor>();

        const int take = 5;

        // Mock articles returned from repository
        mockArticleRepository
            .Setup(repo => repo.GetAll(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(FakesGenerator.SeedArticles(10));

        mockIdentityPropertiesInteractor
            .Setup(interactor => interactor.Execute(It.IsAny<string>()))
            .ReturnsAsync(new IdentityProperties { CountryCode = "US" });

        var recommendedArticlesInteractor = new RecommendedArticlesInteractor(
            mockArticleRepository.Object,
            mockIdentityPropertiesInteractor.Object,
            Selector,
            Mock.Of<IServiceScopeFactory>()
        );

        // Act
        var result = await _controller.GetRecommendedArticles(recommendedArticlesInteractor, "en");

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var returnedArticles = Assert.IsAssignableFrom<IEnumerable<ArticleDto>>(okResult.Value);
        Assert.Equal(take, returnedArticles.Count());
        return;

        ICollection<Article> Selector(
            List<Article> articles,
            IServiceScopeFactory serviceScopeFactory,
            HttpContext httpContext) => articles.OrderBy(a => a.Id).Take(take).ToList();
    }

    [Fact]
    public async Task RecommendedArticles_ReturnsOk_WithEmptyList_WhenNoArticlesExist()
    {
        // Arrange
        var mockArticleRepository = new Mock<IArticleRepository>();
        var mockIdentityPropertiesInteractor = new Mock<IGetIdentityPropertiesInteractor>();

        mockArticleRepository
            .Setup(repo => repo.GetAll(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync([]);

        mockIdentityPropertiesInteractor
            .Setup(interactor => interactor.Execute(It.IsAny<string>()))
            .ReturnsAsync(new IdentityProperties { CountryCode = "US" });

        var recommendedArticlesInteractor = new RecommendedArticlesInteractor(
            mockArticleRepository.Object,
            mockIdentityPropertiesInteractor.Object,
            Selector,
            Mock.Of<IServiceScopeFactory>()
        );

        // Act
        var result = await _controller.GetRecommendedArticles(recommendedArticlesInteractor, "en");

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var returnedArticles = Assert.IsAssignableFrom<IEnumerable<ArticleDto>>(okResult.Value);
        Assert.Empty(returnedArticles);
        return;

        ICollection<Article> Selector(
            List<Article> articles,
            IServiceScopeFactory serviceScopeFactory,
            HttpContext httpContext) => articles;
    }

    [Fact]
    public async Task GetArticle_ReturnsNotFound_WhenInvalidArticleIdProvided()
    {
        // Arrange
        _mockGetArticleInteractor
            .Setup(x => x.Execute(It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync((Article?)(null));

        // Act
        var result = await _controller.GetArticle(_mockGetArticleInteractor.Object, -1);

        // Assert
        Assert.IsType<NotFoundObjectResult>(result);
    }

    [Fact]
    public async Task Article_ReturnsEmptyList_WhenNoArticlesMatchFilter()
    {
        // Arrange
        var paginatedItems = new PaginatedItems<Article>(0, 0, 1, new List<Article>()); // No articles
        _mockGetArticlesInteractor
            .Setup(x => x.GetArticlesAsync(It.IsAny<PaginationRequest>(), It.IsAny<string>(), It.IsAny<SortRequest>(),
                It.IsAny<ArticleFilters>()))
            .ReturnsAsync(paginatedItems);

        var filtersDto = new ArticleFiltersDto(
            Search: "NonExistent",
            CategoryIds: [],
            TagIds: []
        );

        var sortRequest = new SortRequest("title");
        var paginationRequest = new PaginationRequest { Page = 0, PageSize = 10 };

        // Act
        var result = await _controller.Article(_mockGetArticlesInteractor.Object, filtersDto, sortRequest, paginationRequest, "en");

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var paginatedResponse = Assert.IsType<PaginatedItems<ArticleDto>>(okResult.Value);
        Assert.Empty(paginatedResponse.Data);  // Ensure the data list is empty
    }

    [Fact]
    public async Task GetArticle_ReturnsOk_WhenArticleExists()
    {
        var article = FakesGenerator.CreateFakeArticle();
        _mockGetArticleInteractor
            .Setup(x => x.Execute(It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync(article);

        var result = await _controller.GetArticle(_mockGetArticleInteractor.Object, 1);

        var okResult = Assert.IsType<OkObjectResult>(result);
        var returnedArticle = Assert.IsType<ArticleDto>(okResult.Value);
        Assert.Equal(article.Id, returnedArticle.Id);
    }

    [Fact]
    public async Task GetArticle_ReturnsNotFound_WhenArticleDoesNotExist()
    {
        // Arrange
        _mockGetArticleInteractor
            .Setup(x => x.Execute(It.IsAny<int>(), It.IsAny<string>()))
            .ReturnsAsync((Article?)(null));

        // Act
        var result = await _controller.GetArticle(_mockGetArticleInteractor.Object, 1, "en");

        // Assert
        Assert.IsType<NotFoundObjectResult>(result);
    }

    [Fact]
    public async Task Article_ReturnsOk_WhenArticlesExist()
    {
        // Arrange
        var paginatedItems = new PaginatedItems<Article>(0, 10, 1, [FakesGenerator.CreateFakeArticle()]);
        _mockGetArticlesInteractor
            .Setup(x => x.GetArticlesAsync(It.IsAny<PaginationRequest>(), It.IsAny<string>(), It.IsAny<SortRequest>(),
                It.IsAny<ArticleFilters>()))
            .ReturnsAsync(paginatedItems);

        var filtersDto = new ArticleFiltersDto(
            Search: "Test",
            CategoryIds: [1],
            TagIds: [1]
        );

        var sortRequest = new SortRequest("title");
        var paginationRequest = new PaginationRequest { Page = 0, PageSize = 10 };

        // Act
        var result = await _controller.Article(_mockGetArticlesInteractor.Object, filtersDto, sortRequest,
            paginationRequest, "en");

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var paginatedResponse = Assert.IsType<PaginatedItems<ArticleDto>>(okResult.Value);
        Assert.Single(paginatedResponse.Data);
    }

    [Fact]
    public async Task Article_ReturnsBadRequest_WhenCountryCodeNotSet()
    {
        // Arrange
        _mockGetArticlesInteractor
            .Setup(x => x.GetArticlesAsync(It.IsAny<PaginationRequest>(), It.IsAny<string>(), It.IsAny<SortRequest>(),
                It.IsAny<ArticleFilters>()))
            .ThrowsAsync(new CountryCodeNotSetException());

        var filtersDto = new ArticleFiltersDto(
            Search: "Test",
            CategoryIds: [1],
            TagIds: [1]
        );

        var sortRequest = new SortRequest("title");
        var paginationRequest = new PaginationRequest { Page = 0, PageSize = 10 };

        // Act
        var result = await _controller.Article(_mockGetArticlesInteractor.Object, filtersDto, sortRequest,
            paginationRequest, "en");

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal(400, badRequestResult.StatusCode);
    }
}
