using NwadHealth.Besthealthorg.Foundation.CustomTypes;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

/// <summary>
/// Domain model representing a Tag.
/// </summary>
public sealed class Tag
{
    /// <summary>
    /// The unique identifier associated with this instance.
    /// </summary>
    public required int Id { get; set;  }

    /// <summary>
    /// Gets or sets the Name associated with this instance.
    /// </summary>
    /// <value>
    /// A <see cref="NonEmptyString"/> that represents the Tag Name. The value assigned to this property must not be null or empty.
    /// </value>
    /// <exception cref="ArgumentException">Thrown when an attempt is made to set the property with a null or empty string.</exception>
    public required NonEmptyString Name { get; set; }

    /// <summary>
    /// The Language Code associated with this instance.
    /// </summary>
    public required string LanguageCode { get; set; }

    /// <summary>
    /// The articles belonging to this tag.
    /// </summary>
    public ICollection<Article> Articles { get; set; } = [];
}
