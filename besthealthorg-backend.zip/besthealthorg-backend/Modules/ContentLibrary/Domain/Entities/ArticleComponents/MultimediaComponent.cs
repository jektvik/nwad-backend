using NwadHealth.Besthealthorg.Foundation.CustomTypes;
using NwadHealth.Besthealthorg.Foundation.Exceptions;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

/// <summary>
/// Represents a multimedia component that contains media elements such as images or videos.
/// This abstract class serves as a base for specific multimedia types (e.g., image, video), and includes
/// properties and behaviors that are common to all media types, such as the media URL and positioning within an article.
/// </summary>
/// <remarks>
/// This class is designed to store a media element's URL, which must be valid and well-formed. The
/// position parameter defines the order in which the media element will appear in the article.
/// Derived classes (like <see cref="ImageComponent"/> and <see cref="VideoComponent"/>) will inherit from this class
/// and may extend or modify its behavior.
/// </remarks>
public abstract class MultimediaComponent : ArticleComponent
{
    /// <summary>
    /// Gets or sets the URL associated with this multimedia component instance.
    /// </summary>
    /// <value>
    /// A non-nullable <see cref="UrlString"/> that represents the URL of this multimedia component.
    /// </value>
    /// <exception cref="ArgumentNotUrlException">
    /// Thrown when set with an invalid URL
    /// </exception>
    public required UrlString Url { get; set; }
}
