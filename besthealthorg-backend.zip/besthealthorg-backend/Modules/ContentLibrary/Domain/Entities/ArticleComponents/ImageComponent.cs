namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

/// <summary>
/// Represents an image component within an article.
/// </summary>
/// <remarks>
/// This class is specifically for handling image content, using a URL that must be valid and non-empty.
/// It inherits properties such as position and URL from the <see cref="MultimediaComponent"/> class.
/// </remarks>
public class ImageComponent: MultimediaComponent;
