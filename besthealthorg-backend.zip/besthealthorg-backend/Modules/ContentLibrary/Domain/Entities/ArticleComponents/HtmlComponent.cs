using NwadHealth.Besthealthorg.Foundation.CustomTypes;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

/// <summary>
/// Represents a component type that holds HTML content within an article.
/// </summary>
/// <remarks>
/// This class is part of the component system for articles, and is designed to store HTML content
/// that can be displayed in different positions of an article. The position value defines the
/// order of this content within the article.
/// </remarks>
public class HtmlComponent: ArticleComponent
{
    /// <summary>
    /// Gets or sets the HTML content associated with this instance.
    /// </summary>
    /// <value>
    /// A <see cref="NonEmptyString"/> that represents the HTML content.
    /// The value assigned to this property must be a non-empty string; otherwise, an
    /// <see cref="ArgumentException"/> will be thrown.
    /// </value>
    /// <exception cref="ArgumentException">
    /// Thrown when an attempt is made to set the HTML property to a null or empty string.
    /// </exception>
    public required NonEmptyString Html { get; set; }
}
