namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

/// <summary>
/// Represents an video component within an article.
/// </summary>
/// <remarks>
/// This class is specifically for handling video content, using a URL that must be valid and non-empty.
/// It inherits properties such as position and URL from the <see cref="MultimediaComponent"/> class.
/// </remarks>
public class VideoComponent : MultimediaComponent;
