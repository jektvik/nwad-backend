namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

/// <summary>
/// Root node for article components.
/// </summary>
public abstract class ArticleComponent
{
    /// <summary>
    /// The unique identifier of the component.
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Represent the position of the component in the article.
    /// </summary>
    public required int Position { get; set; }

    /// <summary>
    /// The article ID that the component belongs to.
    /// <remarks>
    /// Part of a composite foreign key, alongside <see cref="ArticleLanguageCode"/>.
    /// </remarks>
    /// </summary>
    public int ArticleId { get; set; }

    /// <summary>
    /// The article language code that the component belongs to.
    /// <remarks>
    /// Part of a composite foreign key, alongside <see cref="ArticleId"/>.
    /// </remarks>
    /// </summary>
    public string ArticleLanguageCode { get; set; }
}
