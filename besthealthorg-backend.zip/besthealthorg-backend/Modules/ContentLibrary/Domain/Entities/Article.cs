#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;
using NwadHealth.Besthealthorg.Foundation.CustomTypes;
using NwadHealth.Besthealthorg.Foundation.Exceptions;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

/// <summary>
/// Domain model representing an article.
/// </summary>
public sealed class Article
{
    /// <summary>
    /// Initialises a new article.
    /// </summary>
    public Article() {
        var now = DateTime.UtcNow;
        CreatedAt = now;
        UpdatedAt = now;
    }

    /// <summary>
    /// The unique identifier associated with this instance.
    /// </summary>
    public required int Id { get; set; }

    /// <summary>
    /// The language code associated with this instance.
    /// </summary>
    public required string LanguageCode { get; set; }

    /// <summary>
    /// The language associated with this instance.
    /// </summary>
    public Language Language { get; set; }

    /// <summary>
    /// The title associated with this instance.
    /// </summary>
    /// <value>
    /// A <see cref="NonEmptyString"/> that represents the Title of this article.
    /// The value assigned to this property must not be null or empty.
    /// </value>
    /// <exception cref="ArgumentException">Thrown when an attempt is made to set the property with a null or empty string.</exception>
    public required NonEmptyString Title { get; set; }

    /// <summary>
    /// Gets or sets the Author Name associated with this instance.
    /// </summary>
    /// <value>
    /// A <see cref="NonEmptyString"/> that represents the Author Name. The value assigned to this property must not be null or empty.
    /// </value>
    /// <exception cref="ArgumentException">Thrown when an attempt is made to set the property with a null or empty string.</exception>
    public required NonEmptyString AuthorName { get; set; }

    /// <summary>
    /// Gets or sets the original article URL associated with this instance.
    /// </summary>
    /// <value>
    /// A nullable <see cref="UrlString"/> that represents the original article URL.
    /// </value>
    /// <exception cref="ArgumentNotUrlException">
    /// Thrown when set with an invalid URL
    /// </exception>
    public UrlString? OriginalArticleUrl { get; set; }

    /// <summary>
    /// Gets or sets the thumbnail URL associated with this instance.
    /// </summary>
    /// <value>
    /// A required <see cref="UrlString"/> that represents the thumbnail URL.
    /// </value>
    /// <exception cref="ArgumentNotUrlException">
    /// Thrown when set with an invalid URL
    /// </exception>
    public required UrlString ThumbnailUrl { get; set; }

    /// <summary>
    /// The creation time associated with this instance.
    /// </summary>
    public DateTime CreatedAt { get; set; }

    /// <summary>
    /// The date which the article was last updated.
    /// </summary>
    public DateTime UpdatedAt { get; set; }

    /// <summary>
    /// The tags associated with this instance.
    /// </summary>
    /// <value>
    /// A collection of <see cref="Tag"/> objects representing the tags associated with this instance.
    /// </value>
    public ICollection<Tag> Tags { get; set; } = [];

    /// <summary>
    /// The categories associated with this instance.
    /// </summary>
    /// <value>
    /// A collection of <see cref="Category"/> objects representing the filters associated with this instance.
    /// </value>
    public ICollection<Category> Categories { get; set; } = [];

    /// <summary>
    /// The country code associated with this instance.
    /// </summary>
    public string? CountryCode { get; set; }

    /// <summary>
    /// The country associated with this instance.
    /// </summary>
    public Country? Country { get; set; }

    /// <summary>
    /// Private backing field for components
    /// </summary>
    private readonly List<ArticleComponent> _components = [];

    /// <summary>
    /// Expose article components as a read-only collection.
    /// </summary>
    public IReadOnlyCollection<ArticleComponent> Components
    {
        get => _components.AsReadOnly();
        init => UpdateComponents(value);
    }

    /// <summary>
    /// Updates the entire components collection, ensuring position uniqueness.
    /// </summary>
    /// <param name="newComponents">The new collection of components.</param>
    public void UpdateComponents(IEnumerable<ArticleComponent> newComponents)
    {
        var updatedComponents = newComponents.ToList();

        EnsureComponentsOrderNotSame(updatedComponents);

        _components.Clear();
        _components.AddRange(updatedComponents);
    }

    /// <summary>
    /// Removes a component from the collection.
    /// </summary>
    /// <param name="articleComponent">The componentto remove.</param>
    public bool RemoveComponent(ArticleComponent articleComponent)
    {
        return _components.Remove(articleComponent);
    }

    /// <summary>
    /// Method to ensure components positions are unique
    /// </summary>
    /// <param name="components">The components to check the order</param>
    /// <exception cref="ArgumentException">Throws if components positions aren't unique</exception>
    private static void EnsureComponentsOrderNotSame(ICollection<ArticleComponent> components)
    {
        if (components.Select(c => c.Position).Distinct().Count() < components.Count)
        {
            throw new ArgumentException("The components must have unique positions.");
        }
    }
}
