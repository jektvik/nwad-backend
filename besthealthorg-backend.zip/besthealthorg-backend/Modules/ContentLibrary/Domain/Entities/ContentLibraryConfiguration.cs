using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

/// <summary>
/// Provides configuration for the content library module
/// </summary>
public class ContentLibraryConfiguration
{
    /// <summary>
    /// Declare a delegate that will be used to select recommended articles
    /// </summary>
    public delegate ICollection<Article> RecommendedArticleSelector(List<Article> articles, IServiceScopeFactory scope, HttpContext httpContext);

    /// <summary>
    /// Define a field to hold the delegate.
    /// </summary>
    /// <remarks>
    /// Default implementation selects the first 5 articles from the list.
    /// </remarks>
    public RecommendedArticleSelector RecommendedArticlesSelector = (articles, _, _) => articles.Take(5).ToList();
}
