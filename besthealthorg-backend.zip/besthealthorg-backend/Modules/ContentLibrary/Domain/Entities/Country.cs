using System.Text.RegularExpressions;
using NwadHealth.Besthealthorg.Foundation.CustomTypes;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

/// <summary>
/// Domain model representing a country.
/// </summary>
public sealed class Country
{
    private static readonly Regex CountryCodeRegex = new("^[a-zA-Z]{2}$", RegexOptions.Compiled, TimeSpan.FromMilliseconds(100));

    /// <summary>
    /// The name of the country associated with this instance.
    /// </summary>
    /// <value>
    /// A required <see cref="NonEmptyString"/> that represents the name of this country.
    /// The value assigned to this property must not be null or empty.
    /// </value>
    /// <exception cref="ArgumentException">Thrown when an attempt is made to set the property with a null or empty string.</exception>
    public required NonEmptyString Name { get; set; }

    /// <summary>
    /// The 2-letter country code, according to the ISO 3166-1 alpha-2 standard
    /// associated with this country.
    /// </summary>
    /// <remarks>
    /// <a href="https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2">ISO 3166-1 alpha-2</a>
    /// </remarks>
    /// <exception cref="ArgumentException">If the provided country code is invalid</exception>
    public required string Code
    {
        get => _code;

        init
        {
            var sanitizedCode = value.ToUpper().Trim();
            if (!IsValidCountryCode(sanitizedCode))
            {
                throw new ArgumentException("Country code must be a two-letter code");
            }

            _code = sanitizedCode;
        }
    }
    /// <summary>
    /// Backing field for the Code property
    /// </summary>
    private readonly string _code = string.Empty;

    /// <summary>
    /// The articles belonging to this country.
    /// </summary>
    /// <value>
    /// A collection of <see cref="Article"/> objects representing the articles associated with this instance.
    /// </value>
    public ICollection<Article> Articles { get; init; } = new List<Article>();

    /// <summary>
    /// The languages associated with this country.
    /// </summary>
    /// <value>
    /// A collection of <see cref="Language"/> objects representing the languages associated with this instance.
    /// </value>
    public ICollection<Language> Languages { get; init; } = new List<Language>();

    private static bool IsValidCountryCode(string? code)
    {
        return code is not null && CountryCodeRegex.IsMatch(code);
    }
}
