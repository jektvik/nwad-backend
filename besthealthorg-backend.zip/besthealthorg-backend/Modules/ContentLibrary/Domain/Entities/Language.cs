using System.Text.RegularExpressions;
using NwadHealth.Besthealthorg.Foundation.CustomTypes;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

/// <summary>
/// Domain model representing a language.
/// </summary>
public sealed class Language
{
    private static readonly Regex LanguageCodeRegex = new("^[a-zA-Z]{2}$", RegexOptions.Compiled, TimeSpan.FromMilliseconds(100));

    /// <summary>
    /// The name associated with this language.
    /// </summary>
    /// <value>
    /// A required <see cref="NonEmptyString"/> that represents the name of the language.
    /// The value assigned to this property must not be null or empty.
    /// </value>
    /// <exception cref="ArgumentException">Thrown when an attempt is made to set the property with a null or empty string.</exception>
    public required NonEmptyString Name { get; set; }

    /// <summary>
    /// The 2-letter language code, according to the ISO 639-1 standard, associated with this language.
    /// </summary>
    /// <remarks>
    /// <a href="https://en.wikipedia.org/wiki/ISO_639-1">ISO 639-1</a>
    /// </remarks>
    /// <exception cref="ArgumentException">Thrown when an attempt is made to set an invalid country code</exception>
    public required string Code
    {
        get => _code;

        init
        {
            var sanitizedCode = value.ToUpper().Trim();
            if (!IsValidLanguageCode(sanitizedCode))
            {
                throw new ArgumentException("Language code must be a two-letter code");
            }

            _code = sanitizedCode;
        }
    }

    /// <summary>
    /// Backing field for the Code property
    /// </summary>
    private readonly string _code = string.Empty;

    /// <summary>
    /// The articles belonging to this language.
    /// </summary>
    /// <value>
    /// A collection of <see cref="Article"/> objects representing the articles associated with this language.
    /// </value>
    public ICollection<Article> Articles { get; init; } = [];

    /// <summary>
    /// The countries associated with this language.
    /// </summary>
    /// <value>
    /// A collection of <see cref="Country"/> objects representing the countries associated with this language.
    /// </value>
    public ICollection<Country> Countries { get; init; } = [];

    /// <summary>
    /// The categories associated with this language.
    /// </summary>
    public ICollection<Category> Categories { get; init; } = [];

    /// <summary>
    /// The tags associated with this language.
    /// </summary>
    public ICollection<Tag> Tags { get; init; } = [];

    private static bool IsValidLanguageCode(string code)
    {
        return LanguageCodeRegex.IsMatch(code);
    }
}
