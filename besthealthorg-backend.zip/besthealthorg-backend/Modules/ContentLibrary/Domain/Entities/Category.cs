using NwadHealth.Besthealthorg.Foundation.CustomTypes;
using NwadHealth.Besthealthorg.Foundation.Exceptions;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;

/// <summary>
/// Domain model representing a category.
/// </summary>
public sealed class Category
{
    /// <summary>
    /// The unique identifier associated with this instance.
    /// </summary>
    public required int Id { get; set; }

    /// <summary>
    /// The name associated with this category.
    /// </summary>
    /// <value>
    /// A <see cref="NonEmptyString"/> that represents the name. The value assigned to this property must not be null or empty.
    /// </value>
    /// <exception cref="ArgumentException">Thrown when an attempt is made to set the property with an empty string.</exception>
    public required NonEmptyString Name { get; set; }

    /// <summary>
    /// The image URL associated with this instance.
    /// </summary>
    /// <value>
    /// A required <see cref="UrlString"/> that represents the image URL of this category.
    /// </value>
    /// <exception cref="ArgumentNotUrlException">
    /// Thrown when set with an invalid URL
    /// </exception>
    public required UrlString ImageUrl { get; set; }

    /// <summary>
    /// The Language Code associated with this instance.
    /// </summary>
    public required string LanguageCode { get; init; }

    /// <summary>
    /// The articles belonging to this category.
    /// </summary>
    /// <value>
    /// A collection of <see cref="Article"/> objects representing the articles associated with this instance.
    /// </value>
    public ICollection<Article> Articles { get; set; } = [];
}
