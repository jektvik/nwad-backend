using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Foundation.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;

/// <inheritdoc />
public class CategoryRepository(IContentLibraryDbContext dbContext, ILogger<CategoryRepository> logger) : ICategoryRepository
{
    /// <inheritdoc />
    public async Task<Category> Create(Category category)
    {
        logger.LogInformation("Creating category");

        var entityEntry = dbContext.ContentCategories.Add(category);

        await dbContext.SaveChangesAsync();

        return entityEntry.Entity;
    }

    /// <inheritdoc />
    public async Task<Category?> Get(int id, string languageCode)
    {
        return await dbContext.ContentCategories
            .Include(f => f.Articles)
            .AsNoTracking()
            .SingleOrDefaultAsync(c => c.Id == id && c.LanguageCode == languageCode);
    }

    /// <inheritdoc />
    public async Task<List<Category>> GetAll(string languageCode)
    {
        return await dbContext.ContentCategories
            .AsNoTracking()
            .Include(c => c.Articles)
            .Where(c => c.LanguageCode == languageCode)
            .ToListAsync();
    }

    /// <inheritdoc />
    public async Task<Category> Update(Category category)
    {
        var existingCategory = await dbContext.ContentCategories
            .SingleAsync(c => c.Id == category.Id && c.LanguageCode == category.LanguageCode);

        existingCategory.ImageUrl = category.ImageUrl;
        existingCategory.Name = category.Name;

        var entityEntry = dbContext.ContentCategories.Update(existingCategory);

        await dbContext.SaveChangesAsync();
        return entityEntry.Entity;
    }

    /// <inheritdoc />
    public async Task<int> Delete(int id, string? languageCode = null)
    {
        return await dbContext.ContentCategories
            .Where(c => c.Id == id && (languageCode == null || c.LanguageCode == languageCode))
            .ExecuteDeleteAsync();
    }
}
