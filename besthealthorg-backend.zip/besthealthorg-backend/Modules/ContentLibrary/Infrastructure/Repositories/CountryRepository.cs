using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;

/// <inheritdoc />
public class CountryRepository(IContentLibraryDbContext dbContext) : ICountryRepository
{
    /// <inheritdoc />
    public async Task<Country> Create(Country country)
    {
        var entityEntry = dbContext.ContentCountries.Add(country);

        // Iterate through the languages associated with the country
        foreach (var language in country.Languages)
        {
            var existingLanguage = await dbContext
                .ContentLanguages
                .FirstOrDefaultAsync(l => l.Code == language.Code);

            if (existingLanguage is null)
            {
                // If the language doesn't exist, add it
                dbContext.ContentLanguages.Add(language);
            }
            else
            {
                // If the language exists, ensure it's not tracked twice
                dbContext.ContentLanguages.Add(existingLanguage).State = EntityState.Unchanged;
            }
        }

        await dbContext.SaveChangesAsync();

        return entityEntry.Entity;
    }

    /// <inheritdoc />
    public async Task<Country?> Get(string countryCode)
    {
        return await dbContext.ContentCountries
            .AsNoTracking()
            .Include(c => c.Languages)
            .FirstOrDefaultAsync(c => c.Code == countryCode);
    }

    /// <inheritdoc />
    public async Task<Country> Update(string countryCode, Country country)
    {
        // Find the existing country in the database
        var existingCountry = await dbContext.ContentCountries
            .Include(c => c.Languages)
            .SingleAsync(c => c.Code == countryCode);

        existingCountry.Name = country.Name;

        foreach (var updatedLanguage in country.Languages)
        {
            var existingLanguage = await dbContext.ContentLanguages
                .FirstOrDefaultAsync(l => l.Code == updatedLanguage.Code);

            if (existingLanguage is null)
            {
                // If the language doesn't exist, add it (start tracking it) and associate it with the country
                dbContext.ContentLanguages.Add(updatedLanguage);
                existingCountry.Languages.Add(updatedLanguage);
            }
            else
            {
                // If the language already exists, ensure it's not already linked
                var isLanguageAlreadyLinked = existingCountry.Languages
                    .Any(l => l.Code == existingLanguage.Code);

                // Link the existing language to the country if it's not already linked
                if (!isLanguageAlreadyLinked)
                {
                    existingCountry.Languages.Add(existingLanguage);
                }
            }
        }

        // Save changes to the database
        await dbContext.SaveChangesAsync();

        return existingCountry;
    }

    /// <inheritdoc />
    public async Task<int> Delete(string countryCode)
    {
        return await dbContext.ContentCountries
            .Where(c => c.Code == countryCode)
            .ExecuteDeleteAsync();
    }
}
