using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;

/// <inheritdoc />
public class TagRepository(IContentLibraryDbContext dbContext, ILogger<TagRepository> logger): ITagRepository
{
    /// <inheritdoc />
    public async Task<Tag> Create(Tag tag)
    {
        logger.LogInformation("Attempting to create tag");
        var entityEntry = dbContext.ContentTags.Add(tag);

        await dbContext.SaveChangesAsync();

        return entityEntry.Entity;
    }

    /// <inheritdoc />
    public async Task<Tag?> Get(int id, string languageCode)
    {
        return await dbContext.ContentTags
            .AsNoTracking()
            .Include(t => t.Articles)
            .SingleOrDefaultAsync(t => t.Id == id && t.LanguageCode == languageCode);
    }

    /// <inheritdoc />
    public async Task<List<Tag>> GetAll(string languageCode)
    {
        return await dbContext.ContentTags
            .AsNoTracking()
            .Where(t => t.LanguageCode == languageCode)
            .ToListAsync();
    }

    /// <inheritdoc />
    public async Task<Tag> Update(Tag tag)
    {
        logger.LogInformation("Attempting to update tag");
        var entry = dbContext.ContentTags.Update(tag);

        await dbContext.SaveChangesAsync();

        return entry.Entity;
    }

    /// <inheritdoc />
    public async Task<int> Delete(int id, string? languageCode = null)
    {
        return await dbContext.ContentTags
            .Where(t => t.Id == id && (languageCode == null || t.LanguageCode == languageCode))
            .ExecuteDeleteAsync();
    }
}
