using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;

/// <inheritdoc />
public class LanguageRepository(IContentLibraryDbContext dbContext) : ILanguageRepository
{
    /// <inheritdoc />
    public async Task<Language> Create(Language language)
    {
        var entityEntry = dbContext.ContentLanguages.Add(language);

        foreach (var languageCountry in language.Countries)
        {
            var existingCountry = await dbContext.ContentCountries
                .FirstOrDefaultAsync(c => c.Code == languageCountry.Code);

            if (existingCountry is null)
            {
                dbContext.ContentCountries.Add(languageCountry);
            }
            else
            {
                dbContext.ContentCountries.Entry(languageCountry).State = EntityState.Unchanged;
            }
        }

        await dbContext.SaveChangesAsync();

        return entityEntry.Entity;
    }

    /// <inheritdoc />
    public async Task<Language?> Get(string languageCode)
    {
        return await dbContext.ContentLanguages
            .AsNoTracking()
            .Include(l => l.Countries)
            .FirstOrDefaultAsync(l => l.Code == languageCode);
    }

    /// <inheritdoc />
    public async Task<Language> Update(string languageCode, Language language)
    {
        // Fetch the language entity from the database, including its associated countries.
        var existingLanguageInDb = await dbContext.ContentLanguages
            .Include(l => l.Countries)
            .SingleAsync(l => l.Code == languageCode);

        // Update the name of the existing language.
        existingLanguageInDb.Name = language.Name;

        // Iterate through the countries in the updated language object.
        foreach (var updatedCountry in language.Countries)
        {
            // Check if the country already exists in the database based on the country code.
            var existingCountryInDb = await dbContext.ContentCountries
                .FirstOrDefaultAsync(c => c.Code == updatedCountry.Code);

            // If the country does not exist in the database, add it to the Countries table and to the language.
            if (existingCountryInDb is null)
            {
                dbContext.ContentCountries.Add(updatedCountry); // Add the new country to the Countries table
                existingLanguageInDb.Countries.Add(updatedCountry); // Associate the new country with the language
            }
            else
            {
                // Check if the existing country is already linked to the language to avoid duplicates.
                var isCountryAlreadyLinkedToLanguage = existingLanguageInDb.Countries
                    .Any(c => c.Code == existingCountryInDb.Code);

                // If the country isn't already linked to the language, add it to the language's country list.
                if (!isCountryAlreadyLinkedToLanguage)
                {
                    existingLanguageInDb.Countries
                        .Add(existingCountryInDb); // Link the existing country to the language
                }
            }
        }

        // Persist the changes to the database.
        await dbContext.SaveChangesAsync();

        // Return the updated language entity.
        return existingLanguageInDb;
    }

    /// <inheritdoc />
    public async Task<int> Delete(string languageCode)
    {
        return await dbContext.ContentLanguages
            .Where(l => l.Code == languageCode)
            .ExecuteDeleteAsync();
    }
}
