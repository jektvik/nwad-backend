using System.Linq.Expressions;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Extensions;
using NwadHealth.Besthealthorg.Foundation.Extensions;
using NwadHealth.Besthealthorg.Foundation.Pagination;
using NwadHealth.Besthealthorg.Foundation.Sorting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;

/// <inheritdoc />
public class ArticleRepository(IContentLibraryDbContext dbContext, ILogger<ArticleRepository> logger): IArticleRepository
{
    /// <inheritdoc />
    public async Task<Article> Create(Article article)
    {
        logger.LogInformation("Attempting to create article");

        await SetRelations(article, [..article.Categories], [..article.Tags]);

        var entityEntry = dbContext.ContentArticles.Add(article);

        await dbContext.SaveChangesAsync();

        logger.LogInformation("Successfully created article with ID: {ArticleId}", article.Id);

        return entityEntry.Entity;
    }

    /// <inheritdoc />
    public async Task<Article> Update(Article article)
    {
        logger.LogInformation("Attempting to update article with ID: {ArticleId}", article.Id);

        var existingArticle = await dbContext
            .ContentArticles
            .Include(a => a.Tags)
            .Include(a => a.Categories)
            .Include(a => a.Country)
            .Include(a => a.Components)
            .Include(a => a.Language)
            .SingleAsync(a => a.Id == article.Id && a.LanguageCode == article.LanguageCode);

        await UpdateArticleProperties(existingArticle, article);

        existingArticle.UpdatedAt = DateTime.UtcNow;

        var entity = dbContext.ContentArticles.Entry(existingArticle);

        await dbContext.SaveChangesAsync();

        logger.LogInformation("Successfully updated article with ID: {ArticleId}", article.Id);

        return entity.Entity;
    }

    /// <inheritdoc />
    public async Task<Article?> Get(int id, string languageCode)
    {
        return await dbContext
            .ContentArticles
            .IncludeCategoriesForLanguage(languageCode)
            .IncludeTagsForLanguage(languageCode)
            .Include(a => a.Country)
            .Include(a => a.Components.OrderBy(c => c.Position))
            .Include(a => a.Language)
            .AsNoTracking()
            .SingleOrDefaultAsync(a => a.Id == id && a.LanguageCode == languageCode);
    }

    /// <inheritdoc />
    public async Task<PaginatedItems<Article>> GetAll(
        PaginationRequest paginationRequest,
        SortRequest sortRequest,
        ArticleFilters articleFilters)
    {
        logger.LogInformation("Attempting to retrieve all articles with filters: {@ArticleFilters}", articleFilters);

        var combinedFilters = CombineFilters(
            ArticlesFor(articleFilters.CountryCode, articleFilters.LanguageCode),
            ArticlesForKeyword(articleFilters.Keyword),
            ArticlesForTag(articleFilters.TagIds),
            ArticlesForCategories(articleFilters.CategoryIds)
        );

        var totalCount = await dbContext.ContentArticles
            .CountAsync(combinedFilters);

        var (pageSize, pageIndex) = paginationRequest.Limit(totalCount, 100);

        var articles = await dbContext
            .ContentArticles
            .IncludeCategoriesForLanguage(articleFilters.LanguageCode)
            .IncludeTagsForLanguage(articleFilters.LanguageCode)
            .Where(combinedFilters)
            .SortBy(sortRequest.SortBy ?? "title", sortRequest.SortOrder)
            .ThenBy(a => a.Id)
            .Skip(pageSize * pageIndex)
            .Take(pageSize)
            .AsNoTracking()
            .ToListAsync();

        return new PaginatedItems<Article>(pageIndex, pageSize, totalCount, articles);
    }

    public Task<List<Article>> GetAll(string languageCode, string countryCode)
    {
        return dbContext.ContentArticles
            .Where(ArticlesFor(countryCode, languageCode))
            .IncludeCategoriesForLanguage(languageCode)
            .IncludeTagsForLanguage(languageCode)
            .Include(a => a.Country)
            .Include(a => a.Components)
            .Include(a => a.Language)
            .AsNoTracking()
            .ToListAsync();
    }

    private static Expression<Func<T, bool>> CombineFilters<T>(
        Expression<Func<T, bool>> firstFilter,
        Expression<Func<T, bool>> secondFilter)
    {
        var parameter = Expression.Parameter(typeof(T), "article");

        var combinedBody = Expression.AndAlso(
            Expression.Invoke(firstFilter, parameter),
            Expression.Invoke(secondFilter, parameter)
        );

        return Expression.Lambda<Func<T, bool>>(combinedBody, parameter);
    }

    private static Expression<Func<T, bool>> CombineFilters<T>(
        params Expression<Func<T, bool>>[] filters)
    {
        if (filters.Length == 0)
        {
            return _ => true;
        }

        if (filters.Length == 1)
        {
            return filters.First();
        }

        return filters.Aggregate(CombineFilters);
    }

    private static Expression<Func<Article, bool>> ArticlesForTag(ICollection<int> tagIds)
    {
        return article => tagIds.Count == 0 || article.Tags.Any(t => tagIds.Contains(t.Id));
    }

    private static Expression<Func<Article, bool>> ArticlesForCategories(ICollection<int> categoryIds)
    {
        return article => categoryIds.Count == 0 || article.Categories.Any(t => categoryIds.Contains(t.Id));
    }

    private static Expression<Func<Article, bool>> ArticlesForKeyword(string? keyword)
    {
        return article => string.IsNullOrEmpty(keyword) || ((string)article.Title).Contains(keyword);
    }

    /// <summary>
    /// Creates an expression to filter articles by country and language.
    /// Returns all articles with no associated country that match the specified language,
    /// as well as country-specific articles that match both the provided country code and language code.
    /// </summary>
    /// <param name="countryCode">The country code to filter articles by. Country-specific articles must match this code.</param>
    /// <param name="languageCode">The language code to filter articles by. This is required and applies to both global and country-specific articles.</param>
    /// <returns>An expression that can be used to filter articles in LINQ.</returns>
    private static Expression<Func<Article, bool>> ArticlesFor(string? countryCode, string languageCode)
    {
        return article => article.LanguageCode == languageCode
                          && (article.CountryCode == null || countryCode == null || article.CountryCode == countryCode);
    }

    /// <inheritdoc />
    public async Task<int> Delete(int id, string? languageCode = null)
    {
        return await dbContext.ContentArticles
            .Where(a => a.Id == id && (languageCode == null || a.LanguageCode == languageCode))
            .ExecuteDeleteAsync();
    }

    private async Task UpdateArticleProperties(Article trackedArticle, Article updatedArticle)
    {
        if (updatedArticle.Components.Count > 0)
        {
            trackedArticle.UpdateComponents(updatedArticle.Components);
        }

        trackedArticle.AuthorName = updatedArticle.AuthorName;
        trackedArticle.OriginalArticleUrl = updatedArticle.OriginalArticleUrl;
        trackedArticle.ThumbnailUrl = updatedArticle.ThumbnailUrl;

        Country? newCountry = null;

        if (updatedArticle.Country is not null || updatedArticle.CountryCode is not null)
        {
            var code = updatedArticle.Country?.Code ?? updatedArticle.CountryCode;

            newCountry = await dbContext
                .ContentCountries
                .FindAsync(code);
        }

        trackedArticle.Country = newCountry;

        await SetRelations(trackedArticle, updatedArticle.Categories, updatedArticle.Tags);
    }

    private async Task SetRelations(Article article, ICollection<Category> categories, ICollection<Tag> tags)
    {
        article.Tags.Clear();
        foreach (var tag in tags)
        {
            var existingTag = await dbContext.ContentTags
                .FindAsync(tag.Id, tag.LanguageCode);

            article.Tags.Add(existingTag ?? tag);
        }

        article.Categories.Clear();
        foreach (var newCategory in categories)
        {
            var existingCategory = await dbContext.ContentCategories
                .FindAsync(newCategory.Id, newCategory.LanguageCode);

            article.Categories.Add(existingCategory ?? newCategory);
        }
    }
}
