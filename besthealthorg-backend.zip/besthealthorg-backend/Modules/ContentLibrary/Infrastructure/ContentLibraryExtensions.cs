using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetArticlesInteractor;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetCategoriesInteractor;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.GetTagsInteractor;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interactors.RecommendedArticlesInteractor;
using NwadHealth.Besthealthorg.ContentLibraryModule.ApplicationLogic.Interfaces;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure;

/// <summary>
/// Provides extension methods for configuring BESTHEALTHORG content library module
/// </summary>
public static class ContentLibraryExtensions
{
    /// <summary>
    /// Configures dependency injection to use the provided configuration
    /// </summary>
    /// <typeparam name="TDbContext">The type of the database context</typeparam>
    /// <param name="services">The IServiceCollection to be configured</param>
    /// <param name="configuration">The content library configuration</param>
    /// <returns>The same IServiceCollection the method was called on, with configuration set</returns>
    public static void AddPaceContentLibrary<TDbContext>(this IServiceCollection services, ContentLibraryConfiguration configuration)
        where TDbContext : DbContext, IContentLibraryDbContext
    {
        services.AddSingleton(configuration.RecommendedArticlesSelector);

        services.AddRepositories();
        services.AddInteractors();

        services.AddScoped<IContentLibraryDbContext>(provider => provider.GetRequiredService<TDbContext>());
    }

    private static void AddRepositories(this IServiceCollection services)
    {
        services.AddScoped<ICountryRepository, CountryRepository>();
        services.AddScoped<ILanguageRepository, LanguageRepository>();
        services.AddScoped<ITagRepository, TagRepository>();
        services.AddScoped<ICategoryRepository, CategoryRepository>();
        services.AddScoped<IArticleRepository, ArticleRepository>();
    }

    private static void AddInteractors(this IServiceCollection services)
    {
        services.AddScoped<IGetArticleInteractor, GetArticleInteractor>();
        services.AddScoped<IGetArticlesInteractor, GetArticlesInteractor>();
        services.AddScoped<IGetCategoriesInteractor, GetCategoriesInteractor>();
        services.AddScoped<IGetTagsInteractor, GetTagsInteractor>();
        services.AddScoped<IRecommendedArticlesInteractor, RecommendedArticlesInteractor>();
    }
}
