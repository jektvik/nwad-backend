using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using static NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations.ValueConverters;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures EF for the Language entity
/// </summary>
public class LanguageEntityTypeConfiguration: IEntityTypeConfiguration<Language>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<Language> builder)
    {
        builder
            .ToTable("ContentLanguages")
            .HasKey(language => language.Code);

        builder
            .Property(language => language.Name)
            .HasConversion(NonEmptyStringConverter)
            .HasMaxLength(80)
            .IsRequired();

        builder
            .Property(language => language.Code)
            .HasMaxLength(2)
            .IsRequired();
    }
}
