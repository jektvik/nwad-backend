using NwadHealth.Besthealthorg.Foundation.CustomTypes;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Provides EF core value converters for custom types
/// </summary>
public static class ValueConverters
{
    /// <summary>
    /// Converts a <see cref="NonEmptyString"/> to a <see cref="string"/> and vice versa
    /// </summary>
    public static readonly ValueConverter<NonEmptyString, string> NonEmptyStringConverter =
        new(v => v.ToString(),
            v => new NonEmptyString(v));

    /// <summary>
    /// Converts a <see cref="UrlString"/> to a <see cref="string"/> and vice versa
    /// </summary>
    public static readonly ValueConverter<UrlString, string> UrlStringConverter =
        new(v => v.ToString(),
            v => new UrlString(v));
}
