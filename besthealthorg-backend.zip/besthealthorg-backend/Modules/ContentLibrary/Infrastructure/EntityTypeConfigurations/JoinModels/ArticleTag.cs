namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations.JoinModels;

/// <summary>
/// Join entity representing the many-to-many relationship between articles and tags.
/// </summary>
public class ArticleTag
{
    /// <summary>
    /// The language code of the article.
    /// </summary>
    public string ArticleLanguageCode { get; set; }

    /// <summary>
    /// The ID of the article.
    /// </summary>
    public int ArticleId { get; set; }

    /// <summary>
    /// The language code of the tag.
    /// </summary>
    public string TagLanguageCode { get; set; }

    /// <summary>
    /// The ID of the tag.
    /// </summary>
    public int TagId { get; set; }
}
