namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations.JoinModels;
/// <summary>
/// Join entity representing the many-to-many relationship between articles and categories.
/// </summary>
public class ArticleCategory
{
    /// <summary>
    /// The language code of the article.
    /// </summary>
    public string ArticleLanguageCode { get; set; }

    /// <summary>
    /// The ID of the article.
    /// </summary>
    public int ArticleId { get; set; }

    /// <summary>
    /// The language code of the category.
    /// </summary>
    public string CategoryLanguageCode { get; set; }

    /// <summary>
    /// The ID of the category.
    /// </summary>
    public int CategoryId { get; set; }
}
