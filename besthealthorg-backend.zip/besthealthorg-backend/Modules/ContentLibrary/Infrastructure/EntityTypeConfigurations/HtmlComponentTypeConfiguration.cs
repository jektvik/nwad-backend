using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures EF for the <see cref="HtmlComponent"/>
/// </summary>
public class HtmlComponentTypeConfiguration: IEntityTypeConfiguration<HtmlComponent>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<HtmlComponent> builder)
    {
        builder.Property(ht => ht.Html)
            .HasConversion(ValueConverters.NonEmptyStringConverter);
    }
}
