using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures EF for the <see cref="ImageComponent"/> entity
/// </summary>
public class ImageComponentTypeConfiguration: IEntityTypeConfiguration<ImageComponent>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<ImageComponent> builder)
    {
        builder.Property(it => it.Url)
            .HasMaxLength(255)
            .HasConversion(ValueConverters.UrlStringConverter)
            .IsRequired();
    }
}
