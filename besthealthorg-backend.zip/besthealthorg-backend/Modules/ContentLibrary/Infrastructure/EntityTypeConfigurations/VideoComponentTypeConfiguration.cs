using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures EF for the <see cref="VideoComponent"/> entity
/// </summary>
public class VideoComponentTypeConfiguration: IEntityTypeConfiguration<VideoComponent>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<VideoComponent> builder)
    {
        builder.Property(vt => vt.Url)
            .HasMaxLength(255)
            .HasConversion(ValueConverters.UrlStringConverter)
            .IsRequired();
    }
}
