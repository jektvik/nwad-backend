using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using static NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations.ValueConverters;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures EF for the Tag entity
/// </summary>
public class TagEntityTypeConfiguration: IEntityTypeConfiguration<Tag>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<Tag> builder)
    {
        builder
            .ToTable("ContentTags")
            .HasKey(tag => new { tag.Id, tag.LanguageCode });

        builder.Property(t => t.Name)
            .HasConversion(NonEmptyStringConverter)
            .HasMaxLength(80)
            .IsRequired();

        builder.HasOne<Language>()
            .WithMany()
            .HasForeignKey(t => t.LanguageCode);
    }
}
