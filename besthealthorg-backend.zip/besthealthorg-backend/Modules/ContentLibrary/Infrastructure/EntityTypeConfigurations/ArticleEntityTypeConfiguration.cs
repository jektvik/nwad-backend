using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations.JoinModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using static NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations.ValueConverters;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures EF for the Article entity
/// </summary>
public class ArticleEntityTypeConfiguration: IEntityTypeConfiguration<Article>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<Article> builder)
    {
        builder
            .ToTable("ContentArticles")
            .HasKey(a => new { a.Id, a.LanguageCode });

        builder.Property(a => a.Id).ValueGeneratedNever();

        builder
            .Property(article => article.AuthorName)
            .HasConversion(NonEmptyStringConverter)
            .HasMaxLength(120)
            .IsRequired();

        builder.HasOne(a => a.Language)
            .WithMany(a => a.Articles)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);

        builder
            .Property(article => article.Title)
            .HasConversion(NonEmptyStringConverter)
            .HasMaxLength(255);

        builder
            .Property(article => article.OriginalArticleUrl)
            .HasConversion(UrlStringConverter)
            .HasMaxLength(255);

        builder
            .Property(article => article.ThumbnailUrl)
            .HasConversion(UrlStringConverter)
            .HasMaxLength(255)
            .IsRequired();

        builder
            .Property(article => article.CountryCode)
            .HasMaxLength(2)
            .IsRequired(false);

        builder
            .HasOne(article => article.Country)
            .WithMany(country => country.Articles)
            .HasForeignKey(article => article.CountryCode)
            .IsRequired(false)
            .OnDelete(DeleteBehavior.Restrict);

        builder
            .HasMany(article => article.Tags)
            .WithMany(tag => tag.Articles)
            .UsingEntity<ArticleTag>(
                right => right
                    .HasOne<Tag>()
                    .WithMany()
                    .HasForeignKey(articleTag => new { articleTag.TagId, articleTag.TagLanguageCode })
                    .OnDelete(DeleteBehavior.Restrict),
                left => left
                    .HasOne<Article>()
                    .WithMany()
                    .HasForeignKey(articleTag => new { articleTag.ArticleId, articleTag.ArticleLanguageCode })
                    .OnDelete(DeleteBehavior.Cascade)
                );

        builder
            .HasMany(article => article.Categories)
            .WithMany(category => category.Articles)
            .UsingEntity<ArticleCategory>(
                right => right
                    .HasOne<Category>()
                    .WithMany()
                    .HasForeignKey(articleTag => new { articleTag.CategoryId, articleTag.CategoryLanguageCode })
                    .OnDelete(DeleteBehavior.Restrict),
                left => left
                    .HasOne<Article>()
                    .WithMany()
                    .HasForeignKey(articleTag => new { articleTag.ArticleId, articleTag.ArticleLanguageCode })
                    .OnDelete(DeleteBehavior.Cascade)
            );

        builder.HasMany(article => article.Components)
            .WithOne()
            .HasForeignKey(ct => new { ct.ArticleId, ct.ArticleLanguageCode })
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);
    }
}
