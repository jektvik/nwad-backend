using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using static NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations.ValueConverters;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures EF for the Country entity
/// </summary>
public class CountryEntityTypeConfiguration : IEntityTypeConfiguration<Country>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<Country> builder)
    {
        builder
            .ToTable("ContentCountries")
            .HasKey(country => country.Code);

        builder
            .Property(country => country.Code)
            .HasMaxLength(2)
            .IsRequired();

        builder
            .Property(country => country.Name)
            .HasMaxLength(80)
            .HasConversion(NonEmptyStringConverter)
            .IsRequired();

        builder
            .HasMany(country => country.Languages)
            .WithMany(language => language.Countries);
    }
}
