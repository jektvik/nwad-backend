using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities.ArticleComponents;

/// <summary>
/// Configures EF for the root node <see cref="ArticleComponent"/>
/// </summary>
public class ArticleComponentTypeConfiguration: IEntityTypeConfiguration<ArticleComponent>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<ArticleComponent> builder)
    {
        builder.UseTpcMappingStrategy();
    }
}
