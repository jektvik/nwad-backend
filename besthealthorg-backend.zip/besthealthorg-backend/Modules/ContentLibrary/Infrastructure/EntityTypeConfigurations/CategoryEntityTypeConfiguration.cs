using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using static NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations.ValueConverters;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.EntityTypeConfigurations;

/// <summary>
/// Configures EF for the Category entity
/// </summary>
public class CategoryEntityTypeConfiguration: IEntityTypeConfiguration<Category>
{
    /// <inheritdoc />
    public void Configure(EntityTypeBuilder<Category> builder)
    {
        builder.ToTable("ContentCategories")
            .HasKey(category => new { category.Id, category.LanguageCode });

        builder.Property(category => category.ImageUrl)
            .HasMaxLength(255)
            .HasConversion(UrlStringConverter)
            .IsRequired();

        builder.Property(category => category.Name)
            .HasConversion(NonEmptyStringConverter)
            .HasMaxLength(80)
            .IsRequired();

        builder.HasOne<Language>()
            .WithMany()
            .HasForeignKey(t => t.LanguageCode);
    }
}
