using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure.Extensions;

/// <summary>
/// Extensions for the Category entity
/// </summary>
public static class ArticleEfExtensions
{
    /// <summary>
    /// Include category translations for the given language
    /// </summary>
    /// <param name="query">The query</param>
    /// <param name="languageCode">The language code to get</param>
    public static IIncludableQueryable<Article, IEnumerable<Category>> IncludeCategoriesForLanguage(
        this IQueryable<Article> query,
        string languageCode)
    {
        return query
            .Include(a => a.Categories.Where(c => c.LanguageCode == languageCode));
    }

    /// <summary>
    /// Include translations for a specific language
    /// </summary>
    /// <param name="query">The query</param>
    /// <param name="languageCode">The language code to get</param>
    public static IIncludableQueryable<Article, IEnumerable<Tag>> IncludeTagsForLanguage(
        this IQueryable<Article> query,
        string languageCode)
    {
        return query
            .Include(a => a.Tags.Where(t => t.LanguageCode == languageCode));
    }
}
