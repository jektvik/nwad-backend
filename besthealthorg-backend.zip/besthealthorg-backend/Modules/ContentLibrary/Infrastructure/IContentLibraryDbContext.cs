using System.Reflection;
using NwadHealth.Besthealthorg.ContentLibraryModule.Domain.Entities;
using NwadHealth.Besthealthorg.Foundation.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace NwadHealth.Besthealthorg.ContentLibraryModule.Infrastructure;

/// <summary>
/// Interface for the content library database context
/// </summary>
public interface IContentLibraryDbContext: IDbContext
{
    /// <summary>
    /// The collection of stored articles
    /// </summary>
    public DbSet<Article> ContentArticles { get; set; }

    /// <summary>
    /// The collection of stored tags
    /// </summary>
    public DbSet<Tag> ContentTags { get; set; }

    /// <summary>
    /// The collection of stored filters
    /// </summary>
    public DbSet<Category> ContentCategories { get; set; }

    /// <summary>
    /// The collection of stored languages
    /// </summary>
    public DbSet<Language> ContentLanguages { get; set; }

    /// <summary>
    /// The collection of stored countries
    /// </summary>
    public DbSet<Country> ContentCountries { get; set; }

    /// <summary>
    /// EF core configuration for the database context
    /// </summary>
    /// <param name="modelBuilder">The model builder to use for configuring</param>
    void ConfigureDbSets(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
    }
}
